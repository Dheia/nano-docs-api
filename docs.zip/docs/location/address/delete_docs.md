
لحذف عنوان  
نستخدم الرابط التالى مع تمرير رقم العنوان المراد حذفه 
نوع الطلب delete
localhost:8006/api/v1/location/address/delete/1