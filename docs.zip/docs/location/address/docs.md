localhost:8006/api/v1/location/address/

متغيرات يمكن استخدامها 
isActive النوع boolean  القيمه الافتراضيه true 
isDefault النوع boolean القيمه الافتراضيه false  يتم تمرير هذ المتغير عند طلب العنوان الافتراضي مثلا
q النوعع string  يتم استخدامه لتمرير كلمه البحث  


لطب كافه العناوين التابعه للمستخدم  

localhost:8006/api/v1/location/address/
نوع الطلب get 

القيمه الراجعه

{
  "data": [
    {
      "id": 1,
      "address_1": "اليمن اب 11",
      "address_2": "شارع تعز 1",
      "street_name": null,
      "street_number": null,
      "latitude": 0,
      "longitude": 0,
      "radius": 0,
      "city": null,
      "zip": null,
      "postcode": null,
      "country_long": null,
      "country_id": "2",
      "state_id": "3",
      "directorate_id": null,
      "formataddress": null,
      "vicinity": null,
      "geo_components": null,
      "addressable_type": "RainLab\\User\\Models\\User",
      "addressable_id": 543,
      "user_id": null,
      "user_type": null,
      "is_default": false,
      "is_published": true,
      "is_active": true,
      "created_at": "2022-10-14 22:28:21",
      "updated_at": "2022-10-14 22:29:17",
      "deleted_at": ""
    },
    {
      "id": 2,
      "address_1": "اليمن اب 2",
      "address_2": "شارع تعز 2",
      "street_name": null,
      "street_number": null,
      "latitude": 0,
      "longitude": 0,
      "radius": 0,
      "city": null,
      "zip": null,
      "postcode": null,
      "country_long": null,
      "country_id": "2",
      "state_id": "3",
      "directorate_id": null,
      "formataddress": null,
      "vicinity": null,
      "geo_components": null,
      "addressable_type": "RainLab\\User\\Models\\User",
      "addressable_id": 543,
      "user_id": 543,
      "user_type": "RainLab\\User\\Models\\User",
      "is_default": true,
      "is_published": true,
      "is_active": true,
      "created_at": "2022-10-14 22:19:13",
      "updated_at": "2022-10-14 22:19:13",
      "deleted_at": ""
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}

لاضافه عنوان للمستخدم  
localhost:8006/api/v1/location/address/add
نوع الطلب post 

معا تمرير حقول العنوان  

لتعديل عنوان معين 

localhost:8006/api/v1/location/address/update/1
نوع الطلب put 
معا معاتمرير الحقول المرا المراد تعديلها 
 النتيجه الراجعه كا التالي

{
  "id": 1,
  "address_1": "اليمن اب 11",
  "address_2": "شارع تعز 1",
  "street_name": null,
  "street_number": null,
  "latitude": 0,
  "longitude": 0,
  "radius": 0,
  "city": null,
  "zip": null,
  "postcode": null,
  "country_long": null,
  "country_id": "2",
  "state_id": "3",
  "directorate_id": null,
  "formataddress": null,
  "vicinity": null,
  "geo_components": null,
  "addressable_type": "RainLab\\User\\Models\\User",
  "addressable_id": 543,
  "user_id": null,
  "user_type": null,
  "is_default": false,
  "is_published": true,
  "is_active": true,
  "created_at": "2022-10-14 22:28:21",
  "updated_at": "2022-10-14 22:29:17",
  "deleted_at": ""
}

لحذف عنوان  
نستخدم الرابط التالى مع تمرير رقم العنوان المراد حذفه 
نوع الطلب delete
localhost:8006/api/v1/location/address/delete/1