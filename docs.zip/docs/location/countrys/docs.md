## Countrys  Api

This endpoint allows you to `list`, `show` your countrys.

/location/countrys

### The Countrys object

#### Public Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in orders  records |
| `orderBy`           | `string`  |  using orderBy departments records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy departments records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isEnabled`           | `boolean`  | **Required**. The get is Enabled  Records default value true    |
| `isPinned`           | `boolean`  |  The get is Pinned  Records default value false    |
| `include`           | `string `  | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/location/countrys?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `states`           | `hasMany`  | The get states   | 

### List countrys

Returns a list of Countrys ’

```
GET /api/v1/location/countrys
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Example 1 get List Countrys  

**فى المثال التالى سنقوم بجلب الدول  **
```
GET http://localhost:8006/api/v1/location/countrys
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": "AU",
      "name": "Australia",
      "is_enabled": true,
      "is_pinned": true
    },
    {
      "id": 2,
      "code": "CA",
      "name": "Canada",
      "is_enabled": true,
      "is_pinned": true
    },
    {
      "id": 3,
      "code": "GB",
      "name": "United Kingdom",
      "is_enabled": true,
      "is_pinned": true
    },
    {
      "id": 4,
      "code": "US",
      "name": "United States",
      "is_enabled": true,
      "is_pinned": true
    },
    {
      "id": 78,
      "code": "FR",
      "name": "France",
      "is_enabled": true,
      "is_pinned": false
    },
    {
      "id": 103,
      "code": "HU",
      "name": "Hungary",
      "is_enabled": true,
      "is_pinned": false
    },
    {
      "id": 105,
      "code": "IN",
      "name": "India",
      "is_enabled": true,
      "is_pinned": false
    },
    {
      "id": 109,
      "code": "IE",
      "name": "Ireland",
      "is_enabled": true,
      "is_pinned": false
    },
    {
      "id": 159,
      "code": "NL",
      "name": "Netherlands",
      "is_enabled": true,
      "is_pinned": false
    },
    {
      "id": 161,
      "code": "NZ",
      "name": "New Zealand",
      "is_enabled": true,
      "is_pinned": false
    },
    {
      "id": 184,
      "code": "RO",
      "name": "Romania",
      "is_enabled": true,
      "is_pinned": false
    },
    {
      "id": 210,
      "code": "ES",
      "name": "Spain",
      "is_enabled": true,
      "is_pinned": false
    },
    {
      "id": 249,
      "code": "en",
      "name": "يمن",
      "is_enabled": true,
      "is_pinned": false
    }
  ],
  "meta": {
    "pagination": {
      "total": 13,
      "count": 13,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```


### Show Data Record Country 

```
GET /api/v1/location/countrys/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record Country 2

```
GET http://localhost:8006/api/v1/location/countrys/2
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "id": 2,
  "code": "CA",
  "name": "Canada",
  "is_enabled": true,
  "is_pinned": true
}

```

#### Example 3 Show Data Record Country 2 and States

**فى المثال التالى سنقوم بجلب بيانات الدولة رقم 2 معا بيانات المدن التابعه لهذه الدولة**

```
GET http://localhost:8006/api/v1/location/countrys/2?include=states
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "id": 2,
  "code": "CA",
  "name": "Canada",
  "is_enabled": true,
  "is_pinned": true,
  "states": {
    "data": [
      {
        "id": 87,
        "code": "AB",
        "name": "Alberta",
        "country_id": 2,
        "is_enabled": true
      },
      {
        "id": 88,
        "code": "BC",
        "name": "British Columbia",
        "country_id": 2,
        "is_enabled": true
      },
      {
        "id": 89,
        "code": "MB",
        "name": "Manitoba",
        "country_id": 2,
        "is_enabled": true
      },
      {
        "id": 90,
        "code": "NB",
        "name": "New Brunswick",
        "country_id": 2,
        "is_enabled": true
      },
      {
        "id": 91,
        "code": "NL",
        "name": "Newfoundland and Labrador",
        "country_id": 2,
        "is_enabled": true
      },
      {
        "id": 92,
        "code": "NT",
        "name": "Northwest Territories",
        "country_id": 2,
        "is_enabled": true
      },
      {
        "id": 93,
        "code": "NS",
        "name": "Nova Scotia",
        "country_id": 2,
        "is_enabled": true
      },
      {
        "id": 94,
        "code": "NU",
        "name": "Nunavut",
        "country_id": 2,
        "is_enabled": true
      },
      {
        "id": 95,
        "code": "ON",
        "name": "Ontario",
        "country_id": 2,
        "is_enabled": true
      },
      {
        "id": 96,
        "code": "PE",
        "name": "Prince Edward Island",
        "country_id": 2,
        "is_enabled": true
      }
    ],
    "meta": {
      "pagination": {
        "total": 347,
        "count": 10,
        "per_page": 10,
        "current_page": 1,
        "total_pages": 35,
        "links": {
          "next": "http:\/\/localhost:8006\/api\/v1\/location\/countrys\/2?page=2"
        }
      }
    }
  }
}
```


**يمكننا ايضا جلب بيانات كافة الدول معا بيانات المدن التابعه لكل دولة بتضمين العلاقة states كما فى المثال السابق **

### Check Last Update Country Data 

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/location/countrys/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/location/countrys/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": {
      "activity_cache.country": "2022-12-20 18:15:32",
      "activity_cache.state": "2022-12-20 18:15:32",
      "activity_cache.directorate": "2022-12-20 18:15:32"
    }
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2022-12-20 18:17:04",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": {
      "activity_cache.country": "2022-12-20 18:15:32",
      "activity_cache.state": "2022-12-20 18:15:32",
      "activity_cache.directorate": "2022-12-20 18:15:32"
    }
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **



