## States  Api

This endpoint allows you to `list`, `show` your states.

/location/states

### The States object

#### Public Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in orders  records |
| `orderBy`           | `string`  |  using orderBy departments records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy departments records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isEnabled`           | `boolean`  | **Required**. The get is Enabled  Records default value true    |
| `country_id`           | `string`  |  The get states Records in country_id default value false    |
| `include`           | `string `  | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/location/states?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `country`           | `belongsTo`  | The get country |
| `directorates`           | `hasMany`  | The get directorates   | 

### List states

Returns a list of States 

```
GET /api/v1/location/states
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Example 1 get List States  

**فى المثال التالى سنقوم بجلب بيانات المدن   **

```
GET http://localhost:8006/api/v1/location/states
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 99,
      "code": "YT",
      "name": "Yukon",
      "country_id": 2,
      "is_enabled": true
    },
    {
      "id": 98,
      "code": "SK",
      "name": "Saskatchewan",
      "country_id": 2,
      "is_enabled": true
    },
    {
      "id": 97,
      "code": "QC",
      "name": "Quebec",
      "country_id": 2,
      "is_enabled": true
    },
    {
      "id": 96,
      "code": "PE",
      "name": "Prince Edward Island",
      "country_id": 2,
      "is_enabled": true
    },
    {
      "id": 95,
      "code": "ON",
      "name": "Ontario",
      "country_id": 2,
      "is_enabled": true
    },
    {
      "id": 94,
      "code": "NU",
      "name": "Nunavut",
      "country_id": 2,
      "is_enabled": true
    },
    {
      "id": 93,
      "code": "NS",
      "name": "Nova Scotia",
      "country_id": 2,
      "is_enabled": true
    },
    {
      "id": 92,
      "code": "NT",
      "name": "Northwest Territories",
      "country_id": 2,
      "is_enabled": true
    },
    {
      "id": 91,
      "code": "NL",
      "name": "Newfoundland and Labrador",
      "country_id": 2,
      "is_enabled": true
    },
    {
      "id": 90,
      "code": "NB",
      "name": "New Brunswick",
      "country_id": 2,
      "is_enabled": true
    },
    {
      "id": 89,
      "code": "MB",
      "name": "Manitoba",
      "country_id": 2,
      "is_enabled": true
    },
    {
      "id": 88,
      "code": "BC",
      "name": "British Columbia",
      "country_id": 2,
      "is_enabled": true
    },
    {
      "id": 87,
      "code": "AB",
      "name": "Alberta",
      "country_id": 2,
      "is_enabled": true
    },
    {
      "id": 1066,
      "code": "711",
      "name": "711",
      "country_id": 2,
      "is_enabled": true
    },
    {
      "id": 1065,
      "code": "3206",
      "name": "3206",
      "country_id": 2,
      "is_enabled": true
    }
  ],
  "meta": {
    "pagination": {
      "total": 347,
      "count": 15,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 24,
      "links": {
        "next": "http:\/\/localhost:8006\/api\/v1\/location\/states?page=2"
      }
    }
  }
}
```

**
يمكن ايضا تمرير العلاقه 
country ضمن المتغير include لجلب اسم الدوله امام كل مدينه 
**

```
GET http://localhost:8006/api/v1/location/states?include=country
```

```json
{
  "data": [
    {
      "id": 99,
      "code": "YT",
      "name": "Yukon",
      "country_id": 2,
      "is_enabled": true,
      "country": {
        "id": 2,
        "code": "CA",
        "name": "Canada",
        "is_enabled": true,
        "is_pinned": true
      }
    },
    {
      "id": 98,
      "code": "SK",
      "name": "Saskatchewan",
      "country_id": 2,
      "is_enabled": true,
      "country": {
        "id": 2,
        "code": "CA",
        "name": "Canada",
        "is_enabled": true,
        "is_pinned": true
      }
    },
    {
      "id": 97,
      "code": "QC",
      "name": "Quebec",
      "country_id": 2,
      "is_enabled": true,
      "country": {
        "id": 2,
        "code": "CA",
        "name": "Canada",
        "is_enabled": true,
        "is_pinned": true
      }
    },
    {
      "id": 96,
      "code": "PE",
      "name": "Prince Edward Island",
      "country_id": 2,
      "is_enabled": true,
      "country": {
        "id": 2,
        "code": "CA",
        "name": "Canada",
        "is_enabled": true,
        "is_pinned": true
      }
    },
    {
      "id": 95,
      "code": "ON",
      "name": "Ontario",
      "country_id": 2,
      "is_enabled": true,
      "country": {
        "id": 2,
        "code": "CA",
        "name": "Canada",
        "is_enabled": true,
        "is_pinned": true
      }
    },
    {
      "id": 94,
      "code": "NU",
      "name": "Nunavut",
      "country_id": 2,
      "is_enabled": true,
      "country": {
        "id": 2,
        "code": "CA",
        "name": "Canada",
        "is_enabled": true,
        "is_pinned": true
      }
    },
    {
      "id": 93,
      "code": "NS",
      "name": "Nova Scotia",
      "country_id": 2,
      "is_enabled": true,
      "country": {
        "id": 2,
        "code": "CA",
        "name": "Canada",
        "is_enabled": true,
        "is_pinned": true
      }
    },
    {
      "id": 92,
      "code": "NT",
      "name": "Northwest Territories",
      "country_id": 2,
      "is_enabled": true,
      "country": {
        "id": 2,
        "code": "CA",
        "name": "Canada",
        "is_enabled": true,
        "is_pinned": true
      }
    },
    {
      "id": 91,
      "code": "NL",
      "name": "Newfoundland and Labrador",
      "country_id": 2,
      "is_enabled": true,
      "country": {
        "id": 2,
        "code": "CA",
        "name": "Canada",
        "is_enabled": true,
        "is_pinned": true
      }
    },
    {
      "id": 90,
      "code": "NB",
      "name": "New Brunswick",
      "country_id": 2,
      "is_enabled": true,
      "country": {
        "id": 2,
        "code": "CA",
        "name": "Canada",
        "is_enabled": true,
        "is_pinned": true
      }
    },
    {
      "id": 89,
      "code": "MB",
      "name": "Manitoba",
      "country_id": 2,
      "is_enabled": true,
      "country": {
        "id": 2,
        "code": "CA",
        "name": "Canada",
        "is_enabled": true,
        "is_pinned": true
      }
    },
    {
      "id": 88,
      "code": "BC",
      "name": "British Columbia",
      "country_id": 2,
      "is_enabled": true,
      "country": {
        "id": 2,
        "code": "CA",
        "name": "Canada",
        "is_enabled": true,
        "is_pinned": true
      }
    },
    {
      "id": 87,
      "code": "AB",
      "name": "Alberta",
      "country_id": 2,
      "is_enabled": true,
      "country": {
        "id": 2,
        "code": "CA",
        "name": "Canada",
        "is_enabled": true,
        "is_pinned": true
      }
    },
    {
      "id": 1066,
      "code": "711",
      "name": "711",
      "country_id": 2,
      "is_enabled": true,
      "country": {
        "id": 2,
        "code": "CA",
        "name": "Canada",
        "is_enabled": true,
        "is_pinned": true
      }
    },
    {
      "id": 1065,
      "code": "3206",
      "name": "3206",
      "country_id": 2,
      "is_enabled": true,
      "country": {
        "id": 2,
        "code": "CA",
        "name": "Canada",
        "is_enabled": true,
        "is_pinned": true
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 347,
      "count": 15,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 24,
      "links": {
        "next": "http:\/\/localhost:8006\/api\/v1\/location\/states?page=2"
      }
    }
  }
}

```


### Show Data Record State 

```
GET /api/v1/location/states/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record State 99

```
GET http://localhost:8006/api/v1/location/states/99
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "id": 99,
  "code": "YT",
  "name": "Yukon",
  "country_id": 2,
  "is_enabled": true,
}
```

#### Example 3 Show Data Record State 2 and Directorates

**فى المثال التالى سنقوم بجلب بيانات المدينة رقم 87 مع بيانات المديريات التابعه لها **

```
GET http://localhost:8006/api/v1/location/states/87?include=directorates
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "id": 87,
  "code": "AB",
  "name": "Alberta",
  "country_id": 2,
  "is_enabled": true,
  "directorates": {
    "data": [
      {
        "id": 1,
        "code": "mdyryh-tgrbh",
        "name": "مديريه تجربه",
        "country_id": 2,
        "state_id": 87,
        "is_enabled": true
      },
      {
        "id": 45,
        "code": "tgrbh-al-id",
        "name": "تجربه ال id",
        "country_id": 2,
        "state_id": 87,
        "is_enabled": true
      }
    ],
    "meta": {
      "pagination": {
        "total": 2,
        "count": 2,
        "per_page": 10,
        "current_page": 1,
        "total_pages": 1,
        "links": []
      }
    }
  }
}
```


**يمكننا ايضا جلب بيانات كافة المدن معا بيانات المديريات التابعه لكل مدينة بتضمين العلاقة states كما فى المثال السابق **

### Check Last Update State Data 

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/location/states/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/location/states/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": {
      "activity_cache.state": "2022-12-20 18:15:32",
      "activity_cache.country": "2022-12-20 18:15:32",
      "activity_cache.directorate": "2022-12-20 18:15:32"
    }
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2022-12-20 18:35:07",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": {
      "activity_cache.state": "2022-12-20 18:15:32",
      "activity_cache.country": "2022-12-20 18:15:32",
      "activity_cache.directorate": "2022-12-20 18:15:32"
    }
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **



