## Messages Language

This endpoint allows you to `list`, `show` your messages.

/translate/messages

**الجزء الخاص بجلب نصوص الترجمه من خلال هذا الجزء يمكنك جل ملف الترجمه او جلب ترجمه متغير معين او جلب كافة ملفات الترجمه **

### The Accept-Language 

**يمكن تهية اللغة فى النظام من خلال  تمرير كود اللغه فى راس الطلب ضمن المتغير  Accept-Language**

Header Parameters
```json
{
  "Accept-Language":"ar"
}
```

**عند تمرير المتغير السابق فى راس الطلب فان النظام سيقوم بجلب اي بيانات بالاعتماد على اللغه الممرره فمثلا لوقمن بتمرير كود اللغه العربيه سيتم ارجاع البيانات باللغه العربيه وهكذا**


### The messages object

#### Public Parameters
| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in messages records |
| `orderBy`           | `string`  |  using orderBy messages records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy messages records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/translate/messages?exclude=created_at,updated_at
```


### List messages

Returns a list of messages.

```
GET /api/v1/translate/messages
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": "daynamic.title.title.features",
      "message_data": {
        "x": "daynamic.title.title_features"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 2,
      "code": "nano.btn.more",
      "message_data": {
        "x": "nano.btn.more"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 3,
      "code": "daynamic.title.categories.blog.categories",
      "message_data": {
        "x": "daynamic.title_categories.blog_categories"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 4,
      "code": "daynamic.title.categories.tags",
      "message_data": {
        "x": "daynamic.title_categories.tags"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 5,
      "code": "nano.all.albumlist",
      "message_data": {
        "x": "nano.all.albumList",
        "ar": "البومات الصور",
        "en": "البومات الصور"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 6,
      "code": "nano.all.videolist",
      "message_data": {
        "x": "nano.all.videoList"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 7,
      "code": "daynamic.title.categories.title.tags",
      "message_data": {
        "x": "daynamic.title_categories.title_tags"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 8,
      "code": "daynamic.msg.no.data.لاتوجد.بيانات.لعرضها",
      "message_data": {
        "x": "daynamic.msg_no_data.لاتوجد بيانات لعرضها"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 9,
      "code": "daynamic.title.categories.title.links",
      "message_data": {
        "x": "daynamic.title_categories.title_links"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 10,
      "code": "read.more",
      "message_data": {
        "x": "Read More.."
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 11,
      "code": "daynamic.title.title.all.photos",
      "message_data": {
        "x": "daynamic.title.title_all_photos"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 12,
      "code": "daynamic.title.last.news",
      "message_data": {
        "x": "daynamic.title.last_news"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 13,
      "code": "nano.search.placeholder",
      "message_data": {
        "x": "nano.search.placeholder",
        "ar": "اكتب نص البحث هنا",
        "en": "search"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 14,
      "code": "nano.hero.title",
      "message_data": {
        "x": "nano.hero.title"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 15,
      "code": "nano.hero.description",
      "message_data": {
        "x": "nano.hero.description"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    }
  ],
  "meta": {
    "pagination": {
      "total": 65,
      "count": 15,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 5,
      "links": {
        "next": "https:\/\/alnaeem.nano2soft.com\/api\/v1\/translate\/messages?page=2"
      }
    }
  }
}
```

### Example 1 get List Messages 

GET http://localhost:8006/api/v1/translate/messages

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": "daynamic.title.title.features",
      "message_data": {
        "x": "daynamic.title.title_features"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 2,
      "code": "nano.btn.more",
      "message_data": {
        "x": "nano.btn.more"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 3,
      "code": "daynamic.title.categories.blog.categories",
      "message_data": {
        "x": "daynamic.title_categories.blog_categories"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 4,
      "code": "daynamic.title.categories.tags",
      "message_data": {
        "x": "daynamic.title_categories.tags"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 5,
      "code": "nano.all.albumlist",
      "message_data": {
        "x": "nano.all.albumList",
        "ar": "البومات الصور",
        "en": "البومات الصور"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 6,
      "code": "nano.all.videolist",
      "message_data": {
        "x": "nano.all.videoList"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 7,
      "code": "daynamic.title.categories.title.tags",
      "message_data": {
        "x": "daynamic.title_categories.title_tags"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 8,
      "code": "daynamic.msg.no.data.لاتوجد.بيانات.لعرضها",
      "message_data": {
        "x": "daynamic.msg_no_data.لاتوجد بيانات لعرضها"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 9,
      "code": "daynamic.title.categories.title.links",
      "message_data": {
        "x": "daynamic.title_categories.title_links"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 10,
      "code": "read.more",
      "message_data": {
        "x": "Read More.."
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 11,
      "code": "daynamic.title.title.all.photos",
      "message_data": {
        "x": "daynamic.title.title_all_photos"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 12,
      "code": "daynamic.title.last.news",
      "message_data": {
        "x": "daynamic.title.last_news"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 13,
      "code": "nano.search.placeholder",
      "message_data": {
        "x": "nano.search.placeholder",
        "ar": "اكتب نص البحث هنا",
        "en": "search"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 14,
      "code": "nano.hero.title",
      "message_data": {
        "x": "nano.hero.title"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    },
    {
      "id": 15,
      "code": "nano.hero.description",
      "message_data": {
        "x": "nano.hero.description"
      },
      "found": 1,
      "object_type": "RainLab\\Translate\\Models\\Message"
    }
  ],
  "meta": {
    "pagination": {
      "total": 65,
      "count": 15,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 5,
      "links": {
        "next": "https:\/\/alnaeem.nano2soft.com\/api\/v1\/translate\/messages?page=2"
      }
    }
  }
}
```

### Show Data Record Messages 

```
GET /api/v1/translate/messages/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record Messages 5

```
GET http://localhost:8006/api/v1/translate/messages/5
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "id": 5,
  "code": "nano.all.albumlist",
  "message_data": {
    "x": "nano.all.albumList",
    "ar": "البومات الصور",
    "en": "البومات الصور"
  },
  "found": 1,
  "object_type": "RainLab\\Translate\\Models\\Message"
}
```

### get Translate with code  

**لجلب نص الترجمه لكود معين نقوم بتمرير كود اللغه وكود الرساله المراد ترجمتها من خلال الرابط التالي  **

```
GET /api/v1/translate/messages/trans
```

Required Parameters: `messageId`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `messageId`           | `string`  | **Required**. The message Id          |
| `locale`           | `string`  | The locale code          |
| `params`           | `array`  | The params           |

**فى حله عدم تمرير اللغه المراد الترجمه لها سيتم الاعتماد على اللغه الافتراضيه او اللغه الممرره فى راس الطلب **

#### Example 2 Data Translate messageId Loacle=ar

```
GET http://localhost:8006/api/v1/translate/messages/trans?messageId=%27nano.all.albumlist%27&locale=ar
```

**البراميترات الممرره **
```json
{
  "messageId": "nano.all.albumlist",
  "locale": "ar"
}
```
##### Response

```html
Status: 200 Ok
```

```json
{
  "data": "البومات الصور"
}
```

#### Example 3 Data Translate messageId Loacle=en


**عند تمرير المتغيرات التاليه ستكون النتيجه كالتالي  **
```json
{
  "messageId": "nano.all.albumlist",
  "locale": "en"
}
```

##### Response
```
GET http://localhost:8006/api/v1/translate/messages/trans?messageId=%27nano.all.albumlist%27&locale=en
```

```html
Status: 200 Ok
```
```json
{
  "data": "Album Photos"
}
```

### Export All Data Translate Messages on Locale 

**لجلب كافه نصوص الترجمه للغه معينه نستخدم الرابط التالي **

```
GET /api/v1/translate/messages/export/locales
```

Required Parameters: `locale`

**البراميترات الممرره **

```json
{
  "locale": "ar"
}
```

**فيحاله عدم تمرير قيمه المتغير locale سيتم ارجاع بيانات اللغه الافتراضيه او الممرره فى راس الطلب ان وجدات **

#### Example 4 Export All Data Translate locale=ar

**بالمثال التالي سنقوم بجلب نصوص الترجمه التابعه للغه العربيه **
```
GET http://localhost:8006/api/v1/translate/messages/export/locales?locale=ar
```

##### Response

**البراميترات الممرره **

```json
{
  "locale": "ar"
}
```

```html
Status: 200 Ok
```

```json
{
  "locale": "ar",
  "data": [
    {
      "code": "daynamic.title.title.features",
      "value": "المميزات",
      "default": "daynamic.title.title_features"
    },
    {
      "code": "nano.btn.more",
      "value": "اكثر",
      "default": "nano.btn.more"
    },
    {
      "code": "daynamic.title.categories.blog.categories",
      "value": "التصنيفات",
      "default": "daynamic.title_categories.blog_categories"
    },
    {
      "code": "daynamic.title.categories.tags",
      "value": "هاشتجات",
      "default": "daynamic.title_categories.tags"
    },
    {
      "code": "nano.all.albumlist",
      "value": "البومات الصور",
      "default": "nano.all.albumList"
    },
    {
      "code": "nano.all.videolist",
      "value": "الفيديوهات",
      "default": "nano.all.videoList"
    },
    {
      "code": "daynamic.title.categories.title.tags",
      "value": "الهاشتجات",
      "default": "daynamic.title_categories.title_tags"
    },
    {
      "code": "daynamic.msg.no.data.لاتوجد.بيانات.لعرضها",
      "value": "لايوجد بيانات",
      "default": "daynamic.msg_no_data.لاتوجد بيانات لعرضها"
    },
    {
      "code": "daynamic.title.categories.title.links",
      "value": "روابط ذات صله",
      "default": "daynamic.title_categories.title_links"
    },
    {
      "code": "read.more",
      "value": "اكثر",
      "default": "Read More.."
    },
    {
      "code": "daynamic.title.title.all.photos",
      "value": "كافة الصور",
      "default": "daynamic.title.title_all_photos"
    },
    {
      "code": "daynamic.title.last.news",
      "value": "اخر الاخبار",
      "default": "daynamic.title.last_news"
    },
    {
      "code": "nano.search.placeholder",
      "value": "اكتب نص البحث هنا",
      "default": "nano.search.placeholder"
    },
    {
      "code": "nano.hero.title",
      "value": "العنوان",
      "default": "nano.hero.title"
    },
    {
      "code": "nano.hero.description",
      "value": "الوصف",
      "default": "nano.hero.description"
    },
    {
      "code": "nano.footer.menu",
      "value": "القائمه",
      "default": "nano.footer.menu"
    },
    {
      "code": "nano.footer.contact",
      "value": "يمكنكم التواصل معنا عن طريق :",
      "default": "nano.footer.contact"
    },
    {
      "code": "nano.footer.addres",
      "value": " العنوان",
      "default": "nano.footer.addres"
    },
    {
      "code": "nano.footer.social",
      "value": "كما يمكنكم زيارتنا على مواقع التواصل التالية",
      "default": "nano.footer.social"
    },
    {
      "code": "nano.author.crafted.with",
      "value": "تطوير",
      "default": "nano.author.crafted_with"
    },
    {
      "code": "nano.footer.phone",
      "value": " الهاتف",
      "default": "nano.footer.phone"
    },
    {
      "code": "nano.footer.email",
      "value": " البريد",
      "default": "nano.footer.email"
    },
    {
      "code": "nano.footer.website",
      "value": "الموقع الالكتروني",
      "default": "nano.footer.website"
    },
    {
      "code": "nano.site.name",
      "value": "نانو سوفت لتطبيقات الويب",
      "default": "nano.site.name"
    },
    {
      "code": "nano.nav.home",
      "value": "الرئيسية",
      "default": "nano.nav.home"
    },
    {
      "code": "nano.search.no.results",
      "value": "لاتوجد نتائج بحث مطابقه",
      "default": "nano.search.no_results"
    },
    {
      "code": "nano.account.on.access",
      "value": "لاتمتلك صلاحيات للوصول لهذه الصفحه",
      "default": "nano.account.on_access"
    },
    {
      "code": "nano.account.plass.sign.in",
      "value": "يرجا تسجيل الدخول اولاً من خلال الرابط التالي",
      "default": "nano.account.plass_sign_in"
    },
    {
      "code": "nano.account.nav.update",
      "value": "البيانات الشخصية",
      "default": "nano.account.nav_update"
    },
    {
      "code": "nano.account.nav.aqers",
      "value": "عقاراتي",
      "default": "nano.account.nav_aqers"
    },
    {
      "code": "nano.account.sign.in",
      "value": "دخول",
      "default": "nano.account.sign_in"
    },
    {
      "code": "nano.account.sign.up",
      "value": "تسجيل",
      "default": "nano.account.sign_up"
    },
    {
      "code": "nano.account.logout",
      "value": "خروج",
      "default": "nano.account.Logout"
    },
    {
      "code": "nano.account.forgot.password",
      "value": "هل نسيت كلمة السر ؟",
      "default": "nano.account.forgot_password"
    },
    {
      "code": "nano.account.signin.label",
      "value": "تسجيل الدخول",
      "default": "nano.account.signin_label"
    },
    {
      "code": "nano.account.signin.form.name",
      "value": "الاسم",
      "default": "nano.account.signin_form.Name"
    },
    {
      "code": "nano.account.signin.form.placeholder.name",
      "value": "ادخل اسم المستخدم",
      "default": "nano.account.signin_form.placeholder_Name"
    },
    {
      "code": "nano.account.signin.form.email",
      "value": "البريد الالكتروني",
      "default": "nano.account.signin_form.Email"
    },
    {
      "code": "nano.account.signin.form.placeholder.email",
      "value": "ادخل البريد الالكتروني",
      "default": "nano.account.signin_form.placeholder_Email"
    },
    {
      "code": "nano.account.signin.form.password",
      "value": "كلمةالسر",
      "default": "nano.account.signin_form.password"
    },
    {
      "code": "nano.account.signin.form.placeholder.password",
      "value": "اكتب كلمة السر هنا",
      "default": "nano.account.signin_form.placeholder_password"
    },
    {
      "code": "nano.account.signin.form.button.sign.in",
      "value": "تسجيل الدخول",
      "default": "nano.account.signin_form.button_sign_in"
    },
    {
      "code": "nano.account.register.label",
      "value": "التسجيل",
      "default": "nano.account.register_label"
    },
    {
      "code": "nano.account.register.form.full.name",
      "value": "الاسم",
      "default": "nano.account.register_form.full_name"
    },
    {
      "code": "nano.account.register.form.placeholder.full.name",
      "value": "اكتب الاسم هنا",
      "default": "nano.account.register_form.placeholder_full_name"
    },
    {
      "code": "nano.account.register.form.username",
      "value": "اسم الدخول",
      "default": "nano.account.register_form.username"
    },
    {
      "code": "nano.account.register.form.placeholder.username",
      "value": "اكتب اسم الدخول انجليزي هنا",
      "default": "nano.account.register_form.placeholder_username"
    },
    {
      "code": "nano.account.register.form.password",
      "value": "كلمة السر ",
      "default": "nano.account.register_form.password"
    },
    {
      "code": "nano.account.register.form.placeholder.password",
      "value": "اكتب كلمة السر هنا",
      "default": "nano.account.register_form.placeholder_password"
    },
    {
      "code": "nano.account.register.form.button.register",
      "value": "تسجيل ",
      "default": "nano.account.register_form.button_register"
    },
    {
      "code": "nano.footer.main.menu",
      "value": "القائمة الرئيسية",
      "default": "nano.footer.main_menu"
    },
    {
      "code": "nano.footer.share.social",
      "value": "شارك الموقع ",
      "default": "nano.footer.share_social"
    },
    {
      "code": "nano.aqer.categories.aqer",
      "value": "التصنيفات الرئيسية",
      "default": "nano.aqer.categories_aqer"
    },
    {
      "code": "nano.aqer.type.options.advert",
      "value": "عقار",
      "default": "nano.aqer.type_options.advert"
    },
    {
      "code": "nano.aqer.type.options.order",
      "value": "مطلوب",
      "default": "nano.aqer.type_options.order"
    },
    {
      "code": "nano.aqer.type.is.parleying.1",
      "value": "السعر قابل لتفاوض",
      "default": "nano.aqer.type_is_parleying.1"
    },
    {
      "code": "nano.aqer.type.is.parleying.0",
      "value": "السعر غير قابل لتفاوض",
      "default": "nano.aqer.type_is_parleying.0"
    },
    {
      "code": "nano.work.categories.work",
      "value": "تصنيفات الاعمال",
      "default": "nano.work.categories_work"
    },
    {
      "code": "nano.all.photos",
      "value": "صور",
      "default": "nano.all.photos"
    },
    {
      "code": "عن.نانو.سوفت.للانظمة.الخدمية.وتطبيقات.الويب",
      "value": "",
      "default": "عن نانو سوفت للانظمة الخدمية وتطبيقات الويب"
    },
    {
      "code": "go.to.backend",
      "value": "ذهاب الى لوحة التحكم",
      "default": "Go TO Backend"
    },
    {
      "code": "nano.soft.web.systems",
      "value": "Nano Soft Web Systems",
      "default": "Nano Soft Web Systems"
    },
    {
      "code": "abuot",
      "value": "عنا",
      "default": "Abuot"
    },
    {
      "code": "backend",
      "value": "لوحة التحكم",
      "default": "Backend"
    },
    {
      "code": "nanosoft",
      "value": "نانوسوفت",
      "default": "NanoSoft"
    }
  ]
}
```

#### Example 5 Export All Data Translate locale=en

**بالمثال التالي سنقوم بجلب نصوص الترجمه التابعه للغه الافتراضيه بدون تمرير معرف اللغه  **
```
GET http://localhost:8006/api/v1/translate/messages/export/locales
```

##### Response

**من خلال النتيجه فى الاسفل نلاحظ انه تم تضمين اللغه الافتراضيه تلقائين **

```html
Status: 200 Ok
```

```json
{
  "locale": "en",
  "data": [
    {
      "code": "daynamic.title.title.features",
      "value": "Features",
      "default": "daynamic.title.title_features"
    },
    {
      "code": "nano.btn.more",
      "value": "More",
      "default": "nano.btn.more"
    },
    {
      "code": "daynamic.title.categories.blog.categories",
      "value": "Categories",
      "default": "daynamic.title_categories.blog_categories"
    },
    {
      "code": "daynamic.title.categories.tags",
      "value": "Tags",
      "default": "daynamic.title_categories.tags"
    },
    {
      "code": "nano.all.albumlist",
      "value": "Album Photos",
      "default": "nano.all.albumList"
    },
    {
      "code": "nano.all.videolist",
      "value": "Videos",
      "default": "nano.all.videoList"
    },
    {
      "code": "daynamic.title.categories.title.tags",
      "value": "Tags",
      "default": "daynamic.title_categories.title_tags"
    },
    {
      "code": "daynamic.msg.no.data.لاتوجد.بيانات.لعرضها",
      "value": "No Data",
      "default": "daynamic.msg_no_data.لاتوجد بيانات لعرضها"
    },
    {
      "code": "daynamic.title.categories.title.links",
      "value": "Links",
      "default": "daynamic.title_categories.title_links"
    },
    {
      "code": "read.more",
      "value": "Read More",
      "default": "Read More.."
    },
    {
      "code": "daynamic.title.title.all.photos",
      "value": "All photos",
      "default": "daynamic.title.title_all_photos"
    },
    {
      "code": "daynamic.title.last.news",
      "value": "Last News",
      "default": "daynamic.title.last_news"
    },
    {
      "code": "nano.search.placeholder",
      "value": "search",
      "default": "nano.search.placeholder"
    },
    {
      "code": "nano.hero.title",
      "value": "Titel",
      "default": "nano.hero.title"
    },
    {
      "code": "nano.hero.description",
      "value": "Description",
      "default": "nano.hero.description"
    },
    {
      "code": "nano.footer.menu",
      "value": "Menu",
      "default": "nano.footer.menu"
    },
    {
      "code": "nano.footer.contact",
      "value": "يمكنكم التواصل معنا عن طريق :",
      "default": "nano.footer.contact"
    },
    {
      "code": "nano.footer.addres",
      "value": " العنوان",
      "default": "nano.footer.addres"
    },
    {
      "code": "nano.footer.social",
      "value": "كما يمكنكم زيارتنا على مواقع التواصل التالية",
      "default": "nano.footer.social"
    },
    {
      "code": "nano.author.crafted.with",
      "value": "Crafted with",
      "default": "nano.author.crafted_with"
    },
    {
      "code": "nano.footer.phone",
      "value": " الهاتف",
      "default": "nano.footer.phone"
    },
    {
      "code": "nano.footer.email",
      "value": " البريد",
      "default": "nano.footer.email"
    },
    {
      "code": "nano.footer.website",
      "value": "Website",
      "default": "nano.footer.website"
    },
    {
      "code": "nano.site.name",
      "value": "NanoSoft FOr web",
      "default": "nano.site.name"
    },
    {
      "code": "nano.nav.home",
      "value": "Home",
      "default": "nano.nav.home"
    },
    {
      "code": "nano.search.no.results",
      "value": "لاتوجد نتائج بحث مطابقه",
      "default": "nano.search.no_results"
    },
    {
      "code": "nano.account.on.access",
      "value": "لاتمتلك صلاحيات للوصول لهذه الصفحه",
      "default": "nano.account.on_access"
    },
    {
      "code": "nano.account.plass.sign.in",
      "value": "يرجا تسجيل الدخول اولاً من خلال الرابط التالي",
      "default": "nano.account.plass_sign_in"
    },
    {
      "code": "nano.account.nav.update",
      "value": "البيانات الشخصية",
      "default": "nano.account.nav_update"
    },
    {
      "code": "nano.account.nav.aqers",
      "value": "عقاراتي",
      "default": "nano.account.nav_aqers"
    },
    {
      "code": "nano.account.sign.in",
      "value": "دخول",
      "default": "nano.account.sign_in"
    },
    {
      "code": "nano.account.sign.up",
      "value": "تسجيل",
      "default": "nano.account.sign_up"
    },
    {
      "code": "nano.account.logout",
      "value": "خروج",
      "default": "nano.account.Logout"
    },
    {
      "code": "nano.account.forgot.password",
      "value": "هل نسيت كلمة السر ؟",
      "default": "nano.account.forgot_password"
    },
    {
      "code": "nano.account.signin.label",
      "value": "تسجيل الدخول",
      "default": "nano.account.signin_label"
    },
    {
      "code": "nano.account.signin.form.name",
      "value": "الاسم",
      "default": "nano.account.signin_form.Name"
    },
    {
      "code": "nano.account.signin.form.placeholder.name",
      "value": "ادخل اسم المستخدم",
      "default": "nano.account.signin_form.placeholder_Name"
    },
    {
      "code": "nano.account.signin.form.email",
      "value": "البريد الالكتروني",
      "default": "nano.account.signin_form.Email"
    },
    {
      "code": "nano.account.signin.form.placeholder.email",
      "value": "ادخل البريد الالكتروني",
      "default": "nano.account.signin_form.placeholder_Email"
    },
    {
      "code": "nano.account.signin.form.password",
      "value": "كلمةالسر",
      "default": "nano.account.signin_form.password"
    },
    {
      "code": "nano.account.signin.form.placeholder.password",
      "value": "اكتب كلمة السر هنا",
      "default": "nano.account.signin_form.placeholder_password"
    },
    {
      "code": "nano.account.signin.form.button.sign.in",
      "value": "تسجيل الدخول",
      "default": "nano.account.signin_form.button_sign_in"
    },
    {
      "code": "nano.account.register.label",
      "value": "التسجيل",
      "default": "nano.account.register_label"
    },
    {
      "code": "nano.account.register.form.full.name",
      "value": "الاسم",
      "default": "nano.account.register_form.full_name"
    },
    {
      "code": "nano.account.register.form.placeholder.full.name",
      "value": "اكتب الاسم هنا",
      "default": "nano.account.register_form.placeholder_full_name"
    },
    {
      "code": "nano.account.register.form.username",
      "value": "اسم الدخول",
      "default": "nano.account.register_form.username"
    },
    {
      "code": "nano.account.register.form.placeholder.username",
      "value": "اكتب اسم الدخول انجليزي هنا",
      "default": "nano.account.register_form.placeholder_username"
    },
    {
      "code": "nano.account.register.form.password",
      "value": "كلمة السر ",
      "default": "nano.account.register_form.password"
    },
    {
      "code": "nano.account.register.form.placeholder.password",
      "value": "اكتب كلمة السر هنا",
      "default": "nano.account.register_form.placeholder_password"
    },
    {
      "code": "nano.account.register.form.button.register",
      "value": "تسجيل ",
      "default": "nano.account.register_form.button_register"
    },
    {
      "code": "nano.footer.main.menu",
      "value": "القائمة الرئيسية",
      "default": "nano.footer.main_menu"
    },
    {
      "code": "nano.footer.share.social",
      "value": "شارك الموقع ",
      "default": "nano.footer.share_social"
    },
    {
      "code": "nano.aqer.categories.aqer",
      "value": "التصنيفات الرئيسية",
      "default": "nano.aqer.categories_aqer"
    },
    {
      "code": "nano.aqer.type.options.advert",
      "value": "عقار",
      "default": "nano.aqer.type_options.advert"
    },
    {
      "code": "nano.aqer.type.options.order",
      "value": "مطلوب",
      "default": "nano.aqer.type_options.order"
    },
    {
      "code": "nano.aqer.type.is.parleying.1",
      "value": "السعر قابل لتفاوض",
      "default": "nano.aqer.type_is_parleying.1"
    },
    {
      "code": "nano.aqer.type.is.parleying.0",
      "value": "السعر غير قابل لتفاوض",
      "default": "nano.aqer.type_is_parleying.0"
    },
    {
      "code": "nano.work.categories.work",
      "value": "تصنيفات الاعمال",
      "default": "nano.work.categories_work"
    },
    {
      "code": "nano.all.photos",
      "value": "photos",
      "default": "nano.all.photos"
    },
    {
      "code": "عن.نانو.سوفت.للانظمة.الخدمية.وتطبيقات.الويب",
      "value": "Abuot Nano2soft",
      "default": "عن نانو سوفت للانظمة الخدمية وتطبيقات الويب"
    },
    {
      "code": "go.to.backend",
      "value": "Go To Backend",
      "default": "Go TO Backend"
    },
    {
      "code": "nano.soft.web.systems",
      "value": "Nano Soft Web Systems",
      "default": "Nano Soft Web Systems"
    },
    {
      "code": "abuot",
      "value": "Abuot",
      "default": "Abuot"
    },
    {
      "code": "backend",
      "value": "Backend",
      "default": "Backend"
    },
    {
      "code": "nanosoft",
      "value": "Nano2soft",
      "default": "NanoSoft"
    }
  ]
}
```

### Export All Data Translate Messages 

**لجلب كافه نصوص الترجمه نستخدم الرابط التالي **

```
GET /api/v1/translate/messages/export/all
```

#### Example 6 Export All Data Translate 

```
GET http://localhost:8006/api/v1/translate/messages/export/all
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "data": [
    {
      "code": "daynamic.title.title.features",
      "default": "",
      "en": "Features",
      "ar": "المميزات"
    },
    {
      "code": "nano.btn.more",
      "default": "",
      "en": "More",
      "ar": "اكثر"
    },
    {
      "code": "daynamic.title.categories.blog.categories",
      "default": "",
      "en": "Categories",
      "ar": "التصنيفات"
    },
    {
      "code": "daynamic.title.categories.tags",
      "default": "",
      "en": "Tags",
      "ar": "هاشتجات"
    },
    {
      "code": "nano.all.albumlist",
      "default": "",
      "en": "Album Photos",
      "ar": "البومات الصور"
    },
    {
      "code": "nano.all.videolist",
      "default": "",
      "en": "Videos",
      "ar": "الفيديوهات"
    },
    {
      "code": "daynamic.title.categories.title.tags",
      "default": "",
      "en": "Tags",
      "ar": "الهاشتجات"
    },
    {
      "code": "daynamic.msg.no.data.لاتوجد.بيانات.لعرضها",
      "default": "",
      "en": "No Data",
      "ar": "لايوجد بيانات"
    },
    {
      "code": "daynamic.title.categories.title.links",
      "default": "",
      "en": "Links",
      "ar": "روابط ذات صله"
    },
    {
      "code": "read.more",
      "default": "",
      "en": "Read More",
      "ar": "اكثر"
    },
    {
      "code": "daynamic.title.title.all.photos",
      "default": "",
      "en": "All photos",
      "ar": "كافة الصور"
    },
    {
      "code": "daynamic.title.last.news",
      "default": "",
      "en": "Last News",
      "ar": "اخر الاخبار"
    },
    {
      "code": "nano.search.placeholder",
      "default": "",
      "en": "search",
      "ar": "اكتب نص البحث هنا"
    },
    {
      "code": "nano.hero.title",
      "default": "",
      "en": "Titel",
      "ar": "العنوان"
    },
    {
      "code": "nano.hero.description",
      "default": "",
      "en": "Description",
      "ar": "الوصف"
    },
    {
      "code": "nano.footer.menu",
      "default": "",
      "en": "Menu",
      "ar": "القائمه"
    },
    {
      "code": "nano.footer.contact",
      "default": "",
      "en": "يمكنكم التواصل معنا عن طريق :",
      "ar": "يمكنكم التواصل معنا عن طريق :"
    },
    {
      "code": "nano.footer.addres",
      "default": "",
      "en": " العنوان",
      "ar": " العنوان"
    },
    {
      "code": "nano.footer.social",
      "default": "",
      "en": "كما يمكنكم زيارتنا على مواقع التواصل التالية",
      "ar": "كما يمكنكم زيارتنا على مواقع التواصل التالية"
    },
    {
      "code": "nano.author.crafted.with",
      "default": "",
      "en": "Crafted with",
      "ar": "تطوير"
    },
    {
      "code": "nano.footer.phone",
      "default": "",
      "en": " الهاتف",
      "ar": " الهاتف"
    },
    {
      "code": "nano.footer.email",
      "default": "",
      "en": " البريد",
      "ar": " البريد"
    },
    {
      "code": "nano.footer.website",
      "default": "",
      "en": "Website",
      "ar": "الموقع الالكتروني"
    },
    {
      "code": "nano.site.name",
      "default": "",
      "en": "NanoSoft FOr web",
      "ar": "نانو سوفت لتطبيقات الويب"
    },
    {
      "code": "nano.nav.home",
      "default": "",
      "en": "Home",
      "ar": "الرئيسية"
    },
    {
      "code": "nano.search.no.results",
      "default": "",
      "en": "لاتوجد نتائج بحث مطابقه",
      "ar": "لاتوجد نتائج بحث مطابقه"
    },
    {
      "code": "nano.account.on.access",
      "default": "",
      "en": "لاتمتلك صلاحيات للوصول لهذه الصفحه",
      "ar": "لاتمتلك صلاحيات للوصول لهذه الصفحه"
    },
    {
      "code": "nano.account.plass.sign.in",
      "default": "",
      "en": "يرجا تسجيل الدخول اولاً من خلال الرابط التالي",
      "ar": "يرجا تسجيل الدخول اولاً من خلال الرابط التالي"
    },
    {
      "code": "nano.account.nav.update",
      "default": "",
      "en": "البيانات الشخصية",
      "ar": "البيانات الشخصية"
    },
    {
      "code": "nano.account.nav.aqers",
      "default": "",
      "en": "عقاراتي",
      "ar": "عقاراتي"
    },
    {
      "code": "nano.account.sign.in",
      "default": "",
      "en": "دخول",
      "ar": "دخول"
    },
    {
      "code": "nano.account.sign.up",
      "default": "",
      "en": "تسجيل",
      "ar": "تسجيل"
    },
    {
      "code": "nano.account.logout",
      "default": "",
      "en": "خروج",
      "ar": "خروج"
    },
    {
      "code": "nano.account.forgot.password",
      "default": "",
      "en": "هل نسيت كلمة السر ؟",
      "ar": "هل نسيت كلمة السر ؟"
    },
    {
      "code": "nano.account.signin.label",
      "default": "",
      "en": "تسجيل الدخول",
      "ar": "تسجيل الدخول"
    },
    {
      "code": "nano.account.signin.form.name",
      "default": "",
      "en": "الاسم",
      "ar": "الاسم"
    },
    {
      "code": "nano.account.signin.form.placeholder.name",
      "default": "",
      "en": "ادخل اسم المستخدم",
      "ar": "ادخل اسم المستخدم"
    },
    {
      "code": "nano.account.signin.form.email",
      "default": "",
      "en": "البريد الالكتروني",
      "ar": "البريد الالكتروني"
    },
    {
      "code": "nano.account.signin.form.placeholder.email",
      "default": "",
      "en": "ادخل البريد الالكتروني",
      "ar": "ادخل البريد الالكتروني"
    },
    {
      "code": "nano.account.signin.form.password",
      "default": "",
      "en": "كلمةالسر",
      "ar": "كلمةالسر"
    },
    {
      "code": "nano.account.signin.form.placeholder.password",
      "default": "",
      "en": "اكتب كلمة السر هنا",
      "ar": "اكتب كلمة السر هنا"
    },
    {
      "code": "nano.account.signin.form.button.sign.in",
      "default": "",
      "en": "تسجيل الدخول",
      "ar": "تسجيل الدخول"
    },
    {
      "code": "nano.account.register.label",
      "default": "",
      "en": "التسجيل",
      "ar": "التسجيل"
    },
    {
      "code": "nano.account.register.form.full.name",
      "default": "",
      "en": "الاسم",
      "ar": "الاسم"
    },
    {
      "code": "nano.account.register.form.placeholder.full.name",
      "default": "",
      "en": "اكتب الاسم هنا",
      "ar": "اكتب الاسم هنا"
    },
    {
      "code": "nano.account.register.form.username",
      "default": "",
      "en": "اسم الدخول",
      "ar": "اسم الدخول"
    },
    {
      "code": "nano.account.register.form.placeholder.username",
      "default": "",
      "en": "اكتب اسم الدخول انجليزي هنا",
      "ar": "اكتب اسم الدخول انجليزي هنا"
    },
    {
      "code": "nano.account.register.form.password",
      "default": "",
      "en": "كلمة السر ",
      "ar": "كلمة السر "
    },
    {
      "code": "nano.account.register.form.placeholder.password",
      "default": "",
      "en": "اكتب كلمة السر هنا",
      "ar": "اكتب كلمة السر هنا"
    },
    {
      "code": "nano.account.register.form.button.register",
      "default": "",
      "en": "تسجيل ",
      "ar": "تسجيل "
    },
    {
      "code": "nano.footer.main.menu",
      "default": "",
      "en": "القائمة الرئيسية",
      "ar": "القائمة الرئيسية"
    },
    {
      "code": "nano.footer.share.social",
      "default": "",
      "en": "شارك الموقع ",
      "ar": "شارك الموقع "
    },
    {
      "code": "nano.aqer.categories.aqer",
      "default": "",
      "en": "التصنيفات الرئيسية",
      "ar": "التصنيفات الرئيسية"
    },
    {
      "code": "nano.aqer.type.options.advert",
      "default": "",
      "en": "عقار",
      "ar": "عقار"
    },
    {
      "code": "nano.aqer.type.options.order",
      "default": "",
      "en": "مطلوب",
      "ar": "مطلوب"
    },
    {
      "code": "nano.aqer.type.is.parleying.1",
      "default": "",
      "en": "السعر قابل لتفاوض",
      "ar": "السعر قابل لتفاوض"
    },
    {
      "code": "nano.aqer.type.is.parleying.0",
      "default": "",
      "en": "السعر غير قابل لتفاوض",
      "ar": "السعر غير قابل لتفاوض"
    },
    {
      "code": "nano.work.categories.work",
      "default": "",
      "en": "تصنيفات الاعمال",
      "ar": "تصنيفات الاعمال"
    },
    {
      "code": "nano.all.photos",
      "default": "",
      "en": "photos",
      "ar": "صور"
    },
    {
      "code": "عن.نانو.سوفت.للانظمة.الخدمية.وتطبيقات.الويب",
      "default": "",
      "en": "Abuot Nano2soft",
      "ar": "عن نانو سوفت للانظمة الخدمية وتطبيقات الويب"
    },
    {
      "code": "go.to.backend",
      "default": "",
      "en": "Go To Backend",
      "ar": "ذهاب الى لوحة التحكم"
    },
    {
      "code": "nano.soft.web.systems",
      "default": "",
      "en": "Nano Soft Web Systems",
      "ar": "Nano Soft Web Systems"
    },
    {
      "code": "abuot",
      "default": "",
      "en": "Abuot",
      "ar": "عنا"
    },
    {
      "code": "backend",
      "default": "",
      "en": "Backend",
      "ar": "لوحة التحكم"
    },
    {
      "code": "nanosoft",
      "default": "",
      "en": "Nano2soft",
      "ar": "نانوسوفت"
    }
  ]
}
```
