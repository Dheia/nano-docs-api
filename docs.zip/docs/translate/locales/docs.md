## Locales Language

This endpoint allows you to `list`, `show` your locales.

/translate/locales

**الجز الخاص باللغات التي يدعمها النظام يمكنك من خلال هذا الجزء جلب كافه اللغات المدعومه فى النظام **

### The Accept-Language 

**يمكن تهية اللغة فى النظام من خلال  تمرير كود اللغه فى راس الطلب ضمن المتغير  Accept-Language**

Header Parameters
```json
{
  "Accept-Language":"ar"
}
```

**عند تمرير المتغير السابق فى راس الطلب فان النظام سيقوم بجلب اي بيانات بالاعتماد على اللغه الممرره فمثلا لوقمن بتمرير كود اللغه العربيه سيتم ارجاع البيانات باللغه العربيه وهكذا**

### The locales object

#### Public Parameters
| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in locales records |
| `orderBy`           | `string`  |  using orderBy locales records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy locales records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isEnabled`           | `boolean`  | **Required**. The get is Active  locales default value true    |
| `isDefault`           | `boolean`  | The get is Default  Locales default value false  | 
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/translate/locales?exclude=created_at,updated_at
```


### List locales

Returns a list of locales.

**لجلب اللغه نستخدم الرابط التالي **

```
GET /api/v1/translate/locales
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": "en",
      "name": "English",
      "is_default": 1,
      "is_enabled": 1,
      "sort_order": 1,
      "object_type": "RainLab\\Translate\\Models\\Locale"
    },
    {
      "id": 2,
      "code": "ar",
      "name": "Arabic",
      "is_default": 0,
      "is_enabled": 1,
      "sort_order": 2,
      "object_type": "RainLab\\Translate\\Models\\Locale"
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Example 1 get List Locales 

GET http://localhost:8006/api/v1/translate/locales

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": "en",
      "name": "English",
      "is_default": 1,
      "is_enabled": 1,
      "sort_order": 1,
      "object_type": "RainLab\\Translate\\Models\\Locale"
    },
    {
      "id": 2,
      "code": "ar",
      "name": "Arabic",
      "is_default": 0,
      "is_enabled": 1,
      "sort_order": 2,
      "object_type": "RainLab\\Translate\\Models\\Locale"
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Show Data Record Locales 

```
GET /api/v1/translate/locales/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record Locales 2

```
GET http://localhost:8006/api/v1/translate/locales/2
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "id": 2,
  "code": "ar",
  "name": "Arabic",
  "is_default": 0,
  "is_enabled": 1,
  "sort_order": 2,
  "object_type": "RainLab\\Translate\\Models\\Locale"
}
```
