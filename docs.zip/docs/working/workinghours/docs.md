## Working Hours

This endpoint allows you to `list`, `show` your type.

/working/workinghours

** من خلال هذا الجزء يمكنك جلب اوقات العمل الخاصه بالتطبيق او متجر معين  **

### The types object

#### Public Parameters
| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in types records |
| `orderBy`           | `string`  |  using orderBy types records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy types records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  types default value true    |
| `type`           | `string`  | The get type in workinghours records types default value opening  | 
| `worknable_id`           | `integer`  | The get  shoping working Hours default value apps  | 
| `worknable_type`           | `string`  |  get records types departments default value departments.         |
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/working/workinghours?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `departments`           | `belongsTo`  | The get companys |
| `user`           | `belongsTo`  | The get user |



### List types

Returns a list of types you’ve previously created.

```
GET /api/v1/working/workinghours
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |


### Example 1 get List working Hours 

** فى المثال التالى سنقوم بجلب اوقات عمل التطبيق **

GET http://localhost:8006/api/v1/working/workinghours

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 180,
      "type": "opening",
      "type_time": "daily",
      "weekday": 0,
      "weekday_iso": "Monday",
      "weekday_name": "اثنين",
      "opening_time": "01:45:00",
      "closing_time": "23:55:00",
      "day": "2022-12-04T21:00:00.000000Z",
      "open": "2022-12-04T22:45:00.000000Z",
      "close": "2022-12-05T20:55:00.000000Z",
      "worknable_id": 4,
      "worknable_type": "Tss\\Basic\\Models\\Department",
      "is_active": true,
      "created_at": "2022-09-30 23:32:52",
      "updated_at": "2022-09-30 23:32:52",
      "deleted_at": ""
    },
    {
      "id": 181,
      "type": "opening",
      "type_time": "daily",
      "weekday": 1,
      "weekday_iso": "Tuesday",
      "weekday_name": "ثلاثاء",
      "opening_time": "01:45:00",
      "closing_time": "23:55:00",
      "day": "2022-12-05T21:00:00.000000Z",
      "open": "2022-12-05T22:45:00.000000Z",
      "close": "2022-12-06T20:55:00.000000Z",
      "worknable_id": 4,
      "worknable_type": "Tss\\Basic\\Models\\Department",
      "is_active": true,
      "created_at": "2022-09-30 23:32:52",
      "updated_at": "2022-09-30 23:32:52",
      "deleted_at": ""
    },
    {
      "id": 182,
      "type": "opening",
      "type_time": "daily",
      "weekday": 2,
      "weekday_iso": "Wednesday",
      "weekday_name": "أربعاء",
      "opening_time": "01:45:00",
      "closing_time": "23:55:00",
      "day": "2022-12-06T21:00:00.000000Z",
      "open": "2022-12-06T22:45:00.000000Z",
      "close": "2022-12-07T20:55:00.000000Z",
      "worknable_id": 4,
      "worknable_type": "Tss\\Basic\\Models\\Department",
      "is_active": true,
      "created_at": "2022-09-30 23:32:52",
      "updated_at": "2022-09-30 23:32:52",
      "deleted_at": ""
    },
    {
      "id": 183,
      "type": "opening",
      "type_time": "daily",
      "weekday": 3,
      "weekday_iso": "Thursday",
      "weekday_name": "خميس",
      "opening_time": "01:45:00",
      "closing_time": "23:55:00",
      "day": "2022-12-07T21:00:00.000000Z",
      "open": "2022-12-07T22:45:00.000000Z",
      "close": "2022-12-08T20:55:00.000000Z",
      "worknable_id": 4,
      "worknable_type": "Tss\\Basic\\Models\\Department",
      "is_active": true,
      "created_at": "2022-09-30 23:32:52",
      "updated_at": "2022-09-30 23:32:52",
      "deleted_at": ""
    },
    {
      "id": 184,
      "type": "opening",
      "type_time": "daily",
      "weekday": 4,
      "weekday_iso": "Friday",
      "weekday_name": "جمعة",
      "opening_time": "01:45:00",
      "closing_time": "23:55:00",
      "day": "2022-12-08T21:00:00.000000Z",
      "open": "2022-12-08T22:45:00.000000Z",
      "close": "2022-12-09T20:55:00.000000Z",
      "worknable_id": 4,
      "worknable_type": "Tss\\Basic\\Models\\Department",
      "is_active": true,
      "created_at": "2022-09-30 23:32:52",
      "updated_at": "2022-09-30 23:32:52",
      "deleted_at": ""
    },
    {
      "id": 185,
      "type": "opening",
      "type_time": "daily",
      "weekday": 5,
      "weekday_iso": "Saturday",
      "weekday_name": "سبت",
      "opening_time": "01:45:00",
      "closing_time": "23:55:00",
      "day": "2022-12-09T21:00:00.000000Z",
      "open": "2022-12-09T22:45:00.000000Z",
      "close": "2022-12-10T20:55:00.000000Z",
      "worknable_id": 4,
      "worknable_type": "Tss\\Basic\\Models\\Department",
      "is_active": false,
      "created_at": "2022-09-30 23:32:52",
      "updated_at": "2022-09-30 23:32:52",
      "deleted_at": ""
    },
    {
      "id": 186,
      "type": "opening",
      "type_time": "daily",
      "weekday": 6,
      "weekday_iso": "Sunday",
      "weekday_name": "أحد",
      "opening_time": "01:45:00",
      "closing_time": "23:55:00",
      "day": "2022-12-10T21:00:00.000000Z",
      "open": "2022-12-10T22:45:00.000000Z",
      "close": "2022-12-11T20:55:00.000000Z",
      "worknable_id": 4,
      "worknable_type": "Tss\\Basic\\Models\\Department",
      "is_active": false,
      "created_at": "2022-09-30 23:32:52",
      "updated_at": "2022-09-30 23:32:52",
      "deleted_at": ""
    }
  ],
  "meta": {
    "pagination": {
      "total": 7,
      "count": 7,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Show Data Record working Hours 

```
GET /api/v1/working/workinghours/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record working Show 183

```
GET http://localhost:8006/api/v1/working/workinghours/183
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "id": 183,
  "type": "opening",
  "type_time": "daily",
  "weekday": 3,
  "weekday_iso": "Thursday",
  "weekday_name": "خميس",
  "opening_time": "01:45:00",
  "closing_time": "23:55:00",
  "day": "2022-12-07T21:00:00.000000Z",
  "open": "2022-12-07T22:45:00.000000Z",
  "close": "2022-12-08T20:55:00.000000Z",
  "worknable_id": 4,
  "worknable_type": "Tss\\Basic\\Models\\Department",
  "is_active": true,
  "created_at": "2022-09-30 23:32:52",
  "updated_at": "2022-09-30 23:32:52",
  "deleted_at": ""
}
```

