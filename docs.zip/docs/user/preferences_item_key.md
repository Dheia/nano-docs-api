http://localhost:8006/api/v1/user/preferences/key?preferenceKey=backend::reportwidgets.Pepoles&key=welcome

{
  "data": {
    "class": "Tss\\Basic\\ReportWidgets\\WelcomePepoles",
    "sortOrder": 50,
    "configuration": {
      "title": "مرحبا بكم في ادارة الأشخاص",
      "ocWidgetWidth": 10,
      "ocWidgetNewRow": null
    }
  }
}

http://localhost:8006/api/v1/user/preferences/key?preferenceKey=backend::reportwidgets.Pepoles&key=welcome.configuration

{
  "data": {
    "title": "مرحبا بكم في ادارة الأشخاص",
    "ocWidgetWidth": 10,
    "ocWidgetNewRow": null
  }
}

http://localhost:8006/api/v1/user/preferences/key?preferenceKey=backend::reportwidgets.Pepoles&key=welcome.configuration.ocWidgetWidth

{
  "data": 10
}