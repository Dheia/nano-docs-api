http://localhost:8006/api/v1/user/preferences

{
  "data": {
    "locale": "ar",
    "fallback_locale": "ar",
    "timezone": "Asia\/Aden",
    "editor_font_size": "12",
    "editor_word_wrap": "fluid",
    "editor_code_folding": "manual",
    "editor_tab_size": "4",
    "editor_theme": "twilight",
    "editor_show_invisibles": "0",
    "editor_highlight_active_line": "1",
    "editor_use_hard_tabs": "0",
    "editor_show_gutter": "1",
    "editor_auto_closing": "0",
    "editor_autocompletion": "manual",
    "editor_enable_snippets": "0",
    "editor_display_indent_guides": "0",
    "editor_show_print_margin": "0",
    "rounded_avatar": "1",
    "topmenu_label": "0",
    "sidebar_description": "0",
    "sidebar_search": "0",
    "focus_searchfield": "0",
    "context_menu": "0",
    "virtual_keyboard": "0",
    "user_id": 4
  }
}