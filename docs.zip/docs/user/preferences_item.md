http://localhost:8006/api/v1/user/preferences/item?preferenceKey=backend::reportwidgets.Pepoles

{
  "data": {
    "welcome": {
      "class": "Tss\\Basic\\ReportWidgets\\WelcomePepoles",
      "sortOrder": 50,
      "configuration": {
        "title": "مرحبا بكم في ادارة الأشخاص",
        "ocWidgetWidth": 10,
        "ocWidgetNewRow": null
      }
    }
  }
}