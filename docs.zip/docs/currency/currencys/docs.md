## Currencys

This endpoint allows you to `list`, `show` your currencys.

/currency/currencys

**من خلال هذا الجزء يمكنك جلب العملات **

### The currencys object

#### Public Parameters
| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in currencys records |
| `orderBy`           | `string`  |  using orderBy currencys records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy currencys records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  currencys default value true    |
| `isDefault`           | `boolean`  | The get is  Default record currencys default value false  | 
| `isNotDefault`           | `integer`  | The get is Not Defaultrecords currencys default value false  | 

| `include`           | `string` | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/currency/currencys?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `department`           | `belongsTo`  | The get department Refrence | 

### List currencys

Returns a list of currencys 
```
GET /api/v1/currency/currencys
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": "2-2-1",
      "name": "ريال يمني",
      "part_name": "فلس",
      "currency_code": "RYL",
      "currency_symbol": "ريال",
      "decimal_point": ".",
      "thousand_separator": ",",
      "place_symbol_before": 0,
      "factor": 2,
      "format": null,
      "rate": null,
      "min_rate": null,
      "max_rate": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_default": 1,
      "is_active": 1,
      "sort_order": 1,
      "created_at": "2022-10-24 21:34:39",
      "updated_at": "2022-10-24 21:34:39",
      "object_type": "Tss\\Currency\\Models\\Currency"
    },
    {
      "id": 2,
      "code": "2-2-2",
      "name": "ريال سعودي",
      "part_name": null,
      "currency_code": "RYLS",
      "currency_symbol": "ريال سعودي",
      "decimal_point": ".",
      "thousand_separator": ",",
      "place_symbol_before": 0,
      "factor": 2,
      "format": null,
      "rate": null,
      "min_rate": null,
      "max_rate": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_default": 0,
      "is_active": 1,
      "sort_order": 2,
      "created_at": "2022-10-24 21:34:39",
      "updated_at": "2022-10-24 21:34:39",
      "object_type": "Tss\\Currency\\Models\\Currency"
    },
    {
      "id": 3,
      "code": "2-2-3",
      "name": "U.S. Dollar",
      "part_name": null,
      "currency_code": "USD",
      "currency_symbol": "$",
      "decimal_point": ".",
      "thousand_separator": ",",
      "place_symbol_before": 1,
      "factor": 2,
      "format": null,
      "rate": null,
      "min_rate": null,
      "max_rate": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_default": 0,
      "is_active": 1,
      "sort_order": 3,
      "created_at": "2022-10-24 21:34:39",
      "updated_at": "2022-10-24 21:34:39",
      "object_type": "Tss\\Currency\\Models\\Currency"
    },
    {
      "id": 4,
      "code": "2-2-4",
      "name": "Euro",
      "part_name": null,
      "currency_code": "EUR",
      "currency_symbol": "€",
      "decimal_point": ".",
      "thousand_separator": ",",
      "place_symbol_before": 1,
      "factor": 2,
      "format": null,
      "rate": null,
      "min_rate": null,
      "max_rate": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_default": 0,
      "is_active": 1,
      "sort_order": 4,
      "created_at": "2022-10-24 21:34:39",
      "updated_at": "2022-10-24 21:34:39",
      "object_type": "Tss\\Currency\\Models\\Currency"
    },
    {
      "id": 5,
      "code": "2-2-5",
      "name": "Pound Sterling",
      "part_name": null,
      "currency_code": "GBP",
      "currency_symbol": "£",
      "decimal_point": ".",
      "thousand_separator": ",",
      "place_symbol_before": 1,
      "factor": 2,
      "format": null,
      "rate": null,
      "min_rate": null,
      "max_rate": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_default": 0,
      "is_active": 1,
      "sort_order": 5,
      "created_at": "2022-10-24 21:34:39",
      "updated_at": "2022-10-24 21:34:39",
      "object_type": "Tss\\Currency\\Models\\Currency"
    },
    {
      "id": 6,
      "code": "2-2-6",
      "name": "Australian Dollar",
      "part_name": null,
      "currency_code": "AUD",
      "currency_symbol": "$",
      "decimal_point": ".",
      "thousand_separator": ",",
      "place_symbol_before": 1,
      "factor": 2,
      "format": null,
      "rate": null,
      "min_rate": null,
      "max_rate": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_default": 0,
      "is_active": 1,
      "sort_order": 6,
      "created_at": "2022-10-24 21:34:39",
      "updated_at": "2022-10-24 21:34:39",
      "object_type": "Tss\\Currency\\Models\\Currency"
    }
  ],
  "meta": {
    "pagination": {
      "total": 6,
      "count": 6,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

### Example 1 get List Currencys 

```
GET http://localhost:8006/api/v1/currency/currencys
```
#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": "2-2-1",
      "name": "ريال يمني",
      "part_name": "فلس",
      "currency_code": "RYL",
      "currency_symbol": "ريال",
      "decimal_point": ".",
      "thousand_separator": ",",
      "place_symbol_before": 0,
      "factor": 2,
      "format": null,
      "rate": null,
      "min_rate": null,
      "max_rate": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_default": 1,
      "is_active": 1,
      "sort_order": 1,
      "created_at": "2022-10-24 21:34:39",
      "updated_at": "2022-10-24 21:34:39",
      "object_type": "Tss\\Currency\\Models\\Currency"
    },
    {
      "id": 2,
      "code": "2-2-2",
      "name": "ريال سعودي",
      "part_name": null,
      "currency_code": "RYLS",
      "currency_symbol": "ريال سعودي",
      "decimal_point": ".",
      "thousand_separator": ",",
      "place_symbol_before": 0,
      "factor": 2,
      "format": null,
      "rate": null,
      "min_rate": null,
      "max_rate": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_default": 0,
      "is_active": 1,
      "sort_order": 2,
      "created_at": "2022-10-24 21:34:39",
      "updated_at": "2022-10-24 21:34:39",
      "object_type": "Tss\\Currency\\Models\\Currency"
    },
    {
      "id": 3,
      "code": "2-2-3",
      "name": "U.S. Dollar",
      "part_name": null,
      "currency_code": "USD",
      "currency_symbol": "$",
      "decimal_point": ".",
      "thousand_separator": ",",
      "place_symbol_before": 1,
      "factor": 2,
      "format": null,
      "rate": null,
      "min_rate": null,
      "max_rate": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_default": 0,
      "is_active": 1,
      "sort_order": 3,
      "created_at": "2022-10-24 21:34:39",
      "updated_at": "2022-10-24 21:34:39",
      "object_type": "Tss\\Currency\\Models\\Currency"
    },
    {
      "id": 4,
      "code": "2-2-4",
      "name": "Euro",
      "part_name": null,
      "currency_code": "EUR",
      "currency_symbol": "€",
      "decimal_point": ".",
      "thousand_separator": ",",
      "place_symbol_before": 1,
      "factor": 2,
      "format": null,
      "rate": null,
      "min_rate": null,
      "max_rate": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_default": 0,
      "is_active": 1,
      "sort_order": 4,
      "created_at": "2022-10-24 21:34:39",
      "updated_at": "2022-10-24 21:34:39",
      "object_type": "Tss\\Currency\\Models\\Currency"
    },
    {
      "id": 5,
      "code": "2-2-5",
      "name": "Pound Sterling",
      "part_name": null,
      "currency_code": "GBP",
      "currency_symbol": "£",
      "decimal_point": ".",
      "thousand_separator": ",",
      "place_symbol_before": 1,
      "factor": 2,
      "format": null,
      "rate": null,
      "min_rate": null,
      "max_rate": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_default": 0,
      "is_active": 1,
      "sort_order": 5,
      "created_at": "2022-10-24 21:34:39",
      "updated_at": "2022-10-24 21:34:39",
      "object_type": "Tss\\Currency\\Models\\Currency"
    },
    {
      "id": 6,
      "code": "2-2-6",
      "name": "Australian Dollar",
      "part_name": null,
      "currency_code": "AUD",
      "currency_symbol": "$",
      "decimal_point": ".",
      "thousand_separator": ",",
      "place_symbol_before": 1,
      "factor": 2,
      "format": null,
      "rate": null,
      "min_rate": null,
      "max_rate": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_default": 0,
      "is_active": 1,
      "sort_order": 6,
      "created_at": "2022-10-24 21:34:39",
      "updated_at": "2022-10-24 21:34:39",
      "object_type": "Tss\\Currency\\Models\\Currency"
    }
  ],
  "meta": {
    "pagination": {
      "total": 6,
      "count": 6,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

### Example 2 get Default Currency 

GET https://alnaeem.nano2soft.com/api/v1/currency/currencys?isDefault=true

**فى المثال التالي سنقوم بجلب بيانات العملة الافتراضيه**

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": "2-2-1",
      "name": "ريال يمني",
      "part_name": "فلس",
      "currency_code": "RYL",
      "currency_symbol": "ريال",
      "decimal_point": ".",
      "thousand_separator": ",",
      "place_symbol_before": 0,
      "factor": 2,
      "format": null,
      "rate": null,
      "min_rate": null,
      "max_rate": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_default": 1,
      "is_active": 1,
      "sort_order": 1,
      "created_at": "2022-10-24 21:34:39",
      "updated_at": "2022-10-24 21:34:39",
      "object_type": "Tss\\Currency\\Models\\Currency"
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```


### Show Data Record Currencys 

```
GET /api/v1/currency/currencys/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 3 Show Data Record Currencys 4

```
GET http://localhost:8006/api/v1/currency/currencys/4
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "id": 4,
  "code": "2-2-4",
  "name": "Euro",
  "part_name": null,
  "currency_code": "EUR",
  "currency_symbol": "€",
  "decimal_point": ".",
  "thousand_separator": ",",
  "place_symbol_before": 1,
  "factor": 2,
  "format": null,
  "rate": null,
  "min_rate": null,
  "max_rate": null,
  "companys_id": "2",
  "departments_id": "2",
  "is_default": 0,
  "is_active": 1,
  "sort_order": 4,
  "created_at": "2022-10-24 21:34:39",
  "updated_at": "2022-10-24 21:34:39",
  "object_type": "Tss\\Currency\\Models\\Currency"
}
```

### Check Last Update Currencys Daa 

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/currency/currencys/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **
**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/currency/currencys/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على المحلات بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2023-08-29 19:57:02",
    "other_updated": {
      "activity_cache.currency": "2023-08-29 19:57:02",
      "activity_cache.exchangerate": "2023-08-29 19:57:02",
      "activity_cache.exchangelot": "2023-08-29 19:57:02"
    }
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2023-08-29 19:58:49",
    "last_updated": "2023-08-29 19:57:02",
    "other_updated": {
      "activity_cache.currency": "2023-08-29 19:57:02",
      "activity_cache.exchangerate": "2023-08-29 19:57:02",
      "activity_cache.exchangelot": "2023-08-29 19:57:02"
    }
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **

