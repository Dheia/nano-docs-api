## Carts Api

This endpoint allows you to `Manage Carts products`, `show`,  `add`, `update`, `update`, `delete` your carts.

```
 /api/v1/shop/carts
```

### Public Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `rowId`           | `string`  |  rowId in carts Item Identify |
| `menuId or id `           | `integer`  | **Required** Identify Products Id |
| `quantity`           | `integer`  | **Required** Quantity |
| `comment`           | `string`  |  comment in the item  |
| `options`           | `array`  |  Other  Options in the item |


### get Carts Data

Returns a list of items in carts and subtotal and other total 

```
GET /api/v1/shop/carts
```
#### Returns Attributes In Data Carts 

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `content`           | `array`  |  ritems in carts |
| `conditions `           | `array`  | conditions aplly to carts  |
| `count`           | `integer`  | sum Quantity all items |
| `subtotalWithoutConditions`           | `integer`  |  المجموع الفرعي قبل الخصوم او الضرائب  |
| `subtotal`           | `integer`  |  subtotal |
| `total`           | `integer`  |  total |


#### Example 1 get List Carts 

```
GET http://localhost:8006/api/v1/shop/carts
```

#### Response

```html
Status: 200 OK
```

```json
{
  "content": {
    "c4bdc41d31462c9c59e3648c711b7bd6": {
      "rowId": "c4bdc41d31462c9c59e3648c711b7bd6",
      "id": 2,
      "name": "الصنف الثاني",
      "qty": 8,
      "price": 0,
      "options": [],
      "conditions": [],
      "comment": "comment this",
      "subtotal": 0
    },
    "a775bac9cff7dec2b984e023b95206aa": {
      "rowId": "a775bac9cff7dec2b984e023b95206aa",
      "id": 3,
      "name": "نفر رز",
      "qty": 28,
      "price": 0,
      "options": [],
      "conditions": [],
      "comment": null,
      "subtotal": 0
    }
  },
  "conditions": {
    "tip": {
      "name": "tip",
      "label": "nano.cart::default.text_tip",
      "priority": "",
      "removeable": false,
      "metaData": {
        "amount": 40,
        "amountType": "amount"
      }
    }
  },
  "count": 36,
  "subtotalWithoutConditions": 0,
  "subtotal": 0,
  "total": 40
}
```
### Add Item to Carts 

```
POST /api/v1/shop/carts/add
```
** يتم استخدام هذه الداله لاضافه صنف الى السله وذلك بتمرير رقم الصنف والكميه والملاحظه ان وجدت  **

**عند استخدام نفس الداله لاكثر من مره بنفس القيم الممرره سيتم اضافه الكميه الممرره الى الكميه السابقه كعمليه زياده للكميه بالقيمه الممرره **

**ايضا يمكن استخدام نفس الداله لتعديل صنف فى السله وذلك بتمرير رقم الصنف والكميه  **


#### Parameters  

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `rowId`           | `string`  |  rowId in carts Item Identify |
| `menuId or id `           | `integer`  | **Required** Identify Products Id |
| `quantity`           | `integer`  | **Required** Quantity |
| `comment`           | `string`  |  comment in the item  |
| `options`           | `array`  |  Other  Options in the item |


#### Example 2 Add Item to Carts 

**اضافه صنف الى السله   **

**فى المثال التالى قمنا بتمرير رقم الصنف 3 والكميه 4  معا كتابه ملاحظه للصنف **

##### البيانات التي تم تمريرها فى الطلب كا التالي  

```json
{
  "menuId": 3,
  "quantity": 4,
  "comment": "ملاحظات على الصنف ",
}
```
  
  
```
POST http://localhost:8006/api/v1/shop/carts/add?quantity=4&menuId=3&comment=%D9%85%D9%84%D8%A7%D8%AD%D8%B8%D8%A7%D8%AA%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%B5%D9%86%D9%81
```

#### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم تحديث السله بنجاح ",
  "data": {
    "content": {
      "c4bdc41d31462c9c59e3648c711b7bd6": {
        "rowId": "c4bdc41d31462c9c59e3648c711b7bd6",
        "id": 2,
        "name": "الصنف الثاني",
        "qty": 8,
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "comment this",
        "subtotal": 0
      },
      "a5d953bd82541f216e265c50b7c6e879": {
        "rowId": "a5d953bd82541f216e265c50b7c6e879",
        "id": 3,
        "name": "نفر رز",
        "qty": 8,
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف",
        "subtotal": 0
      }
    },
    "conditions": [],
    "count": 16,
    "subtotalWithoutConditions": 0,
    "subtotal": 0,
    "total": 0
  }
}
```

### Update Quantity Items 

**لتعديل الكميه الخاصه بصنف معين تم اضافته الى السله نستخدم الرابط التالى معا تمرير معرف الصنف فى السله والكميه **

```
POST /api/v1/shop/carts/updateqty/{rowId?}/{quantity?}
```
#### Attributes 

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `rowId`           | `string`  |  ritems in carts |
| `quantity `           | `integer|string`  | quantity [integer|plus|minus]  |

** فى متغير الكميه يمكن تمرير الكميه كا رقم او يمكن تمرير قيمه نصيه معبره عن الزياده او النقصان **
#### Example 3 Update quantity

** فى المثال التالى سنقوم بتغيير كميه الصنف الى 3  **


```json
{
  "rowId": "a5d953bd82541f216e265c50b7c6e879",
  "quantity": 3,
}
```
```
POST http://localhost:8006/api/v1/shop/carts/updateqty?rowId=a5d953bd82541f216e265c50b7c6e879&quantity=3
```

#### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم تحديث الكمية بنجاح ",
  "data": {
    "content": {
      "c4bdc41d31462c9c59e3648c711b7bd6": {
        "rowId": "c4bdc41d31462c9c59e3648c711b7bd6",
        "id": 2,
        "name": "الصنف الثاني",
        "qty": 8,
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "comment this",
        "subtotal": 0
      },
      "a5d953bd82541f216e265c50b7c6e879": {
        "rowId": "a5d953bd82541f216e265c50b7c6e879",
        "id": 3,
        "name": "نفر رز",
        "qty": "3",
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف",
        "subtotal": 0
      }
    },
    "conditions": [],
    "count": 11,
    "subtotalWithoutConditions": 0,
    "subtotal": 0,
    "total": 0
  }
}
```

**لزياده الصنف بمقدار واحد نقوم بتمرير البيانات كا التالي  :- **

```json
{
  "rowId": "a5d953bd82541f216e265c50b7c6e879",
  "quantity": "plus",
}
```

```
POST http://localhost:8006/api/v1/shop/carts/updateqty?rowId=a5d953bd82541f216e265c50b7c6e879&quantity=plus
```

#### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم تحديث الكمية بنجاح ",
  "data": {
    "content": {
      "c4bdc41d31462c9c59e3648c711b7bd6": {
        "rowId": "c4bdc41d31462c9c59e3648c711b7bd6",
        "id": 2,
        "name": "الصنف الثاني",
        "qty": 8,
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "comment this",
        "subtotal": 0
      },
      "a5d953bd82541f216e265c50b7c6e879": {
        "rowId": "a5d953bd82541f216e265c50b7c6e879",
        "id": 3,
        "name": "نفر رز",
        "qty": 4,
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف",
        "subtotal": 0
      }
    },
    "conditions": [],
    "count": 12,
    "subtotalWithoutConditions": 0,
    "subtotal": 0,
    "total": 0
  }
}
```

### Delete Item in Carts 

**لحذف صنف معين من السله نستخدم الرابط التالى معا تمرير معرف الصنف فى السله **

```
DELETE /api/v1/shop/carts/delete/{rowId?}
```
#### Example 3 Update quantity

** فى المثال التالى سنقوم  بحذف صنف معين من السله   **



```json
{
  "rowId": "a5d953bd82541f216e265c50b7c6e879",
}
```

```
DELETE http://localhost:8006/api/v1/shop/carts/delete?rowId=a5d953bd82541f216e265c50b7c6e879
```

#### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم حذف الصنف من السله بنجاح  ",
  "data": {
    "content": {
      "c4bdc41d31462c9c59e3648c711b7bd6": {
        "rowId": "c4bdc41d31462c9c59e3648c711b7bd6",
        "id": 2,
        "name": "الصنف الثاني",
        "qty": 8,
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "comment this",
        "subtotal": 0
      }
    },
    "conditions": [],
    "count": 8,
    "subtotalWithoutConditions": 0,
    "subtotal": 0,
    "total": 0
  }
}
```
```json
{
  "code": "200",
  "message": "تم تحديث السله بنجاح ",
  "data": {
    "content": [
      {
        "rowId": "63667a79c53ed4f6dcb79afdb20f46c8",
        "id": 3,
        "name": "نفر رز",
        "qty": 24,
        "price": 0,
        "options": [
          {
            "id": "units",
            "name": "الوحدات",
            "values": [
              {
                "id": 3,
                "name": "حبه",
                "qty": 2,
                "price": 200,
                "subtotal": 400
              },
              {
                "id": 4,
                "name": "نص",
                "qty": 3,
                "price": 100,
                "subtotal": 300
              }
            ],
            "subtotal": 700
          }
        ],
        "conditions": [],
        "comment": "ملاحظات على الصنف",
        "subtotal": 16800
      },
      {
        "rowId": "318bddb37a13cdd63cf85934220a3b12",
        "id": 2,
        "name": "الصنف الثاني",
        "qty": 6,
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف",
        "subtotal": 0
      },
      {
        "rowId": "fc8bccb483d49907d45f2ca2e8dd223e",
        "id": 2,
        "name": "الصنف الثاني",
        "qty": 6,
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف ",
        "subtotal": 0
      }
    ],
    "conditions": [],
    "count": 36,
    "subtotalWithoutConditions": 16800,
    "subtotal": 16800,
    "total": 16800
  }
}
```



