## OrdersStatess  Api

This endpoint allows you to `list`, `show` your Orders States.

/orders/ordersstates

** الجزء الخاص بجلب حالات الطلب   **

### The Orders States object

#### Public Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in Orders States  records |
| `orderBy`           | `string`  |  using orderBy departments records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy departments records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  OrdersStatess default value true    |
| `isDefault`           | `boolean`  | The get is Is default  OrdersStates default value
false    |
| `companys_id`           | `integer`  |  get records OrdersStates to companys_id default value false.         |
| `departments_id`           | `integer`  | get records OrdersStatess to departments_id
default value false.          |
| `include`           | `string `  | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/orders/ordersstates?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `department`           | `belongsTo`  | The get department | 


### List Orders States

Returns a list of OrdersStatess’

```
GET /api/v1/orders/ordersstates
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

### Example 1 get List OrdersStatess  

```
GET http://localhost:8006/api/v1/orders/ordersstates
```

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": "2-2-1",
      "name": "In shopping Cart",
      "color": null,
      "description": "In shopping Cart",
      "is_completed": 0,
      "is_cancel": 0,
      "is_default": 0,
      "is_active": 1,
      "config_data": null,
      "other_data": null,
      "flag": "CART",
      "ref_type": "CART",
      "ref_key_name": null,
      "ref_key_values": null,
      "sort_order": 1,
      "created_at": "2023-08-26 16:13:58",
      "updated_at": "2023-08-26 16:13:58"
    },
    {
      "id": 2,
      "code": "2-2-2",
      "name": "جديد",
      "color": null,
      "description": "جديد",
      "is_completed": 0,
      "is_cancel": 0,
      "is_default": 1,
      "is_active": 1,
      "config_data": null,
      "other_data": null,
      "flag": "NEW",
      "ref_type": "NEW",
      "ref_key_name": null,
      "ref_key_values": null,
      "sort_order": 2,
      "created_at": "2023-08-26 16:13:58",
      "updated_at": "2023-08-26 16:13:58"
    },
    {
      "id": 3,
      "code": "2-2-3",
      "name": "قيد التجهيز",
      "color": null,
      "description": "قيد التجهيز",
      "is_completed": 0,
      "is_cancel": 0,
      "is_default": 0,
      "is_active": 1,
      "config_data": null,
      "other_data": null,
      "flag": "PROCESSING",
      "ref_type": "PROCESSING",
      "ref_key_name": null,
      "ref_key_values": null,
      "sort_order": 3,
      "created_at": "2023-08-26 16:13:58",
      "updated_at": "2023-08-26 16:13:58"
    },
    {
      "id": 4,
      "code": "2-2-4",
      "name": "قيد التوصيل",
      "color": null,
      "description": "قيد التوصيل",
      "is_completed": 0,
      "is_cancel": 0,
      "is_default": 0,
      "is_active": 1,
      "config_data": null,
      "other_data": null,
      "flag": "DELIVERY",
      "ref_type": "DELIVERY",
      "ref_key_name": null,
      "ref_key_values": null,
      "sort_order": 4,
      "created_at": "2023-08-26 16:13:58",
      "updated_at": "2023-08-26 16:13:58"
    },
    {
      "id": 5,
      "code": "2-2-5",
      "name": "مكتمل",
      "color": null,
      "description": "مكتمل",
      "is_completed": 1,
      "is_cancel": 0,
      "is_default": 0,
      "is_active": 1,
      "config_data": null,
      "other_data": null,
      "flag": "COMPLETE",
      "ref_type": "COMPLETE",
      "ref_key_name": null,
      "ref_key_values": null,
      "sort_order": 5,
      "created_at": "2023-08-26 16:13:58",
      "updated_at": "2023-08-26 16:13:58"
    },
    {
      "id": 6,
      "code": "2-2-6",
      "name": "ملغي",
      "color": null,
      "description": "ملغي",
      "is_completed": 0,
      "is_cancel": 1,
      "is_default": 0,
      "is_active": 1,
      "config_data": null,
      "other_data": null,
      "flag": "CANCELLED",
      "ref_type": "CANCELLED",
      "ref_key_name": null,
      "ref_key_values": null,
      "sort_order": 6,
      "created_at": "2023-08-26 16:13:58",
      "updated_at": "2023-08-26 16:13:58"
    }
  ],
  "meta": {
    "pagination": {
      "total": 6,
      "count": 6,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```


### Show Data Record OrdersStates 

```
GET /api/v1/orders/ordersstates/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record OrdersStates 2

```
GET http://localhost:8006/api/v1/orders/ordersstates/2
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "id": 2,
  "code": "2-2-2",
  "name": "جديد",
  "color": null,
  "description": "جديد",
  "is_completed": 0,
  "is_cancel": 0,
  "is_default": 1,
  "is_active": 1,
  "config_data": null,
  "other_data": null,
  "flag": "NEW",
  "ref_type": "NEW",
  "ref_key_name": null,
  "ref_key_values": null,
  "sort_order": 2,
  "created_at": "2023-08-26 16:13:58",
  "updated_at": "2023-08-26 16:13:58"
}
```

### Check Last Update OrdersStates Data 

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/orders/ordersstates/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/orders/ordersstates/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": null
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2022-12-20 18:17:04",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": null
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **