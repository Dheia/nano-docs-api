## Orders  Api

This endpoint allows you to `list`, `show` your orders.

/orders/orders
### The orders object

#### Public Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in orders  records |
| `orderBy`           | `string`  |  using orderBy departments records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy departments records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `order_states`           | `string`  | **Required**. The get Orders  status [all,notComplete,NEW,PROCESSING,DELIVERY,CANCELLED,COMPLETE] default value notComplete    |
| `isActive`           | `boolean`  | **Required**. The get is Active  departments default value true    |
| `companys_id`           | `integer`  |  get records orders to companys_id default value false.         |
| `departments_id`           | `integer`  | get records orders to departments_id default value true.          |
| `tagsId`           | `string `  | useing get orders where tagsId [2,3,4] default value ''
| 
| `isFavorites`           | `boolean `  | useing get orders where my Favorites default value false 
| 
| `include`           | `string `  | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/orders/orders?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `department`           | `belongsTo`  | The get department | 
| `order_types`           | `belongsTo`  | The get order_type | 
| `items`           | `hasMany`  | The get items   | 
| `totals`           | `hasMany`  | The get Totals Records   | 
| `orders_states`           | `belongsTo`  | The get orders_states   |
| `orders_states_company`           | `belongsTo`  | The get orders_states_company   | 
| `payment_method`           | `belongsTo`  | The get payment_method   | 
| `shipping_method`           | `belongsTo`  | The get shipping_method   | 
| `shipping_method_company`           | `belongsTo`  | The get shipping_method_company   | 
| `load_type or load_type_company`           | `belongsTo`  | The get load_type   | 
| `vehicle_type or vehicle_type_company`           | `belongsTo`  | The get vehicle_type   | 
| `car`           | `belongsTo`  | The get car   | 
| `user`           | `belongsTo`  | The get user   | 
| `customer`           | `belongsTo`  | The get customer   | 
| `delivery`           | `belongsTo`  | The get delivery   | 
| `delivery_user`           | `belongsTo`  | The get delivery_user   | 
| `billing_address`           | `belongsTo`  | The get billing_address   | 
| `shipping_address`           | `belongsTo`  | The get shipping_address   | 
| `billing_country`           | `belongsTo`  | The get billing_country   | 
| `shipping_country`           | `belongsTo`  | The get shipping_country   | 
| `billing_state`           | `belongsTo`  | The get billing_state   | 
| `shipping_state`           | `belongsTo`  | The get shipping_state.   | 


### List orders

Returns a list of orders you’

```
GET /api/v1/orders/orders
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

### Example 1 get List Orders  

**فى المثال التالى سنقوم بجلب طلبات المستخدم الحالي  الجديده والتي مازالت قيد انتظار التوصيل **
```
GET http://localhost:8006/api/v1/orders/orders
```

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 10,
      "order_type": "delivery",
      "user_id": 543,
      "customer_id": null,
      "email": "kddd9033@gmail.com",
      "order_states_id": 2,
      "order_states_ref_type": "NEW",
      "user_status": "NEW",
      "shipping_method_id": 1,
      "shipping_method_ref_type": "DELIVERY",
      "shipping_address_id": null,
      "shipping_company": null,
      "shipping_firstname": null,
      "shipping_lastname": null,
      "shipping_phone": null,
      "shipping_email": null,
      "shipping_country": null,
      "shipping_state": "",
      "shipping_address_1": "",
      "shipping_address_2": "",
      "shipping_lines": null,
      "shipping_city": null,
      "shipping_zip": null,
      "shipping_postcode": "",
      "shipping_lat": 0,
      "shipping_lng": 0,
      "shipping_radius": null,
      "billing_differs": 0,
      "billing_address_id": null,
      "billing_company": null,
      "billing_firstname": null,
      "billing_lastname": null,
      "billing_email": null,
      "billing_phone": null,
      "billing_country": null,
      "billing_state": "",
      "billing_address_1": "",
      "billing_address_2": "",
      "billing_lines": null,
      "billing_city": null,
      "billing_zip": null,
      "billing_postcode": "",
      "billing_lat": 0,
      "billing_lng": 0,
      "billing_radius": null,
      "delivery_id": null,
      "delivery_status": "NEW",
      "assignee_id": null,
      "payment_method_id": 1,
      "payment_state": "Nano\\MicroCart\\Classes\\PaymentState\\PendingState",
      "processed": 1,
      "payment_trans_id": null,
      "card_type": null,
      "card_first_name": null,
      "card_last_name": null,
      "card_number": null,
      "card_expiry_month": null,
      "card_expiry_year": null,
      "card_cvv": null,
      "main_currencys_id": "1",
      "currencys_id": "1",
      "rate": "1.000000000000",
      "distance_unit": "km",
      "shipping_price": "500.00",
      "shipping_distance": "5109.166611579733",
      "shipping_total": "2554583.00",
      "subtotal": "1500.0000",
      "cart_total": "1400.0000",
      "order_discount": "-100.0000",
      "order_taxes": null,
      "order_total": "2555983.0000",
      "total_payment_pre_taxes": null,
      "total_payment_taxes": null,
      "total_payment_post_taxes": "2555983.0000",
      "order_date": "2022-12-22 19:02:02",
      "delivery_at": null,
      "shipped_at": null,
      "end_date": null,
      "because_cancel": null,
      "customer_notes": null,
      "admin_notes": null,
      "tracking_number": null,
      "tracking_url": null,
      "ip_address": "127.0.0.1",
      "user_agent": "okhttp\/3.8.1",
      "companys_id": "2",
      "departments_id": "4",
      "paper_id": null,
      "extend_id": null,
      "employees_id": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 10,
      "created_by": null,
      "updated_by": null,
      "deleted_by": null,
      "created_at": "2022-12-22 17:37:13",
      "updated_at": "2022-12-22 19:02:03",
      "deleted_at": null,
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null,
      "object_type": "Nano\\Orders\\Models\\Order",
      "totals": {
        "data": [
          {
            "id": 46,
            "code": "coupon",
            "orders_id": "10",
            "title": "Coupon  [2222]",
            "priority": 200,
            "value": -100,
            "is_summable": true,
            "metaData": {
              "code": "2222"
            },
            "notes": null,
            "companys_id": null,
            "departments_id": null,
            "other_data": null,
            "config_data": null,
            "sort_order": null,
            "created_at": "",
            "updated_at": ""
          },
          {
            "id": 47,
            "code": "subtotal",
            "orders_id": "10",
            "title": "Sub Total",
            "priority": 0,
            "value": 1500,
            "is_summable": false,
            "metaData": false,
            "notes": null,
            "companys_id": null,
            "departments_id": null,
            "other_data": null,
            "config_data": null,
            "sort_order": null,
            "created_at": "",
            "updated_at": ""
          },
          {
            "id": 48,
            "code": "cart_total",
            "orders_id": "10",
            "title": "Cart Total",
            "priority": 999,
            "value": 1400,
            "is_summable": false,
            "metaData": false,
            "notes": null,
            "companys_id": null,
            "departments_id": null,
            "other_data": null,
            "config_data": null,
            "sort_order": null,
            "created_at": "",
            "updated_at": ""
          },
          {
            "id": 49,
            "code": "shipping_total",
            "orders_id": "10",
            "title": "Shipping Total",
            "priority": 999,
            "value": 2554583,
            "is_summable": true,
            "metaData": {
              "shipping_method_id": 1,
              "distance_unit": "km",
              "distance_unit_name": "كيلو متر",
              "shipping_price": "500.00",
              "shipping_distance": "5109.166611579733"
            },
            "notes": null,
            "companys_id": null,
            "departments_id": null,
            "other_data": null,
            "config_data": null,
            "sort_order": null,
            "created_at": "",
            "updated_at": ""
          },
          {
            "id": 50,
            "code": "total",
            "orders_id": "10",
            "title": "Order Total",
            "priority": 999,
            "value": 2555983,
            "is_summable": false,
            "metaData": false,
            "notes": null,
            "companys_id": null,
            "departments_id": null,
            "other_data": null,
            "config_data": null,
            "sort_order": null,
            "created_at": "",
            "updated_at": ""
          }
        ]
      },
      "items": {
        "data": [
          {
            "id": 19,
            "code": "2-4-19",
            "orders_id": "10",
            "kind": "100_item",
            "is_new": false,
            "products_id": "4",
            "custom_name": "حبة دجاج برست",
            "units_id": "1",
            "units_name": "حبه",
            "real_price": 500,
            "quantity": 3,
            "subtotal_discount": 0,
            "subtotal_tax": 0,
            "subtotal": 1500,
            "option_values": [],
            "conditions": null,
            "customer_notes": "ملاحظات على الصنف 4",
            "admin_notes": null,
            "companys_id": "2",
            "departments_id": "4",
            "properties": null,
            "other_data": null,
            "config_data": null,
            "sort_order": 19,
            "created_at": "2022-12-22 19:02:02",
            "updated_at": "2022-12-22 19:02:02"
          }
        ]
      },
      "payment_method": {
        "id": 1,
        "code": "aldfaa-aand-alastlam",
        "name": "الدفع عند الاستلام",
        "description": "<p>الدفع عند الاستلام<\/p>",
        "instructions": null,
        "payment_provider": "CacheOnDelivery",
        "label": "",
        "price": 0,
        "percentage": "0.0000",
        "is_default": false,
        "sort_order": 1,
        "created_at": "2022-12-19 20:32:59",
        "updated_at": "2022-12-20 22:25:38",
        "logo": null
      }
    },
    {
      "id": 9,
      "order_type": "delivery",
      "user_id": 543,
      "customer_id": null,
      "email": "kddd9033@gmail.com",
      "order_states_id": 2,
      "order_states_ref_type": "NEW",
      "user_status": "NEW",
      "shipping_method_id": 1,
      "shipping_method_ref_type": "DELIVERY",
      "shipping_address_id": null,
      "shipping_company": null,
      "shipping_firstname": null,
      "shipping_lastname": null,
      "shipping_phone": null,
      "shipping_email": null,
      "shipping_country": null,
      "shipping_state": "",
      "shipping_address_1": "",
      "shipping_address_2": "",
      "shipping_lines": null,
      "shipping_city": null,
      "shipping_zip": null,
      "shipping_postcode": "",
      "shipping_lat": 0,
      "shipping_lng": 0,
      "shipping_radius": null,
      "billing_differs": 0,
      "billing_address_id": null,
      "billing_company": null,
      "billing_firstname": null,
      "billing_lastname": null,
      "billing_email": null,
      "billing_phone": null,
      "billing_country": null,
      "billing_state": "",
      "billing_address_1": "",
      "billing_address_2": "",
      "billing_lines": null,
      "billing_city": null,
      "billing_zip": null,
      "billing_postcode": "",
      "billing_lat": 0,
      "billing_lng": 0,
      "billing_radius": null,
      "delivery_id": null,
      "delivery_status": "NEW",
      "assignee_id": null,
      "payment_method_id": 1,
      "payment_state": "Nano\\MicroCart\\Classes\\PaymentState\\PendingState",
      "processed": 1,
      "payment_trans_id": null,
      "card_type": null,
      "card_first_name": null,
      "card_last_name": null,
      "card_number": null,
      "card_expiry_month": null,
      "card_expiry_year": null,
      "card_cvv": null,
      "main_currencys_id": "1",
      "currencys_id": "1",
      "rate": "1.000000000000",
      "distance_unit": "km",
      "shipping_price": "500.00",
      "shipping_distance": "5109.166611579733",
      "shipping_total": "2554583.00",
      "subtotal": "4000.0000",
      "cart_total": "3900.0000",
      "order_discount": "-100.0000",
      "order_taxes": null,
      "order_total": "2558483.0000",
      "total_payment_pre_taxes": null,
      "total_payment_taxes": null,
      "total_payment_post_taxes": "2558483.0000",
      "order_date": "2022-12-22 17:37:00",
      "delivery_at": null,
      "shipped_at": null,
      "end_date": null,
      "because_cancel": null,
      "customer_notes": null,
      "admin_notes": null,
      "tracking_number": null,
      "tracking_url": null,
      "ip_address": "127.0.0.1",
      "user_agent": "okhttp\/3.8.1",
      "companys_id": "2",
      "departments_id": "4",
      "paper_id": null,
      "extend_id": null,
      "employees_id": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 9,
      "created_by": null,
      "updated_by": null,
      "deleted_by": null,
      "created_at": "2022-12-22 17:36:36",
      "updated_at": "2022-12-22 17:37:01",
      "deleted_at": null,
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null,
      "object_type": "Nano\\Orders\\Models\\Order",
      "totals": {
        "data": [
          {
            "id": 41,
            "code": "coupon",
            "orders_id": "9",
            "title": "Coupon  [2222]",
            "priority": 200,
            "value": -100,
            "is_summable": true,
            "metaData": {
              "code": "2222"
            },
            "notes": null,
            "companys_id": null,
            "departments_id": null,
            "other_data": null,
            "config_data": null,
            "sort_order": null,
            "created_at": "",
            "updated_at": ""
          },
          {
            "id": 42,
            "code": "subtotal",
            "orders_id": "9",
            "title": "Sub Total",
            "priority": 0,
            "value": 4000,
            "is_summable": false,
            "metaData": false,
            "notes": null,
            "companys_id": null,
            "departments_id": null,
            "other_data": null,
            "config_data": null,
            "sort_order": null,
            "created_at": "",
            "updated_at": ""
          },
          {
            "id": 43,
            "code": "cart_total",
            "orders_id": "9",
            "title": "Cart Total",
            "priority": 999,
            "value": 3900,
            "is_summable": false,
            "metaData": false,
            "notes": null,
            "companys_id": null,
            "departments_id": null,
            "other_data": null,
            "config_data": null,
            "sort_order": null,
            "created_at": "",
            "updated_at": ""
          },
          {
            "id": 44,
            "code": "shipping_total",
            "orders_id": "9",
            "title": "Shipping Total",
            "priority": 999,
            "value": 2554583,
            "is_summable": true,
            "metaData": {
              "shipping_method_id": 1,
              "distance_unit": "km",
              "distance_unit_name": "كيلو متر",
              "shipping_price": "500.00",
              "shipping_distance": "5109.166611579733"
            },
            "notes": null,
            "companys_id": null,
            "departments_id": null,
            "other_data": null,
            "config_data": null,
            "sort_order": null,
            "created_at": "",
            "updated_at": ""
          },
          {
            "id": 45,
            "code": "total",
            "orders_id": "9",
            "title": "Order Total",
            "priority": 999,
            "value": 2558483,
            "is_summable": false,
            "metaData": false,
            "notes": null,
            "companys_id": null,
            "departments_id": null,
            "other_data": null,
            "config_data": null,
            "sort_order": null,
            "created_at": "",
            "updated_at": ""
          }
        ]
      },
      "items": {
        "data": [
          {
            "id": 17,
            "code": "2-4-17",
            "orders_id": "9",
            "kind": "100_item",
            "is_new": false,
            "products_id": "4",
            "custom_name": "حبة دجاج برست",
            "units_id": "2",
            "units_name": "نص",
            "real_price": 200,
            "quantity": 5,
            "subtotal_discount": 0,
            "subtotal_tax": 0,
            "subtotal": 1000,
            "option_values": "a:0:{}",
            "conditions": null,
            "customer_notes": "ملاحظات على الصنف 4",
            "admin_notes": null,
            "companys_id": "2",
            "departments_id": "4",
            "properties": null,
            "other_data": null,
            "config_data": null,
            "sort_order": 17,
            "created_at": "2022-12-22 17:37:00",
            "updated_at": "2022-12-22 17:37:00"
          },
          {
            "id": 18,
            "code": "2-4-18",
            "orders_id": "9",
            "kind": "100_item",
            "is_new": false,
            "products_id": "4",
            "custom_name": "حبة دجاج برست",
            "units_id": "1",
            "units_name": "حبه",
            "real_price": 500,
            "quantity": 6,
            "subtotal_discount": 0,
            "subtotal_tax": 0,
            "subtotal": 3000,
            "option_values": "a:0:{}",
            "conditions": null,
            "customer_notes": "ملاحظات على الصنف 4",
            "admin_notes": null,
            "companys_id": "2",
            "departments_id": "4",
            "properties": null,
            "other_data": null,
            "config_data": null,
            "sort_order": 18,
            "created_at": "2022-12-22 17:37:00",
            "updated_at": "2022-12-22 17:37:00"
          }
        ]
      },
      "payment_method": {
        "id": 1,
        "code": "aldfaa-aand-alastlam",
        "name": "الدفع عند الاستلام",
        "description": "<p>الدفع عند الاستلام<\/p>",
        "instructions": null,
        "payment_provider": "CacheOnDelivery",
        "label": "",
        "price": 0,
        "percentage": "0.0000",
        "is_default": false,
        "sort_order": 1,
        "created_at": "2022-12-19 20:32:59",
        "updated_at": "2022-12-20 22:25:38",
        "logo": null
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 10,
      "count": 2,
      "per_page": 2,
      "current_page": 1,
      "total_pages": 5,
      "links": {
        "next": "http:\/\/localhost:8006\/api\/v1\/orders\/orders?page=2"
      }
    }
  }
}
```

### Example 2 get List Orders  order_states=COMPLETE

** لجلب الطلبات المكتملة  **

**نقوم بارسال البرميتر التالى ضمن الطلب **
```json
{
"order_states":"COMPLETE"
}
```
```
GET http://localhost:8006/api/v1/orders/orders?order_states=COMPLETE
```

#### Response

```html
Status: 200 OK
```

```json
```

### Example 3 get List Orders  order_states=DELIVERY

** لجلب الطلبات التي قيد التوصيل فى الوقت الحالى    **

**نقوم بارسال البرميتر التالى ضمن الطلب **
```json
{
"order_states":"DELIVERY"
}
```

```
GET http://localhost:8006/api/v1/orders/orders?order_states=DELIVERY
```

#### Response

```html
Status: 200 OK
```

```json
```

### Example 4 get List Orders  order_states=CANCELLED

** لجلب الطلبات الملغيه   **

**نقوم بارسال البرميتر التالى ضمن الطلب **
```json
{
"order_states":"CANCELLED"
}
```

```
GET http://localhost:8006/api/v1/orders/orders?order_states=CANCELLED
```

#### Response

```html
Status: 200 OK
```

```json
```

### Example 5 get data Orders  

** لجب بيانات طلب معين نقوم  بتمرير رقم الطلب فى الرابط كا التالى **

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


```
GET /api/v1/orders/orders/{id}
```
```
GET http://localhost:8006/api/v1/orders/orders/4
```

#### Response

```html
Status: 200 OK
```

```json
```
### Example 6 cancelled Orders  

** لالغاء طلب معين للمستخدم الحالي نقوم   بتمرير رقم الطلب فى الرابط كا التالى **

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


```
POST /api/v1/orders/orders/cancelled/{id}
```
```
POST http://localhost:8006/api/v1/orders/orders/cancelled/4
```

**يتم الغاء الطلب فى حاله ان الطلب لم يتم معالجته من قبل الاداره **

**فى حاله كان الطلب قيد التجهيز او قيد التوصيل لان يتم الغاء الطلب ولكن سيتم تغيير حاله الطلب من قبل العميل وسيتم ارسال اشعار الى الاداره بطلبك للالغاء **

#### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم الغاء الطلب بنجاح  ",
}
```

**فى حالة كان الطلب قيد التوصيل او قيد التجهيز سيتم ارجاع البيانات التاليه **

```json
{
  "code": "200",
  "message":" الطلب الخاص بك قيد المعالجه سيتم اعلام الإداره برغبتك بالغاء الطلب يرجاء انتظار تاكيد الإداره لالغاء طلبك بشكل كامل ",
}
```
#### Response 401 Error UNAUTHORIZED 

** يتم ارجاع خطاء فى حاله عدم وجود مستخدم مسجل كا التالي  **

```html
Status: 401 Error UNAUTHORIZED
```

```json
{
  "error": {
    "code": "UNAUTHORIZED",
    "http_code": 401,
    "message": "Invalid user credential."
  }
}
```
#### Response 404 Error Order not found 

** يتم ارجاع خطاء فى حاله عدم وجود رقم الطلب المراد الغائه كا التالي  **

```html
Status: 401 Error UNAUTHORIZED
```

```json
{
  "error": {
    "code": "NOT_FOUND",
    "http_code": 404,
    "message": "Order not found."
  }
}
```

### Example 7 Get My Favorites Orders 

**لجلب الطلبات المفضله للمستخدم الحالى نقوم بتمرير المتغير isFavorites = true **

```
GET /api/v1/orders/orders
```

Required Parameters: `isFavorites = true`

```
GET http://localhost:8006/api/v1/orders/orders?isFavorites=true
```

#### Response

```html
Status: 200 Ok
```

** من خلال السجلات الراجعه فى الاسفل نلاحظ ان الخاصيه  user_is_favorite=true 
بمعنا ان هذا الطلب مضاف الى مفضله المستخدم الحالى **


```json
```



### Example 8 Get Orders  with companys_id or departments_id

** لجلب الطلبات االتابعه لفرع معين او لمتجر معين نستخدم البراميتر companys_id
او البراميتر departments_id**

**ملاحظه يمكنك جلب قيمه companys_id من بيانات الاقسام departmentsوالذي تمثل المتاجر **
```
GET /api/v1/orders/orders
```

Required Parameters: `companys_id`

```
http://localhost:8006/api/v1/orders/orders?companys_id=2
```

#### Response

```html
Status: 200 Ok
```

```json
```

####فى حال تمرير رقم فرع او متجر غير موجود سيتم ارجاع الخطاء التالى 


```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "المتجر المحدد غير موجود ضمن المتاجر تاكد من رقم المتجر "
  }
}
```

