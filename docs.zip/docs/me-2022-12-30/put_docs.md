### Update Current User Data
** يتم استخدام الرابط التالى لتعديل بيانات المستخدم مع تمرير الحقول المراد تعديلها **
```
PUT /api/v1/me
```

```
PUT http://localhost:8006/api/v1/me
```

#### Example update Data User 

** ف ى المثال التالى سنقوم بتعديل رقم الدوله ورقم المدينه  **

```
PUT http://localhost:8006/api/v1/me?country_id=2&state_id=2
```
#### Response

**فى حالة حدوث خطاء سيتم ارجاع الخطاء كالتالى **

```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "تأكيد الخاصية  password  ليس كافياً"
  }
}
```

**فى حال نجحة العمليه سيتم ارجاع بيانات المستخدم بعد التعديل كالتالي :- **

```html
Status: 200 OK
```

```json
{
  "id": 543,
  "name": "dheiaAli1",
  "username": "kddd9033@gmail.com",
  "email": "kddd9033@gmail.com",
  "mobile": null,
  "gender": null,
  "address_1": null,
  "address_2": null,
  "street_name": null,
  "street_number": null,
  "latitude": null,
  "longitude": null,
  "geo_components": null,
  "city": null,
  "zip": null,
  "postcode": null,
  "country_long": null,
  "country_id": "2",
  "state_id": "2",
  "directorate_id": null,
  "formataddress": null,
  "vicinity": null,
  "avatar": null,
  "companys_id": "2",
  "departments_id": "2",
  "employees_id": null,
  "ref_type": "user",
  "ref_id": null,
  "permissions": null,
  "is_guest": false,
  "is_superuser": false,
  "is_activated": true,
  "activated_at": "2022-08-31 20:23:58",
  "last_login": "2022-10-15 22:12:07",
  "created_at": "2022-08-31 20:23:58",
  "updated_at": "2022-10-15 22:12:07",
  "deleted_at": "",
  "created_ip_address": "127.0.0.1",
  "last_ip_address": "127.0.0.1"
}
```
