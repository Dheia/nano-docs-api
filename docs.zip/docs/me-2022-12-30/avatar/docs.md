## Delete avatar User 

**لحذف صورة المستخدم نستخدم الرابط التالى **

```
DELETE /api/v1/me/avatar
```

```
DELETE http://localhost:8006/api/v1/me/avatar
```
#### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم حذف الصوره بنجاح  "
}
```
#### Response Error 
** يتم ارجاع خطاء فى حاله عدم وجود مستخدم مسجل كا التالي  **

```html
Status: 401 Error UNAUTHORIZED
```

```json
{
  "error": {
    "code": "UNAUTHORIZED",
    "http_code": 401,
    "message": "Invalid user credential."
  }
}
```
