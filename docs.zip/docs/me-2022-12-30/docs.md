## Me get Current User Data 

This endpoint allows show user data . 

 GET /me/
### The User object

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| 


#### User Attributes

```json
{
  "id": 543,
  "name": "dheiaAli1",
  "username": "kddd9033@gmail.com",
  "email": "kddd9033@gmail.com",
  "mobile": null,
  "gender": null,
  "address_1": null,
  "address_2": null,
  "street_name": null,
  "street_number": null,
  "latitude": null,
  "longitude": null,
  "geo_components": null,
  "city": null,
  "zip": null,
  "postcode": null,
  "country_long": null,
  "country_id": null,
  "state_id": null,
  "directorate_id": null,
  "formataddress": null,
  "vicinity": null,
  "avatar": null,
  "companys_id": "2",
  "departments_id": "2",
  "employees_id": null,
  "ref_type": "user",
  "ref_id": null,
  "permissions": null,
  "is_guest": false,
  "is_superuser": false,
  "is_activated": true,
  "activated_at": "2022-08-31 20:23:58",
  "last_login": "2022-10-15 20:14:35",
  "created_at": "2022-08-31 20:23:58",
  "updated_at": "2022-10-15 20:14:35",
  "deleted_at": "",
  "created_ip_address": "127.0.0.1",
  "last_ip_address": "127.0.0.1"
}
```


#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `department`           | `belongsTo`  | The department | 
| `groups`           | `belongsTo`  | The get groups    | 
| `notifications`           | `hasMany`  | The get notifications user   | 
| `address`           | `hasMany`  | The get address user   | 
| `country`           | `belongsTo`  | The get country data   | 
| `state`           | `belongsTo`  | The get state data   | 
| `directorate`           | `belongsTo`  | The get directorate data   | 


#### Require Useing token to show User Data

** add Parameters Authorization in headr request **

Authorization = [token_type token]

** Require Authorization in Header Request**

```html
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiOTJiYjhkNWJjZjE4MWYxMjcyMjhlZjc5ODFmYzE5ZWFmOGY1ZjVjMWUxZjg5ZWEzMDVhMDNiMzMxZjM2OWUxYjMzZDA3NWFkM2FlMGE3YTMiLCJpYXQiOjE2NjU4NTUyODcuOTM4NDI1MSwibmJmIjoxNjY1ODU1Mjg3LjkzODQ3NDksImV4cCI6MTY5NzM5MTI4Ny45MDM3Mzk5LCJzdWIiOiI1NDkiLCJzY29wZXMiOltdfQ.uKRNZo1MNtDmdjR3pk00JjPoyE6IcJMvqdqMEOhR7syyw_a584gH4rMW9Jp4Rqq7Rc6ttM9UvKoDUk6Y38oA6elU96PcSk8nRsWZ_grSR7EwSX4DgW8qhEfVGUUm8GRceen12OBYnB3-sHOluVGWotFJdYYjWtWc9pw9otX3a8ZcC1kM3FZDqusYkPRuQiG4PiCsaRL1dRiMyp5cEc1JPma0aZL9iOBqwwB9sJYd9_wYz8S-ZEWBAGXwqbOkhZ9_GYwnfckQlgKiO1pDuX_Au_F138E659BFKNXibvU8rUTi9q15smFJ8icUBHrUhzIcQFjfdgqPQfGXkanJr5BcpByZbQMEqPhe18IBGduNaE53wClR4UL3ighFSmZWUa1ebdq6oKama5-DWDUVF18pi_owiTlkfHyXF-2aEvT-myxC7_9jvfbC3KVrOGCRuHiwWBALcdYP45ogSo7-RVCAupQi9TGrkzU85tEKCuo-JYQ3ATHjCmuW0bHsazM9je2vIe6j_-56v7YBaMR7vxoJ1kk-1rLoiEOg_IbRJ9XuQDCMk7gCOZLS9TmYvLm2oBe4VjTw7GVB8GxwB3mC8OwrcVyubTvNHTgvZH8BOrJDF349uQea4PGvXgySNktMo490zUQqn56uCCcBry3glHpdw-MYbBD5mGt5ma3AP4riLXE
```


#### Response Error 
** يتم ارجاع خطاء فى حاله عدم وجود مستخدم مسجل كا التالي  **

```html
Status: 401 Error UNAUTHORIZED
```

```json
{
  "error": {
    "code": "UNAUTHORIZED",
    "http_code": 401,
    "message": "Invalid user credential."
  }
}
```

### Show Data Current User

Returns a Data User 

```
GET /api/v1/me
```
```
GET http://localhost:8006/api/v1/me
```


#### Response

```html
Status: 200 OK
```

```json
{
  "id": 543,
  "name": "dheiaAli1",
  "username": "kddd9033@gmail.com",
  "email": "kddd9033@gmail.com",
  "mobile": null,
  "gender": null,
  "address_1": null,
  "address_2": null,
  "street_name": null,
  "street_number": null,
  "latitude": null,
  "longitude": null,
  "geo_components": null,
  "city": null,
  "zip": null,
  "postcode": null,
  "country_long": null,
  "country_id": null,
  "state_id": null,
  "directorate_id": null,
  "formataddress": null,
  "vicinity": null,
  "avatar": null,
  "companys_id": "2",
  "departments_id": "2",
  "employees_id": null,
  "ref_type": "user",
  "ref_id": null,
  "permissions": null,
  "is_guest": false,
  "is_superuser": false,
  "is_activated": true,
  "activated_at": "2022-08-31 20:23:58",
  "last_login": "2022-10-15 21:25:30",
  "created_at": "2022-08-31 20:23:58",
  "updated_at": "2022-10-15 21:25:30",
  "deleted_at": "",
  "created_ip_address": "127.0.0.1",
  "last_ip_address": "127.0.0.1"
}
```

### Update Current User Data
** يتم استخدام الرابط التالى لتعديل بيانات المستخدم مع تمرير الحقول المراد تعديلها **
```
PUT /api/v1/me
```

```
PUT http://localhost:8006/api/v1/me
```

#### Example update Data User 

** ف ى المثال التالى سنقوم بتعديل رقم الدوله ورقم المدينه  **

```
PUT http://localhost:8006/api/v1/me?country_id=2&state_id=2
```
#### Response

**فى حالة حدوث خطاء سيتم ارجاع الخطاء كالتالى **

```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "تأكيد الخاصية  password  ليس كافياً"
  }
}
```

**فى حال نجحة العمليه سيتم ارجاع بيانات المستخدم بعد التعديل كالتالي :- **

```html
Status: 200 OK
```

```json
{
  "id": 543,
  "name": "dheiaAli1",
  "username": "kddd9033@gmail.com",
  "email": "kddd9033@gmail.com",
  "mobile": null,
  "gender": null,
  "address_1": null,
  "address_2": null,
  "street_name": null,
  "street_number": null,
  "latitude": null,
  "longitude": null,
  "geo_components": null,
  "city": null,
  "zip": null,
  "postcode": null,
  "country_long": null,
  "country_id": "2",
  "state_id": "2",
  "directorate_id": null,
  "formataddress": null,
  "vicinity": null,
  "avatar": null,
  "companys_id": "2",
  "departments_id": "2",
  "employees_id": null,
  "ref_type": "user",
  "ref_id": null,
  "permissions": null,
  "is_guest": false,
  "is_superuser": false,
  "is_activated": true,
  "activated_at": "2022-08-31 20:23:58",
  "last_login": "2022-10-15 22:12:07",
  "created_at": "2022-08-31 20:23:58",
  "updated_at": "2022-10-15 22:12:07",
  "deleted_at": "",
  "created_ip_address": "127.0.0.1",
  "last_ip_address": "127.0.0.1"
}
```

### Delete avatar User 

**لحذف صورة المستخدم نستخدم الرابط التالى **

```
DELETE /api/v1/me/avatar
```

```
DELETE http://localhost:8006/api/v1/me/avatar
```
#### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم حذف الصوره بنجاح  "
}
```

### Example 1 get Data User and address

```
GET http://localhost:8006/api/v1/me?include=country,state,directorate,address
```

#### Response

```html
Status: 200 OK
```

```json
{
  "id": 543,
  "name": "dheiaAli1",
  "username": "kddd9033@gmail.com",
  "email": "kddd9033@gmail.com",
  "mobile": null,
  "gender": null,
  "address_1": null,
  "address_2": null,
  "street_name": null,
  "street_number": null,
  "latitude": null,
  "longitude": null,
  "geo_components": null,
  "city": null,
  "zip": null,
  "postcode": null,
  "country_long": null,
  "country_id": null,
  "state_id": null,
  "directorate_id": null,
  "formataddress": null,
  "vicinity": null,
  "avatar": null,
  "companys_id": "2",
  "departments_id": "2",
  "employees_id": null,
  "ref_type": "user",
  "ref_id": null,
  "permissions": null,
  "is_guest": false,
  "is_superuser": false,
  "is_activated": true,
  "activated_at": "2022-08-31 20:23:58",
  "last_login": "2022-10-15 22:00:40",
  "created_at": "2022-08-31 20:23:58",
  "updated_at": "2022-10-15 22:00:40",
  "deleted_at": "",
  "created_ip_address": "127.0.0.1",
  "last_ip_address": "127.0.0.1",
  "address": {
    "data": [
      {
        "id": 1,
        "address_1": "اليمن اب 11",
        "address_2": "شارع تعز 1",
        "street_name": null,
        "street_number": null,
        "latitude": 0,
        "longitude": 0,
        "radius": 0,
        "city": null,
        "zip": null,
        "postcode": null,
        "country_long": null,
        "country_id": "2",
        "state_id": "3",
        "directorate_id": null,
        "formataddress": null,
        "vicinity": null,
        "geo_components": null,
        "addressable_type": "RainLab\\User\\Models\\User",
        "addressable_id": 543,
        "user_id": null,
        "user_type": null,
        "is_default": false,
        "is_published": true,
        "is_active": true,
        "created_at": "2022-10-14 22:28:21",
        "updated_at": "2022-10-14 22:29:17",
        "deleted_at": ""
      },
      {
        "id": 2,
        "address_1": "اليمن اب 2",
        "address_2": "شارع تعز 2",
        "street_name": null,
        "street_number": null,
        "latitude": 0,
        "longitude": 0,
        "radius": 0,
        "city": null,
        "zip": null,
        "postcode": null,
        "country_long": null,
        "country_id": "2",
        "state_id": "3",
        "directorate_id": null,
        "formataddress": null,
        "vicinity": null,
        "geo_components": null,
        "addressable_type": "RainLab\\User\\Models\\User",
        "addressable_id": 543,
        "user_id": 543,
        "user_type": "RainLab\\User\\Models\\User",
        "is_default": true,
        "is_published": true,
        "is_active": true,
        "created_at": "2022-10-14 22:19:13",
        "updated_at": "2022-10-14 22:19:13",
        "deleted_at": ""
      }
    ]
  },
  "country": [],
  "state": [],
  "directorate": []
}
```

### Example 2 get Data User and notifications

```
GET http://localhost:8006/api/v1/me?include=notifications
```

#### Response

```html
Status: 200 OK
```

```json
{
  "id": 543,
  "name": "dheiaAli1",
  "username": "kddd9033@gmail.com",
  "email": "kddd9033@gmail.com",
  "mobile": null,
  "gender": null,
  "address_1": null,
  "address_2": null,
  "street_name": null,
  "street_number": null,
  "latitude": null,
  "longitude": null,
  "geo_components": null,
  "city": null,
  "zip": null,
  "postcode": null,
  "country_long": null,
  "country_id": null,
  "state_id": null,
  "directorate_id": null,
  "formataddress": null,
  "vicinity": null,
  "avatar": null,
  "companys_id": "2",
  "departments_id": "2",
  "employees_id": null,
  "ref_type": "user",
  "ref_id": null,
  "permissions": null,
  "is_guest": false,
  "is_superuser": false,
  "is_activated": true,
  "activated_at": "2022-08-31 20:23:58",
  "last_login": "2022-10-15 22:01:15",
  "created_at": "2022-08-31 20:23:58",
  "updated_at": "2022-10-15 22:01:15",
  "deleted_at": "",
  "created_ip_address": "127.0.0.1",
  "last_ip_address": "127.0.0.1",
  "notifications": {
    "data": [
      {
        "id": "3ef8f411-390b-4993-90e2-7c33eb039dd4",
        "event_type": "RainLab\\User\\NotifyRules\\UserActivatedEvent",
        "notifiable_id": 543,
        "notifiable_type": "RainLab\\User\\Models\\User",
        "icon": null,
        "type": null,
        "body": "تم تنشيط الحساب بنجاح",
        "data": {
          "name": "dheiaAli1",
          "email": "kddd9033@gmail.com",
          "username": "kddd9033@gmail.com",
          "login": "kddd9033@gmail.com",
          "password": null,
          "user": {
            "id": 543,
            "name": "dheiaAli1",
            "email": "kddd9033@gmail.com",
            "permissions": null,
            "is_activated": true,
            "activated_at": "2022-08-31 20:23:58",
            "last_login": "2022-10-13 21:29:13",
            "created_at": "2022-08-31 20:23:58",
            "updated_at": "2022-10-13 21:29:13",
            "username": "kddd9033@gmail.com",
            "surname": null,
            "deleted_at": null,
            "last_seen": null,
            "is_guest": 0,
            "is_superuser": 0,
            "iu_gender": null,
            "iu_job": null,
            "iu_about": null,
            "iu_webpage": null,
            "iu_blog": null,
            "iu_facebook": null,
            "iu_twitter": null,
            "iu_skype": null,
            "iu_icq": null,
            "iu_comment": null,
            "iu_telephone": null,
            "iu_company": null,
            "phone": null,
            "company": null,
            "street_addr": null,
            "city": null,
            "zip": null,
            "state_id": null,
            "country_id": null,
            "mobile": null,
            "companys_id": "2",
            "departments_id": "2",
            "employees_id": null,
            "ref_type": "user",
            "barcode": null,
            "manual_code": null,
            "created_by": null,
            "updated_by": null,
            "deleted_by": null,
            "timezone_id": 1,
            "settings": null,
            "created_ip_address": "127.0.0.1",
            "last_ip_address": "127.0.0.1",
            "offline_mall_customer_group_id": null,
            "vdomah_role_id": null,
            "vdomah_roles_role_id": 0
          },
          "isBackend": 0,
          "isConsole": 0,
          "appLocale": "ar",
          "sender": null
        },
        "read_at": "2022-10-13 21:54:27",
        "created_at": "2022-10-13 21:30:03",
        "updated_at": "2022-10-13 21:54:27",
        "parsed_body": "<p>تم تنشيط الحساب بنجاح<\/p>"
      },
      {
        "id": "81a39897-4b74-4f82-9653-679c80ff4f7e",
        "event_type": "RainLab\\User\\NotifyRules\\UserActivatedEvent",
        "notifiable_id": 543,
        "notifiable_type": "RainLab\\User\\Models\\User",
        "icon": null,
        "type": null,
        "body": "تم تنشيط الحساب بنجاح",
        "data": {
          "name": "dheiaAli1",
          "email": "kddd9033@gmail.com",
          "username": "kddd9033@gmail.com",
          "login": "kddd9033@gmail.com",
          "password": null,
          "user": {
            "id": 543,
            "name": "dheiaAli1",
            "email": "kddd9033@gmail.com",
            "permissions": null,
            "is_activated": true,
            "activated_at": "2022-08-31 20:23:58",
            "last_login": "2022-10-13 20:48:34",
            "created_at": "2022-08-31 20:23:58",
            "updated_at": "2022-10-13 20:48:34",
            "username": "kddd9033@gmail.com",
            "surname": null,
            "deleted_at": null,
            "last_seen": null,
            "is_guest": 0,
            "is_superuser": 0,
            "iu_gender": null,
            "iu_job": null,
            "iu_about": null,
            "iu_webpage": null,
            "iu_blog": null,
            "iu_facebook": null,
            "iu_twitter": null,
            "iu_skype": null,
            "iu_icq": null,
            "iu_comment": null,
            "iu_telephone": null,
            "iu_company": null,
            "phone": null,
            "company": null,
            "street_addr": null,
            "city": null,
            "zip": null,
            "state_id": null,
            "country_id": null,
            "mobile": null,
            "companys_id": "2",
            "departments_id": "2",
            "employees_id": null,
            "ref_type": "user",
            "barcode": null,
            "manual_code": null,
            "created_by": null,
            "updated_by": null,
            "deleted_by": null,
            "timezone_id": 1,
            "settings": null,
            "created_ip_address": "127.0.0.1",
            "last_ip_address": "127.0.0.1",
            "offline_mall_customer_group_id": null,
            "vdomah_role_id": null,
            "vdomah_roles_role_id": 0
          },
          "isBackend": 0,
          "isConsole": 0,
          "appLocale": "ar",
          "sender": null
        },
        "read_at": "2022-10-13 21:54:27",
        "created_at": "2022-10-13 21:29:13",
        "updated_at": "2022-10-13 21:54:27",
        "parsed_body": "<p>تم تنشيط الحساب بنجاح<\/p>"
      },
      {
        "id": "d9b4ff74-a4bd-4e9e-97db-6847a747f027",
        "event_type": "RainLab\\User\\NotifyRules\\UserActivatedEvent",
        "notifiable_id": 543,
        "notifiable_type": "RainLab\\User\\Models\\User",
        "icon": null,
        "type": null,
        "body": "تم تنشيط الحساب بنجاح",
        "data": {
          "name": "dheiaAli1",
          "email": "kddd9033@gmail.com",
          "username": "kddd9033@gmail.com",
          "login": "kddd9033@gmail.com",
          "password": null,
          "user": {
            "id": 543,
            "name": "dheiaAli1",
            "email": "kddd9033@gmail.com",
            "permissions": null,
            "is_activated": true,
            "activated_at": "2022-08-31 20:23:58",
            "last_login": "2022-10-13 20:47:11",
            "created_at": "2022-08-31 20:23:58",
            "updated_at": "2022-10-13 20:47:11",
            "username": "kddd9033@gmail.com",
            "surname": null,
            "deleted_at": null,
            "last_seen": null,
            "is_guest": 0,
            "is_superuser": 0,
            "iu_gender": null,
            "iu_job": null,
            "iu_about": null,
            "iu_webpage": null,
            "iu_blog": null,
            "iu_facebook": null,
            "iu_twitter": null,
            "iu_skype": null,
            "iu_icq": null,
            "iu_comment": null,
            "iu_telephone": null,
            "iu_company": null,
            "phone": null,
            "company": null,
            "street_addr": null,
            "city": null,
            "zip": null,
            "state_id": null,
            "country_id": null,
            "mobile": null,
            "companys_id": "2",
            "departments_id": "2",
            "employees_id": null,
            "ref_type": "user",
            "barcode": null,
            "manual_code": null,
            "created_by": null,
            "updated_by": null,
            "deleted_by": null,
            "timezone_id": 1,
            "settings": null,
            "created_ip_address": "127.0.0.1",
            "last_ip_address": "127.0.0.1",
            "offline_mall_customer_group_id": null,
            "vdomah_role_id": null,
            "vdomah_roles_role_id": 0
          },
          "isBackend": 0,
          "isConsole": 0,
          "appLocale": "ar",
          "sender": null
        },
        "read_at": "2022-10-13 21:54:27",
        "created_at": "2022-10-13 20:48:34",
        "updated_at": "2022-10-13 21:54:27",
        "parsed_body": "<p>تم تنشيط الحساب بنجاح<\/p>"
      },
      {
        "id": "872c2b99-2962-49cd-ae32-2b5bc96347d6",
        "event_type": "RainLab\\User\\NotifyRules\\UserActivatedEvent",
        "notifiable_id": 543,
        "notifiable_type": "RainLab\\User\\Models\\User",
        "icon": null,
        "type": null,
        "body": "تم تنشيط الحساب بنجاح",
        "data": {
          "name": "dheiaAli1",
          "email": "kddd9033@gmail.com",
          "username": "kddd9033@gmail.com",
          "login": "kddd9033@gmail.com",
          "password": null,
          "user": {
            "id": 543,
            "name": "dheiaAli1",
            "email": "kddd9033@gmail.com",
            "permissions": null,
            "is_activated": true,
            "activated_at": "2022-08-31 20:23:58",
            "last_login": "2022-10-13 20:29:59",
            "created_at": "2022-08-31 20:23:58",
            "updated_at": "2022-10-13 20:29:59",
            "username": "kddd9033@gmail.com",
            "surname": null,
            "deleted_at": null,
            "last_seen": null,
            "is_guest": 0,
            "is_superuser": 0,
            "iu_gender": null,
            "iu_job": null,
            "iu_about": null,
            "iu_webpage": null,
            "iu_blog": null,
            "iu_facebook": null,
            "iu_twitter": null,
            "iu_skype": null,
            "iu_icq": null,
            "iu_comment": null,
            "iu_telephone": null,
            "iu_company": null,
            "phone": null,
            "company": null,
            "street_addr": null,
            "city": null,
            "zip": null,
            "state_id": null,
            "country_id": null,
            "mobile": null,
            "companys_id": "2",
            "departments_id": "2",
            "employees_id": null,
            "ref_type": "user",
            "barcode": null,
            "manual_code": null,
            "created_by": null,
            "updated_by": null,
            "deleted_by": null,
            "timezone_id": 1,
            "settings": null,
            "created_ip_address": "127.0.0.1",
            "last_ip_address": "127.0.0.1",
            "offline_mall_customer_group_id": null,
            "vdomah_role_id": null,
            "vdomah_roles_role_id": 0
          },
          "isBackend": 0,
          "isConsole": 0,
          "appLocale": "ar",
          "sender": null
        },
        "read_at": "2022-10-13 21:54:27",
        "created_at": "2022-10-13 20:47:11",
        "updated_at": "2022-10-13 21:54:27",
        "parsed_body": "<p>تم تنشيط الحساب بنجاح<\/p>"
      },
      {
        "id": "cff82184-8f52-49fd-9962-6aafebebfa09",
        "event_type": "RainLab\\User\\NotifyRules\\UserActivatedEvent",
        "notifiable_id": 543,
        "notifiable_type": "RainLab\\User\\Models\\User",
        "icon": null,
        "type": null,
        "body": "تم تنشيط الحساب بنجاح",
        "data": {
          "name": "dheiaAli1",
          "email": "kddd9033@gmail.com",
          "username": "kddd9033@gmail.com",
          "login": "kddd9033@gmail.com",
          "password": null,
          "user": {
            "id": 543,
            "name": "dheiaAli1",
            "email": "kddd9033@gmail.com",
            "permissions": null,
            "is_activated": true,
            "activated_at": "2022-08-31 20:23:58",
            "last_login": "2022-10-13 20:28:46",
            "created_at": "2022-08-31 20:23:58",
            "updated_at": "2022-10-13 20:28:46",
            "username": "kddd9033@gmail.com",
            "surname": null,
            "deleted_at": null,
            "last_seen": null,
            "is_guest": 0,
            "is_superuser": 0,
            "iu_gender": null,
            "iu_job": null,
            "iu_about": null,
            "iu_webpage": null,
            "iu_blog": null,
            "iu_facebook": null,
            "iu_twitter": null,
            "iu_skype": null,
            "iu_icq": null,
            "iu_comment": null,
            "iu_telephone": null,
            "iu_company": null,
            "phone": null,
            "company": null,
            "street_addr": null,
            "city": null,
            "zip": null,
            "state_id": null,
            "country_id": null,
            "mobile": null,
            "companys_id": "2",
            "departments_id": "2",
            "employees_id": null,
            "ref_type": "user",
            "barcode": null,
            "manual_code": null,
            "created_by": null,
            "updated_by": null,
            "deleted_by": null,
            "timezone_id": 1,
            "settings": null,
            "created_ip_address": "127.0.0.1",
            "last_ip_address": "127.0.0.1",
            "offline_mall_customer_group_id": null,
            "vdomah_role_id": null,
            "vdomah_roles_role_id": 0
          },
          "isBackend": 0,
          "isConsole": 0,
          "appLocale": "ar",
          "sender": null
        },
        "read_at": "2022-10-13 21:54:27",
        "created_at": "2022-10-13 20:29:59",
        "updated_at": "2022-10-13 21:54:27",
        "parsed_body": "<p>تم تنشيط الحساب بنجاح<\/p>"
      },
      {
        "id": "33bec64a-0b73-4d44-8323-41f92c799d46",
        "event_type": "RainLab\\User\\NotifyRules\\UserActivatedEvent",
        "notifiable_id": 543,
        "notifiable_type": "RainLab\\User\\Models\\User",
        "icon": null,
        "type": null,
        "body": "تم تنشيط الحساب بنجاح",
        "data": {
          "name": "dheiaAli1",
          "email": "kddd9033@gmail.com",
          "username": "kddd9033@gmail.com",
          "login": "kddd9033@gmail.com",
          "password": null,
          "user": {
            "id": 543,
            "name": "dheiaAli1",
            "email": "kddd9033@gmail.com",
            "permissions": null,
            "is_activated": true,
            "activated_at": "2022-08-31 20:23:58",
            "last_login": "2022-10-13 20:26:14",
            "created_at": "2022-08-31 20:23:58",
            "updated_at": "2022-10-13 20:26:14",
            "username": "kddd9033@gmail.com",
            "surname": null,
            "deleted_at": null,
            "last_seen": null,
            "is_guest": 0,
            "is_superuser": 0,
            "iu_gender": null,
            "iu_job": null,
            "iu_about": null,
            "iu_webpage": null,
            "iu_blog": null,
            "iu_facebook": null,
            "iu_twitter": null,
            "iu_skype": null,
            "iu_icq": null,
            "iu_comment": null,
            "iu_telephone": null,
            "iu_company": null,
            "phone": null,
            "company": null,
            "street_addr": null,
            "city": null,
            "zip": null,
            "state_id": null,
            "country_id": null,
            "mobile": null,
            "companys_id": "2",
            "departments_id": "2",
            "employees_id": null,
            "ref_type": "user",
            "barcode": null,
            "manual_code": null,
            "created_by": null,
            "updated_by": null,
            "deleted_by": null,
            "timezone_id": 1,
            "settings": null,
            "created_ip_address": "127.0.0.1",
            "last_ip_address": "127.0.0.1",
            "offline_mall_customer_group_id": null,
            "vdomah_role_id": null,
            "vdomah_roles_role_id": 0
          },
          "isBackend": 0,
          "isConsole": 0,
          "appLocale": "ar",
          "sender": null
        },
        "read_at": "2022-10-13 21:54:27",
        "created_at": "2022-10-13 20:28:46",
        "updated_at": "2022-10-13 21:54:27",
        "parsed_body": "<p>تم تنشيط الحساب بنجاح<\/p>"
      },
      {
        "id": "a71f0d7a-81f5-4ebb-a2b6-dbacceeb8c69",
        "event_type": "RainLab\\User\\NotifyRules\\UserActivatedEvent",
        "notifiable_id": 543,
        "notifiable_type": "RainLab\\User\\Models\\User",
        "icon": null,
        "type": null,
        "body": null,
        "data": {
          "name": "dheiaAli1",
          "email": "kddd9033@gmail.com",
          "username": "kddd9033@gmail.com",
          "login": "kddd9033@gmail.com",
          "password": null,
          "user": {
            "id": 543,
            "name": "dheiaAli1",
            "email": "kddd9033@gmail.com",
            "permissions": null,
            "is_activated": true,
            "activated_at": "2022-08-31 20:23:58",
            "last_login": "2022-10-02 22:35:55",
            "created_at": "2022-08-31 20:23:58",
            "updated_at": "2022-10-02 22:35:55",
            "username": "kddd9033@gmail.com",
            "surname": null,
            "deleted_at": null,
            "last_seen": null,
            "is_guest": 0,
            "is_superuser": 0,
            "iu_gender": null,
            "iu_job": null,
            "iu_about": null,
            "iu_webpage": null,
            "iu_blog": null,
            "iu_facebook": null,
            "iu_twitter": null,
            "iu_skype": null,
            "iu_icq": null,
            "iu_comment": null,
            "iu_telephone": null,
            "iu_company": null,
            "phone": null,
            "company": null,
            "street_addr": null,
            "city": null,
            "zip": null,
            "state_id": null,
            "country_id": null,
            "mobile": null,
            "companys_id": "2",
            "departments_id": "2",
            "employees_id": null,
            "ref_type": "user",
            "barcode": null,
            "manual_code": null,
            "created_by": null,
            "updated_by": null,
            "deleted_by": null,
            "timezone_id": 1,
            "settings": null,
            "created_ip_address": "127.0.0.1",
            "last_ip_address": "127.0.0.1",
            "offline_mall_customer_group_id": null,
            "vdomah_role_id": null,
            "vdomah_roles_role_id": 0
          },
          "isBackend": 1,
          "isConsole": 0,
          "appLocale": "ar",
          "sender": null
        },
        "read_at": "2022-10-13 21:54:27",
        "created_at": "2022-10-02 22:37:58",
        "updated_at": "2022-10-13 21:54:27",
        "parsed_body": ""
      },
      {
        "id": "467315c5-0858-42af-bfd6-41b321e8c00a",
        "event_type": "RainLab\\User\\NotifyRules\\UserActivatedEvent",
        "notifiable_id": 543,
        "notifiable_type": "RainLab\\User\\Models\\User",
        "icon": null,
        "type": null,
        "body": null,
        "data": {
          "name": "dheiaAli1",
          "email": "kddd9033@gmail.com",
          "username": "kddd9033@gmail.com",
          "login": "kddd9033@gmail.com",
          "password": null,
          "user": {
            "id": 543,
            "name": "dheiaAli1",
            "email": "kddd9033@gmail.com",
            "permissions": null,
            "is_activated": true,
            "activated_at": "2022-08-31 20:23:58",
            "last_login": "2022-10-02 22:35:55",
            "created_at": "2022-08-31 20:23:58",
            "updated_at": "2022-10-02 22:35:55",
            "username": "kddd9033@gmail.com",
            "surname": null,
            "deleted_at": null,
            "last_seen": null,
            "is_guest": 0,
            "is_superuser": 0,
            "iu_gender": null,
            "iu_job": null,
            "iu_about": null,
            "iu_webpage": null,
            "iu_blog": null,
            "iu_facebook": null,
            "iu_twitter": null,
            "iu_skype": null,
            "iu_icq": null,
            "iu_comment": null,
            "iu_telephone": null,
            "iu_company": null,
            "phone": null,
            "company": null,
            "street_addr": null,
            "city": null,
            "zip": null,
            "state_id": null,
            "country_id": null,
            "mobile": null,
            "companys_id": "2",
            "departments_id": "2",
            "employees_id": null,
            "ref_type": "user",
            "barcode": null,
            "manual_code": null,
            "created_by": null,
            "updated_by": null,
            "deleted_by": null,
            "timezone_id": 1,
            "settings": null,
            "created_ip_address": "127.0.0.1",
            "last_ip_address": "127.0.0.1",
            "offline_mall_customer_group_id": null,
            "vdomah_role_id": null,
            "vdomah_roles_role_id": 0
          },
          "isBackend": 0,
          "isConsole": 0,
          "appLocale": "ar",
          "sender": null
        },
        "read_at": "2022-10-13 21:54:27",
        "created_at": "2022-10-02 22:37:55",
        "updated_at": "2022-10-13 21:54:27",
        "parsed_body": ""
      },
      {
        "id": "6687445d-4fac-429a-b21a-262d1a76f7ee",
        "event_type": "RainLab\\User\\NotifyRules\\UserActivatedEvent",
        "notifiable_id": 543,
        "notifiable_type": "RainLab\\User\\Models\\User",
        "icon": null,
        "type": null,
        "body": null,
        "data": {
          "name": "dheiaAli1",
          "email": "kddd9033@gmail.com",
          "username": "kddd9033@gmail.com",
          "login": "kddd9033@gmail.com",
          "password": null,
          "user": {
            "id": 543,
            "name": "dheiaAli1",
            "email": "kddd9033@gmail.com",
            "permissions": null,
            "is_activated": true,
            "activated_at": "2022-08-31 20:23:58",
            "last_login": "2022-10-02 22:35:55",
            "created_at": "2022-08-31 20:23:58",
            "updated_at": "2022-10-02 22:35:55",
            "username": "kddd9033@gmail.com",
            "surname": null,
            "deleted_at": null,
            "last_seen": null,
            "is_guest": 0,
            "is_superuser": 0,
            "iu_gender": null,
            "iu_job": null,
            "iu_about": null,
            "iu_webpage": null,
            "iu_blog": null,
            "iu_facebook": null,
            "iu_twitter": null,
            "iu_skype": null,
            "iu_icq": null,
            "iu_comment": null,
            "iu_telephone": null,
            "iu_company": null,
            "phone": null,
            "company": null,
            "street_addr": null,
            "city": null,
            "zip": null,
            "state_id": null,
            "country_id": null,
            "mobile": null,
            "companys_id": "2",
            "departments_id": "2",
            "employees_id": null,
            "ref_type": "user",
            "barcode": null,
            "manual_code": null,
            "created_by": null,
            "updated_by": null,
            "deleted_by": null,
            "timezone_id": 1,
            "settings": null,
            "created_ip_address": "127.0.0.1",
            "last_ip_address": "127.0.0.1",
            "offline_mall_customer_group_id": null,
            "vdomah_role_id": null,
            "vdomah_roles_role_id": 0
          },
          "isBackend": 0,
          "isConsole": 0,
          "appLocale": "ar",
          "sender": null
        },
        "read_at": "2022-10-13 21:54:27",
        "created_at": "2022-10-02 22:37:55",
        "updated_at": "2022-10-13 21:54:27",
        "parsed_body": ""
      },
      {
        "id": "dade4731-eb01-4329-aa87-62b249942095",
        "event_type": "RainLab\\User\\NotifyRules\\UserActivatedEvent",
        "notifiable_id": 543,
        "notifiable_type": "RainLab\\User\\Models\\User",
        "icon": null,
        "type": null,
        "body": null,
        "data": {
          "name": "dheiaAli1",
          "email": "kddd9033@gmail.com",
          "username": "kddd9033@gmail.com",
          "login": "kddd9033@gmail.com",
          "password": null,
          "user": {
            "id": 543,
            "name": "dheiaAli1",
            "email": "kddd9033@gmail.com",
            "permissions": null,
            "is_activated": true,
            "activated_at": "2022-08-31 20:23:58",
            "last_login": "2022-10-02 22:35:55",
            "created_at": "2022-08-31 20:23:58",
            "updated_at": "2022-10-02 22:35:55",
            "username": "kddd9033@gmail.com",
            "surname": null,
            "deleted_at": null,
            "last_seen": null,
            "is_guest": 0,
            "is_superuser": 0,
            "iu_gender": null,
            "iu_job": null,
            "iu_about": null,
            "iu_webpage": null,
            "iu_blog": null,
            "iu_facebook": null,
            "iu_twitter": null,
            "iu_skype": null,
            "iu_icq": null,
            "iu_comment": null,
            "iu_telephone": null,
            "iu_company": null,
            "phone": null,
            "company": null,
            "street_addr": null,
            "city": null,
            "zip": null,
            "state_id": null,
            "country_id": null,
            "mobile": null,
            "companys_id": "2",
            "departments_id": "2",
            "employees_id": null,
            "ref_type": "user",
            "barcode": null,
            "manual_code": null,
            "created_by": null,
            "updated_by": null,
            "deleted_by": null,
            "timezone_id": 1,
            "settings": null,
            "created_ip_address": "127.0.0.1",
            "last_ip_address": "127.0.0.1",
            "offline_mall_customer_group_id": null,
            "vdomah_role_id": null,
            "vdomah_roles_role_id": 0
          },
          "isBackend": 1,
          "isConsole": 0,
          "appLocale": "ar",
          "sender": null
        },
        "read_at": "2022-10-13 21:54:27",
        "created_at": "2022-10-02 22:37:50",
        "updated_at": "2022-10-13 21:54:27",
        "parsed_body": ""
      }
    ]
  }
}
```
