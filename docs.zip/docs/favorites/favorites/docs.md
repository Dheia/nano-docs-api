## Favorites Api 

This endpoint allows Favorites user. 

**هذا الجزء خاص بالمفضله واضافه الاصناف او المتاجر او اي كائن ضمن النظام الى مفضلة المستخدم **
 
```
GET /api/v1/favorites/favorites
```

### The Favorites object

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `object_type`           | `string` | object class name 
| 
| `object_id`           | `string` |  identify object id
| 
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

** object_type اسم المتغير الخاص بحمل اسم الكائن المراد اضافته الى المفضله **

**object_id اسم المتغير الخاص بحمل رقم معرف  الكائن المراد اضافته الى المفضله **

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/favorites/favorites?exclude=created_at,updated_at
```


#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `user`           | `belongsTo`  | The get user data |


#### Require Useing token User to add or delete Favorites

** add Parameters Authorization in headr request **

Authorization = [token_type token]

** Require Authorization in Header Request**

```html
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiOTJiYjhkNWJjZjE4MWYxMjcyMjhlZjc5ODFmYzE5ZWFmOGY1ZjVjMWUxZjg5ZWEzMDVhMDNiMzMxZjM2OWUxYjMzZDA3NWFkM2FlMGE3YTMiLCJpYXQiOjE2NjU4NTUyODcuOTM4NDI1MSwibmJmIjoxNjY1ODU1Mjg3LjkzODQ3NDksImV4cCI6MTY5NzM5MTI4Ny45MDM3Mzk5LCJzdWIiOiI1NDkiLCJzY29wZXMiOltdfQ.uKRNZo1MNtDmdjR3pk00JjPoyE6IcJMvqdqMEOhR7syyw_a584gH4rMW9Jp4Rqq7Rc6ttM9UvKoDUk6Y38oA6elU96PcSk8nRsWZ_grSR7EwSX4DgW8qhEfVGUUm8GRceen12OBYnB3-sHOluVGWotFJdYYjWtWc9pw9otX3a8ZcC1kM3FZDqusYkPRuQiG4PiCsaRL1dRiMyp5cEc1JPma0aZL9iOBqwwB9sJYd9_wYz8S-ZEWBAGXwqbOkhZ9_GYwnfckQlgKiO1pDuX_Au_F138E659BFKNXibvU8rUTi9q15smFJ8icUBHrUhzIcQFjfdgqPQfGXkanJr5BcpByZbQMEqPhe18IBGduNaE53wClR4UL3ighFSmZWUa1ebdq6oKama5-DWDUVF18pi_owiTlkfHyXF-2aEvT-myxC7_9jvfbC3KVrOGCRuHiwWBALcdYP45ogSo7-RVCAupQi9TGrkzU85tEKCuo-JYQ3ATHjCmuW0bHsazM9je2vIe6j_-56v7YBaMR7vxoJ1kk-1rLoiEOg_IbRJ9XuQDCMk7gCOZLS9TmYvLm2oBe4VjTw7GVB8GxwB3mC8OwrcVyubTvNHTgvZH8BOrJDF349uQea4PGvXgySNktMo490zUQqn56uCCcBry3glHpdw-MYbBD5mGt5ma3AP4riLXE
```

### Add Favorites object
**لاضافه كائن معين يجب ان يكون المستخدم مسجل دخول على النظام **

```
POST /api/v1/favorites/favorites/add
```

**يجب تمرير اسم الكائن المراد اضافته الى المفضله مع معرف  الكائن id **

#### Example 1 Add Product 2 from Favorites list Current User

**فى المثال التالى سنقوم باضافه الصنف رقم 2 من قائمه مفضله المستخدم الحالى **

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
}
```

```
GET http://localhost:8006/api/v1/favorites/favorites/add?include=user&object_type=\Nano\Shop\Models\Product&object_id=2

```

##### Response

**في حال تمت عمليه الاضافه الى المفضله بنجاح سيتم ارجاع النتيجه التاليه **


```html
Status: 200 OK
```

```json
{
  "favoriteable_type": "products",
  "favoriteable_id": 2,
  "user_id": 543,
  "created_at": "2022-10-11 22:14:16",
  "updated_at": "2022-10-11 22:14:16",
  "user": {
    "id": 543,
    "name": "dheiaAli1",
    "email": "kddd9033@gmail.com",
    "permissions": null,
    "is_activated": true,
    "activated_at": "2022-08-31 20:23:58",
    "last_login": "2022-10-11 22:59:36",
    "created_at": "2022-08-31 20:23:58",
    "updated_at": "2022-10-11 22:59:36",
    "username": "kddd9033@gmail.com",
    "surname": null,
    "deleted_at": null,
    "last_seen": null,
    "is_guest": 0,
    "is_superuser": 0,
    "iu_gender": null,
    "iu_job": null,
    "iu_about": null,
    "iu_webpage": null,
    "iu_blog": null,
    "iu_facebook": null,
    "iu_twitter": null,
    "iu_skype": null,
    "iu_icq": null,
    "iu_comment": null,
    "iu_telephone": null,
    "iu_company": null,
    "phone": null,
    "company": null,
    "street_addr": null,
    "city": null,
    "zip": null,
    "state_id": null,
    "country_id": null,
    "mobile": null,
    "companys_id": "2",
    "departments_id": "2",
    "employees_id": null,
    "ref_type": "user",
    "barcode": null,
    "manual_code": null,
    "created_by": null,
    "updated_by": null,
    "deleted_by": null,
    "timezone_id": 1,
    "settings": null,
    "created_ip_address": "127.0.0.1",
    "last_ip_address": "127.0.0.1",
    "offline_mall_customer_group_id": null,
    "vdomah_role_id": null,
    "vdomah_roles_role_id": 0
  }
}
```

**لاحظ انه فى النتيجه السابقه تم ارجاع بيانات السجل فى جدول المفضله مع بيانات المستخدم الذي قام باضافه الصنف رقم 2 الي قائمه مفضلته وذلك لاننا قمنا بتضمين العلاقه user فى الطلب **

### Response Error 
**فى بعض الحالات يتم ارجاع خطاء عن محاوله جلب قائمه المفضله او فى حاله الاضافه او الحذف سنستعرض هذه الاخطاء **

#### Response 401 Error UNAUTHORIZED 

** يتم ارجاع خطاء فى حاله عدم وجود مستخدم مسجل كا التالي  **

```html
Status: 401 Error UNAUTHORIZED
```

```json
{
  "error": {
    "code": "UNAUTHORIZED",
    "http_code": 401,
    "message": "Invalid user credential."
  }
}
```

#### Response 404 Error NOT_FOUND 

**خطاء عدم وجود الكائن المراد اضافته الى المفضله او عدم وجود رقم الكائن كا التالي  **

```html
Status: 404 Error NOT_FOUND
```

```json
{
  "error": {
    "code": "NOT_FOUND",
    "http_code": 404,
    "message": "object_type not found."
  }
}
```

or

```json
{
  "error": {
    "code": "NOT_FOUND",
    "http_code": 404,
    "message": "Object id 28 not  found."
  }
}
```

### Delete Object in Favorites List Current User

**لحذف كائن من قائمه المفضلة للمستخدم الحالى نستخدم الرابط التالي معا تمرير البرامترات كما فى جزء الاضافه **

```
DELETE /api/v1/favorites/favorites/delete
```

**يجب تمرير اسم الكائن المراد حذفه من  المفضله مع معرف  الكائن id **

#### Example 2 Delete Product 2 from Favorites list Current User

**فى المثال التالى سنقوم بحذف  الصنف رقم 2 الى قائمه مفضله المستخدم الحالى **

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
}
```

```
DELETE http://localhost:8006/api/v1/favorites/favorites/delete?object_type=\Nano\Shop\Models\Product&object_id=2
```

##### Response

**في حال تمت عمليه الحذف من المفضله بنجاح سيتم ارجاع النتيجه التاليه **


```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم حذف الكائن من المفضله "
}
```

**فى حال حدث خطاء سيتم ارجع الخطاء كما وضحنا فى جزء الاخطاء سابقا**

### Toggle Favorites Object in List Current User

**تعمل هذه الداله عمل دالة الاضافه ودالة الحذف فى نفس الوقت **

**بمعنا انه فى حال لم يتم اضافه الكائن للمفضله من قبل يتم اضافته **

**وفى حال انه قد تم اضافة الكائن الى المفضله من قبل  تقوم ب **

**يمكن استخدام هذه الداله فى كل الحالات بحيث ستقوم الداله بالفحص والتنفيذ **

```
POST /api/v1/favorites/favorites/toggle
```

**يجب تمرير اسم الكائن  مع معرف  الكائن id **

#### Example 3 Use Toggle Add Product 2 from Favorites list Current User

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
}
```

```
POST http://localhost:8006/api/v1/favorites/favorites/toggle?object_type=\Nano\Shop\Models\Product&object_id=2
```

##### Response

**بما ان الصنف رقم 2 غير مضاف الى مفضله المستخدم الحالى ستكون النتيجه كا التالى  **


```html
Status: 200 OK
```

```json
{
  "favoriteable_type": "products",
  "favoriteable_id": 2,
  "user_id": 543,
  "created_at": "2022-10-11 23:29:22",
  "updated_at": "2022-10-11 23:29:22"
}
```

**فى حال حدث خطاء سيتم ارجع الخطاء كما وضحنا فى جزء الاخطاء سابقا**

#### Example 4 Use Toggle Delete Product 2 from Favorites list Current User

**فى المثال التالى سنقوم بحذف  الصنف رقم 2 من مفضلة المستخدم الحالى **

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
}
```

```
POST http://localhost:8006/api/v1/favorites/favorites/toggle?object_type=\Nano\Shop\Models\Product&object_id=2
```

##### Response

**فى هذه الحالة ستقوم الدالة بالفحص هل الصنف مضافه الى مفضله المستخدم  نعم سيتم حذفه **


```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم حذف الكائن من المفضله "
}
```

**فى حال حدث خطاء سيتم ارجع الخطاء كما وضحنا فى جزء الاخطاء سابقا**

### Get Favorites List 

 **يمكنك جلب  قائمه المفضله لنوع معين من الكائنات او لكافه الكائنات من خلال الرابط التالي **

```
GET /api/v1/favorites/favorites
```

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isUser`           | `boolean`  | use not curent user deafult value true
| 
| `object_type`           | `string`  | object class name 
| 
| `object_id`           | `string`  |  identify object id
| 
| `include`           | `string` | get relation using [relation1,relation2,relation3]

**isUser**
**يتم استخدام المتغير السابق فى حاله اردنا جلب جميع الاصناف التي قام المستخدمون باضافتها الى مفضلتهم وذلك بجعل قيمة المتغير صفر **

** object_type اسم المتغير الخاص بحمل اسم الكائن **

**object_id اسم المتغير الخاص بحمل رقم معرف  الكائن **


#### Example 5 

**فى المثال التالي سنقوم بجلب كافه الاصناف التي اضافها المستخدمون الى مفضلتهم **

```
GET http://localhost:8006/api/v1/favorites/favorites?isUser=0&object_type=Nano\Shop\Models\Product
```

**البيانات التي تم تمريرها كا التالي **

```json
{
  "isUser":0,
  "object_type":"\Nano\Shop\Models\Product",
}
```


##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "favoriteable_type": "products",
      "favoriteable_id": 4,
      "user_id": 1,
      "created_at": "2022-10-11 22:14:16",
      "updated_at": "2022-10-11 22:14:16"
    },
    {
      "favoriteable_type": "products",
      "favoriteable_id": 2,
      "user_id": 543,
      "created_at": "2022-10-11 22:14:16",
      "updated_at": "2022-10-11 22:14:16"
    },
    {
      "favoriteable_type": "products",
      "favoriteable_id": 2,
      "user_id": 544,
      "created_at": "2022-10-11 22:14:16",
      "updated_at": "2022-10-11 22:14:16"
    },
    {
      "favoriteable_type": "products",
      "favoriteable_id": 4,
      "user_id": 544,
      "created_at": "2022-10-11 22:14:16",
      "updated_at": "2022-10-11 22:14:16"
    },
    {
      "favoriteable_type": "products",
      "favoriteable_id": 4,
      "user_id": 543,
      "created_at": "2022-10-09 23:46:35",
      "updated_at": "2022-10-09 23:46:35"
    }
  ],
  "meta": {
    "pagination": {
      "total": 5,
      "count": 5,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

#### Example 6 

**فى المثال التالي سنقوم بجلب كافه الاشخاص الذين قامو باضافه الصنف رقم 2 الى مفضلتهم  **

```
GET http://localhost:8006/api/v1/favorites/favorites?include=user&isUser=0&object_type=Nano\Shop\Models\Product&object_id=2
```

**البيانات التي تم تمريرها كا التالي **

```json
{
  "include":"user",
  "isUser":0,
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
}
```

##### Response

```html
Status: 200 OK
```

```json
 {
  "data": [
    {
      "favoriteable_type": "products",
      "favoriteable_id": 2,
      "user_id": 543,
      "created_at": "2022-10-11 22:14:16",
      "updated_at": "2022-10-11 22:14:16",
      "user": {
        "id": 543,
        "name": "dheiaAli1",
        "email": "kddd9033@gmail.com",
        "permissions": null,
        "is_activated": true,
        "activated_at": "2022-08-31 20:23:58",
        "last_login": "2022-10-11 22:28:47",
        "created_at": "2022-08-31 20:23:58",
        "updated_at": "2022-10-11 22:28:47",
        "username": "kddd9033@gmail.com",
        "surname": null,
        "deleted_at": null,
        "last_seen": null,
        "is_guest": 0,
        "is_superuser": 0,
        "iu_gender": null,
        "iu_job": null,
        "iu_about": null,
        "iu_webpage": null,
        "iu_blog": null,
        "iu_facebook": null,
        "iu_twitter": null,
        "iu_skype": null,
        "iu_icq": null,
        "iu_comment": null,
        "iu_telephone": null,
        "iu_company": null,
        "phone": null,
        "company": null,
        "street_addr": null,
        "city": null,
        "zip": null,
        "state_id": null,
        "country_id": null,
        "mobile": null,
        "companys_id": "2",
        "departments_id": "2",
        "employees_id": null,
        "ref_type": "user",
        "barcode": null,
        "manual_code": null,
        "created_by": null,
        "updated_by": null,
        "deleted_by": null,
        "timezone_id": 1,
        "settings": null,
        "created_ip_address": "127.0.0.1",
        "last_ip_address": "127.0.0.1",
        "offline_mall_customer_group_id": null,
        "vdomah_role_id": null,
        "vdomah_roles_role_id": 0
      }
    },
    {
      "favoriteable_type": "products",
      "favoriteable_id": 2,
      "user_id": 544,
      "created_at": "2022-10-11 22:14:16",
      "updated_at": "2022-10-11 22:14:16",
      "user": {
        "id": 544,
        "name": "DheiaAli1",
        "email": "kddd90331@gmail.com",
        "permissions": null,
        "is_activated": true,
        "activated_at": "2022-10-06 16:48:40",
        "last_login": "2022-10-06 19:45:10",
        "created_at": "2022-10-06 16:48:40",
        "updated_at": "2022-10-06 19:45:10",
        "username": "kddd90331@gmail.com",
        "surname": null,
        "deleted_at": null,
        "last_seen": null,
        "is_guest": 0,
        "is_superuser": 0,
        "iu_gender": null,
        "iu_job": null,
        "iu_about": null,
        "iu_webpage": null,
        "iu_blog": null,
        "iu_facebook": null,
        "iu_twitter": null,
        "iu_skype": null,
        "iu_icq": null,
        "iu_comment": null,
        "iu_telephone": null,
        "iu_company": null,
        "phone": null,
        "company": null,
        "street_addr": null,
        "city": null,
        "zip": null,
        "state_id": null,
        "country_id": null,
        "mobile": null,
        "companys_id": "2",
        "departments_id": "2",
        "employees_id": null,
        "ref_type": "user",
        "barcode": null,
        "manual_code": null,
        "created_by": null,
        "updated_by": null,
        "deleted_by": null,
        "timezone_id": 1,
        "settings": null,
        "created_ip_address": "127.0.0.1",
        "last_ip_address": "127.0.0.1",
        "offline_mall_customer_group_id": null,
        "vdomah_role_id": null,
        "vdomah_roles_role_id": 0
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```


