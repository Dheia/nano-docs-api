### Add Favorites object
**لاضافه كائن معين يجب ان يكون المستخدم مسجل دخول على النظام **

```
POST /api/v1/favorites/favorites/add
```

**يجب تمرير اسم الكائن المراد اضافته الى المفضله مع معرف  الكائن id **

#### Example 1 Add Product 2 from Favorites list Current User

**فى المثال التالى سنقوم باضافه الصنف رقم 2 من قائمه مفضله المستخدم الحالى **

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
}
```

```
GET http://localhost:8006/api/v1/favorites/favorites/add?include=user&object_type=\Nano\Shop\Models\Product&object_id=2

```

##### Response

**في حال تمت عمليه الاضافه الى المفضله بنجاح سيتم ارجاع النتيجه التاليه **


```html
Status: 200 OK
```

```json
{
  "favoriteable_type": "products",
  "favoriteable_id": 2,
  "user_id": 543,
  "created_at": "2022-10-11 22:14:16",
  "updated_at": "2022-10-11 22:14:16",
  "user": {
    "id": 543,
    "name": "dheiaAli1",
    "email": "kddd9033@gmail.com",
    "permissions": null,
    "is_activated": true,
    "activated_at": "2022-08-31 20:23:58",
    "last_login": "2022-10-11 22:59:36",
    "created_at": "2022-08-31 20:23:58",
    "updated_at": "2022-10-11 22:59:36",
    "username": "kddd9033@gmail.com",
    "surname": null,
    "deleted_at": null,
    "last_seen": null,
    "is_guest": 0,
    "is_superuser": 0,
    "iu_gender": null,
    "iu_job": null,
    "iu_about": null,
    "iu_webpage": null,
    "iu_blog": null,
    "iu_facebook": null,
    "iu_twitter": null,
    "iu_skype": null,
    "iu_icq": null,
    "iu_comment": null,
    "iu_telephone": null,
    "iu_company": null,
    "phone": null,
    "company": null,
    "street_addr": null,
    "city": null,
    "zip": null,
    "state_id": null,
    "country_id": null,
    "mobile": null,
    "companys_id": "2",
    "departments_id": "2",
    "employees_id": null,
    "ref_type": "user",
    "barcode": null,
    "manual_code": null,
    "created_by": null,
    "updated_by": null,
    "deleted_by": null,
    "timezone_id": 1,
    "settings": null,
    "created_ip_address": "127.0.0.1",
    "last_ip_address": "127.0.0.1",
    "offline_mall_customer_group_id": null,
    "vdomah_role_id": null,
    "vdomah_roles_role_id": 0
  }
}
```

**لاحظ انه فى النتيجه السابقه تم ارجاع بيانات السجل فى جدول المفضله مع بيانات المستخدم الذي قام باضافه الصنف رقم 2 الي قائمه مفضلته وذلك لاننا قمنا بتضمين العلاقه user فى الطلب **

### Response Error 
**فى بعض الحالات يتم ارجاع خطاء عن محاوله جلب قائمه المفضله او فى حاله الاضافه او الحذف سنستعرض هذه الاخطاء **

#### Response 401 Error UNAUTHORIZED 

** يتم ارجاع خطاء فى حاله عدم وجود مستخدم مسجل كا التالي  **

```html
Status: 401 Error UNAUTHORIZED
```

```json
{
  "error": {
    "code": "UNAUTHORIZED",
    "http_code": 401,
    "message": "Invalid user credential."
  }
}
```

#### Response 404 Error NOT_FOUND 

**خطاء عدم وجود الكائن المراد اضافته الى المفضله او عدم وجود رقم الكائن كا التالي  **

```html
Status: 404 Error NOT_FOUND
```

```json
{
  "error": {
    "code": "NOT_FOUND",
    "http_code": 404,
    "message": "object_type not found."
  }
}
```

or

```json
{
  "error": {
    "code": "NOT_FOUND",
    "http_code": 404,
    "message": "Object id 28 not  found."
  }
}
```

### Delete Object in Favorites List Current User

**لحذف كائن من قائمه المفضلة للمستخدم الحالى نستخدم الرابط التالي معا تمرير البرامترات كما فى جزء الاضافه **

```
DELETE /api/v1/favorites/favorites/delete
```

**يجب تمرير اسم الكائن المراد حذفه من  المفضله مع معرف  الكائن id **

#### Example 2 Delete Product 2 from Favorites list Current User

**فى المثال التالى سنقوم بحذف  الصنف رقم 2 الى قائمه مفضله المستخدم الحالى **

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
}
```

```
DELETE http://localhost:8006/api/v1/favorites/favorites/delete?object_type=\Nano\Shop\Models\Product&object_id=2
```

##### Response

**في حال تمت عمليه الحذف من المفضله بنجاح سيتم ارجاع النتيجه التاليه **


```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم حذف الكائن من المفضله "
}
```

**فى حال حدث خطاء سيتم ارجع الخطاء كما وضحنا فى جزء الاخطاء سابقا**

### Toggle Favorites Object in List Current User

**تعمل هذه الداله عمل دالة الاضافه ودالة الحذف فى نفس الوقت **

**بمعنا انه فى حال لم يتم اضافه الكائن للمفضله من قبل يتم اضافته **

**وفى حال انه قد تم اضافة الكائن الى المفضله من قبل  تقوم ب **

**يمكن استخدام هذه الداله فى كل الحالات بحيث ستقوم الداله بالفحص والتنفيذ **

```
POST /api/v1/favorites/favorites/toggle
```

**يجب تمرير اسم الكائن  مع معرف  الكائن id **

#### Example 3 Use Toggle Add Product 2 from Favorites list Current User

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
}
```

```
POST http://localhost:8006/api/v1/favorites/favorites/toggle?object_type=\Nano\Shop\Models\Product&object_id=2
```

##### Response

**بما ان الصنف رقم 2 غير مضاف الى مفضله المستخدم الحالى ستكون النتيجه كا التالى  **


```html
Status: 200 OK
```

```json
{
  "favoriteable_type": "products",
  "favoriteable_id": 2,
  "user_id": 543,
  "created_at": "2022-10-11 23:29:22",
  "updated_at": "2022-10-11 23:29:22"
}
```

**فى حال حدث خطاء سيتم ارجع الخطاء كما وضحنا فى جزء الاخطاء سابقا**

#### Example 4 Use Toggle Delete Product 2 from Favorites list Current User

**فى المثال التالى سنقوم بحذف  الصنف رقم 2 من مفضلة المستخدم الحالى **

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
}
```

```
POST http://localhost:8006/api/v1/favorites/favorites/toggle?object_type=\Nano\Shop\Models\Product&object_id=2
```

##### Response

**فى هذه الحالة ستقوم الدالة بالفحص هل الصنف مضافه الى مفضله المستخدم  نعم سيتم حذفه **


```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم حذف الكائن من المفضله "
}
```

**فى حال حدث خطاء سيتم ارجع الخطاء كما وضحنا فى جزء الاخطاء سابقا**