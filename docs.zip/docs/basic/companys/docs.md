## Companys

This endpoint allows you to `list`, `show` your companys.

/basic/companys
### The companys object

#### Public Parameters
| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in companys records |
| `orderBy`           | `string`  |  using orderBy companys records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy companys records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  companys default value true    |
| `isNotHidden`           | `boolean`  | The get is Not Hidden in Web records companys default value true  | 
| `isHidden`           | `integer`  | The get is Hidden in Web records companys default value false  | 
| `IsMain`           | `boolean`  |  get main records companys default value false.         |
| `IsSub`           | `boolean`  | get main records companys default value true.          |
| `tags_type_id`           | `integer` | useing select type companys default value false
| 
| `isOpened`           | `boolean` | check companys is Opene default value false
| 
| `isClosed`           | `boolean` | check companys is Closed default value false
| 
| `openTime`           | `boolean` | get open Time in current date default value false
| 
| `closeTime`           | `boolean` | get close Time in current date default value false
| 
| `getPeriod`           | `boolean` | get Period Time Works in current date default value false
| 
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/basic/companys?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `tags_type`           | `belongsTo`  | The get Type Refrence | 
| `parent`           | `belongsTo`  | The get parent companys   | 
| `children`           | `hasMany`  | The get childrens companys   | 
| `country`           | `belongsTo`  | The get country data   | 
| `state`           | `belongsTo`  | The get state data   | 
| `directorate`           | `belongsTo`  | The get directorate data   | 


### List companys

Returns a list of companys you’ve previously created.

```
GET /api/v1/basic/companys
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 4,
      "code": "2-2-4",
      "name": "مدارس الوفاء الاهلية",
      "short_description": "مدارس الوفاء الاهلية",
      "description": "مدارس الوفاء الاهلية",
      "meta_title": "مدارس الوفاء الاهلية",
      "meta_description": "مدارس الوفاء الاهلية",
      "keywords": "مدارس الوفاء الاهلية",
      "business_number": "",
      "vat_number": "",
      "mobile": "770529482",
      "phone": null,
      "email": null,
      "website": null,
      "companys_id": "2",
      "address": "اب الدليل",
      "address_1": null,
      "address_2": null,
      "street_name": null,
      "street_number": null,
      "latitude": null,
      "longitude": null,
      "geo_components": null,
      "city": null,
      "zip": null,
      "postcode": null,
      "country_long": null,
      "country_id": "249",
      "state_id": "1067",
      "directorate_id": null,
      "formataddress": null,
      "vicinity": null,
      "is_default": 1,
      "is_hidden": 0,
      "is_active": 1,
      "main_sub": "sub",
      "parent_id": "2",
      "level": "2",
      "tags_type_id": "1",
      "links": null,
      "properties": null,
      "created_at": "2018-06-29 17:23:50",
      "updated_at": "2022-10-14 17:19:39",
      "image": null,
      "images": [],
      "files": []
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Example 1 get List Companys 

GET http://localhost:8006/api/v1/basic/companys

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 4,
      "code": "2-2-4",
      "name": "مدارس الوفاء الاهلية",
      "short_description": "مدارس الوفاء الاهلية",
      "description": "مدارس الوفاء الاهلية",
      "meta_title": "مدارس الوفاء الاهلية",
      "meta_description": "مدارس الوفاء الاهلية",
      "keywords": "مدارس الوفاء الاهلية",
      "business_number": "",
      "vat_number": "",
      "mobile": "770529482",
      "phone": null,
      "email": null,
      "website": null,
      "companys_id": "2",
      "address": "اب الدليل",
      "address_1": null,
      "address_2": null,
      "street_name": null,
      "street_number": null,
      "latitude": null,
      "longitude": null,
      "geo_components": null,
      "city": null,
      "zip": null,
      "postcode": null,
      "country_long": null,
      "country_id": "249",
      "state_id": "1067",
      "directorate_id": null,
      "formataddress": null,
      "vicinity": null,
      "is_default": 1,
      "is_hidden": 0,
      "is_active": 1,
      "main_sub": "sub",
      "parent_id": "2",
      "level": "2",
      "tags_type_id": "1",
      "links": null,
      "properties": null,
      "created_at": "2018-06-29 17:23:50",
      "updated_at": "2022-10-14 17:19:39",
      "image": null,
      "images": [],
      "files": []
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Example 2 get Companys and working Time

GET http://localhost:8006/api/v1/basic/companys?isOpened=true&isClosed=true&openTime=true&closeTime=true

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 4,
      "code": "2-2-4",
      "name": "مدارس الوفاء الاهلية",
      "short_description": "مدارس الوفاء الاهلية",
      "description": "مدارس الوفاء الاهلية",
      "meta_title": "مدارس الوفاء الاهلية",
      "meta_description": "مدارس الوفاء الاهلية",
      "keywords": "مدارس الوفاء الاهلية",
      "business_number": "",
      "vat_number": "",
      "mobile": "770529482",
      "phone": null,
      "email": null,
      "website": null,
      "companys_id": "2",
      "address": "اب الدليل",
      "address_1": null,
      "address_2": null,
      "street_name": null,
      "street_number": null,
      "latitude": null,
      "longitude": null,
      "geo_components": null,
      "city": null,
      "zip": null,
      "postcode": null,
      "country_long": null,
      "country_id": "249",
      "state_id": "1067",
      "directorate_id": null,
      "formataddress": null,
      "vicinity": null,
      "is_default": 1,
      "is_hidden": 0,
      "is_active": 1,
      "main_sub": "sub",
      "parent_id": "2",
      "level": "2",
      "tags_type_id": "1",
      "links": null,
      "properties": null,
      "created_at": "2018-06-29 17:23:50",
      "updated_at": "2022-10-14 17:19:39",
      "image": null,
      "images": [],
      "files": [],
      "is_opened": false,
      "is_closed": true,
      "openTime": {
        "date": "2022-10-17 01:45:00.000000",
        "timezone_type": 3,
        "timezone": "Asia\/Aden"
      },
      "closeTime": {
        "date": "2022-10-17 23:55:00.000000",
        "timezone_type": 3,
        "timezone": "Asia\/Aden"
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```


### Show Data Record Companys 

```
GET /api/v1/basic/companys/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 3 Show Data Record Companys 4

```
GET http://localhost:8006/api/v1/basic/companys/4
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "id": 4,
  "code": "2-2-4",
  "name": "مدارس الوفاء الاهلية",
  "short_description": "مدارس الوفاء الاهلية",
  "description": "مدارس الوفاء الاهلية",
  "meta_title": "مدارس الوفاء الاهلية",
  "meta_description": "مدارس الوفاء الاهلية",
  "keywords": "مدارس الوفاء الاهلية",
  "business_number": "",
  "vat_number": "",
  "mobile": "770529482",
  "phone": null,
  "email": null,
  "website": null,
  "companys_id": "2",
  "address": "اب الدليل",
  "address_1": null,
  "address_2": null,
  "street_name": null,
  "street_number": null,
  "latitude": null,
  "longitude": null,
  "geo_components": null,
  "city": null,
  "zip": null,
  "postcode": null,
  "country_long": null,
  "country_id": "249",
  "state_id": "1067",
  "directorate_id": null,
  "formataddress": null,
  "vicinity": null,
  "is_default": 1,
  "is_hidden": 0,
  "is_active": 1,
  "main_sub": "sub",
  "parent_id": "2",
  "level": "2",
  "tags_type_id": "1",
  "links": null,
  "properties": null,
  "created_at": "2018-06-29 17:23:50",
  "updated_at": "2022-10-14 17:19:39",
  "image": null,
  "images": [],
  "files": [],
}
```

#### Example 4 Show Data Record Companys 4 and working time

```
GET http://localhost:8006/api/v1/basic/companys/4?isOpened=true&isClosed=true&openTime=true&closeTime=true
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "id": 4,
  "code": "2-2-4",
  "name": "مدارس الوفاء الاهلية",
  "short_description": "مدارس الوفاء الاهلية",
  "description": "مدارس الوفاء الاهلية",
  "meta_title": "مدارس الوفاء الاهلية",
  "meta_description": "مدارس الوفاء الاهلية",
  "keywords": "مدارس الوفاء الاهلية",
  "business_number": "",
  "vat_number": "",
  "mobile": "770529482",
  "phone": null,
  "email": null,
  "website": null,
  "companys_id": "2",
  "address": "اب الدليل",
  "address_1": null,
  "address_2": null,
  "street_name": null,
  "street_number": null,
  "latitude": null,
  "longitude": null,
  "geo_components": null,
  "city": null,
  "zip": null,
  "postcode": null,
  "country_long": null,
  "country_id": "249",
  "state_id": "1067",
  "directorate_id": null,
  "formataddress": null,
  "vicinity": null,
  "is_default": 1,
  "is_hidden": 0,
  "is_active": 1,
  "main_sub": "sub",
  "parent_id": "2",
  "level": "2",
  "tags_type_id": "1",
  "links": null,
  "properties": null,
  "created_at": "2018-06-29 17:23:50",
  "updated_at": "2022-10-14 17:19:39",
  "image": null,
  "images": [],
  "files": [],
  "is_opened": false,
  "is_closed": true,
  "openTime": {
    "date": "2022-10-17 01:45:00.000000",
    "timezone_type": 3,
    "timezone": "Asia\/Aden"
  },
  "closeTime": {
    "date": "2022-10-17 23:55:00.000000",
    "timezone_type": 3,
    "timezone": "Asia\/Aden"
  }
}
```

#### Example 5 Show Data Record Companys 4 and working time and Include Relation

```
GET http://localhost:8006/api/v1/basic/companys/4?isOpened=true&isClosed=true&openTime=true&closeTime=true&include=companys,tags_type,parent,children
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "id": 4,
  "code": "2-2-4",
  "name": "مدارس الوفاء الاهلية",
  "short_description": "مدارس الوفاء الاهلية",
  "description": "مدارس الوفاء الاهلية",
  "meta_title": "مدارس الوفاء الاهلية",
  "meta_description": "مدارس الوفاء الاهلية",
  "keywords": "مدارس الوفاء الاهلية",
  "business_number": "",
  "vat_number": "",
  "mobile": "770529482",
  "phone": null,
  "email": null,
  "website": null,
  "companys_id": "2",
  "address": "اب الدليل",
  "address_1": null,
  "address_2": null,
  "street_name": null,
  "street_number": null,
  "latitude": null,
  "longitude": null,
  "geo_components": null,
  "city": null,
  "zip": null,
  "postcode": null,
  "country_long": null,
  "country_id": "249",
  "state_id": "1067",
  "directorate_id": null,
  "formataddress": null,
  "vicinity": null,
  "is_default": 1,
  "is_hidden": 0,
  "is_active": 1,
  "main_sub": "sub",
  "parent_id": "2",
  "level": "2",
  "tags_type_id": "1",
  "links": null,
  "properties": null,
  "created_at": "2018-06-29 17:23:50",
  "updated_at": "2022-10-14 17:19:39",
  "image": null,
  "images": [],
  "files": [],
  "is_opened": false,
  "is_closed": true,
  "openTime": {
    "date": "2022-10-17 01:45:00.000000",
    "timezone_type": 3,
    "timezone": "Asia\/Aden"
  },
  "closeTime": {
    "date": "2022-10-17 23:55:00.000000",
    "timezone_type": 3,
    "timezone": "Asia\/Aden"
  },
  "companys": {
    "id": 2,
    "code": "2",
    "name": "مدارس الوفاء الأهلية النموذجية",
    "short_description": "شركة رقم 1",
    "description": "شركة رقم 1",
    "meta_title": "",
    "meta_description": "",
    "keywords": null,
    "business_number": null,
    "vat_number": null,
    "mobile": null,
    "phone": [],
    "email": [],
    "website": [],
    "address": "إب - الدليل - جوار محطة المشدود",
    "address_1": null,
    "address_2": null,
    "street_name": null,
    "street_number": null,
    "latitude": null,
    "longitude": null,
    "geo_components": null,
    "city": null,
    "zip": null,
    "postcode": null,
    "country_long": null,
    "country_id": "1",
    "state_id": null,
    "directorate_id": null,
    "formataddress": null,
    "vicinity": null,
    "is_active": 1,
    "tags_type_id": null,
    "links": [],
    "properties": [],
    "created_at": "2018-04-05 16:54:53",
    "updated_at": "2019-12-04 13:08:14"
  },
  "tags_type": {
    "id": 1,
    "code": "1-1",
    "name": "الفئه العامه  ",
    "slug": "tags_public",
    "ref_type": "tags_public",
    "short_description": "الفئه العامه الافتراضيه لكافه الانواع والاقسام ",
    "description": "الفئه العامه الافتراضيه لكافه الانواع والاقسام ",
    "meta_title": "الفئه العامه  ",
    "meta_description": null,
    "keywords": null,
    "user_id": null,
    "user_type": null,
    "companys_id": "1",
    "companys_id": "1",
    "is_companys": 1,
    "is_public": 1,
    "is_default": 1,
    "is_active": 1,
    "is_published": 0,
    "published_at": "",
    "unpublished_at": "",
    "properties": null,
    "created_at": "",
    "updated_at": "",
    "image": null,
    "images": []
  },
  "parent": {
    "id": 2,
    "code": "1-2",
    "name": "مدارس الوفاء الأهلية النموذجية",
    "short_description": "مدارس الوفاء الاهلية",
    "description": "مدارس الوفاء الاهلية",
    "meta_title": "مدارس الوفاء الاهلية",
    "meta_description": "مدارس الوفاء الاهلية",
    "keywords": "مدارس الوفاء الاهلية",
    "business_number": "",
    "vat_number": "",
    "mobile": "770429482",
    "phone": [
      {
        "phone_label": "هاتف المكتب",
        "phone_number": "04461300",
        "phone_type": "home",
        "sort_show": "1",
        "is_default": "1",
        "is_show": "1",
        "phone_note": "هاتف المكتب",
        "_group": "phone"
      }
    ],
    "email": [
      {
        "email_label": "البريد الرسمي",
        "email_text": "kddd90@gmail.com",
        "sort_show": "1",
        "is_default": "1",
        "is_show": "1",
        "email_note": "",
        "_group": "email"
      }
    ],
    "website": [
      {
        "website_label": "الموقع الرسمي",
        "website_url": "www.tss-y.com",
        "website_type": "website",
        "sort_show": "1",
        "is_default": "1",
        "is_show": "1",
        "website_note": "",
        "_group": "website"
      }
    ],
    "companys_id": "2",
    "address": "مدارس الوفاء الأهلية النموذجية",
    "address_1": null,
    "address_2": null,
    "street_name": null,
    "street_number": null,
    "latitude": null,
    "longitude": null,
    "geo_components": null,
    "city": null,
    "zip": null,
    "postcode": null,
    "country_long": null,
    "country_id": "249",
    "state_id": "1067",
    "directorate_id": null,
    "formataddress": null,
    "vicinity": null,
    "is_default": 1,
    "is_hidden": 0,
    "is_active": 1,
    "main_sub": "main",
    "parent_id": null,
    "level": "1",
    "tags_type_id": "1",
    "links": null,
    "properties": null,
    "created_at": "2018-06-29 17:17:24",
    "updated_at": "2022-10-14 17:17:41",
    "image": null,
    "images": [],
    "files": [],
    "is_opened": false,
    "is_closed": true,
    "openTime": null,
    "closeTime": null
  },
  "children": {
    "data": [],
    "meta": {
      "pagination": {
        "total": 0,
        "count": 0,
        "per_page": 10,
        "current_page": 1,
        "total_pages": 1,
        "links": []
      }
    }
  }
}
```

#### Example 4 Show Data Record Companys 4 and working time

```
GET http://localhost:8006/api/v1/basic/companys/4?isOpened=true&isClosed=true&openTime=true&closeTime=true
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "id": 4,
  "code": "2-2-4",
  "name": "مدارس الوفاء الاهلية",
  "short_description": "مدارس الوفاء الاهلية",
  "description": "مدارس الوفاء الاهلية",
  "meta_title": "مدارس الوفاء الاهلية",
  "meta_description": "مدارس الوفاء الاهلية",
  "keywords": "مدارس الوفاء الاهلية",
  "business_number": "",
  "vat_number": "",
  "mobile": "770529482",
  "phone": null,
  "email": null,
  "website": null,
  "companys_id": "2",
  "address": "اب الدليل",
  "address_1": null,
  "address_2": null,
  "street_name": null,
  "street_number": null,
  "latitude": null,
  "longitude": null,
  "geo_components": null,
  "city": null,
  "zip": null,
  "postcode": null,
  "country_long": null,
  "country_id": "249",
  "state_id": "1067",
  "directorate_id": null,
  "formataddress": null,
  "vicinity": null,
  "is_default": 1,
  "is_hidden": 0,
  "is_active": 1,
  "main_sub": "sub",
  "parent_id": "2",
  "level": "2",
  "tags_type_id": "1",
  "links": null,
  "properties": null,
  "created_at": "2018-06-29 17:23:50",
  "updated_at": "2022-10-14 17:19:39",
  "image": null,
  "images": [],
  "files": [],
  "is_opened": false,
  "is_closed": true,
  "openTime": {
    "date": "2022-10-17 01:45:00.000000",
    "timezone_type": 3,
    "timezone": "Asia\/Aden"
  },
  "closeTime": {
    "date": "2022-10-17 23:55:00.000000",
    "timezone_type": 3,
    "timezone": "Asia\/Aden"
  }
}
```

#### Example 6 Show Data Record Companys 4 and working time and Include Relation

```
GET http://localhost:8006/api/v1/basic/companys/4?isOpened=true&isClosed=true&openTime=true&closeTime=true&include=companys,tags_type,parent,children,country,state,directorate
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "id": 4,
  "code": "2-2-4",
  "name": "مدارس الوفاء الاهلية",
  "short_description": "مدارس الوفاء الاهلية",
  "description": "مدارس الوفاء الاهلية",
  "meta_title": "مدارس الوفاء الاهلية",
  "meta_description": "مدارس الوفاء الاهلية",
  "keywords": "مدارس الوفاء الاهلية",
  "business_number": "",
  "vat_number": "",
  "mobile": "770529482",
  "phone": null,
  "email": null,
  "website": null,
  "companys_id": "2",
  "address": "اب الدليل",
  "address_1": null,
  "address_2": null,
  "street_name": null,
  "street_number": null,
  "latitude": null,
  "longitude": null,
  "geo_components": null,
  "city": null,
  "zip": null,
  "postcode": null,
  "country_long": null,
  "country_id": "249",
  "state_id": "1067",
  "directorate_id": null,
  "formataddress": null,
  "vicinity": null,
  "is_default": 1,
  "is_hidden": 0,
  "is_active": 1,
  "main_sub": "sub",
  "parent_id": "2",
  "level": "2",
  "tags_type_id": "1",
  "links": null,
  "properties": null,
  "created_at": "2018-06-29 17:23:50",
  "updated_at": "2022-10-14 17:19:39",
  "image": null,
  "images": [],
  "files": [],
  "is_opened": false,
  "is_closed": true,
  "openTime": {
    "date": "2022-10-17 01:45:00.000000",
    "timezone_type": 3,
    "timezone": "Asia\/Aden"
  },
  "closeTime": {
    "date": "2022-10-17 23:55:00.000000",
    "timezone_type": 3,
    "timezone": "Asia\/Aden"
  },
  "companys": {
    "id": 2,
    "code": "2",
    "name": "مدارس الوفاء الأهلية النموذجية",
    "short_description": "شركة رقم 1",
    "description": "شركة رقم 1",
    "meta_title": "",
    "meta_description": "",
    "keywords": null,
    "business_number": null,
    "vat_number": null,
    "mobile": null,
    "phone": [],
    "email": [],
    "website": [],
    "address": "إب - الدليل - جوار محطة المشدود",
    "address_1": null,
    "address_2": null,
    "street_name": null,
    "street_number": null,
    "latitude": null,
    "longitude": null,
    "geo_components": null,
    "city": null,
    "zip": null,
    "postcode": null,
    "country_long": null,
    "country_id": "1",
    "state_id": null,
    "directorate_id": null,
    "formataddress": null,
    "vicinity": null,
    "is_active": 1,
    "tags_type_id": null,
    "links": [],
    "properties": [],
    "created_at": "2018-04-05 16:54:53",
    "updated_at": "2019-12-04 13:08:14"
  },
  "tags_type": {
    "id": 1,
    "code": "1-1",
    "name": "الفئه العامه  ",
    "slug": "tags_public",
    "ref_type": "tags_public",
    "short_description": "الفئه العامه الافتراضيه لكافه الانواع والاقسام ",
    "description": "الفئه العامه الافتراضيه لكافه الانواع والاقسام ",
    "meta_title": "الفئه العامه  ",
    "meta_description": null,
    "keywords": null,
    "user_id": null,
    "user_type": null,
    "companys_id": "1",
    "companys_id": "1",
    "is_companys": 1,
    "is_public": 1,
    "is_default": 1,
    "is_active": 1,
    "is_published": 0,
    "published_at": "",
    "unpublished_at": "",
    "properties": null,
    "created_at": "",
    "updated_at": "",
    "image": null,
    "images": []
  },
  "parent": {
    "id": 2,
    "code": "1-2",
    "name": "مدارس الوفاء الأهلية النموذجية",
    "short_description": "مدارس الوفاء الاهلية",
    "description": "مدارس الوفاء الاهلية",
    "meta_title": "مدارس الوفاء الاهلية",
    "meta_description": "مدارس الوفاء الاهلية",
    "keywords": "مدارس الوفاء الاهلية",
    "business_number": "",
    "vat_number": "",
    "mobile": "770429482",
    "phone": [
      {
        "phone_label": "هاتف المكتب",
        "phone_number": "04461300",
        "phone_type": "home",
        "sort_show": "1",
        "is_default": "1",
        "is_show": "1",
        "phone_note": "هاتف المكتب",
        "_group": "phone"
      }
    ],
    "email": [
      {
        "email_label": "البريد الرسمي",
        "email_text": "kddd90@gmail.com",
        "sort_show": "1",
        "is_default": "1",
        "is_show": "1",
        "email_note": "",
        "_group": "email"
      }
    ],
    "website": [
      {
        "website_label": "الموقع الرسمي",
        "website_url": "www.tss-y.com",
        "website_type": "website",
        "sort_show": "1",
        "is_default": "1",
        "is_show": "1",
        "website_note": "",
        "_group": "website"
      }
    ],
    "companys_id": "2",
    "address": "مدارس الوفاء الأهلية النموذجية",
    "address_1": null,
    "address_2": null,
    "street_name": null,
    "street_number": null,
    "latitude": null,
    "longitude": null,
    "geo_components": null,
    "city": null,
    "zip": null,
    "postcode": null,
    "country_long": null,
    "country_id": "249",
    "state_id": "1067",
    "directorate_id": null,
    "formataddress": null,
    "vicinity": null,
    "is_default": 1,
    "is_hidden": 0,
    "is_active": 1,
    "main_sub": "main",
    "parent_id": null,
    "level": "1",
    "tags_type_id": "1",
    "links": null,
    "properties": null,
    "created_at": "2018-06-29 17:17:24",
    "updated_at": "2022-10-14 17:17:41",
    "image": null,
    "images": [],
    "files": [],
    "is_opened": false,
    "is_closed": true,
    "openTime": null,
    "closeTime": null
  },
  "children": {
    "data": [],
    "meta": {
      "pagination": {
        "total": 0,
        "count": 0,
        "per_page": 10,
        "current_page": 1,
        "total_pages": 1,
        "links": []
      }
    }
  },
  "country": {
    "id": 249,
    "code": "en",
    "name": "يمن",
    "is_enabled": true,
    "is_pinned": false
  },
  "state": {
    "id": 1067,
    "code": "snaaa",
    "name": "صنعاء",
    "country_id": 249,
    "is_enabled": true
  },
  "directorate": []
}
```