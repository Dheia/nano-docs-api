## Settings

This endpoint allows you to `list`, `show` your settings.

/basic/settings

**من خلال هذا الجزء يمكنك جلب الاعدادات العامة  **

### Example 1 get List Settings 

GET http://localhost:8006/api/v1/basic/settings

#### Response

```html
Status: 200 OK
```

```json
{
  "updated_at": "2022-12-16 22:06:23",
  "website_name": "نانو سوفت",
  "website_url": "http:\/\/naon2soft.com",
  "meta_title": "نانو 2 سوفت للبرمجيات وتقنية المعلومات",
  "meta_description": "نانو 2 سوفت للبرمجيات وتقنية المعلومات",
  "meta_keywords": "نانو سوفت , برمجيات , انظمة , شركة , تصميم , مواقع",
  "website_baner_type": "text",
  "address": "Yemen IBB",
  "work_time": "",
  "map_type": "link",
  "map_link": "",
  "map_content": "",
  "website_author": "Nano 2 Soft",
  "website_author_name": "Nano 2 Soft  Eng\/ Dheia Ali Al-Shami  00967770529482",
  "author_web": "https:\/\/nano2soft.com",
  "author_phone": "00967770529482",
  "author_email": "info@nano2soft.com",
  "author_address": "Yemen IBB",
  "load_google_fonts": "1",
  "google_font_family": "Roboto+Slab:300,400,700|Raleway:300,300i,400,400i,700,700i",
  "load_fontawesome": "1",
  "load_material_icons": "1",
  "load_stroke7_icons": "1",
  "load_jQuery": "1",
  "jQuery_version": "2.2.4",
  "main_content_layout": "",
  "page_header_style": "",
  "website_theme": "",
  "page_header_fixed": "1",
  "brand_primary": "#3f9ce8",
  "brand_secondary": "#3f9ce8",
  "body_bg": "#f0f2f5",
  "body_color": "#575757",
  "body_color_dark": "#171717",
  "header_bg": "#ffffff",
  "sidebar_bg": "#ffffff",
  "load_animate_css": "1",
  "load_wow_js": "1",
  "load_owl_carousel": "1",
  "website_baner": "\/favicon.png",
  "website_baner_about": "",
  "website_baner_story": "",
  "website_baner_goles": "",
  "phone": [
    {
      "phone_label": "",
      "phone_number": "770529482",
      "phone_type": "mobile",
      "sort_show": "1",
      "is_default": "1",
      "is_show": "1",
      "phone_note": ""
    }
  ],
  "email": null,
  "accounts": null,
  "social_links": [
    {
      "icon": "fab fa-google-plus-g",
      "name": "جوجل",
      "link": "http:\/\/nano2soft.com"
    },
    {
      "icon": "fab fa-facebook",
      "name": "fasebokk",
      "link": "http:\/\/nano2soft.com"
    }
  ]
}
```


#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/basic/settings?exclude=created_at,updated_at
```
