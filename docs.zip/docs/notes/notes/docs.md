## Notes  Api

This endpoint allows you to `list`, `show` your notes.

/notes/notes

**الجزء الخاص بالملاحظات يمكنك من جلب الملاحظات او اضافة ملاحظات جديدة**


### The notes object

#### Public Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in notes  records |
| `orderBy`           | `string`  |  using orderBy departments records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy departments records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  notes default value true    |
| `companys_id`           | `integer`  |  get records notes to companys_id default value false.         |
| `departments_id`           | `integer`  | get records notes to departments_id default value true.          |
| `isFavorites`           | `boolean `  | useing get notes where my Favorites default value false 
| 
| `include`           | `string `  | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/notes/notes?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `department`           | `belongsTo`  | The get department | 
| `user`           | `belongsTo`  | The get user   | 

### List notes

Returns a list of Notes’

```
GET /api/v1/notes/notes
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Example 1 get List Notes  

```
GET http://localhost:8006/api/v1/notes/notes
```

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 39,
      "code": "2-4-39",
      "barcode": "",
      "name": "الملاحظة الثانية تعديل.",
      "content": "تعديل نص الملاحظة الثانية",
      "additional_data": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-03 18:58:00",
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 39,
      "created_at": "2023-12-03 18:58:00",
      "updated_at": "2023-12-03 19:01:23",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Tss\\Notes\\Models\\Note"
    },
    {
      "id": 38,
      "code": "2-4-38",
      "barcode": "",
      "name": "الملاحظة الثالثة hhh",
      "content": "نص الملاحظة الثالثة hhg",
      "additional_data": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-03 18:42:52",
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 38,
      "created_at": "2023-12-03 18:42:52",
      "updated_at": "2023-12-03 18:42:52",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Tss\\Notes\\Models\\Note"
    },
    {
      "id": 37,
      "code": "2-4-37",
      "barcode": "",
      "name": "الملاحظة الثالثة",
      "content": "نص الملاحظة الثالثة",
      "additional_data": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "",
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 37,
      "created_at": "2023-12-03 18:40:59",
      "updated_at": "2023-12-03 18:40:59",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Tss\\Notes\\Models\\Note"
    },
    {
      "id": 36,
      "code": "2-4-36",
      "barcode": "",
      "name": "الملاحظة الثالثة",
      "content": "نص الملاحظة الثالثة",
      "additional_data": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "",
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 36,
      "created_at": "2023-12-03 18:38:12",
      "updated_at": "2023-12-03 18:38:12",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Tss\\Notes\\Models\\Note"
    },
    {
      "id": 35,
      "code": "2-4-35",
      "barcode": "",
      "name": "الملاحظة الثالثة",
      "content": "نص الملاحظة الثالثة",
      "additional_data": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "",
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 35,
      "created_at": "2023-12-03 18:36:57",
      "updated_at": "2023-12-03 18:36:57",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Tss\\Notes\\Models\\Note"
    },
    {
      "id": 34,
      "code": "2-4-34",
      "barcode": "",
      "name": "الملاحظة الثانية",
      "content": "نص الملاحظة الثانية",
      "additional_data": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "",
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 34,
      "created_at": "2023-12-03 18:33:31",
      "updated_at": "2023-12-03 18:33:31",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Tss\\Notes\\Models\\Note"
    },
    {
      "id": 33,
      "code": "2-4-33",
      "barcode": "",
      "name": "الملاحظة الثانية",
      "content": "نص الملاحظة الثانية",
      "additional_data": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "",
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 33,
      "created_at": "2023-12-03 18:31:24",
      "updated_at": "2023-12-03 18:31:24",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Tss\\Notes\\Models\\Note"
    },
    {
      "id": 32,
      "code": "2-4-32",
      "barcode": "",
      "name": "الملاحظة الاولى",
      "content": "نص الملاحظة الاولى",
      "additional_data": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "",
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 32,
      "created_at": "2023-12-03 18:30:44",
      "updated_at": "2023-12-03 18:30:44",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Tss\\Notes\\Models\\Note"
    },
    {
      "id": 31,
      "code": "2-4-31",
      "barcode": "",
      "name": "الملاحظة الاولى",
      "content": "نص الملاحظة الاولى",
      "additional_data": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "",
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 31,
      "created_at": "2023-12-03 18:28:10",
      "updated_at": "2023-12-03 18:28:10",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Tss\\Notes\\Models\\Note"
    },
    {
      "id": 30,
      "code": "2-4-30",
      "barcode": "",
      "name": "الملاحظة الاولى",
      "content": "نص الملاحظة الاولى",
      "additional_data": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "",
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 30,
      "created_at": "2023-12-03 18:26:08",
      "updated_at": "2023-12-03 18:26:08",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Tss\\Notes\\Models\\Note"
    },
    {
      "id": 29,
      "code": "",
      "barcode": "",
      "name": "الملاحظة الاولى",
      "content": "نص الملاحظة الاولى",
      "additional_data": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "companys_id": "2",
      "departments_id": null,
      "is_active": 1,
      "is_private": 1,
      "date_at": "",
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 29,
      "created_at": "2023-12-03 18:24:25",
      "updated_at": "2023-12-03 18:26:36",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Tss\\Notes\\Models\\Note"
    },
    {
      "id": 28,
      "code": "",
      "barcode": "",
      "name": "الملاحظة الاولى",
      "content": "نص الملاحظة الاولى",
      "additional_data": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "companys_id": "2",
      "departments_id": null,
      "is_active": 1,
      "is_private": 1,
      "date_at": "",
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 28,
      "created_at": "2023-12-03 18:22:30",
      "updated_at": "2023-12-03 18:24:30",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Tss\\Notes\\Models\\Note"
    },
    {
      "id": 27,
      "code": "",
      "barcode": "",
      "name": "الملاحظة الاولى",
      "content": "نص الملاحظة الاولى",
      "additional_data": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "companys_id": "2",
      "departments_id": null,
      "is_active": 1,
      "is_private": 1,
      "date_at": "",
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 27,
      "created_at": "2023-12-03 18:20:16",
      "updated_at": "2023-12-03 18:21:03",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Tss\\Notes\\Models\\Note"
    },
    {
      "id": 26,
      "code": "",
      "barcode": "",
      "name": "الملاحظة الاولى",
      "content": "نص الملاحظة الاولى",
      "additional_data": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "companys_id": "2",
      "departments_id": null,
      "is_active": 1,
      "is_private": 1,
      "date_at": "",
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 26,
      "created_at": "2023-12-03 18:19:02",
      "updated_at": "2023-12-03 18:21:03",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Tss\\Notes\\Models\\Note"
    },
    {
      "id": 25,
      "code": "",
      "barcode": "",
      "name": "الملاحظة الاولى",
      "content": "نص الملاحظة الاولى",
      "additional_data": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "companys_id": "2",
      "departments_id": null,
      "is_active": 1,
      "is_private": 1,
      "date_at": "",
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 25,
      "created_at": "2023-12-03 18:16:46",
      "updated_at": "2023-12-03 18:18:49",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Tss\\Notes\\Models\\Note"
    }
  ],
  "meta": {
    "pagination": {
      "total": 30,
      "count": 15,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 2,
      "links": {
        "next": "http:\/\/localhost:8006\/api\/v1\/notes\/notes?page=2"
      }
    }
  }
}
```


### Show Data Record Note 

```
GET /api/v1/notes/notes/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record Note 25

```
GET http://localhost:8006/api/v1/notes/notes/25
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "id": 25,
  "code": "2--25",
  "barcode": "",
  "name": "الملاحظة الاولى",
  "content": "نص الملاحظة الاولى",
  "additional_data": "",
  "user_type": "RainLab\\User\\Models\\User",
  "user_id": 549,
  "target_type": "",
  "target_id": 0,
  "companys_id": "2",
  "departments_id": null,
  "is_active": 1,
  "is_private": 1,
  "date_at": "2023-12-03 18:16:46",
  "is_relay": 0,
  "user_relay_id": "",
  "relay_date_at": "",
  "created_by": "",
  "properties": null,
  "other_data": null,
  "config_data": null,
  "sort_order": 25,
  "created_at": "2023-12-03 18:16:46",
  "updated_at": "2023-12-03 19:54:35",
  "image": null,
  "images": [],
  "files": [],
  "object_type": "Tss\\Notes\\Models\\Note"
}
```


### Create Note To Current User

** انشاء ملاحظة جديدة **

```
POST /api/v1/notes/notes/create
```


#### Example 4 Create Note To Current User

```
POST http://localhost:8006/api/v1/notes/notes/create
```
**نقوم بتمرير البيانات المطلوبه لانشاء ملاحظة ضمن الطلب **

**الحقو المطلوبه هى **

```json
{
    "name": "عنوان الملاحظة",
    "content": "نص الملاحظة ",
}
```

```
POST http://localhost:8006/api/v1/notes/notes/create?name=%D8%A7%D9%84%D9%85%D9%84%D8%A7%D8%AD%D8%B8%D8%A9%20%D8%A7%D9%84%D8%AB%D8%A7%D9%86%D9%8A%D8%A9&content=%D9%86%D8%B5%20%D8%A7%D9%84%D9%85%D9%84%D8%A7%D8%AD%D8%B8%D8%A9%20%D8%A7%D9%84%D8%AB%D8%A7%D9%86%D9%8A%D8%A9

```

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم انشاء ملاحظة بنجاح ",
  "error": null,
  "errors": null,
  "notes_id": 39,
  "data": {
    "id": 39,
    "code": "2-4-39",
    "barcode": "",
    "name": "الملاحظة الثانية",
    "content": "نص الملاحظة الثانية",
    "additional_data": "",
    "user_type": "RainLab\\User\\Models\\User",
    "user_id": 549,
    "target_type": "",
    "target_id": 0,
    "companys_id": "2",
    "departments_id": 4,
    "is_active": 1,
    "is_private": 1,
    "date_at": "2023-12-03 18:58:00",
    "is_relay": 0,
    "user_relay_id": "",
    "relay_date_at": "",
    "created_by": "",
    "properties": null,
    "other_data": null,
    "config_data": null,
    "sort_order": null,
    "created_at": "2023-12-03 18:58:00",
    "updated_at": "2023-12-03 18:58:00",
    "image": null,
    "images": [],
    "files": [],
    "object_type": "Tss\\Notes\\Models\\Note"
  }
}
```


**فى حالة عدم ارسال كافة الحقو المطلوبه سيتم ارجاع البيانات التاليه **

```json
{
  "code": 0,
  "status": false,
  "message": "لم يتم انشاء ملاحظة  بنجاح ",
  "error": "الخاصية  التاريخ  ليست تأريخاً صالحاً",
  "errors": {
    "date_at": [
      "الخاصية  التاريخ  ليست تأريخاً صالحاً"
    ]
  },
  "data_process": {
    "user_type": "RainLab\\User\\Models\\User",
    "user_id": 549,
    "name": "",
    "content": "الملاحظة الخامسة",
    "target_type": null,
    "target_id": null,
    "is_active": true,
    "is_private": true,
    "date_at": "2023",
    "image": null
  },
  "input_data": {
    "name": "",
    "content": "الملاحظة الخامسة",
    "date_at": "2023"
  },
  "debug": {
    "line": 430,
    "file": "\/storage\/emulated\/0\/htdocs\/october_demo\/plugins\/nano\/notesapi\/apicontrollers\/Notes.php",
    "class": "October\\Rain\\Exception\\ValidationException"
  }
}
```


### Update Note To Current User 

** تعديل بيانات ملاحظة  **

```
PUT /api/v1/notes/notes/update/{id}
```

#### Example 6 Update Fields Note 

```
PUT http://localhost:8006/api/v1/notes/notes/update/39
```
Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |

**الحقول المعدلة**

```json
{
    "name": "الملاحظة الثانية تعديل.",
    "content": "تعديل نص الملاحظة الثانية",
}
```

```
put http://localhost:8006/api/v1/notes/notes/update/39?name=%D8%A7%D9%84%D9%85%D9%84%D8%A7%D8%AD%D8%B8%D8%A9%20%D8%A7%D9%84%D8%AB%D8%A7%D9%86%D9%8A%D8%A9%20%D8%AA%D8%B9%D8%AF%D9%8A%D9%84.%20&content=%D8%AA%D8%B9%D8%AF%D9%8A%D9%84%20%D9%86%D8%B5%20%D8%A7%D9%84%D9%85%D9%84%D8%A7%D8%AD%D8%B8%D8%A9%20%D8%A7%D9%84%D8%AB%D8%A7%D9%86%D9%8A%D8%A9
```
**فى المثال التالى سنقوم بتعديل بيانات ملاحظة     **


##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم التعديل بنجاح ",
  "error": "",
  "data": {
    "id": 39,
    "code": "2-4-39",
    "barcode": "",
    "name": "الملاحظة الثانية تعديل.",
    "content": "تعديل نص الملاحظة الثانية",
    "additional_data": "",
    "user_type": "RainLab\\User\\Models\\User",
    "user_id": 549,
    "target_type": "",
    "target_id": 0,
    "companys_id": "2",
    "departments_id": "4",
    "is_active": 1,
    "is_private": 1,
    "date_at": "2023-12-03 18:58:00",
    "is_relay": 0,
    "user_relay_id": "",
    "relay_date_at": "",
    "created_by": "",
    "properties": null,
    "other_data": null,
    "config_data": null,
    "sort_order": 39,
    "created_at": "2023-12-03 18:58:00",
    "updated_at": "2023-12-03 19:01:23",
    "image": null,
    "images": [],
    "files": [],
    "object_type": "Tss\\Notes\\Models\\Note"
  }
}
```


### Check Last Update Note Data 

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/notes/notes/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/notes/notes/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": null
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2022-12-20 18:17:04",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": null
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **