## Favorites Api 

This endpoint allows Favorites user. 

**هذا الجزء خاص بالمفضله واضافه الاصناف او المتاجر او اي كائن ضمن النظام الى مفضلة المستخدم **
 
```
GET /api/v1/markable/favorites
```
**or**
```
GET /api/v1/favorites/favorites
```

### The Favorites object

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `object_type`           | `string` | object class name 
| 
| `object_id`           | `string` |  identify object id
| 
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

** object_type اسم المتغير الخاص بحمل اسم الكائن المراد اضافته الى المفضله **

**object_id اسم المتغير الخاص بحمل رقم معرف  الكائن المراد اضافته الى المفضله **

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/favorites/favorites?exclude=created_at,updated_at
```


#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `user`           | `belongsTo`  | The get user data |


#### Require Useing token User to add or delete Favorites

** add Parameters Authorization in headr request **

Authorization = [token_type token]

** Require Authorization in Header Request**

```html
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiOTJiYjhkNWJjZjE4MWYxMjcyMjhlZjc5ODFmYzE5ZWFmOGY1ZjVjMWUxZjg5ZWEzMDVhMDNiMzMxZjM2OWUxYjMzZDA3NWFkM2FlMGE3YTMiLCJpYXQiOjE2NjU4NTUyODcuOTM4NDI1MSwibmJmIjoxNjY1ODU1Mjg3LjkzODQ3NDksImV4cCI6MTY5NzM5MTI4Ny45MDM3Mzk5LCJzdWIiOiI1NDkiLCJzY29wZXMiOltdfQ.uKRNZo1MNtDmdjR3pk00JjPoyE6IcJMvqdqMEOhR7syyw_a584gH4rMW9Jp4Rqq7Rc6ttM9UvKoDUk6Y38oA6elU96PcSk8nRsWZ_grSR7EwSX4DgW8qhEfVGUUm8GRceen12OBYnB3-sHOluVGWotFJdYYjWtWc9pw9otX3a8ZcC1kM3FZDqusYkPRuQiG4PiCsaRL1dRiMyp5cEc1JPma0aZL9iOBqwwB9sJYd9_wYz8S-ZEWBAGXwqbOkhZ9_GYwnfckQlgKiO1pDuX_Au_F138E659BFKNXibvU8rUTi9q15smFJ8icUBHrUhzIcQFjfdgqPQfGXkanJr5BcpByZbQMEqPhe18IBGduNaE53wClR4UL3ighFSmZWUa1ebdq6oKama5-DWDUVF18pi_owiTlkfHyXF-2aEvT-myxC7_9jvfbC3KVrOGCRuHiwWBALcdYP45ogSo7-RVCAupQi9TGrkzU85tEKCuo-JYQ3ATHjCmuW0bHsazM9je2vIe6j_-56v7YBaMR7vxoJ1kk-1rLoiEOg_IbRJ9XuQDCMk7gCOZLS9TmYvLm2oBe4VjTw7GVB8GxwB3mC8OwrcVyubTvNHTgvZH8BOrJDF349uQea4PGvXgySNktMo490zUQqn56uCCcBry3glHpdw-MYbBD5mGt5ma3AP4riLXE
```

### Add Favorites object
**لاضافه كائن معين يجب ان يكون المستخدم مسجل دخول على النظام **

```
POST /api/v1/favorites/favorites/add
```

**يجب تمرير اسم الكائن المراد اضافته الى المفضله مع معرف  الكائن id **

#### Example 1.1 Add Department 4 from Favorites list Current User

**فى المثال التالى سنقوم باضافه المتجر رقم 4 من قائمه مفضله المستخدم الحالى **

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Tss\Basic\Models\Department",
  "object_id":4,
}
```

```
POST http://localhost:8006/api/v1//favorites/favorites/add?object_type=Tss\Basic\Models\Department&object_id=4

```

##### Response

**في حال تمت عمليه الاضافه الى المفضله بنجاح سيتم ارجاع النتيجه التاليه **


```html
Status: 200 OK
```

```json
{
  "id": 2,
  "markable_type": "Tss\\Basic\\Models\\Department",
  "markable_id": 4,
  "user_id": 3,
  "user_type": "RainLab\\User\\Models\\User",
  "value": "",
  "created_at": "2023-09-14 19:59:28",
  "updated_at": "2023-09-14 19:59:28"
}
```

#### Example 1.2 Add Product 4 from Favorites list Current User

**فى المثال التالى سنقوم باضافه الصنف رقم 4 من قائمه مفضله المستخدم الحالى **

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":4,
}
```

```
GET http://localhost:8006/api/v1//favorites/favorites/add?object_type=\Nano\Shop\Models\Product&object_id=4&include=user

```

##### Response

**في حال تمت عمليه الاضافه الى المفضله بنجاح سيتم ارجاع النتيجه التاليه **


```html
Status: 200 OK
```

```json
{
  "id": 1,
  "markable_type": "products",
  "markable_id": 4,
  "user_id": 3,
  "user_type": "RainLab\\User\\Models\\User",
  "value": "",
  "created_at": "2023-09-14 19:54:58",
  "updated_at": "2023-09-14 19:54:58",
  "user": {
    "id": 3,
    "name": "",
    "surname": null,
    "username": "test_user",
    "email": "test@gmail.com",
    "mobile": "770821911",
    "gender": null,
    "date_of_birth": null,
    "address_1": null,
    "address_2": null,
    "street_name": null,
    "street_number": null,
    "latitude": null,
    "longitude": null,
    "geo_components": null,
    "city": "",
    "zip": "",
    "postcode": null,
    "country_long": null,
    "country_id": null,
    "state_id": null,
    "directorate_id": null,
    "formataddress": null,
    "vicinity": null,
    "avatar": null,
    "companys_id": "2",
    "departments_id": "2",
    "employees_id": null,
    "ref_type": "delivery",
    "ref_id": "14",
    "permissions": null,
    "is_guest": false,
    "is_superuser": false,
    "is_activated": true,
    "activated_at": "2023-07-08 18:42:28",
    "last_login": "2023-09-14 19:58:36",
    "created_at": "2023-07-08 18:42:28",
    "updated_at": "2023-09-14 19:58:36",
    "deleted_at": "",
    "created_ip_address": "185.71.133.156",
    "last_ip_address": "176.123.19.67",
    "is_delivery": true,
    "provider": "frontend",
    "orders_user_count": 38,
    "orders_user_complete_count": 1,
    "orders_user_cancelled_count": 1,
    "orders_user_delivery_count": 13,
    "orders_user_new_count": 4,
    "orders_delivery_count": 5,
    "orders_delivery_complete_count": 0,
    "orders_delivery_cancelled_count": 0,
    "orders_delivery_delivery_count": 5,
    "orders_delivery_new_count": 0,
    "ratings_count": 0,
    "countRating": 0,
    "sumRating": 0,
    "averageRating": 0,
    "user_is_rating": 0,
    "user_object_rating": null,
    "favorites_count": 0,
    "user_is_favorite": 0,
    "likes_count": 0,
    "bookmarks_count": 0,
    "reactions_count": 0,
    "object_type": "RainLab\\User\\Models\\User"
  }
}
```


**لاحظ انه فى النتيجه السابقه تم ارجاع بيانات السجل فى جدول المفضله مع بيانات المستخدم الذي قام باضافه الصنف رقم 2 الي قائمه مفضلته وذلك لاننا قمنا بتضمين العلاقه user فى الطلب **

### Response Error 
**فى بعض الحالات يتم ارجاع خطاء عن محاوله جلب قائمه المفضله او فى حاله الاضافه او الحذف سنستعرض هذه الاخطاء **

#### Response 401 Error UNAUTHORIZED 

** يتم ارجاع خطاء فى حاله عدم وجود مستخدم مسجل كا التالي  **

```html
Status: 401 Error UNAUTHORIZED
```

```json
{
  "error": {
    "code": "UNAUTHORIZED",
    "http_code": 401,
    "message": "Invalid user credential."
  }
}
```

#### Response 404 Error NOT_FOUND 

**خطاء عدم وجود الكائن المراد اضافته الى المفضله او عدم وجود رقم الكائن كا التالي  **

```html
Status: 404 Error NOT_FOUND
```

```json
{
  "error": {
    "code": "NOT_FOUND",
    "http_code": 404,
    "message": "object_type not found."
  }
}
```

or

```json
{
  "error": {
    "code": "NOT_FOUND",
    "http_code": 404,
    "message": "Object id 28 not  found."
  }
}
```
#### Response 404 Error object id NOT_FOUND 

**خطاء عدم وجود الكائن المراد اضافته الى المفضله او عدم وجود رقم الكائن كا التالي  **

```html
Status: 404 Error NOT_FOUND
```

```json
{
  "error": {
    "code": "NOT_FOUND",
    "http_code": 404,
    "message": "object_id not found."
  }
}
```

or

```json
{
  "error": {
    "code": "NOT_FOUND",
    "http_code": 404,
    "message": "Object id 28 not  found."
  }
}
```

### Delete Object in Favorites List Current User

**لحذف كائن من قائمه المفضلة للمستخدم الحالى نستخدم الرابط التالي معا تمرير البرامترات كما فى جزء الاضافه **

```
DELETE /api/v1/favorites/favorites/delete
```

**يجب تمرير اسم الكائن المراد حذفه من  المفضله مع معرف  الكائن id **

#### Example 2 Delete Product 2 from Favorites list Current User

**فى المثال التالى سنقوم بحذف  الصنف رقم 2 الى قائمه مفضله المستخدم الحالى **

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
}
```

```
DELETE http://localhost:8006/api/v1/favorites/favorites/delete?object_type=\Nano\Shop\Models\Product&object_id=2
```

##### Response

**في حال تمت عمليه الحذف من المفضله بنجاح سيتم ارجاع النتيجه التاليه **


```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تمت عملية الحذف بنجاح"
}
```

**فى حال حدث خطاء سيتم ارجع الخطاء كما وضحنا فى جزء الاخطاء سابقا**

### Toggle Favorites Object in List Current User

**تعمل هذه الداله عمل دالة الاضافه ودالة الحذف فى نفس الوقت **

**بمعنا انه فى حال لم يتم اضافه الكائن للمفضله من قبل يتم اضافته **

**وفى حال انه قد تم اضافة الكائن الى المفضله من قبل  تقوم ب **

**يمكن استخدام هذه الداله فى كل الحالات بحيث ستقوم الداله بالفحص والتنفيذ **

```
POST /api/v1/favorites/favorites/toggle
```

**يجب تمرير اسم الكائن  مع معرف  الكائن id **

#### Example 3 Use Toggle Add Product 2 from Favorites list Current User


```
POST http://localhost:8006/api/v1/favorites/favorites/toggle?object_type=\Nano\Shop\Models\Product&object_id=2
```
**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
}
```

##### Response

**بما ان الصنف رقم 2 غير مضاف الى مفضله المستخدم الحالى ستكون النتيجه كا التالى  **


```html
Status: 200 OK
```

```json
{
  "id": 6,
  "markable_type": "products",
  "markable_id": 2,
  "user_id": 3,
  "user_type": "RainLab\\User\\Models\\User",
  "value": "",
  "created_at": "2023-09-14 20:05:46",
  "updated_at": "2023-09-14 20:05:46"
}
```

**فى حال حدث خطاء سيتم ارجع الخطاء كما وضحنا فى جزء الاخطاء سابقا**

#### Example 4 Use Toggle Delete Product 2 from Favorites list Current User

**فى المثال التالى سنقوم بتمرير نفس البيانات فى المثال السابق  **

```
POST http://localhost:8006/api/v1/favorites/favorites/toggle?object_type=\Nano\Shop\Models\Product&object_id=2
```

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
}
```


##### Response

**فى هذه الحالة ستقوم الدالة بالفحص هل الصنف مضافه الى مفضله المستخدم  نعم سيتم حذفه **


```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تمت عملية الحذف بنجاح"
}
```

**فى حال حدث خطاء سيتم ارجع الخطاء كما وضحنا فى جزء الاخطاء سابقا**

### Get Favorites List 

 **يمكنك جلب  قائمه المفضله لنوع معين من الكائنات او لكافه الكائنات من خلال الرابط التالي **

```
GET /api/v1/favorites/favorites
```

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isUser`           | `boolean`  | use not curent user deafult value true
| 
| `object_type`           | `string`  | object class name 
| 
| `object_id`           | `string`  |  identify object id
| 
| `include`           | `string` | get relation using [relation1,relation2,relation3]

**isUser**
**يتم استخدام المتغير السابق فى حاله اردنا جلب جميع الاصناف التي قام المستخدمون باضافتها الى مفضلتهم وذلك بجعل قيمة المتغير صفر **

** object_type اسم المتغير الخاص بحمل اسم الكائن **

**object_id اسم المتغير الخاص بحمل رقم معرف  الكائن **


#### Example 5

**فى المثال التالي سنقوم بجلب كافه الكائنات التي اضافها المستخدم الحالي **

```
GET http://localhost:8006/api/v1/favorites/favorites
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 10,
      "markable_type": "products",
      "markable_id": 25,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:08:33",
      "updated_at": "2023-09-14 20:08:33"
    },
    {
      "id": 9,
      "markable_type": "products",
      "markable_id": 222,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:08:28",
      "updated_at": "2023-09-14 20:08:28"
    },
    {
      "id": 8,
      "markable_type": "products",
      "markable_id": 22,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:08:23",
      "updated_at": "2023-09-14 20:08:23"
    },
    {
      "id": 5,
      "markable_type": "Tss\\Basic\\Models\\Department",
      "markable_id": 18,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:05:19",
      "updated_at": "2023-09-14 20:05:19"
    },
    {
      "id": 4,
      "markable_type": "Tss\\Basic\\Models\\Department",
      "markable_id": 10,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:05:13",
      "updated_at": "2023-09-14 20:05:13"
    },
    {
      "id": 3,
      "markable_type": "Tss\\Basic\\Models\\Department",
      "markable_id": 4,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:04:56",
      "updated_at": "2023-09-14 20:04:56"
    },
    {
      "id": 1,
      "markable_type": "products",
      "markable_id": 4,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 19:54:58",
      "updated_at": "2023-09-14 19:54:58"
    }
  ],
  "meta": {
    "pagination": {
      "total": 7,
      "count": 7,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```
#### Example 6 

**فى المثال التالي سنقوم بجلب كافه الاصناف التي اضافها المستخدم الحالي إلى المفضلة **

```
GET http://localhost:8006/api/v1/favorites/favorites?object_type=Nano\Shop\Models\Product
```

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
}
```


##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 10,
      "markable_type": "products",
      "markable_id": 25,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:08:33",
      "updated_at": "2023-09-14 20:08:33"
    },
    {
      "id": 9,
      "markable_type": "products",
      "markable_id": 222,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:08:28",
      "updated_at": "2023-09-14 20:08:28"
    },
    {
      "id": 8,
      "markable_type": "products",
      "markable_id": 22,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:08:23",
      "updated_at": "2023-09-14 20:08:23"
    },
    {
      "id": 1,
      "markable_type": "products",
      "markable_id": 4,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 19:54:58",
      "updated_at": "2023-09-14 19:54:58"
    }
  ],
  "meta": {
    "pagination": {
      "total": 4,
      "count": 4,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```
#### Example  7

**فى المثال التالي سنقوم بجلب كافه المحلات ا   الفروع التي اضافها المستخدم الحالي إلى المفضلة **

```
GET http://localhost:8006/api/v1/favorites/favorites?object_type=Tss\Basic\Models\Department
```

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Tss\Basic\Models\Department",
}
```


##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 5,
      "markable_type": "Tss\\Basic\\Models\\Department",
      "markable_id": 18,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:05:19",
      "updated_at": "2023-09-14 20:05:19"
    },
    {
      "id": 4,
      "markable_type": "Tss\\Basic\\Models\\Department",
      "markable_id": 10,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:05:13",
      "updated_at": "2023-09-14 20:05:13"
    },
    {
      "id": 3,
      "markable_type": "Tss\\Basic\\Models\\Department",
      "markable_id": 4,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:04:56",
      "updated_at": "2023-09-14 20:04:56"
    }
  ],
  "meta": {
    "pagination": {
      "total": 3,
      "count": 3,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```
#### Example 8 

**فى المثال التالي سنقوم بجلب كافه الاصناف التي اضافها المستخدمون الى مفضلتهم **

```
GET http://localhost:8006/api/v1/favorites/favorites?isUser=0&object_type=Nano\Shop\Models\Product
```

**البيانات التي تم تمريرها كا التالي **

```json
{
  "isUser":0,
  "object_type":"\Nano\Shop\Models\Product",
}
```


##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 17,
      "markable_type": "products",
      "markable_id": 22,
      "user_id": 6,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:23:08",
      "updated_at": "2023-09-14 20:23:08"
    },
    {
      "id": 16,
      "markable_type": "products",
      "markable_id": 44,
      "user_id": 6,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:23:01",
      "updated_at": "2023-09-14 20:23:01"
    },
    {
      "id": 15,
      "markable_type": "products",
      "markable_id": 4,
      "user_id": 6,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:22:56",
      "updated_at": "2023-09-14 20:22:56"
    },
    {
      "id": 10,
      "markable_type": "products",
      "markable_id": 25,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:08:33",
      "updated_at": "2023-09-14 20:08:33"
    },
    {
      "id": 9,
      "markable_type": "products",
      "markable_id": 222,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:08:28",
      "updated_at": "2023-09-14 20:08:28"
    },
    {
      "id": 8,
      "markable_type": "products",
      "markable_id": 22,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:08:23",
      "updated_at": "2023-09-14 20:08:23"
    },
    {
      "id": 1,
      "markable_type": "products",
      "markable_id": 4,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 19:54:58",
      "updated_at": "2023-09-14 19:54:58"
    }
  ],
  "meta": {
    "pagination": {
      "total": 7,
      "count": 7,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

#### Example 9 

**فى المثال التالي سنقوم بجلب كافه الاشخاص الذين قامو باضافه الصنف رقم 4 الى مفضلتهم  **

```
GET http://localhost:8006/api/v1/favorites/favorites?include=user&isUser=0&object_type=Nano\Shop\Models\Product&object_id=4
```

**البيانات التي تم تمريرها كا التالي **

```json
{
  "include":"user",
  "isUser":0,
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":4,
}
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 15,
      "markable_type": "products",
      "markable_id": 4,
      "user_id": 6,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 20:22:56",
      "updated_at": "2023-09-14 20:22:56",
      "user": {
        "id": 6,
        "name": "dheia ali",
        "surname": null,
        "username": "770529489@gmail.com",
        "email": "770529489@gmail.com",
        "mobile": "770529489",
        "gender": null,
        "date_of_birth": null,
        "address_1": "",
        "address_2": "",
        "street_name": "",
        "street_number": "",
        "latitude": null,
        "longitude": null,
        "geo_components": null,
        "city": "",
        "zip": "",
        "postcode": null,
        "country_long": null,
        "country_id": null,
        "state_id": null,
        "directorate_id": null,
        "formataddress": null,
        "vicinity": null,
        "avatar": null,
        "companys_id": "2",
        "departments_id": "4",
        "employees_id": null,
        "ref_type": "user",
        "ref_id": null,
        "permissions": null,
        "is_guest": false,
        "is_superuser": false,
        "is_activated": true,
        "activated_at": "2023-08-26 19:31:26",
        "last_login": "2023-09-14 20:23:08",
        "created_at": "2023-08-26 19:24:51",
        "updated_at": "2023-09-14 20:23:08",
        "deleted_at": "",
        "created_ip_address": "176.123.18.44",
        "last_ip_address": "176.123.18.253",
        "is_delivery": true,
        "provider": "frontend",
        "orders_user_count": 2,
        "orders_user_complete_count": 0,
        "orders_user_cancelled_count": 0,
        "orders_user_delivery_count": 0,
        "orders_user_new_count": 0,
        "orders_delivery_count": 1,
        "orders_delivery_complete_count": 0,
        "orders_delivery_cancelled_count": 0,
        "orders_delivery_delivery_count": 1,
        "orders_delivery_new_count": 0,
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": 0,
        "averageRating": 0,
        "user_is_rating": 0,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": 0,
        "likes_count": 0,
        "bookmarks_count": 0,
        "reactions_count": 0,
        "object_type": "RainLab\\User\\Models\\User"
      }
    },
    {
      "id": 1,
      "markable_type": "products",
      "markable_id": 4,
      "user_id": 3,
      "user_type": "RainLab\\User\\Models\\User",
      "value": "",
      "created_at": "2023-09-14 19:54:58",
      "updated_at": "2023-09-14 19:54:58",
      "user": {
        "id": 3,
        "name": "",
        "surname": null,
        "username": "test_user",
        "email": "test@gmail.com",
        "mobile": "770821911",
        "gender": null,
        "date_of_birth": null,
        "address_1": null,
        "address_2": null,
        "street_name": null,
        "street_number": null,
        "latitude": null,
        "longitude": null,
        "geo_components": null,
        "city": "",
        "zip": "",
        "postcode": null,
        "country_long": null,
        "country_id": null,
        "state_id": null,
        "directorate_id": null,
        "formataddress": null,
        "vicinity": null,
        "avatar": null,
        "companys_id": "2",
        "departments_id": "2",
        "employees_id": null,
        "ref_type": "delivery",
        "ref_id": "14",
        "permissions": null,
        "is_guest": false,
        "is_superuser": false,
        "is_activated": true,
        "activated_at": "2023-07-08 18:42:28",
        "last_login": "2023-09-14 20:24:46",
        "created_at": "2023-07-08 18:42:28",
        "updated_at": "2023-09-14 20:24:46",
        "deleted_at": "",
        "created_ip_address": "185.71.133.156",
        "last_ip_address": "176.123.19.67",
        "is_delivery": true,
        "provider": "frontend",
        "orders_user_count": 38,
        "orders_user_complete_count": 1,
        "orders_user_cancelled_count": 1,
        "orders_user_delivery_count": 13,
        "orders_user_new_count": 4,
        "orders_delivery_count": 5,
        "orders_delivery_complete_count": 0,
        "orders_delivery_cancelled_count": 0,
        "orders_delivery_delivery_count": 5,
        "orders_delivery_new_count": 0,
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": 0,
        "averageRating": 0,
        "user_is_rating": 0,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": 0,
        "likes_count": 0,
        "bookmarks_count": 0,
        "reactions_count": 0,
        "object_type": "RainLab\\User\\Models\\User"
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```


