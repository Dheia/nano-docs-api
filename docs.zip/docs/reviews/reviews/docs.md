## Reviews Api 

This endpoint allows Reviews user. 

**هذا الجزء خاص بالتقييم  الاصناف او المتاجر او اي كائن ضمن النظام من قبل   المستخدم **
 
```
GET /api/v1/reviews/reviews
```

### The Reviews object

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `object_type`           | `string` | object class name 
| 
| `object_id`           | `string` |  identify object id
| `rating`           | `integer` |  rating 1-5 **Require**
| 
| `title`           | `string` |  option 
| 
| `content`           | `string` |  option 
| 
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 


** object_type اسم المتغير الخاص بحمل اسم الكائن المراد تقييمه **

**object_id اسم المتغير الخاص بحمل رقم معرف  الكائن المراد تقييمه **

**rating اسم المتغير الخاص بحمل قيمه التقييم وهذه القيمه يجب ان لا تكون اكبر من 5**

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/reviews/reviews?exclude=created_at,updated_at
```
#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `user`           | `belongsTo`  | The get user data |


#### Require Useing token User to add or delete Reviews

** add Parameters Authorization in headr request **

Authorization = [token_type token]

** Require Authorization in Header Request**

```html
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiOTJiYjhkNWJjZjE4MWYxMjcyMjhlZjc5ODFmYzE5ZWFmOGY1ZjVjMWUxZjg5ZWEzMDVhMDNiMzMxZjM2OWUxYjMzZDA3NWFkM2FlMGE3YTMiLCJpYXQiOjE2NjU4NTUyODcuOTM4NDI1MSwibmJmIjoxNjY1ODU1Mjg3LjkzODQ3NDksImV4cCI6MTY5NzM5MTI4Ny45MDM3Mzk5LCJzdWIiOiI1NDkiLCJzY29wZXMiOltdfQ.uKRNZo1MNtDmdjR3pk00JjPoyE6IcJMvqdqMEOhR7syyw_a584gH4rMW9Jp4Rqq7Rc6ttM9UvKoDUk6Y38oA6elU96PcSk8nRsWZ_grSR7EwSX4DgW8qhEfVGUUm8GRceen12OBYnB3-sHOluVGWotFJdYYjWtWc9pw9otX3a8ZcC1kM3FZDqusYkPRuQiG4PiCsaRL1dRiMyp5cEc1JPma0aZL9iOBqwwB9sJYd9_wYz8S-ZEWBAGXwqbOkhZ9_GYwnfckQlgKiO1pDuX_Au_F138E659BFKNXibvU8rUTi9q15smFJ8icUBHrUhzIcQFjfdgqPQfGXkanJr5BcpByZbQMEqPhe18IBGduNaE53wClR4UL3ighFSmZWUa1ebdq6oKama5-DWDUVF18pi_owiTlkfHyXF-2aEvT-myxC7_9jvfbC3KVrOGCRuHiwWBALcdYP45ogSo7-RVCAupQi9TGrkzU85tEKCuo-JYQ3ATHjCmuW0bHsazM9je2vIe6j_-56v7YBaMR7vxoJ1kk-1rLoiEOg_IbRJ9XuQDCMk7gCOZLS9TmYvLm2oBe4VjTw7GVB8GxwB3mC8OwrcVyubTvNHTgvZH8BOrJDF349uQea4PGvXgySNktMo490zUQqn56uCCcBry3glHpdw-MYbBD5mGt5ma3AP4riLXE
```

### Add Reviews object
**لتقييم كائن معين يجب ان يكون المستخدم مسجل دخول على النظام **

```
POST /api/v1/reviews/reviews/add
```

**يجب تمرير اسم الكائن المراد تقييمة مع معرف  الكائن id **

#### Example 1 Add Product 2 from Reviews  Current User

**فى المثال التالى سنقوم بتقييم الصنف رقم 2 من قائمه مفضله المستخدم الحالى **

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
}
```

```
GET http://localhost:8006/api/v1/reviews/reviews/add?include=user&object_type=\Nano\Shop\Models\Product&object_id=2

```

##### Response

**في حال تمت عمليه االتقييم  بنجاح سيتم ارجاع النتيجه التاليه **


```html
Status: 200 OK
```

```json
{
  "id": 21,
  "rating": 4,
  "title": null,
  "content": null,
  "reviewrateable_type": "products",
  "reviewrateable_id": 2,
  "user_id": 543,
  "user_type": "RainLab\\User\\Models\\User",
  "approved": true,
  "is_recommended": true,
  "is_active": true,
  "created_at": "2022-10-26 22:43:02",
  "updated_at": "2022-10-26 22:43:02"
}
```


### Response Error 
**فى بعض الحالات يتم ارجاع خطاء عن محاوله جلب الكائنات التي تم تقييمها او فى حاله االتقييم او الحذف سنستعرض هذه الاخطاء **

#### Response 401 Error UNAUTHORIZED 

** يتم ارجاع خطاء فى حاله عدم وجود مستخدم مسجل كا التالي  **

```html
Status: 401 Error UNAUTHORIZED
```

```json
{
  "error": {
    "code": "UNAUTHORIZED",
    "http_code": 401,
    "message": "Invalid user credential."
  }
}
```

#### Response 404 Error NOT_FOUND 

**خطاء عدم وجود الكائن المراد تقييمة او عدم وجود رقم الكائن كا التالي  **

```html
Status: 404 Error NOT_FOUND
```

```json
{
  "error": {
    "code": "NOT_FOUND",
    "http_code": 404,
    "message": "object_type not found."
  }
}
```

or

```json
{
  "error": {
    "code": "NOT_FOUND",
    "http_code": 404,
    "message": "Object id 28 not  found."
  }
}
```

**في حاله عدم تمرير قيمه rating**

```json
{
  "error": {
    "code": "NOT_FOUND",
    "http_code": 404,
    "message": "Review not found."
  }
}
```

### Delete Object in Reviews List Current User

**لحذف تقييم لكائن معين من قبل المستخدم الحالى نستخدم الرابط التالي معا تمرير البرامترات كما فى جزء الاضافه **

```
DELETE /api/v1/reviews/reviews/delete
```

**يجب تمرير اسم الكائن المراد حذفه من  المفضله مع معرف  الكائن id **

**يمكن ايضا تمرير معرف السجل المراد حذفه فى نهايه الرابط **
#### Example 2 Delete Product 2 from Reviews list Current User

**فى المثال التالى سنقوم بحذف  تقييم الصنف رقم 2 من قبل المستخدم الحالى **

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
}
```

```
DELETE http://localhost:8006/api/v1/reviews/reviews/delete?object_type=\Nano\Shop\Models\Product&object_id=2
```

##### Response

**في حال تمت عمليه الحذف بنجاح سيتم ارجاع النتيجه التاليه **


```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم حذف التقييم"
}
```

**فى حال حدث خطاء سيتم ارجع الخطاء كما وضحنا فى جزء الاخطاء سابقا**

### Toggle Reviews Object in List Current User

**تعمل هذه الداله عمل دالة الاضافه ودالة الحذف فى نفس الوقت **

**بمعنا انه فى حال لم يتم اضافه تقييم للكائن من قبل يتم اضافته **

**وفى حال انه قد تم اضافة تقييم للكائن من قبل  تقوم بتعديل التقييم  **

**يمكن استخدام هذه الداله فى كل الحالات بحيث ستقوم الداله بالفحص والتنفيذ **

```
POST /api/v1/reviews/reviews/toggle
```

**يجب تمرير اسم الكائن  مع معرف  الكائن id **

#### Example 3 Use Toggle Add Product 2 from Reviews list Current User

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
  "rating":4,
}
```

```
POST http://localhost:8006/api/v1/reviews/reviews/toggle?object_type=\Nano\Shop\Models\Product&object_id=2&rating=4
```

##### Response

**بما ان الصنف رقم 2 غير مضاف مقيم من قبل  المستخدم الحالى ستكون النتيجه كا التالى  **


```html
Status: 200 OK
```

```json
{
  "id": 22,
  "rating": 4,
  "title": null,
  "content": null,
  "reviewrateable_type": "products",
  "reviewrateable_id": 2,
  "user_id": 543,
  "user_type": "RainLab\\User\\Models\\User",
  "approved": true,
  "is_recommended": true,
  "is_active": true,
  "created_at": "2022-10-26 22:52:52",
  "updated_at": "2022-10-26 22:52:52"
}
```

**فى حال حدث خطاء سيتم ارجع الخطاء كما وضحنا فى جزء الاخطاء سابقا**

#### Example 4 Use Toggle Update Product 2 from Reviews list Current User

**فى المثال التالى سنقوم بحذف  الصنف رقم 2 من مفضلة المستخدم الحالى **

**البيانات التي تم تمريرها كا التالي **

```json
{
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
  "rating":3,
}
```

```
POST http://localhost:8006/api/v1/reviews/reviews/toggle?object_type=\Nano\Shop\Models\Product&object_id=2&rating=3
```

##### Response

**فى هذه الحالة ستقوم الدالة بالفحص هل الصنف مضافه مقيم من قبل  المستخدم  نعم سيتم حذفه **


```html
Status: 200 OK
```

```json
{
  "id": 22,
  "rating": 3,
  "title": null,
  "content": null,
  "reviewrateable_type": "products",
  "reviewrateable_id": 2,
  "user_id": 543,
  "user_type": "RainLab\\User\\Models\\User",
  "approved": true,
  "is_recommended": true,
  "is_active": true,
  "created_at": "2022-10-26 22:52:52",
  "updated_at": "2022-10-26 22:55:44"
}
```

**فى حال حدث خطاء سيتم ارجع الخطاء كما وضحنا فى جزء الاخطاء سابقا**

### Get Reviews List 

 **يمكنك جلب  قائمه التقييمات لنوع معين من الكائنات او لكافه الكائنات من خلال الرابط التالي **

```
GET /api/v1/reviews/reviews
```

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isUser`           | `boolean`  | use not curent user deafult value true
| 
| `object_type`           | `string`  | object class name 
| 
| `object_id`           | `string`  |  identify object id
| 
| `include`           | `string` | get relation using [relation1,relation2,relation3]

**isUser**
**يتم استخدام المتغير السابق فى حاله اردنا جلب جميع الاصناف التي قام المستخدمون بتقييمها وذلك بجعل قيمة المتغير صفر **

** object_type اسم المتغير الخاص بحمل اسم الكائن **

**object_id اسم المتغير الخاص بحمل رقم معرف  الكائن **


#### Example 5 

**فى المثال التالي سنقوم بجلب كافه الاصناف التي قام المستخدمون بتقييمها **

```
GET http://localhost:8006/api/v1/reviews/reviews?isUser=0&object_type=Nano\Shop\Models\Product
```

**البيانات التي تم تمريرها كا التالي **

```json
{
  "isUser":0,
  "object_type":"\Nano\Shop\Models\Product",
}
```


##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 23,
      "rating": 5,
      "title": null,
      "content": null,
      "reviewrateable_type": "products",
      "reviewrateable_id": 1,
      "user_id": 543,
      "user_type": "RainLab\\User\\Models\\User",
      "approved": true,
      "is_recommended": true,
      "is_active": true,
      "created_at": "2022-10-26 22:59:34",
      "updated_at": "2022-10-26 22:59:34"
    },
    {
      "id": 22,
      "rating": 3,
      "title": null,
      "content": null,
      "reviewrateable_type": "products",
      "reviewrateable_id": 2,
      "user_id": 543,
      "user_type": "RainLab\\User\\Models\\User",
      "approved": true,
      "is_recommended": true,
      "is_active": true,
      "created_at": "2022-10-26 22:52:52",
      "updated_at": "2022-10-26 22:55:44"
    },
    {
      "id": 15,
      "rating": 3,
      "title": "543منتج رائع",
      "content": "التعليق 543",
      "reviewrateable_type": "products",
      "reviewrateable_id": 4,
      "user_id": 543,
      "user_type": "RainLab\\User\\Models\\User",
      "approved": true,
      "is_recommended": true,
      "is_active": true,
      "created_at": "2022-10-11 19:12:46",
      "updated_at": "2022-10-11 19:23:31"
    }
  ],
  "meta": {
    "pagination": {
      "total": 3,
      "count": 3,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

#### Example 6 

**فى المثال التالي سنقوم بجلب كافه الاشخاص الذين قامو بتقييم الصنف رقم 2 الى مفضلتهم  **

```
GET http://localhost:8006/api/v1/reviews/reviews?include=user&isUser=0&object_type=Nano\Shop\Models\Product&object_id=2
```

**البيانات التي تم تمريرها كا التالي **

```json
{
  "include":"user",
  "isUser":0,
  "object_type":"\Nano\Shop\Models\Product",
  "object_id":2,
}
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 27,
      "rating": 2,
      "title": null,
      "content": null,
      "reviewrateable_type": "products",
      "reviewrateable_id": 2,
      "user_id": 445,
      "user_type": "RainLab\\User\\Models\\User",
      "approved": true,
      "is_recommended": true,
      "is_active": true,
      "created_at": "2022-10-26 23:08:28",
      "updated_at": "2022-10-26 23:08:28"
    },
    {
      "id": 26,
      "rating": 5,
      "title": null,
      "content": null,
      "reviewrateable_type": "products",
      "reviewrateable_id": 2,
      "user_id": 443,
      "user_type": "RainLab\\User\\Models\\User",
      "approved": true,
      "is_recommended": true,
      "is_active": true,
      "created_at": "2022-10-26 23:08:17",
      "updated_at": "2022-10-26 23:08:17"
    },
    {
      "id": 25,
      "rating": 5,
      "title": null,
      "content": null,
      "reviewrateable_type": "products",
      "reviewrateable_id": 2,
      "user_id": 444,
      "user_type": "RainLab\\User\\Models\\User",
      "approved": true,
      "is_recommended": true,
      "is_active": true,
      "created_at": "2022-10-26 23:06:14",
      "updated_at": "2022-10-26 23:06:14"
    },
    {
      "id": 22,
      "rating": 3,
      "title": null,
      "content": null,
      "reviewrateable_type": "products",
      "reviewrateable_id": 2,
      "user_id": 543,
      "user_type": "RainLab\\User\\Models\\User",
      "approved": true,
      "is_recommended": true,
      "is_active": true,
      "created_at": "2022-10-26 22:52:52",
      "updated_at": "2022-10-26 22:55:44"
    }
  ],
  "meta": {
    "pagination": {
      "total": 4,
      "count": 4,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```


