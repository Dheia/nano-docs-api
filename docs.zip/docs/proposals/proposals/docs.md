## Proposals  Api

This endpoint allows you to `list`, `show` your proposals.

/proposals/proposals

**الجزء الخاص بالمقترحات والشكاوي والبلاغات **

**عند استخدام هذا الجزء من الضروري ان يكون هناك مستخدم مسجل دخول **

### The proposals object

#### Public Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in proposals  records |
| `orderBy`           | `string`  |  using orderBy departments records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy departments records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  proposals default value true    |
| `companys_id`           | `integer`  |  get records proposals to companys_id default value false.         |
| `departments_id`           | `integer`  | get records proposals to departments_id default value true.          |
| `type`           | `string`  | get records proposals to [proposals ,reports , complaints] default value all.          |
| `target_type`           | `string`  | get records proposals  default value all.          |
| `target_id`           | `integer|string`  | get records proposals  default value all.          |
| `isFavorites`           | `boolean `  | useing get proposals where my Favorites default value false 
| 
| `include`           | `string `  | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

**شرح قيم الحقل type **

```json
{
  "proposals": "مقترحات",
  "complaints": "شكاوي",
  "reports": "بلاغات",
}
```

**يجب تحديد النوع عند الاضافه علماً ان القيمة الافتراضيه هيا مقترحات proposals**
#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/proposals/proposals?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `department`           | `belongsTo`  | The get department | 
| `user`           | `belongsTo`  | The get user   | 

### List proposals

Returns a list of Proposals’

```
GET /api/v1/proposals/proposals
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Example 1.1 get List Proposals  

**سنقوم بجلب كافه انواع السجلات مقترحات وشكاوي وبلاغات **

```
GET http://localhost:8006/api/v1/proposals/proposals
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 5,
      "code": "2-4-5",
      "barcode": "",
      "name": "عنوان الشكوى رقم اثنين بعد التعديل",
      "content": "نص موضوع الشكوي رقم اثنان بعد التعديل",
      "type": "complaints",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 18:07:25",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 5,
      "created_at": "2023-12-04 18:07:25",
      "updated_at": "2023-12-04 18:13:39",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    },
    {
      "id": 4,
      "code": "2-4-4",
      "barcode": "",
      "name": "عنوان الشكوى رقم واحد",
      "content": "نص موضوع الشكوي رقم واحد",
      "type": "complaints",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 18:05:59",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 4,
      "created_at": "2023-12-04 18:05:59",
      "updated_at": "2023-12-04 18:05:59",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    },
    {
      "id": 3,
      "code": "2-4-3",
      "barcode": "",
      "name": "عنوان المقترح الثالث",
      "content": "نص موضوع المقترح الثالث",
      "type": "proposals",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 17:59:07",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 3,
      "created_at": "2023-12-04 17:59:07",
      "updated_at": "2023-12-04 17:59:07",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    },
    {
      "id": 2,
      "code": "2-4-2",
      "barcode": "",
      "name": "عنوان المقترح الثاني",
      "content": "نص موضوع المقترح الثاني",
      "type": "proposals",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 17:47:11",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 2,
      "created_at": "2023-12-04 17:47:11",
      "updated_at": "2023-12-04 17:47:11",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    },
    {
      "id": 1,
      "code": "2-4-1",
      "barcode": "",
      "name": "عنوان المقترح الاول",
      "content": "نص موضوع المقترح الاول",
      "type": "proposals",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 17:41:11",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 1,
      "created_at": "2023-12-04 17:41:11",
      "updated_at": "2023-12-04 17:41:11",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    }
  ],
  "meta": {
    "pagination": {
      "total": 5,
      "count": 5,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```


#### Example 1.2 get List Proposals where type = proposals  

**لجلب المقترحات فقط نمرر النوع مقترخ  **

```json
{
  "type": "proposals",
}
```

```
GET http://localhost:8006/api/v1/proposals/proposals?type=proposals
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 3,
      "code": "2-4-3",
      "barcode": "",
      "name": "عنوان المقترح الثالث",
      "content": "نص موضوع المقترح الثالث",
      "type": "proposals",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 17:59:07",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 3,
      "created_at": "2023-12-04 17:59:07",
      "updated_at": "2023-12-04 17:59:07",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    },
    {
      "id": 2,
      "code": "2-4-2",
      "barcode": "",
      "name": "عنوان المقترح الثاني",
      "content": "نص موضوع المقترح الثاني",
      "type": "proposals",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 17:47:11",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 2,
      "created_at": "2023-12-04 17:47:11",
      "updated_at": "2023-12-04 17:47:11",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    },
    {
      "id": 1,
      "code": "2-4-1",
      "barcode": "",
      "name": "عنوان المقترح الاول",
      "content": "نص موضوع المقترح الاول",
      "type": "proposals",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 17:41:11",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 1,
      "created_at": "2023-12-04 17:41:11",
      "updated_at": "2023-12-04 17:41:11",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    }
  ],
  "meta": {
    "pagination": {
      "total": 3,
      "count": 3,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

#### Example 1.3 get List Proposals where type = complaints  

**لجلب الشكاوي فقط نمرر النوع شكاوي **

```json
{
  "type": "complaints",
}
```

```
GET http://localhost:8006/api/v1/proposals/proposals?type=complaints
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 5,
      "code": "2-4-5",
      "barcode": "",
      "name": "عنوان الشكوى رقم اثنين بعد التعديل",
      "content": "نص موضوع الشكوي رقم اثنان بعد التعديل",
      "type": "complaints",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 18:07:25",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 5,
      "created_at": "2023-12-04 18:07:25",
      "updated_at": "2023-12-04 18:13:39",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    },
    {
      "id": 4,
      "code": "2-4-4",
      "barcode": "",
      "name": "عنوان الشكوى رقم واحد",
      "content": "نص موضوع الشكوي رقم واحد",
      "type": "complaints",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "",
      "target_id": 0,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 18:05:59",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 4,
      "created_at": "2023-12-04 18:05:59",
      "updated_at": "2023-12-04 18:05:59",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

#### Example 1.4 get List Proposals where type = reports  

**لجلب البلاغات فقط نمرر النوع بلاغ  **

```json
{
  "type": "reports",
}
```

```
GET http://localhost:8006/api/v1/proposals/proposals?type=reports
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 10,
      "code": "2-4-10",
      "barcode": "",
      "name": "عنوان البلاغ ان وجد",
      "content": "نص البلاغ على المستخدم رقم 550",
      "type": "reports",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "RainLab\\User\\Models\\User",
      "target_id": 550,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 19:05:52",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 10,
      "created_at": "2023-12-04 19:05:52",
      "updated_at": "2023-12-04 19:05:52",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    },
    {
      "id": 9,
      "code": "2-4-9",
      "barcode": "",
      "name": "عنوان البلاغ ان وجد",
      "content": "نص البلاغ عن المتجر رقم 4",
      "type": "reports",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "Tss\\Basic\\Models\\Department",
      "target_id": 4,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 19:03:08",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 9,
      "created_at": "2023-12-04 19:03:08",
      "updated_at": "2023-12-04 19:03:08",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    },
    {
      "id": 8,
      "code": "2-4-8",
      "barcode": "",
      "name": "عنوان البلاغ ان وجد",
      "content": "نص البلاغ عن المتجر رقم 4",
      "type": "reports",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "Tss\\Basic\\Models\\Department",
      "target_id": 4,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 18:58:27",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 8,
      "created_at": "2023-12-04 18:58:27",
      "updated_at": "2023-12-04 18:58:27",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    },
    {
      "id": 7,
      "code": "2-4-7",
      "barcode": "",
      "name": "عنوان البلاغ ان وجد",
      "content": "نص البلاغ عن المتجر رقم 4",
      "type": "reports",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "TssBasicModelsDepartment",
      "target_id": 4,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 18:54:15",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 7,
      "created_at": "2023-12-04 18:54:15",
      "updated_at": "2023-12-04 18:54:15",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    },
    {
      "id": 6,
      "code": "2-4-6",
      "barcode": "",
      "name": "عنوان البلاغ ان وجد",
      "content": "نص البلاغ هنا",
      "type": "reports",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "RainLab\\User\\Models\\User",
      "target_id": 550,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 18:51:52",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 6,
      "created_at": "2023-12-04 18:51:52",
      "updated_at": "2023-12-04 18:51:52",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    }
  ],
  "meta": {
    "pagination": {
      "total": 5,
      "count": 5,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

#### Example 1.5 get List Proposals where type = reports and target_type = User

**لجلب البلاغات فقط نمرر النوع بلاغ  **
**البلاغات على مستخدم فرنت معين **

```json
{
  "type": "reports",
  "target_type": "RainLab\\User\\Models\\User",
  "target_id": 550,
}
```

```
GET http://localhost:8006/api/v1/proposals/proposals?type=reports&target_type=RainLab\\User\\Models\\User&target_id=550
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 10,
      "code": "2-4-10",
      "barcode": "",
      "name": "عنوان البلاغ ان وجد",
      "content": "نص البلاغ على المستخدم رقم 550",
      "type": "reports",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "RainLab\\User\\Models\\User",
      "target_id": 550,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 19:05:52",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 10,
      "created_at": "2023-12-04 19:05:52",
      "updated_at": "2023-12-04 19:05:52",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    },
    {
      "id": 6,
      "code": "2-4-6",
      "barcode": "",
      "name": "عنوان البلاغ ان وجد",
      "content": "نص البلاغ هنا",
      "type": "reports",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "RainLab\\User\\Models\\User",
      "target_id": 550,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 18:51:52",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 6,
      "created_at": "2023-12-04 18:51:52",
      "updated_at": "2023-12-04 18:51:52",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

#### Example 1.6 get List Proposals where type = reports and target_type = Department

**لجلب البلاغات فقط نمرر النوع بلاغ  **
**البلاغات على كافة المحلات  **

```json
{
  "type": "reports",
  "target_type": "Tss\\Basic\\Models\\Department",
  "target_id": 550,
}
```

```
GET http://localhost:8006/api/v1/proposals/proposals?type=reports&target_type=Tss\\Basic\\Models\\Department
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 11,
      "code": "2-4-11",
      "barcode": "",
      "name": "عنوان البلاغ ان وجد",
      "content": "نص البلاغ عن المتجر رقم 3",
      "type": "reports",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "Tss\\Basic\\Models\\Department",
      "target_id": 3,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 19:22:35",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 11,
      "created_at": "2023-12-04 19:22:35",
      "updated_at": "2023-12-04 19:22:35",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    },
    {
      "id": 9,
      "code": "2-4-9",
      "barcode": "",
      "name": "عنوان البلاغ ان وجد",
      "content": "نص البلاغ عن المتجر رقم 4",
      "type": "reports",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "Tss\\Basic\\Models\\Department",
      "target_id": 4,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 19:03:08",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 9,
      "created_at": "2023-12-04 19:03:08",
      "updated_at": "2023-12-04 19:03:08",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    },
    {
      "id": 8,
      "code": "2-4-8",
      "barcode": "",
      "name": "عنوان البلاغ ان وجد",
      "content": "نص البلاغ عن المتجر رقم 4",
      "type": "reports",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "Tss\\Basic\\Models\\Department",
      "target_id": 4,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 18:58:27",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 8,
      "created_at": "2023-12-04 18:58:27",
      "updated_at": "2023-12-04 18:58:27",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    }
  ],
  "meta": {
    "pagination": {
      "total": 3,
      "count": 3,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

#### Example 1.7 get List Proposals where type = reports and target_type = Department and target_id = 3

**لجلب البلاغات فقط نمرر النوع بلاغ  **
**البلاغات على المحل رقم 3 فقط   **

```json
{
  "type": "reports",
  "target_type": "Tss\\Basic\\Models\\Department",
  "target_id": 3,
}
```

```
GET http://localhost:8006/api/v1/proposals/proposals?type=reports&target_type=Tss\\Basic\\Models\\Department&target_id=3
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 11,
      "code": "2-4-11",
      "barcode": "",
      "name": "عنوان البلاغ ان وجد",
      "content": "نص البلاغ عن المتجر رقم 3",
      "type": "reports",
      "categories_id": "",
      "user_type": "RainLab\\User\\Models\\User",
      "user_id": 549,
      "target_type": "Tss\\Basic\\Models\\Department",
      "target_id": 3,
      "reply_at": "",
      "reply_content": "",
      "reply_by": "",
      "read_at": "",
      "is_important": 0,
      "is_relay": 0,
      "user_relay_id": "",
      "relay_date_at": "",
      "relay_content": "",
      "companys_id": "2",
      "departments_id": "4",
      "is_active": 1,
      "is_private": 1,
      "date_at": "2023-12-04 19:22:35",
      "created_by": "",
      "properties": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 11,
      "created_at": "2023-12-04 19:22:35",
      "updated_at": "2023-12-04 19:22:35",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano2\\Proposals\\Models\\Proposal"
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```



### Show Data Record Proposal 

```
GET /api/v1/proposals/proposals/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record Proposal 2

```
GET http://localhost:8006/api/v1/proposals/proposals/2
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "id": 2,
  "code": "2-4-2",
  "barcode": "",
  "name": "عنوان المقترح الثاني",
  "content": "نص موضوع المقترح الثاني",
  "type": "proposals",
  "categories_id": "",
  "user_type": "RainLab\\User\\Models\\User",
  "user_id": 549,
  "target_type": "",
  "target_id": 0,
  "reply_at": "",
  "reply_content": "",
  "reply_by": "",
  "read_at": "",
  "is_important": 0,
  "is_relay": 0,
  "user_relay_id": "",
  "relay_date_at": "",
  "relay_content": "",
  "companys_id": "2",
  "departments_id": "4",
  "is_active": 1,
  "is_private": 1,
  "date_at": "2023-12-04 17:47:11",
  "created_by": "",
  "properties": null,
  "other_data": null,
  "config_data": null,
  "sort_order": 2,
  "created_at": "2023-12-04 17:47:11",
  "updated_at": "2023-12-04 17:47:11",
  "image": null,
  "images": [],
  "files": [],
  "object_type": "Nano2\\Proposals\\Models\\Proposal"
}
```


### Create Proposal To Current User

** انشاء مقترحات او شكوى او بلاغ  جديدة **

```
POST /api/v1/proposals/proposals/create
```


#### Example 3.1 Create Proposal To Current User

**فى المثال التالي سنقوم بانشاء مقترح جديد **
```
POST http://localhost:8006/api/v1/proposals/proposals/create
```
**نقوم بتمرير البيانات المطلوبه ضمن الطلب **

**الحقو المطلوبه هى **

```json
{
    "name": "عنوان المقترح الثالث",
    "content": "نص موضوع المقترح الثالث",
}
```

```
POST http://localhost:8006/api/v1/proposals/proposals/create?name=%D8%B9%D9%86%D9%88%D8%A7%D9%86%20%D8%A7%D9%84%D9%85%D9%82%D8%AA%D8%B1%D8%AD%20%D8%A7%D9%84%D8%AB%D8%A7%D9%84%D8%AB&content=%D9%86%D8%B5%20%D9%85%D9%88%D8%B6%D9%88%D8%B9%20%D8%A7%D9%84%D9%85%D9%82%D8%AA%D8%B1%D8%AD%20%D8%A7%D9%84%D8%AB%D8%A7%D9%84%D8%AB

```

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تمت عملية الاضافة بنجاح ",
  "error": null,
  "errors": null,
  "proposals_id": 3,
  "data": {
    "id": 3,
    "code": "2-4-3",
    "barcode": "",
    "name": "عنوان المقترح الثالث",
    "content": "نص موضوع المقترح الثالث",
    "type": "proposals",
    "categories_id": "",
    "user_type": "RainLab\\User\\Models\\User",
    "user_id": 549,
    "target_type": "",
    "target_id": 0,
    "reply_at": "",
    "reply_content": "",
    "reply_by": "",
    "read_at": "",
    "is_important": 0,
    "is_relay": 0,
    "user_relay_id": "",
    "relay_date_at": "",
    "relay_content": "",
    "companys_id": "2",
    "departments_id": 4,
    "is_active": 1,
    "is_private": 1,
    "date_at": "2023-12-04 17:59:07",
    "created_by": "",
    "properties": null,
    "other_data": null,
    "config_data": null,
    "sort_order": null,
    "created_at": "2023-12-04 17:59:07",
    "updated_at": "2023-12-04 17:59:07",
    "image": null,
    "images": [],
    "files": [],
    "object_type": "Nano2\\Proposals\\Models\\Proposal"
  }
}
```


**فى حالة عدم ارسال كافة الحقو المطلوبه سيتم ارجاع البيانات التاليه **

```json
{
  "code": 0,
  "status": false,
  "message": "لم تتام عملية   الاضافة   بنجاح ",
  "error": "الخاصية  عنوان  حقل مطلوب",
  "errors": {
    "name": [
      "الخاصية  عنوان  حقل مطلوب"
    ],
    "content": [
      "الخاصية  نص الموضوع  حقل مطلوب"
    ]
  },
  "data_process": {
    "user_type": "RainLab\\User\\Models\\User",
    "user_id": 549,
    "name": null,
    "content": null,
    "type": "proposals",
    "target_type": null,
    "target_id": null,
    "is_active": true,
    "is_private": true,
    "date_at": null,
    "image": null
  },
  "input_data": [],
  "debug": {
    "line": 460,
    "file": "\/storage\/emulated\/0\/htdocs\/october_demo\/plugins\/nano2\/proposalsapi\/apicontrollers\/Proposals.php",
    "class": "October\\Rain\\Exception\\ValidationException"
  }
}
```
#### Example 3.2 Create Complaint To Current User

**فى المثال التالي سنقوم بانشاء شكوى جديدة بتمرير النوع =complaints  **
```
POST http://localhost:8006/api/v1/proposals/proposals/create
```
**نقوم بتمرير البيانات المطلوبه ضمن الطلب **

**الحقو المطلوبه هى **

```json
{
    "name": "عنوان المقترح الثالث",
    "content": "نص موضوع المقترح الثالث",
    "type": "complaints",
}
```

```
POST http://localhost:8006/api/v1/proposals/proposals/create?name=%D8%B9%D9%86%D9%88%D8%A7%D9%86%20%D8%A7%D9%84%D8%B4%D9%83%D9%88%D9%89%20%D8%B1%D9%82%D9%85%20%D9%88%D8%A7%D8%AD%D8%AF%20&content=%D9%86%D8%B5%20%D9%85%D9%88%D8%B6%D9%88%D8%B9%20%D8%A7%D9%84%D8%B4%D9%83%D9%88%D9%8A%20%D8%B1%D9%82%D9%85%20%D9%88%D8%A7%D8%AD%D8%AF&type=complaints

```

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تمت عملية الاضافة بنجاح ",
  "error": null,
  "errors": null,
  "proposals_id": 4,
  "data": {
    "id": 4,
    "code": "2-4-4",
    "barcode": "",
    "name": "عنوان الشكوى رقم واحد",
    "content": "نص موضوع الشكوي رقم واحد",
    "type": "complaints",
    "categories_id": "",
    "user_type": "RainLab\\User\\Models\\User",
    "user_id": 549,
    "target_type": "",
    "target_id": 0,
    "reply_at": "",
    "reply_content": "",
    "reply_by": "",
    "read_at": "",
    "is_important": 0,
    "is_relay": 0,
    "user_relay_id": "",
    "relay_date_at": "",
    "relay_content": "",
    "companys_id": "2",
    "departments_id": 4,
    "is_active": 1,
    "is_private": 1,
    "date_at": "2023-12-04 18:05:59",
    "created_by": "",
    "properties": null,
    "other_data": null,
    "config_data": null,
    "sort_order": null,
    "created_at": "2023-12-04 18:05:59",
    "updated_at": "2023-12-04 18:05:59",
    "image": null,
    "images": [],
    "files": [],
    "object_type": "Nano2\\Proposals\\Models\\Proposal"
  }
}
```

#### Example 3.3 Create Reports To Current User

**فى المثال التالي سنقوم بانشاء بلاغ بتمرير النوع =reports  **

**بلاغ عن مستخدم فرنت رقم 550**
```
POST http://localhost:8006/api/v1/proposals/proposals/create
```
**نقوم بتمرير البيانات المطلوبه ضمن الطلب **

**الحقو المطلوبه هى **

```json
{

    "name": "عنوان البلاغ ان وجد",
    "content": "نص البلاغ على المستخدم رقم 550",
    "type": "reports",
    "target_type": "RainLab\\User\\Models\\User",
    "target_id": 550,
}
```

```
POST http://localhost:8006/api/v1/proposals/proposals/create?name=%D8%B9%D9%86%D9%88%D8%A7%D9%86%20%D8%A7%D9%84%D8%A8%D9%84%D8%A7%D8%BA%20%D8%A7%D9%86%20%D9%88%D8%AC%D8%AF%20&content=%D9%86%D8%B5%20%D8%A7%D9%84%D8%A8%D9%84%D8%A7%D8%BA%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D9%85%D8%B3%D8%AA%D8%AE%D8%AF%D9%85%20%D8%B1%D9%82%D9%85%20550&type=reports&target_type=RainLab\\User\\Models\\User&target_id=550
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تمت عملية الاضافة بنجاح ",
  "error": null,
  "errors": null,
  "proposals_id": 10,
  "data": {
    "id": 10,
    "code": "2-4-10",
    "barcode": "",
    "name": "عنوان البلاغ ان وجد",
    "content": "نص البلاغ على المستخدم رقم 550",
    "type": "reports",
    "categories_id": "",
    "user_type": "RainLab\\User\\Models\\User",
    "user_id": 549,
    "target_type": "RainLab\\User\\Models\\User",
    "target_id": 550,
    "reply_at": "",
    "reply_content": "",
    "reply_by": "",
    "read_at": "",
    "is_important": 0,
    "is_relay": 0,
    "user_relay_id": "",
    "relay_date_at": "",
    "relay_content": "",
    "companys_id": "2",
    "departments_id": 4,
    "is_active": 1,
    "is_private": 1,
    "date_at": "2023-12-04 19:05:52",
    "created_by": "",
    "properties": null,
    "other_data": null,
    "config_data": null,
    "sort_order": null,
    "created_at": "2023-12-04 19:05:52",
    "updated_at": "2023-12-04 19:05:52",
    "image": null,
    "images": [],
    "files": [],
    "object_type": "Nano2\\Proposals\\Models\\Proposal"
  }
}
```

**عند عدم تمرير كافه الحقول المطلوبه سيتم ارجاع التالي **

```json
{
  "code": 0,
  "status": false,
  "message": "لم تتام عملية   الاضافة   بنجاح ",
  "error": "الخاصية  target id حقل مطلوب",
  "errors": {
    "target_id": [
      "الخاصية  target id حقل مطلوب"
    ],
    "target_type": [
      "الخاصية  target type حقل مطلوب"
    ]
  },
  "data_process": {
    "user_type": "RainLab\\User\\Models\\User",
    "user_id": 549,
    "name": "عنوان البلاغ ان وجد ",
    "content": "نص البلاغ هنا ",
    "type": "reports",
    "target_type": null,
    "target_id": null,
    "is_active": true,
    "is_private": true,
    "date_at": null,
    "image": null
  },
  "input_data": {
    "name": "عنوان البلاغ ان وجد ",
    "content": "نص البلاغ هنا ",
    "type": "reports"
  },
  "debug": {
    "line": 460,
    "file": "\/storage\/emulated\/0\/htdocs\/october_demo\/plugins\/nano2\/proposalsapi\/apicontrollers\/Proposals.php",
    "class": "October\\Rain\\Exception\\ValidationException"
  }
}
```
#### Example 3.4 Create Reports To Current User

**فى المثال التالي سنقوم بانشاء بلاغ بتمرير النوع =reports  **

**بلاغ على الفرع او المحل رقم 4**
```
POST http://localhost:8006/api/v1/proposals/proposals/create
```
**نقوم بتمرير البيانات المطلوبه ضمن الطلب **

**الحقو المطلوبه هى **

```json
{

    "name": "عنوان البلاغ ان وجد",
    "content": "نص البلاغ عن المتجر رقم 4",
    "type": "reports",
    "categories_id": "",
    "target_type": "Tss\\Basic\\Models\\Department",
    "target_id": 4,
}
```

```
POST http://localhost:8006/api/v1/proposals/proposals/create?name=%D8%B9%D9%86%D9%88%D8%A7%D9%86%20%D8%A7%D9%84%D8%A8%D9%84%D8%A7%D8%BA%20%D8%A7%D9%86%20%D9%88%D8%AC%D8%AF%20&content=%D9%86%D8%B5%20%D8%A7%D9%84%D8%A8%D9%84%D8%A7%D8%BA%20%D8%B9%D9%86%20%D8%A7%D9%84%D9%85%D8%AA%D8%AC%D8%B1%20%D8%B1%D9%82%D9%85%204%20&type=reports&target_type=Tss\\Basic\\Models\\Department&target_id=4

```

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تمت عملية الاضافة بنجاح ",
  "error": null,
  "errors": null,
  "proposals_id": 9,
  "data": {
    "id": 9,
    "code": "2-4-9",
    "barcode": "",
    "name": "عنوان البلاغ ان وجد",
    "content": "نص البلاغ عن المتجر رقم 4",
    "type": "reports",
    "categories_id": "",
    "user_type": "RainLab\\User\\Models\\User",
    "user_id": 549,
    "target_type": "Tss\\Basic\\Models\\Department",
    "target_id": 4,
    "reply_at": "",
    "reply_content": "",
    "reply_by": "",
    "read_at": "",
    "is_important": 0,
    "is_relay": 0,
    "user_relay_id": "",
    "relay_date_at": "",
    "relay_content": "",
    "companys_id": "2",
    "departments_id": 4,
    "is_active": 1,
    "is_private": 1,
    "date_at": "2023-12-04 19:03:08",
    "created_by": "",
    "properties": null,
    "other_data": null,
    "config_data": null,
    "sort_order": null,
    "created_at": "2023-12-04 19:03:08",
    "updated_at": "2023-12-04 19:03:08",
    "image": null,
    "images": [],
    "files": [],
    "object_type": "Nano2\\Proposals\\Models\\Proposal"
  }
}
```

**عند عدم تمرير كافه الحقول المطلوبه سيتم ارجاع التالي **

```json
{
  "code": 0,
  "status": false,
  "message": "لم تتام عملية   الاضافة   بنجاح ",
  "error": "الخاصية  target id حقل مطلوب",
  "errors": {
    "target_id": [
      "الخاصية  target id حقل مطلوب"
    ],
    "target_type": [
      "الخاصية  target type حقل مطلوب"
    ]
  },
  "data_process": {
    "user_type": "RainLab\\User\\Models\\User",
    "user_id": 549,
    "name": "عنوان البلاغ ان وجد ",
    "content": "نص البلاغ هنا ",
    "type": "reports",
    "target_type": null,
    "target_id": null,
    "is_active": true,
    "is_private": true,
    "date_at": null,
    "image": null
  },
  "input_data": {
    "name": "عنوان البلاغ ان وجد ",
    "content": "نص البلاغ هنا ",
    "type": "reports"
  },
  "debug": {
    "line": 460,
    "file": "\/storage\/emulated\/0\/htdocs\/october_demo\/plugins\/nano2\/proposalsapi\/apicontrollers\/Proposals.php",
    "class": "October\\Rain\\Exception\\ValidationException"
  }
}
```

### Get Options Proposal 

** جلب خيارات الحقول  اثناء انشاء حساب  موصل للمستخدم الحالي **

```
GET /api/v1/proposals/proposals/options
```

#### Example 4 Get Options Fields Proposal 

```
GET http://localhost:8006/api/v1/proposals/proposals/options
```


##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب الخيارات بنجاح ",
  "error": "",
  "data": {
    "type": [
      {
        "id": "proposals",
        "name": "مقترحات"
      },
      {
        "id": "complaints",
        "name": "شكاوي"
      },
      {
        "id": "reports",
        "name": "بلاغ"
      }
    ],
    "status": [
      {
        "id": "active",
        "name": "نشط"
      },
      {
        "id": "inactive",
        "name": "غير نشط"
      }
    ]
  }
}
```

**لجلب خيارات حقل معين نقوم بتمري، اسم الحقل ضمن متغير fields **

```
GET http://localhost:8006/api/v1/proposals/proposals/options?fields=type
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب الخيارات بنجاح ",
  "error": "",
  "data": {
    "type": [
      {
        "id": "proposals",
        "name": "مقترحات"
      },
      {
        "id": "complaints",
        "name": "شكاوي"
      },
      {
        "id": "reports",
        "name": "بلاغ"
      }
    ]
  }
}
```

#### جلب الخيارات على شكل مصفوفه

** نقوم بتمرير المتغير is_collection بالقيمه 0 ضمن الطلب كالتالي **

```
GET http://localhost:8006/api/v1/proposals/proposals/options?is_collection=0
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب الخيارات بنجاح ",
  "error": "",
  "data": {
    "type": {
      "proposals": "مقترحات",
      "complaints": "شكاوي",
      "reports": "بلاغ"
    },
    "status": {
      "active": "نشط",
      "inactive": "غير نشط"
    }
  }
}
```

** لجلب خيارات حقل معين نقوم بتمرير اسم الحقل كالتالي **
```
GET http://localhost:8006/api/v1/proposals/proposals/options?is_collection=0&fields=type
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب الخيارات بنجاح ",
  "error": "",
  "data": {
    "type": {
      "proposals": "مقترحات",
      "complaints": "شكاوي",
      "reports": "بلاغ"
    }
  }
}
```

### Update Proposal To Current User 

** تعديل بيانات مقترح او شكوي او بلاغ  **

```
PUT /api/v1/proposals/proposals/update/{id}
```

#### Example 5 Update Fields Proposal 

```
PUT http://localhost:8006/api/v1/proposals/proposals/update/5
```
Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |

**الحقول المعدلة**

```json
{
    "name": "عنوان الشكوى رقم اثنين بعد التعديل",
    "content": "نص موضوع الشكوي رقم اثنان بعد التعديل",
}
```

```
put http://localhost:8006/api/v1/proposals/proposals/update/5?name=%D8%B9%D9%86%D9%88%D8%A7%D9%86%20%D8%A7%D9%84%D8%B4%D9%83%D9%88%D9%89%20%D8%B1%D9%82%D9%85%20%D8%A7%D8%AB%D9%86%D9%8A%D9%86%20%D8%A8%D8%B9%D8%AF%20%D8%A7%D9%84%D8%AA%D8%B9%D8%AF%D9%8A%D9%84&content=%D9%86%D8%B5%20%D9%85%D9%88%D8%B6%D9%88%D8%B9%20%D8%A7%D9%84%D8%B4%D9%83%D9%88%D9%8A%20%D8%B1%D9%82%D9%85%20%D8%A7%D8%AB%D9%86%D8%A7%D9%86%20%D8%A8%D8%B9%D8%AF%20%D8%A7%D9%84%D8%AA%D8%B9%D8%AF%D9%8A%D9%84
```

**فى المثال التالى سنقوم بتعديل بيانات مقترح او شكوى او بلاغ من خلال تمرير الرقم والحقول المراد تعديل بيانتها     **


##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم التعديل بنجاح ",
  "error": "",
  "data": {
    "id": 5,
    "code": "2-4-5",
    "barcode": "",
    "name": "عنوان الشكوى رقم اثنين بعد التعديل",
    "content": "نص موضوع الشكوي رقم اثنان بعد التعديل",
    "type": "complaints",
    "categories_id": "",
    "user_type": "RainLab\\User\\Models\\User",
    "user_id": 549,
    "target_type": "",
    "target_id": 0,
    "reply_at": "",
    "reply_content": "",
    "reply_by": "",
    "read_at": "",
    "is_important": 0,
    "is_relay": 0,
    "user_relay_id": "",
    "relay_date_at": "",
    "relay_content": "",
    "companys_id": "2",
    "departments_id": "4",
    "is_active": 1,
    "is_private": 1,
    "date_at": "2023-12-04 18:07:25",
    "created_by": "",
    "properties": null,
    "other_data": null,
    "config_data": null,
    "sort_order": 5,
    "created_at": "2023-12-04 18:07:25",
    "updated_at": "2023-12-04 18:13:39",
    "image": null,
    "images": [],
    "files": [],
    "object_type": "Nano2\\Proposals\\Models\\Proposal"
  }
}
```


### Check Last Update Proposal Data 

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/proposals/proposals/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/proposals/proposals/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": null
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2022-12-20 18:17:04",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": null
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **