## Static Menus Language

This endpoint allows you to `list`, `show` your Static Menus.

/cms/menus

**الجز الخاص بالقوائم الديناميكية فى النظام يمكنك من خلال هذا الجزء جلب كافه القوائم فى النظام **

### The Accept-Language 

**يمكن تهية القائمة حسب اللغة فى النظام من خلال  تمرير كود اللغة فى راس الطلب ضمن المتغير  Accept-Language**

Header Parameters
```json
{
  "Accept-Language":"ar"
}
```

### List Menus

Returns a list of Menus.

**لجلب القوائم نستخدم الرابط التالي **

```
GET /api/v1/cms/menus
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Response

```html
Status: 200 OK
```

```json
{
  "data": {
    "mainmenu2": "mainMenu2",
    "mainmenu-footer": "mainMenu2",
    "mainmenu-org": "mainMenu",
    "mainmenu-h": "mainMenu",
    "mainmenu": "mainMenu",
    "mainmenu-school-h": "mainMenu",
    "mainmenu -school": "mainMenu",
    "mainmenu-newday": "mainMenu"
  }
}
```

### Get Data Menus 

**لجلب بيانات قائمة معينه نقوم بستخدام الرابط التالي مع تمرير اسم القائمة فى البراميتر name**

GET http://localhost:8006/api/v1/cms/menus/data

Required Parameters: `name`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `name`           | `string`  | **Required**. The id          |


#### Example 2 get Data Menus name=abouts

```
GET http://localhost:8006/api/v1/cms/menus/data?name=mainmenu2
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": {
    "fileName": "mainmenu2.yaml",
    "content": "name: mainMenu2\nitems:\n#    -\n#        title: الرئيسية\n#        type: cms-page\n#        code: ''\n#        reference: index\n#        viewBag:\n#            isHidden: '0'\n#            cssClass: 'fa fa-home'\n#            isExternal: '0'\n\n    -\n        title: إضافة عرض\n        type: cms-page\n        code: ''\n        reference: login\/new-aqers\n        viewBag:\n            isHidden: '0'\n            cssClass: 'fa fa-plus'\n            isExternal: '0'\n    -\n        title: اعمالنا\n        type: cms-page\n        code: ''\n        reference: work\n        viewBag:\n            isHidden: '0'\n            cssClass: 'fa fa-hospital-o'\n            isExternal: '0'\n    -\n        title: عن الشركة\n        type: cms-page\n        code: ''\n        reference: abouts\n        viewBag:\n            isHidden: '0'\n            cssClass: 'fa fa-bank'\n            isExternal: '0'\n    -\n        title: بحث متقدم\n        type: cms-page\n        code: ''\n        reference: index\n        viewBag:\n            isHidden: '0'\n            cssClass: 'fa fa-search-plus'\n            isExternal: '0'\n#    -\n#        title: 'من نحن'\n#        nesting: '0'\n#        type: static-page\n#        code: ''\n#        reference: about\n#        replace: '0'\n#        viewBag:\n#            isHidden: '0'\n#            cssClass: ''\n#            isExternal: '0'\n#    -\n#        title: لتواصل\n#        type: cms-page\n#        code: ''\n#        reference: faq\n#        viewBag:\n#            isHidden: '0'\n#            cssClass: ''\n#            isExternal: '0'",
    "mtime": 1586614484,
    "markup": null,
    "code": "mainmenu2",
    "name": "mainMenu2",
    "items": [
      {
        "title": "إضافة عرض",
        "items": [],
        "parent": null,
        "nesting": null,
        "type": "cms-page",
        "url": null,
        "code": "",
        "reference": "login\/new-aqers",
        "replace": null,
        "cmsPage": null,
        "exists": false,
        "fillable": [
          "title",
          "nesting",
          "type",
          "url",
          "code",
          "reference",
          "cmsPage",
          "replace",
          "viewBag"
        ],
        "viewBag": {
          "isHidden": "0",
          "cssClass": "fa fa-plus",
          "isExternal": "0"
        }
      },
      {
        "title": "اعمالنا",
        "items": [],
        "parent": null,
        "nesting": null,
        "type": "cms-page",
        "url": null,
        "code": "",
        "reference": "work",
        "replace": null,
        "cmsPage": null,
        "exists": false,
        "fillable": [
          "title",
          "nesting",
          "type",
          "url",
          "code",
          "reference",
          "cmsPage",
          "replace",
          "viewBag"
        ],
        "viewBag": {
          "isHidden": "0",
          "cssClass": "fa fa-hospital-o",
          "isExternal": "0"
        }
      },
      {
        "title": "عن الشركة",
        "items": [],
        "parent": null,
        "nesting": null,
        "type": "cms-page",
        "url": null,
        "code": "",
        "reference": "abouts",
        "replace": null,
        "cmsPage": null,
        "exists": false,
        "fillable": [
          "title",
          "nesting",
          "type",
          "url",
          "code",
          "reference",
          "cmsPage",
          "replace",
          "viewBag"
        ],
        "viewBag": {
          "isHidden": "0",
          "cssClass": "fa fa-bank",
          "isExternal": "0"
        }
      },
      {
        "title": "بحث متقدم",
        "items": [],
        "parent": null,
        "nesting": null,
        "type": "cms-page",
        "url": null,
        "code": "",
        "reference": "index",
        "replace": null,
        "cmsPage": null,
        "exists": false,
        "fillable": [
          "title",
          "nesting",
          "type",
          "url",
          "code",
          "reference",
          "cmsPage",
          "replace",
          "viewBag"
        ],
        "viewBag": {
          "isHidden": "0",
          "cssClass": "fa fa-search-plus",
          "isExternal": "0"
        }
      }
    ],
    "settings": {
      "name": "mainMenu2",
      "items": [
        {
          "title": "إضافة عرض",
          "type": "cms-page",
          "code": "",
          "reference": "login\/new-aqers",
          "viewBag": {
            "isHidden": "0",
            "cssClass": "fa fa-plus",
            "isExternal": "0"
          }
        },
        {
          "title": "اعمالنا",
          "type": "cms-page",
          "code": "",
          "reference": "work",
          "viewBag": {
            "isHidden": "0",
            "cssClass": "fa fa-hospital-o",
            "isExternal": "0"
          }
        },
        {
          "title": "عن الشركة",
          "type": "cms-page",
          "code": "",
          "reference": "abouts",
          "viewBag": {
            "isHidden": "0",
            "cssClass": "fa fa-bank",
            "isExternal": "0"
          }
        },
        {
          "title": "بحث متقدم",
          "type": "cms-page",
          "code": "",
          "reference": "index",
          "viewBag": {
            "isHidden": "0",
            "cssClass": "fa fa-search-plus",
            "isExternal": "0"
          }
        }
      ]
    }
  }
}
```

**فى حالة تمرير اسم قائمة غير موجوده سيتم ارجاع الخطاء التالي**

```json
{
  "data": null
}
```


