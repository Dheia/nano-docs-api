## Static Pages Language

This endpoint allows you to `list`, `show` your Static-Pages.

/cms/static-pages

**الجز الخاص باصفحات الديناميكية المتوفرة فى النظام يمكنك من خلال هذا الجزء جلب كافه الصفحات المدعومه فى النظام **

### The Accept-Language 

**يمكن تهية الصفحة حسب اللغة فى النظام من خلال  تمرير كود اللغة فى راس الطلب ضمن المتغير  Accept-Language**

Header Parameters
```json
{
  "Accept-Language":"ar"
}
```

### List Static-Pages

Returns a list of Static-Pages.

**لجلب الصفحات نستخدم الرابط التالي **

```
GET /api/v1/cms/static-pages
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Response

```html
Status: 200 OK
```

```json
{
  "data": {
    "about": "من نحن",
    "videos": "فيديوهات",
    "wn-blocks": "wn-blocks-s"
  }
}
```

### Get Data Static Pages 

**لجلب بيانات صفحة معينه نقوم بستخدام الرابط التالي مع تمرير اسم الصفحة فى البراميتر name**

GET http://localhost:8006/api/v1/cms/static-pages/data

Required Parameters: `name`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `name`           | `string`  | **Required**. The id          |


#### Example 2 get Data Static Pages name=abouts

```
GET http://localhost:8006/api/v1/cms/static-pages/data?name=about
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": {
    "markup": "<hr>\r\n<hr>\r\n\r\n<h1>من نحن<\/h1><pre><strong>متخصصة في مجال تطوير البرمجيات والأنظمة المحاسبية المختلفة وتطوير المواقع الالكترونية و تسعى الى ان تصبح رائدة في هذا المجال على المستوي الوطني.<\/strong><\/pre>",
    "settings": {
      "components": {
        "viewBag": {
          "title": "من نحن",
          "url": "\/about",
          "layout": "default",
          "is_hidden": "0",
          "navigation_hidden": "0",
          "meta_title": "من نحن",
          "meta_description": "من نحن",
          "localeUrl": {
            "en": "\/about-en"
          }
        }
      }
    },
    "placeholders": []
  }
}
```

**فى حالة تمرير اسم صفحة غير موجوده سيتم ارجاع الخطاء التالي**

```json
{
  "data": null
}
```


### Render Static Pages 

**ارجاع محتوي الصفحة القابل للعرض على الويب اي بشكل مرندر **

```
GET /api/v1/cms/static-pages/render
```

Required Parameters: `name`

**يجيب تمرير اسم الصفحة المراد ارجاع محتوها ضمن المتغير name**

#### Example 3 Render Static Pages name=about

```
GET http://localhost:8006/api/v1/cms/static-pages/render?name=about
```

#### Response

```html
Status: 200 Ok
```

```json
{
    "data": "<!doctype html>
<html lang=\"ar\" class=\"no-focus\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, shrink-to-fit=no\">
    
                                    
    <title>\u0645\u0646 \u0646\u062d\u0646 - \u0646\u0627\u0646\u0648 2 \u0633\u0648\u0641\u062a \u0644\u0644\u0628\u0631\u0645\u062c\u064a\u0627\u062a \u0648\u062a\u0642\u0646\u064a\u0629 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a<\/title>

    <meta name=\"title\" content=\"\u0645\u0646 \u0646\u062d\u0646\">

    <meta name=\"description\" content=\"\u0645\u0646 \u0646\u062d\u0646\">

    <meta name=\"keywords\" content=\"\u0646\u0627\u0646\u0648 \u0633\u0648\u0641\u062a , \u0628\u0631\u0645\u062c\u064a\u0627\u062a , \u0627\u0646\u0638\u0645\u0629 , \u0634\u0631\u0643\u0629 , \u062a\u0635\u0645\u064a\u0645 , \u0645\u0648\u0627\u0642\u0639\">

    <meta name=\"author\" content=\"Nano 2 Soft  Eng\/ Dheia Ali Al-Shami  00967770529482\">

    <link rel=\"canonical\" href=\"http:\/\/localhost:8006\" \/>
    <link rel=\"canonical\" href=\"http:\/\/localhost:8006\" \/>


    <meta name=\"robots\" content=\"index\">
    <meta name=\"robots\" content=\"follow\">


        
        
    

    <!-- Icons |resize(32,32)  media -->
    <!-- The following icons can be replaced with your own, they are used by desktop and mobile browsers -->
    <link rel=\"shortcut icon\" href=\"http:\/\/localhost:8006\/storage\/app\/uploads\/public\/639\/cc1\/9de\/639cc19de67d4476963946.png\">
    <link rel=\"icon\" type=\"image\/png\" sizes=\"192x192\" href=\"http:\/\/localhost:8006\/storage\/app\/uploads\/public\/639\/cc1\/9de\/639cc19de67d4476963946.png\">
    <link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"http:\/\/localhost:8006\/storage\/app\/uploads\/public\/639\/cc1\/9de\/639cc19de67d4476963946.png\">
    <!-- END Icons -->


     <!--Open Graph Meta-->
    <meta property=\"og:title\" content=\"\u0645\u0646 \u0646\u062d\u0646 - \u0646\u0627\u0646\u0648 2 \u0633\u0648\u0641\u062a \u0644\u0644\u0628\u0631\u0645\u062c\u064a\u0627\u062a \u0648\u062a\u0642\u0646\u064a\u0629 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a\">
    <meta property=\"og:site_name\" content=\"\u0646\u0627\u0646\u0648 \u0633\u0648\u0641\u062a\">
    <meta property=\"og:description\" content=\"\u0645\u0646 \u0646\u062d\u0646\">
    <meta property=\"og:type\" content=\"website\">
    <meta property=\"og:url\" content=\"
http:\/\/localhost:8006\/api\/v1\/cms\/static-pages\/render\">
    <meta property=\"og:image\" content=\"http:\/\/localhost:8006\/storage\/app\/uploads\/public\/639\/cc1\/9de\/639cc19de67d4476963946.png\">


    <!-- Stylesheets -->
    <!-- Fonts and Codebase framework -->
    <link rel=\"stylesheet\" href=\"https:\/\/fonts.googleapis.com\/css?family=Muli:300,400,400i,600,700\">

    <link rel=\"stylesheet\" id=\"css-main\" href=\" http:\/\/localhost:8006\/combine\/37c9b13dc30065947e3b7d7efbf47306-1657553506\">

    <link rel=\"stylesheet\" href=\"https:\/\/maxcdn.bootstrapcdn.com\/font-awesome\/4.7.0\/css\/font-awesome.min.css\" \/>
<link rel=\"stylesheet\" href=\"http:\/\/localhost:8006\/plugins\/martin\/ssbuttons\/assets\/css\/social-sharing-nb.css\" \/>
<link rel=\"stylesheet\" href=\"http:\/\/localhost:8006\/plugins\/tss\/scrolltop\/assets\/css\/default.css\" \/>
<link rel=\"stylesheet\" href=\"http:\/\/localhost:8006\/plugins\/tss\/scrolltop\/assets\/css\/scroll_top_lnx.css\" \/>
    <!--  'assets\/_scss\/main2.scss'
    'assets\/_scss\/codebase\/themes\/default.scss'
    -->


    
    <!---->

<!-- 'assets\/js\/plugins\/swiper\/dist\/css\/swiper.min.css',
          'assets\/js\/plugins\/swiper\/src\/swiper.scss',
-->

 <link rel=\"stylesheet\" id=\"css-main9\" href=\" http:\/\/localhost:8006\/combine\/198db73da946a7efacc6252651d4378a-1592281128\">
        \t
         <link rel=\"stylesheet\" id=\"css-venobox\" href=\" http:\/\/localhost:8006\/combine\/b8f3327038c6f4eea0359913b9c09695-1641445772\">
        \t
    <link rel=\"stylesheet\" id=\"css-main2\" href=\" http:\/\/localhost:8006\/combine\/f39d97a7070ac376cdf0bcb840c18612-1629296830\">

    

        <!-- You can include a specific file from css\/themes\/ folder to alter the default color theme of the template. eg: -->
    <!-- <link rel=\"stylesheet\" id=\"css-theme\" href=\"assets\/css\/themes\/flat.min.css\"> -->

    <!--
        Basic RTL CSS Overwrites (Please consider moving it in an external CSS file - it is added inline just for demostration)

        The UI elements will play nice with RTL in most cases. This file is provided as a get started point for RTL projects,
        so please have in mind that a few elements might require some further CSS adjustments.

        Moreover, .float-left\/.float-right and .text-left\/.text-right classes will come in handy
    -->
            <style>
            \/* Set Text Direction to RTL *\/
            html {
                direction: rtl;
            }

            body {
                text-align: right;
            }
            \/*
            .lg-css3.lg-slide.lg-use-css3 .lg-item.lg-current {
                -webkit-transform: translate3d(0,0,0);
                transform: translate3d(0,0,0);
                opacity: 1;
            }.lg-css3.lg-slide.lg-use-css3 .lg-item {
                 opacity: 1 !important;
             }
    *\/
            \/* Sidebar Mini *\/
            @media (min-width: 992px) {
                .sidebar-o.sidebar-mini #sidebar .sidebar-content {
                    -webkit-transform: translateX(0) translateY(0) translateZ(0);
                    transform: translateX(0) translateY(0) translateZ(0);
                }

                .sidebar-r.sidebar-o.sidebar-mini #sidebar .sidebar-content {
                    -webkit-transform: translateX(-166px) translateY(0) translateZ(0);
                    transform: translateX(-166px) translateY(0) translateZ(0);
                }

                .sidebar-r.sidebar-o.sidebar-mini #sidebar:hover .sidebar-content {
                    -webkit-transform: translateX(0) translateY(0) translateZ(0);
                    transform: translateX(0) translateY(0) translateZ(0);
                }
            }

            \/* Main Sidebar Navigation *\/
            .nav-main a {
                padding-right: 40px;
                padding-left: 18px;
            }

            .nav-main a > i {
                right: 19px;
                left: auto;
            }

            .nav-main a.nav-submenu {
                padding-right: 40px;
                padding-left: 35px;
            }

            .nav-main a.nav-submenu::before, .nav-main a.nav-submenu::after {
                right: auto;
                left: 15px;
            }

            .nav-main a.nav-submenu::before {
                content: '\\f105';
            }

            .nav-main a.nav-submenu::after {
                -webkit-transform: rotate(-90deg);
                -o-transform: rotate(-90deg);
                transform: rotate(-90deg);
            }

            .nav-main ul {
                padding-right: 40px;
                padding-left: 0;
            }

            .nav-main ul a,
            .nav-main ul a.nav-submenu {
                padding-right: 0;
                padding-left: 8px;
            }

            .nav-main ul a > i {
                margin-right: 0;
                margin-left: 15px;
            }

            .nav-main ul ul {
                padding-right: 12px;
            }

            \/* Main Header Navigation *\/
            @media (min-width: 992px) {
                .nav-main-header a > i {
                    margin-right: 0;
                    margin-left: 8px;
                }

                .nav-main-header a.nav-submenu {
                    padding-right: 14px;
                    padding-left: 28px;
                }

                .nav-main-header a.nav-submenu::before {
                    right: auto;
                    left: 6px;
                }

                .nav-main-header ul {
                    right: 0;
                    left: auto;
                }

                .nav-main-header ul a.nav-submenu::before {
                    content: '\\f104';
                }

                .nav-main-header ul ul {
                    right: 100%;
                    left: auto;
                }

                .nav-main-header > li:last-child ul {
                    right: auto;
                    left: 0;
                }

                .nav-main-header > li:last-child ul a.nav-submenu::before {
                    content: '\\f105';
                }

                .nav-main-header > li:last-child ul ul {
                    right: auto;
                    left: 100%;
                }
            }

            #gallery li {
                display: block;
                float: right;
                height: 70px;
                margin-bottom: 6px;
                margin-right: 6px;
                width: 100px;
            }


            #sno-id {
                position: fixed;
                top: 0;
                right: 0;
                bottom: 0;
                z-index: 99999;
                width: 100%;

                \/* background-color: #eeeeee;*\/

            }

            .side-overlay2 {
                position: fixed;
                top: 0;
                right: 0;
                bottom: 0;
                z-index: 999999;
                width: 100%;
                \/*background-color: #eeeeee;*\/
                overflow-x: auto;
                overflow-y: auto;
                height: 100%;
                margin: 0px;
                \/*display: none;*\/
                \/* background-color: $side-overlay-bg;
            *\/
                \/* overflow-y: auto;
                 transform: translateX(100%) translateY(0) translateZ(0);
                 -webkit-overflow-scrolling: touch;
                 will-change: transform;
             *\/

            }
            #content-btn-mobile-id{
                position: fixed;
                bottom: 0;
                right: 0;
                z-index: 99999;
                width: 100%;
                background-color: #eeeeee;

            }
            .mode-hidden{
                display: block !important;
            }
        <\/style>
        <!-- END Stylesheets -->
    


    <style>
        html, body {
            font-size: 14px;
        }

        a.block:hover {

            text-decoration: none;
        }
        a:hover, a:focus {
            text-decoration: none !important;
        }

        \/* \u062e\u0627\u0635\u0629 \u0628\u0627\u0644\u0635\u0648\u0631*\/
        #gallery {
            padding-left: 0;
            padding-right: 0;
        }
        #gallery li {
            display: contents;
            float: initial;
            height: 70px;
            margin-bottom: 6px;
            margin-right: 6px;
            width: 100px;
        }
        #lightGallery-outer {
            margin: auto;
            left: 1px !important;
            right: 1px !important;
            background: #0d0d0d;
        }
    <\/style>
<\/head>



    
    

<body>

    <!-- Page loader (functionality is initialized in Template._uiHandlePageLoader()) -->
        <!-- If #page-loader markup and also the \"show\" class is added, the loading screen will be enabled and auto hide once the page loads -->
        <!-- Default background color is the primary color but you can use a bg-* class for a custom bg color -->
        <div id=\"page-loader\" class=\"show \" >
<!--
<i class=\"fa fa-4x fa-sun-o fa-spin text-warning\"><\/i>

                             <i class=\"fa fa-4x fa-hourglass-half fa-spin text-success\"><\/i>
                               <!--
     <i class=\"fa fa-4x fa-cog fa-spin text-success\"><\/i>
                                    <i class=\"fa fa-4x fa-asterisk fa-spin text-info\"><\/i>
                                    -->      
            
                    <!-- END Loading Icons -->
        <\/div>
        
      <!-- END Page Loading  -->





    <!-- Page Container -->
    <!--
        Available classes for #page-container:

    GENERIC

        'enable-cookies'                            Remembers active color theme between pages (when set through color theme helper Codebase() -> uiHandleTheme())

    SIDEBAR & SIDE OVERLAY

        'sidebar-r'                                 Right Sidebar and left Side Overlay (default is left Sidebar and right Side Overlay)
        'sidebar-mini'                              Mini hoverable Sidebar (screen width > 991px)
        'sidebar-o'                                 Visible Sidebar by default (screen width > 991px)
        'sidebar-o-xs'                              Visible Sidebar by default (screen width < 992px)
        'sidebar-inverse'                           Dark themed sidebar

        'side-overlay-hover'                        Hoverable Side Overlay (screen width > 991px)
        'side-overlay-o'                            Visible Side Overlay by default

        'enable-page-overlay'                       Enables a visible clickable Page Overlay (closes Side Overlay on click) when Side Overlay opens

        'side-scroll'                               Enables custom scrolling on Sidebar and Side Overlay instead of native scrolling (screen width > 991px)

    HEADER

        ''                                          Static Header if no class is added
        'page-header-fixed'                         Fixed Header

    HEADER STYLE

        ''                                          Classic Header style if no class is added
        'page-header-modern'                        Modern Header style
        'page-header-inverse'                       Dark themed Header (works only with classic Header style)
        'page-header-glass'                         Light themed Header with transparency by default
                                                    (absolute position, perfect for light images underneath - solid light background on scroll if the Header is also set as fixed)
        'page-header-glass page-header-inverse'     Dark themed Header with transparency by default
                                                    (absolute position, perfect for dark images underneath - solid dark background on scroll if the Header is also set as fixed)

    MAIN CONTENT LAYOUT

        ''                                          Full width Main Content if no class is added
        'main-content-boxed'                        Full width Main Content with a specific maximum width (screen width > 1200px)
        'main-content-narrow'                       Full width Main Content with a percentage width (screen width > 1200px)
    -->
    <div id=\"page-container\" class=\"sidebar-r sidebar-inverse side-scroll


             page-header-fixed
      
     
     
      enable-page-overlay\">
        <!-- Sidebar -->
        <nav id=\"sidebar\">
    <!-- Sidebar Content -->
    <div class=\"sidebar-content\">
        <!-- Side Header -->
        <div class=\"content-header content-header-fullrow bg-black-op-10\">
            <div class=\"content-header-section text-center align-parent\">
                <!-- Close Sidebar, Visible only on mobile screens -->
                <!-- Layout API, functionality initialized in Codebase() -> uiApiLayout() -->
                <button type=\"button\" class=\"btn btn-circle btn-dual-secondary d-lg-none align-v-l\"
                        data-toggle=\"layout\" data-action=\"sidebar_close\">
                    <i class=\"fa fa-times text-danger\"><\/i>
                <\/button>
                <!-- END Close Sidebar -->

                <!-- Logo -->
                <div class=\"content-header-item\">
                    <a class=\"link-effect font-w700\" href=\"http:\/\/localhost:8006\">
                        <!--<i class=\"si si-fire text-primary\"><\/i>-->
                        <!--<span class=\"font-size-xl text-dual-primary-dark\">\u0646\u0627\u0646\u0648 \u0633\u0648\u0641\u062a<\/span>-->
                        <span class=\"font-size-xl text-primary\">
                            \u0646\u0627\u0646\u0648 \u0633\u0648\u0641\u062a
                                                    <\/span>
                    <\/a>
                <\/div>
                <!-- END Logo -->
            <\/div>
        <\/div>
        <!-- END Side Header -->

        <!-- Side Main Navigation -->
        <div class=\"content-side content-side-full\">
            <!--
            Mobile navigation, desktop navigation can be found in #page-header

            If you would like to use the same navigation in both mobiles and desktops, you can use exactly the same markup inside sidebar and header navigation ul lists
            -->
          
            <ul class=\"nav-main\">
            <!--
<ul class=\"nav-main\">
    <li>
        <a class=\"active\" href=\"\">
            <i class=\"si si-home\"><\/i>Home
        <\/a>
    <\/li>
    <li class=\"nav-main-heading\">Heading<\/li>
    <li>
        <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">
            <i class=\"si si-puzzle\"><\/i>Dropdown
        <\/a>
        <ul>
            <li>
                <a href=\"javascript:void(0)\">Link #1<\/a>
            <\/li>
            <li>
                <a href=\"javascript:void(0)\">Link #2<\/a>
            <\/li>
            <li>
                <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">Dropdown<\/a>
                <ul>
                    <li>
                        <a href=\"javascript:void(0)\">Link #1<\/a>
                    <\/li>
                    <li>
                        <a href=\"javascript:void(0)\">Link #2<\/a>
                    <\/li>
                <\/ul>
            <\/li>
        <\/ul>
    <\/li>
    <li class=\"nav-main-heading\">Vital<\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
<\/ul>
-->

            

    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/feature\"
            
            class=\"
            
            
            \">

                               \u0645\u0645\u064a\u0632\u0627\u062a\u0646\u0627
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/assortment\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0627\u0642\u0633\u0627\u0645
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/team\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0637\u0627\u0642\u0645
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/post\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0627\u062e\u0628\u0627\u0631
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/album\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0635\u0648\u0631
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/videos\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0641\u064a\u062f\u064a\u0648\u0647\u0627\u062a
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/staff\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u062a\u0648\u0636\u064a\u0641
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/contact\"
            
            class=\"
            
            
            \">

                               \u0644\u0644\u062a\u0648\u0627\u0635\u0644
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/bookings\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u062d\u062c\u0632 \u0627\u0644\u0627\u0644\u0643\u062a\u0631\u0648\u0646\u064a
            <\/a>

                    
    <\/li>

<!--<li class=\"nav-main-heading\">-->
    <!--<span class=\"sidebar-mini-visible\">PG<\/span>-->
    <!--<span class=\"sidebar-mini-hidden\">Pages<\/span>-->
<!--<\/li>-->
<!--<li>-->
    <!--<a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">-->
        <!--<i class=\"si si-puzzle\"><\/i>Dropdown-->
    <!--<\/a>-->
    <!--<ul>-->
        <!--<li>-->
            <!--<a href=\"javascript:void(0)\">Link #1<\/a>-->
        <!--<\/li>-->
        <!--<li>-->
            <!--<a href=\"javascript:void(0)\">Link #2<\/a>-->
        <!--<\/li>-->
        <!--<li>-->
            <!--<a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">Dropdown<\/a>-->
            <!--<ul>-->
                <!--<li>-->
                    <!--<a href=\"javascript:void(0)\">Link #1<\/a>-->
                <!--<\/li>-->
                <!--<li>-->
                    <!--<a href=\"javascript:void(0)\">Link #2<\/a>-->
                <!--<\/li>-->
            <!--<\/ul>-->
        <!--<\/li>-->
    <!--<\/ul>-->
<!--<\/li>-->            <\/ul>
        <\/div>
        <!-- END Side Main Navigation -->
    <\/div>
    <!-- Sidebar Content -->
<\/nav>        <!-- END Sidebar -->

        <!-- Header -->
        <header id=\"page-header\">
    <!-- Header Content -->
    <div class=\"content-header align-items-start  justify-content-around2 justify-content-between22 justify-content-md-center2\">
        <!-- Right Section -->
        <div class=\"content-header-section d-flex2  \">
            <!-- Logo -->
            <div class=\"content-header-item pt-0\">
                <a class=\"link-effect2 \" href=\"\">
                                        
                                                            <img class=\"log_img img-avatar img-responsive img-circle22 animated swing infinite5\" src=\"http:\/\/localhost:8006\/storage\/app\/uploads\/public\/639\/cbe\/d98\/639cbed986468081928893.png\">
                <\/a>
                <a class=\"link-effect font-w700 font-size-xl font-size-default2  log_name d-none2 d-sm-inline-block2  d-md-block2  ml-2 mb-4 pt-0 mt-0\"
                   href=\"http:\/\/localhost:8006\"
                >
                    <!--<i class=\"si si-fire text-primary\"><\/i>-->
                                        
                    <span class=\"font-size-xl2 text-dual-primary-dark text-btn-header\">
                        \u0646\u0627\u0646\u0648<\/span>
                    <!--<span class=\"font-size-xl text-primary\">\u0646\u0627\u0646\u0648 \u0633\u0648\u0641\u062a<\/span>-->
                    <span class=\"font-size-xl2 text-primary2 text-btn-header\">
                                                            \u0633\u0648\u0641\u062a
                            
                    <\/span>
                <\/a>
    
                 
            <\/div>
            <!-- END Logo -->
        <\/div>
        <!-- END Right Section -->

        <!-- Left Section -->
        <div class=\"content-header-section  mx-auto2 mx-md-auto   \">
            <!-- Header Navigation -->
            <!--
            Desktop Navigation, mobile navigation can be found in #sidebar

            If you would like to use the same navigation in both mobiles and desktops, you can use exactly the same markup inside sidebar and header navigation ul lists
            If your sidebar menu includes headings, they won't be visible in your header navigation by default
            If your sidebar menu includes icons and you would like to hide them, you can add the class 'nav-main-header-no-icons'
            -->
            <!--<ul class=\"nav-main-header nav-main-header-no-icons\">
                <li>
                    <a class=\"active\" href=\"\">
                        <i class=\"si si-home\"><\/i>Home
                    <\/a>
                <\/li>
                <li class=\"nav-main-heading\">Heading<\/li>
                <li>
                    <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">
                        <i class=\"si si-puzzle\"><\/i>Dropdown
                    <\/a>
                    <ul>
                        <li>
                            <a href=\"javascript:void(0)\">Link #1<\/a>
                        <\/li>
                        <li>
                            <a href=\"javascript:void(0)\">Link #2<\/a>
                        <\/li>
                        <li>
                            <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">Dropdown<\/a>
                            <ul>
                                <li>
                                    <a href=\"javascript:void(0)\">Link #1<\/a>
                                <\/li>
                                <li>
                                    <a href=\"javascript:void(0)\">Link #2<\/a>
                                <\/li>
                            <\/ul>
                        <\/li>
                    <\/ul>
                <\/li>
                <li class=\"nav-main-heading\">Vital<\/li>
                <li>
                    <a href=\"javascript:void(0)\">
                        <i class=\"si si-wrench\"><\/i>Page
                    <\/a>
                <\/li>
                <li>
                    <a href=\"javascript:void(0)\">
                        <i class=\"si si-wrench\"><\/i>Page
                    <\/a>
                <\/li>
                <li>
                    <a href=\"javascript:void(0)\">
                        <i class=\"si si-wrench\"><\/i>Page
                    <\/a>
                <\/li>
            <\/ul>-->
            <ul class=\"nav-main-header  nav-main-header-no-icons2 d-none2\">
            <!--
<ul class=\"nav-main\">
    <li>
        <a class=\"active\" href=\"\">
            <i class=\"si si-home\"><\/i>Home
        <\/a>
    <\/li>
    <li class=\"nav-main-heading\">Heading<\/li>
    <li>
        <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">
            <i class=\"si si-puzzle\"><\/i>Dropdown
        <\/a>
        <ul>
            <li>
                <a href=\"javascript:void(0)\">Link #1<\/a>
            <\/li>
            <li>
                <a href=\"javascript:void(0)\">Link #2<\/a>
            <\/li>
            <li>
                <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">Dropdown<\/a>
                <ul>
                    <li>
                        <a href=\"javascript:void(0)\">Link #1<\/a>
                    <\/li>
                    <li>
                        <a href=\"javascript:void(0)\">Link #2<\/a>
                    <\/li>
                <\/ul>
            <\/li>
        <\/ul>
    <\/li>
    <li class=\"nav-main-heading\">Vital<\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
<\/ul>
-->

            

    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/feature\"
            
            class=\"
            
            
            \">

                               \u0645\u0645\u064a\u0632\u0627\u062a\u0646\u0627
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/assortment\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0627\u0642\u0633\u0627\u0645
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/team\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0637\u0627\u0642\u0645
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/post\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0627\u062e\u0628\u0627\u0631
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/album\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0635\u0648\u0631
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/videos\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0641\u064a\u062f\u064a\u0648\u0647\u0627\u062a
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/staff\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u062a\u0648\u0636\u064a\u0641
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/contact\"
            
            class=\"
            
            
            \">

                               \u0644\u0644\u062a\u0648\u0627\u0635\u0644
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/bookings\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u062d\u062c\u0632 \u0627\u0644\u0627\u0644\u0643\u062a\u0631\u0648\u0646\u064a
            <\/a>

                    
    <\/li>

<!--<li class=\"nav-main-heading\">-->
    <!--<span class=\"sidebar-mini-visible\">PG<\/span>-->
    <!--<span class=\"sidebar-mini-hidden\">Pages<\/span>-->
<!--<\/li>-->
<!--<li>-->
    <!--<a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">-->
        <!--<i class=\"si si-puzzle\"><\/i>Dropdown-->
    <!--<\/a>-->
    <!--<ul>-->
        <!--<li>-->
            <!--<a href=\"javascript:void(0)\">Link #1<\/a>-->
        <!--<\/li>-->
        <!--<li>-->
            <!--<a href=\"javascript:void(0)\">Link #2<\/a>-->
        <!--<\/li>-->
        <!--<li>-->
            <!--<a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">Dropdown<\/a>-->
            <!--<ul>-->
                <!--<li>-->
                    <!--<a href=\"javascript:void(0)\">Link #1<\/a>-->
                <!--<\/li>-->
                <!--<li>-->
                    <!--<a href=\"javascript:void(0)\">Link #2<\/a>-->
                <!--<\/li>-->
            <!--<\/ul>-->
        <!--<\/li>-->
    <!--<\/ul>-->
<!--<\/li>-->
            <\/ul>
<!--
            <ul class=\"nav-main-header  nav-main-header-no-icons2  mx-auto\">

                <li>
                       <div class=\"d-none2 d-sm-none2 input-group mx-auto\">
   <form method=\"POST\" action=\"http:\/\/localhost:8006\/api\/v1\/cms\/static-pages\/render\" accept-charset=\"UTF-8\"><input name=\"_session_key\" type=\"hidden\" value=\"VNFEzmWUax71ApSCKfEWQj6eBYLFIYIuGUpu3YEz\"><input name=\"_token\" type=\"hidden\">
    <select name=\"locale\" data-request=\"onSwitchLocale\" class=\"form-control form-control-sm  mx-0 px-0\">
                    <option value=\"en\" >English<\/option>
                    <option value=\"ar\" selected>Arabic<\/option>
            <\/select>
<\/form>                     <\/div>
                <\/li>
            <\/ul>
-->
            <!-- END Header Navigation -->
          


            <!-- User Dropdown -->

            <!-- Color Themes (used just for demonstration) -->
            <!-- Themes functionality initialized in Codebase() -> uiHandleTheme() -->
      <!--     <div class=\"btn-group mr-5\" role=\"group\">
                <button type=\"button\" class=\"btn btn-circle btn-dual-secondary\" id=\"page-header-themes-dropdown\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                    <i class=\"fa fa-paint-brush\"><\/i>
                <\/button>
                <div class=\"dropdown-menu min-width-150\" aria-labelledby=\"page-header-themes-dropdown\">
                    <h6 class=\"dropdown-header text-center\">Color Themes<\/h6>
                    <div class=\"row no-gutters text-center\">
                        <div class=\"col-4 mb-5\">
                            <a class=\"text-default\" data-toggle=\"theme\" data-theme=\"default\" href=\"javascript:void(0)\">
                                <i class=\"fa fa-2x fa-circle\"><\/i>
                            <\/a>
                        <\/div>
                        <div class=\"col-4 mb-5\">
                            <a class=\"text-elegance\" data-toggle=\"theme\" data-theme=\"assets\/css\/themes\/elegance.min.css\" href=\"javascript:void(0)\">
                                <i class=\"fa fa-2x fa-circle\"><\/i>
                            <\/a>
                        <\/div>
                        <div class=\"col-4 mb-5\">
                            <a class=\"text-pulse\" data-toggle=\"theme\" data-theme=\"assets\/css\/themes\/pulse.min.css\" href=\"javascript:void(0)\">
                                <i class=\"fa fa-2x fa-circle\"><\/i>
                            <\/a>
                        <\/div>
                        <div class=\"col-4 mb-5\">
                            <a class=\"text-flat\" data-toggle=\"theme\" data-theme=\"assets\/css\/themes\/flat.min.css\" href=\"javascript:void(0)\">
                                <i class=\"fa fa-2x fa-circle\"><\/i>
                            <\/a>
                        <\/div>
                        <div class=\"col-4 mb-5\">
                            <a class=\"text-corporate\" data-toggle=\"theme\" data-theme=\"assets\/css\/themes\/corporate.min.css\" href=\"javascript:void(0)\">
                                <i class=\"fa fa-2x fa-circle\"><\/i>
                            <\/a>
                        <\/div>
                        <div class=\"col-4 mb-5\">
                            <a class=\"text-earth\" data-toggle=\"theme\" data-theme=\"assets\/css\/themes\/earth.min.css\" href=\"javascript:void(0)\">
                                <i class=\"fa fa-2x fa-circle\"><\/i>
                            <\/a>
                        <\/div>
                    <\/div>
                <\/div>
            <\/div> -->
            <!-- END Color Themes -->
        
    
            <!-- Toggle Sidebar -->
            <!-- Layout API, functionality initialized in Codebase() -> uiApiLayout() -->
            <button type=\"button\" class=\"btn btn-circle btn-dual-secondary d-lg-none\"
                    data-toggle=\"layout\" data-action=\"sidebar_toggle\">
                <i class=\"fa fa-navicon\"><\/i>
            <\/button>
            <!-- END Toggle Sidebar -->
        <\/div>
        <!-- END Left Section -->
    <\/div>
    <!-- END Header Content -->

    
    <!-- Header Loader -->
    <div id=\"page-header-loader\" class=\"overlay-header bg-primary\">
        <div class=\"content-header content-header-fullrow text-center\">
            <div class=\"content-header-item\">
                <i class=\"fa fa-sun-o fa-spin text-white\"><\/i>
            <\/div>
        <\/div>
    <\/div>
    <!-- END Header Loader -->
<\/header>        <!-- END Header -->

        <!-- Main Container -->
        <main id=\"main-container\" class=\"content2  content-full2 main-content-narrow2\">
            <!--<div  class=\"content content-full\">-->
            <!-- Hero -->
                              <!-- Hero -->
<!--
<div class=\"bg-primary overflow-hidden\">
    <div class=\"hero bg-black-op-25\">
        <div class=\"hero-inner\">
            <div class=\"content content-full text-center\">
                <h1 class=\"display-3 font-w700 text-white mb-10 invisible\" data-toggle=\"appear\" data-class=\"animated fadeInDown\">Hero Title<\/h1>
                <h2 class=\"font-w400 text-white-op mb-50 invisible\" data-toggle=\"appear\" data-class=\"animated fadeInDown\">Hero Subtitle.<\/h2>
                <a class=\"btn btn-hero btn-noborder btn-rounded btn-success ml-5 mb-10 invisible\" data-toggle=\"appear\" data-class=\"animated fadeInUp\" href=\"javascript:void(0)\">
                    <i class=\"fa fa-rocket ml-10\"><\/i> Call to Action
                <\/a>
                <a class=\"btn btn-hero btn-noborder btn-rounded btn-primary mb-10 invisible\" data-toggle=\"appear\" data-class=\"animated fadeInUp\" href=\"javascript:void(0)\">
                    <i class=\"fa fa-rocket ml-10\"><\/i> Call to Action
                <\/a>
            <\/div>
        <\/div>
    <\/div>
<\/div>
-->
 
            
<!-- Hero -->
                <div class=\"bg-image222 bg-hero55 bg-image-bottom22\" style=\"background-image: url('http:\/\/localhost:8006\/storage\/app\/media\/favicon.png');
background-size: 100% 100%;
   background-repeat: no-repeat;
   background-position2: 100% 100% !important; ;
background-attachment: fixed;
-webkit-background-size2: cover;
background-size2: contain !important; 
height: 500px !important;\">
                    <div class=\"d-none bg-black-op hero2 hero-static2 hero-promo2 \" style=\" height: 100% !important;\">
                        <div class=\"content content-top text-center\">
                            <div class=\"py-50\">
                                <h1 class=\"font-w700 text-white mb-10\">
     \u0645\u0631\u062d\u0628\u0627 \u0628\u0643\u0645
    <\/h1>
                                <p class=\"h4 font-w400 text-white-op\">
<span class=\"text-slider-items d-none\">
      \u0646\u062d\u0646 \u0641\u0649 \u062e\u062f\u0645\u0629 \u0627\u0644\u0639\u0644\u0645 \u0648\u0627\u0644\u0645\u062c\u062a\u0645\u0639
<\/span>
<strong class=\"text-slider\"><\/strong>
<\/p>


 <p class=\"pt-3 mt-15 d-none\">
                    <a class=\"btn btn-success btn js-scroll px-4 btn-noborder btn-rounded invisible\" 
href=\"tel:770529482\" role=\"button\" data-toggle=\"appear\" data-class=\"animated fadeInUp\">
       
\u0627\u062a\u0635\u0627\u0644
    <span class=\"comit\"><i class=\"fa fa-phone\"><\/i><\/span>
<\/a>
    

<\/p>  
<!--
          <a class=\"btn btn-hero btn-noborder btn-rounded btn-success ml-5 mb-10 invisible\" data-toggle=\"appear\" data-class=\"animated fadeInUp\" href=\"javascript:void(0)\">
                    <i class=\"fa fa-rocket ml-10\"><\/i> Call to Action
                <\/a>
                <a class=\"btn btn-hero btn-noborder btn-rounded btn-primary mb-10 invisible\" data-toggle=\"appear\" data-class=\"animated fadeInUp\" href=\"javascript:void(0)\">
                    <i class=\"fa fa-rocket ml-10\"><\/i> Call to Action
                <\/a>
-->
                            <\/div>
                        <\/div>
                    <\/div>
                <\/div>
                <!-- END Hero -->
            
            <!-- END Hero -->


            <!-- Page  -->
            <div class=\"content content-full m-md-1\">

                                <div class=\" row\">
                                   <\/div>

                <div class=\"row no-gutters \">
                                      
                   <hr>

<hr>



<h1>\u0645\u0646 \u0646\u062d\u0646<\/h1><pre><strong>\u0645\u062a\u062e\u0635\u0635\u0629 \u0641\u064a \u0645\u062c\u0627\u0644 \u062a\u0637\u0648\u064a\u0631 \u0627\u0644\u0628\u0631\u0645\u062c\u064a\u0627\u062a \u0648\u0627\u0644\u0623\u0646\u0638\u0645\u0629 \u0627\u0644\u0645\u062d\u0627\u0633\u0628\u064a\u0629 \u0627\u0644\u0645\u062e\u062a\u0644\u0641\u0629 \u0648\u062a\u0637\u0648\u064a\u0631 \u0627\u0644\u0645\u0648\u0627\u0642\u0639 \u0627\u0644\u0627\u0644\u0643\u062a\u0631\u0648\u0646\u064a\u0629 \u0648 \u062a\u0633\u0639\u0649 \u0627\u0644\u0649 \u0627\u0646 \u062a\u0635\u0628\u062d \u0631\u0627\u0626\u062f\u0629 \u0641\u064a \u0647\u0630\u0627 \u0627\u0644\u0645\u062c\u0627\u0644 \u0639\u0644\u0649 \u0627\u0644\u0645\u0633\u062a\u0648\u064a \u0627\u0644\u0648\u0637\u0646\u064a.<\/strong><\/pre>                   
                                     
                <\/div>
                
                 <div class=\" row\">
                                   <\/div>
            <\/div>
            <!-- END Page -->

        <!--<\/div>-->
<!-- AddToAny BEGIN -->
<div class=\"a2a_kit a2a_kit_size_32 a2a_floating_style a2a_vertical_style\" style=\"left:0px; top:150px;\" 

data-a2a-url=\"http:\/\/localhost:8006\/api\/v1\/cms\/static-pages\/render\" 
data-a2a-title=\"\u0646\u0627\u0646\u0648 \u0633\u0648\u0641\u062a\"

data-a2a-icon-color22=\"lightseagreen\"
>
<a class=\"a2a_dd\" href=\"https:\/\/www.addtoany.com\/share\"><\/a>
<a class=\"a2a_button_facebook\"><\/a>
<a class=\"a2a_button_twitter\"><\/a>
<a class=\"a2a_button_email\"><\/a>
<a class=\"a2a_button_whatsapp\"><\/a>
<a class=\"a2a_button_copy_link\"><\/a>
<a class=\"a2a_button_sms\"><\/a>
<a class=\"a2a_button_telegram\"><\/a>
<a class=\"a2a_button_facebook_messenger\"><\/a>
<\/div>


   

<!-- AddToAny END -->

        <\/main>
        <!-- END Main Container -->

        <!-- Footer -->
        <!-- Footer -->
<footer id=\"page-footer\" class=\"bg-primary text-white opacity-055555 navbar-\">
    <div class=\"content content-full2\">
        <!-- Footer Navigation -->
        <div class=\"row items-push-2x mt-30\">
            <div class=\"col-12  col-md-4 text-center\">

                <ul class=\"nav text-white nav-tabs2 pr-0 nav-pills flex-column flex-sm-row justify-content-center  list2 list-simple-mini2 font-size-ml2 font-w600\">
                    <!--<li>-->
                        <!--<a class=\"link-effect font-w600\" href=\"javascript:void(0)\">Link #1<\/a>-->
                    <!--<\/li>-->
                    <li class=\"nav-item d-md-none my-0 py-0 border-bottom\">
 nano.footer.menu 
<\/li>
                    <!--
<ul class=\"nav-main\">
    <li>
        <a class=\"active\" href=\"\">
            <i class=\"si si-home\"><\/i>Home
        <\/a>
    <\/li>
    <li class=\"nav-main-heading\">Heading<\/li>
    <li>
        <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">
            <i class=\"si si-puzzle\"><\/i>Dropdown
        <\/a>
        <ul>
            <li>
                <a href=\"javascript:void(0)\">Link #1<\/a>
            <\/li>
            <li>
                <a href=\"javascript:void(0)\">Link #2<\/a>
            <\/li>
            <li>
                <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">Dropdown<\/a>
                <ul>
                    <li>
                        <a href=\"javascript:void(0)\">Link #1<\/a>
                    <\/li>
                    <li>
                        <a href=\"javascript:void(0)\">Link #2<\/a>
                    <\/li>
                <\/ul>
            <\/li>
        <\/ul>
    <\/li>
    <li class=\"nav-main-heading\">Vital<\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
<\/ul>
-->

            

<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/feature\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0645\u0645\u064a\u0632\u0627\u062a\u0646\u0627
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/assortment\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u0627\u0642\u0633\u0627\u0645
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/team\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u0637\u0627\u0642\u0645
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/post\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u0627\u062e\u0628\u0627\u0631
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/album\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u0635\u0648\u0631
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/videos\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u0641\u064a\u062f\u064a\u0648\u0647\u0627\u062a
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/staff\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u062a\u0648\u0636\u064a\u0641
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/contact\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0644\u0644\u062a\u0648\u0627\u0635\u0644
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/bookings\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u062d\u062c\u0632 \u0627\u0644\u0627\u0644\u0643\u062a\u0631\u0648\u0646\u064a
    <\/a>

    
<\/li>


                <\/ul>
            <\/div>
            <div class=\" col-12 col-md-4 text-center\">
                <h3 class=\"h5 font-w700\">
                    \u064a\u0645\u0643\u0646\u0643\u0645 \u0627\u0644\u062a\u0648\u0627\u0635\u0644 \u0645\u0639\u0646\u0627 \u0639\u0646 \u0637\u0631\u064a\u0642 :
                <\/h3>
                <div class=\"font-size-sm mb-30\">
                                             \u0627\u0644\u0639\u0646\u0648\u0627\u0646
                        <br>
                        Yemen IBB
                        <br>
                    

                                            <abbr title=\"Phone\">
                             \u0627\u0644\u0647\u0627\u062a\u0641
                        <\/abbr>
                                                                                     770529482
                            <br>
                                                                        
                    
                    
                <\/div>
                <!--<form>-->
                <!--<div class=\"input-group\">-->
                <!--<input type=\"email\" class=\"form-control\" id=\"ld-subscribe-email\" name=\"ld-subscribe-email\" placeholder=\"Your email..\">-->
                <!--<div class=\"input-group-append\">-->
                <!--<button type=\"submit\" class=\"btn btn-square btn-secondary\">Subscribe<\/button>-->
                <!--<\/div>-->
                <!--<\/div>-->
                <!--<\/form>-->
            <\/div>

            <div class=\"col-12 col-md-4 text-center text-white\">
<!--
                <ul class=\"list list-simple-mini font-size-sm\">
                    <li>
                        <a class=\"link-effect font-w600\" href=\"javascript:void(0)\">Link #1<\/a>
                    <\/li>
                    <li>
                        <a class=\"link-effect font-w600\" href=\"javascript:void(0)\">Link #2<\/a>
                    <\/li>
                    <li>
                        <a class=\"link-effect font-w600\" href=\"javascript:void(0)\">Link #3<\/a>
                    <\/li>
                    <li>
                        <a class=\"link-effect font-w600\" href=\"javascript:void(0)\">Link #4<\/a>
                    <\/li>
                    <li>
                        <a class=\"link-effect font-w600\" href=\"javascript:void(0)\">Link #5<\/a>
                    <\/li>
                    <li>
                        <a class=\"link-effect font-w600\" href=\"javascript:void(0)\">Link #6<\/a>
                    <\/li>
                <\/ul>
-->
                <h3 class=\"h5 font-w700 text-white\">\u0643\u0645\u0627 \u064a\u0645\u0643\u0646\u0643\u0645 \u0632\u064a\u0627\u0631\u062a\u0646\u0627 \u0639\u0644\u0649 \u0645\u0648\u0627\u0642\u0639 \u0627\u0644\u062a\u0648\u0627\u0635\u0644 \u0627\u0644\u062a\u0627\u0644\u064a\u0629<\/h3>

                
\t<!--<ul class=\"\">-->
\t\t\t\t\t<!--<li class=\"\">-->
\t\t\t\t<a class=\"btn text-white btn-ml2 btn-circle btn-outline-primary  btn-alt-secondary2   btn-rounded2 btn-square2    \" target=\"_blank\" href=\"http:\/\/nano2soft.com\" title=\"\u062c\u0648\u062c\u0644\">
\t\t\t\t\t<i class=\"fa fa-google-plus-g\"><\/i>
\t\t\t\t<\/a>
\t\t\t<!--<\/li>-->
\t\t\t\t\t<!--<li class=\"\">-->
\t\t\t\t<a class=\"btn text-white btn-ml2 btn-circle btn-outline-primary  btn-alt-secondary2   btn-rounded2 btn-square2    \" target=\"_blank\" href=\"http:\/\/nano2soft.com\" title=\"fasebokk\">
\t\t\t\t\t<i class=\"fa fa-facebook\"><\/i>
\t\t\t\t<\/a>
\t\t\t<!--<\/li>-->
\t\t\t<!--<\/ul>2-->
            <\/div>

        <\/div>
        <!-- END Footer Navigation -->

        <!-- Copyright Info -->
        <div class=\"font-size-xs clearfix border-t  pt-20 pb-30 pb-md-10\">
            <div class=\"float-right\">
                <a class=\"font-w600 text-white\" href=\"http:\/\/localhost:8006\" target=\"_blank\">
                    \u0646\u0627\u0646\u0648 \u0633\u0648\u0641\u062a
                    
                <\/a> &copy; 2020 - <span class=\"js-year-copy\"><\/span>
            <\/div>
            <div class=\"float-left\">
                \u062a\u0637\u0648\u064a\u0631
                <i class=\"fa fa-heart text-pulse\"><\/i>
                <a class=\"font-w600 text-white\" href=\"https:\/\/nano2soft.com\" target=\"_blank\">
                    Nano 2 Soft

                <\/a>
                <br>

                <abbr class=\"d-none\" title=\"Phone\">
                     \u0627\u0644\u0647\u0627\u062a\u0641
                    00967770529482
                <br>
                <\/abbr>    
                <abbr class=\"d-none\" title=\"Mail\">
                     \u0627\u0644\u0628\u0631\u064a\u062f
                <\/abbr>
                <a class=\" d-none font-w600 text-white\" href=\"mailTo:info@nano2soft.com\" title=\"Nano 2 Soft\" target=\"_blank\">
                    info@nano2soft.com

                <\/a>
                

                <abbr title=\"Website\">
                     website
                <\/abbr>
                <a class=\"font-w600 text-white\" href=\"https:\/\/nano2soft.com\" title=\"Nano 2 Soft\" target=\"_blank\">
                    https:\/\/nano2soft.com

                <\/a>
            <\/div>
        <\/div>
        <!-- END Copyright Info -->
    <\/div>
<\/footer>        <!-- END Footer -->

     
        <a class=\"lnxScrollToTop\" id=\"lnxScrollToTop\">
\t<i class=\"lnxScrollToTopArrow\" id=\"lnxScrollToTopArrow\"><\/i>
<\/a>
<script>
(function(){
\tvar mainObject = document.getElementById('lnxScrollToTop');
\tvar arrowObject = document.getElementById('lnxScrollToTopArrow'); 

\tvar op = 0.1;
\tvar isVisible = false;
\tvar timer;
\twindow.onscroll = function (e) {
\t\tvar scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
\t\tif (scrollTop > 200) {
\t\t\tif (!isVisible) {
\t\t\t\tfadeIn(mainObject);
\t\t\t\tisVisible = true;
\t\t\t}
\t\t} else {
\t\t\tif (isVisible) {
\t\t\t\tfadeOut(mainObject);
\t\t\t\tisVisible = false;
\t\t\t}
\t\t}
\t};

\tmainObject.onclick = clicked;
\tfunction clicked (event) {
\t\tvar element = (document.documentElement.scrollTop) ? document.documentElement : document.body;
\t\tscrollTo(element, 0, 300);
\t\tevent.preventDefault();
\t}

\tfunction scrollTo(element, to, duration) {
\t\tvar start = element.scrollTop,
\t\t\tchange = to - start,
\t\t\tcurrentTime = 0,
\t\t\tincrement = 20;
\t\t\t
\t\tvar animateScroll = function(){        
\t\t\tcurrentTime += increment;
\t\t\tvar val = Math.easeInOutQuad(currentTime, start, change, duration);
\t\t\telement.scrollTop = val;
\t\t\tif(currentTime < duration) {
\t\t\t\tsetTimeout(animateScroll, increment);
\t\t\t}
\t\t};
\t\tanimateScroll();
\t}

\tfunction fadeOut(element) {
\t\tclearInterval(timer)
\t\ttimer = setInterval(function () {
\t\t\tif (op <= 0.1){
\t\t\t\tclearInterval(timer);
\t\t\t\top = 0.1;
\t\t\t\telement.style.display = 'none';
\t\t\t}
\t\t\telement.style.opacity = op.toFixed(2);
\t\t\telement.style.filter = 'alpha(opacity=' + op * 100 + \")\";
\t\t\top -= op * 0.2;
\t\t}, 25);
\t}

\tfunction fadeIn(element) {
\t\telement.style.display = 'block';
\t\tclearInterval(timer)
\t\ttimer = setInterval(function () {
\t\t\tif (op >= 1){
\t\t\t\tclearInterval(timer);
\t\t\t\top = 1;
\t\t\t}
\t\t\telement.style.opacity = op.toFixed(2);
\t\t\telement.style.filter = 'alpha(opacity=' + op * 100 + \")\";
\t\t\top += op * 0.2;
\t\t}, 25);
\t}

\t\/\/t = current time
\t\/\/b = start value
\t\/\/c = change in value
\t\/\/d = duration
\tMath.easeInOutQuad = function (t, b, c, d) {
\t\tt \/= d\/2;
\t\tif (t < 1) return c\/2*t*t + b;
\t\tt--;
\t\treturn -c\/2 * (t*(t-2) - 1) + b;
\t};
})();
<\/script>

\t\t

<style>
\t.lnxScrollToTop {
\t\tbackground: #FFF;
\t\twidth: 30px;
\t\theight: 30px;
\t\tline-height: 30px;
\t\t\tbottom: 1%;
\t\t\tmargin: 1%;

\t}
\t.lnxScrollToTop:hover {
\t\tbackground: #E6E6E6;
\t}
\t.lnxScrollToTopArrow {
\t\tcolor: #000;
\t\tfont-size: 20px;
\t}
\t.lnxScrollToTop:hover .lnxScrollToTopArrow {
\t\tcolor: #2E2E2E;
\t}
<\/style>
        


        
    <\/div>
    <!-- END Page Container -->




<!-- Codebase JS -->
<!--
<script src=\"assets\/js\/core\/jquery.min.js\"><\/script>
<script src=\"assets\/js\/codebase.core.min.js\"><\/script>
<script src=\"assets\/js\/codebase.app.min.js\"><\/script>
<script src=\"http:\/\/localhost:8006\/combine\/b050b89525d1582d5acf3161697586f3-1636410626\"><\/script>
,
                
-->

    
<script src=\"http:\/\/localhost:8006\/combine\/1a1b5170f45329edb1a2904a96de7843-1657560414\"><\/script>
<script src=\"http:\/\/localhost:8006\/combine\/83bc13c07b3bde3ae63949baa2f13655-1581776556\"><\/script>

   
    <script src=\"\/modules\/system\/assets\/js\/framework.js\"><\/script>
    <script src=\"\/modules\/system\/assets\/js\/framework.js\"><\/script>
<script src=\"\/modules\/system\/assets\/js\/framework.extras.js\"><\/script>
<link rel=\"stylesheet\" property=\"stylesheet\" href=\"\/modules\/system\/assets\/css\/framework.extras.css\">

<!---->

<script src=\"http:\/\/localhost:8006\/themes\/nano-themes\/assets\/js\/plugins\/swiper\/dist\/js\/swiper.min.js\"><\/script>
<script src=\"http:\/\/localhost:8006\/themes\/nano-themes\/assets\/vendor\/typed.js\/typed.min.js\"><\/script>
<script src=\"http:\/\/localhost:8006\/themes\/nano-themes\/assets\/vendor\/venobox\/venobox.min.js\"><\/script>

<script src=\"https:\/\/maps.googleapis.com\/maps\/api\/js?key=&amp;libraries=places&amp;language=\"><\/script>
<script src=\"http:\/\/localhost:8006\/plugins\/nano\/broadcast\/assets\/js\/vendor\/pusher\/pusher.min.js?pusher-js\"><\/script>
<script src=\"http:\/\/localhost:8006\/plugins\/nano\/broadcast\/assets\/js\/vendor\/echo\/echo.iife.js?echo-js\"><\/script>
<script src=\"http:\/\/localhost:8006\/plugins\/nano\/broadcast\/assets\/js\/vendor\/push\/push.min.js?push-js\"><\/script>
<script src=\"http:\/\/localhost:8006\/plugins\/nano\/broadcast\/assets\/js\/broadcast.js?broadcast-js\"><\/script>
<script>
    $(function(){ 
    $(document).ready(function() { 
        Codebase.loader('show', 'bg-primary');

\/\/Codebase.layout('header_loader_on');
\/\/Codebase.layout('header_loader_off');

\/\/Codebase.loader('hide');
            setTimeout(function(){ 
                     \/\/$('body').addClass('loaded');
\/\/Codebase.layout('header_loader_off');

                     Codebase.loader('hide');
                     
               }, 700);
\/\/Codebase.layout('header_loader_off');
\/\/Codebase.loader('hide');

       }); 
}(jQuery));

<\/script>

<script type=\"text\/javascript\" >
var a2a_config = a2a_config || {};
a2a_config.onclick = 1;
a2a_config.locale = \"ar\";
a2a_config.num_services = 22;

\/*
a2a_config.icon_color = \"unset,#3f9ce8\";
a2a_config.color_bg = \"FFFFFF\";
a2a_config.color_main = \"D7E5ED\";
a2a_config.color_border = \"AECADB\";
a2a_config.color_link_text = \"333333\";
a2a_config.color_link_text_hover = \"333333\";

a2a_config.icon_color = \"#0166ff\";
a2a_config.icon_color = \"seashell,midnightblue\";

FacebookTwitterLinkedInShare
a2a_config.icon_color = \"deeppink\";
FacebookTwitterLinkedInShare
a2a_config.icon_color = \"transparent\";
*\/

<\/script>
<!--
<script async src=\"assets\/js\/page.js\"><\/script>
-->
<script async src=\"https:\/\/static.addtoany.com\/menu\/page.js\"><\/script>


<script>
    \/*
    $(document).ready(function(){
        var targetWidth = 980;
\/\/alert(\"dhyaa\");

        $('meta[name=\"viewport\"]').attr('content', 'width=' + targetWidth);

    });
Codebase.loader('show', 'bg-primary');
                                        setTimeout(function () {
                                            Codebase.loader('hide');
                                        }, 3000);

    *\/
    $(function(){ 
    $(document).ready(function() { 
      
            Codebase.loader('show', 'bg-primary');

\/\/Codebase.layout('header_loader_on');
\/\/Codebase.layout('header_loader_off');

\/\/Codebase.loader('hide');
            setTimeout(function(){ 
                     \/\/$('body').addClass('loaded');
\/\/Codebase.layout('header_loader_off');

                     Codebase.loader('hide');
                     
               }, 700);
\/\/Codebase.layout('header_loader_off');
\/\/Codebase.loader('hide');

       }); 
}(jQuery));


      if ($('.text-slider').length == 1) {

    var typed_strings = $('.text-slider-items').text();
    var typed = new Typed('.text-slider', {
      strings: typed_strings.split(','),
      typeSpeed: 80,
      loop: true,
      backDelay: 1100,
      backSpeed: 30
    });
  }

    
    
<\/script>

<\/body>
<\/html>"
}  

```
