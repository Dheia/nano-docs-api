## Cms Pages Language

This endpoint allows you to `list`, `show` your Cms-Pages.

/cms/cms-pages

**الجز الخاص بالصفحات التي يدعمها النظام يمكنك من خلال هذا الجزء جلب كافه الصفحات المدعومه فى النظام **

### The Accept-Language 

**يمكن تهية الصفحة حسب اللغة فى النظام من خلال  تمرير كود اللغة فى راس الطلب ضمن المتغير  Accept-Language**

Header Parameters
```json
{
  "Accept-Language":"ar"
}
```

### List Cms-Pages

Returns a list of Cms-Pages.

**لجلب الصفحات نستخدم الرابط التالي **

```
GET /api/v1/cms/cms-pages
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Response

```html
Status: 200 OK
```

```json
{
  "data": {
    "abort": "Abort (abort)",
    "abouts": "عن المؤسسة (abouts)",
    "adverts\/advertdetails": "advertdetails (adverts\/advertdetails)",
    "adverts\/posts-advert": "advert (adverts\/posts-advert)",
    "ajax-popup": "الرئيسية (ajax-popup)",
    "album": "album (album)",
    "album-lists": "البومات الصور (album-lists)",
    "aqer": "aqerts (aqer)",
    "aqers\/aqerdetails": "aqerdetails (aqers\/aqerdetails)",
    "aqers\/posts-aqer": "aqer (aqers\/posts-aqer)",
    "assortment": "assortments (assortment)",
    "assortments\/assortmentdetails": "assortmentdetails (assortments\/assortmentdetails)",
    "assortments\/posts-assortment": "assortment (assortments\/posts-assortment)",
    "block": "الرئيسية (block)",
    "blog\/blog": "Blog (blog\/blog)",
    "blog\/category": "Blog Category (blog\/category)",
    "blog\/post": "post (blog\/post)",
    "blog\/search": "Search Blog (blog\/search)",
    "blog\/series-list": "Series Lists (blog\/series-list)",
    "blog\/series-posts": "Series (blog\/series-posts)",
    "blog\/tag": "Tag  (blog\/tag)",
    "blog\/tagpost": "Tag Posts (blog\/tagpost)",
    "bookings": "نموذج الحجز الالكتروني (bookings)",
    "campaign\/message": "Default template (campaign\/message)",
    "campaign\/signup": "campaignSignup (campaign\/signup)",
    "clinets": "خدماتنا (clinets)",
    "con-useing": "شروط الاستخدام (con-useing)",
    "contact": "اتصال بنا (contact)",
    "docs\/doc": "Winter CMS 1.2 User Interface Documentation (docs\/doc)",
    "faq": "faq (faq)",
    "feature": "features (feature)",
    "features\/featuredetails": "featuredetails (features\/featuredetails)",
    "features\/posts-feature": "feature (features\/posts-feature)",
    "forgot-password": "Forgotten your password? (forgot-password)",
    "form": "form (form)",
    "ggg": "ggg (ggg)",
    "image": "image (image)",
    "images\/album": "album (images\/album)",
    "images\/album-lists": "البومات الصور (images\/album-lists)",
    "images\/image": "image (images\/image)",
    "images\/photo": "photo (images\/photo)",
    "index": "الرئيسية (index)",
    "login": "Login (login)",
    "login-register": "Login (login-register)",
    "login\/aqers": "aqers (login\/aqers)",
    "login\/new-aqers": "new-aqers (login\/new-aqers)",
    "login\/update": "update (login\/update)",
    "msg\/chat2": "chat2 (msg\/chat2)",
    "msg\/chat3": "chat3 (msg\/chat3)",
    "msg\/inbox": "inbox (msg\/inbox)",
    "msg\/msg": "msg (msg\/msg)",
    "myaccount": "Account (myaccount)",
    "photo": "photo (photo)",
    "post": "posts (post)",
    "posts\/postdetails": "postdetails (posts\/postdetails)",
    "posts\/posts-post": "post (posts\/posts-post)",
    "privets": "سياسة الخصوصية (privets)",
    "project": "Projects (project)",
    "projects\/posts-project": "project (projects\/posts-project)",
    "projects\/projectdetails": "projectdetails (projects\/projectdetails)",
    "register": "register (register)",
    "search": "Search results (search)",
    "servce": "خدماتنا (servce)",
    "servec\/posts-servce": "servce (servec\/posts-servce)",
    "servec\/servcedetails": "servcedetails (servec\/servcedetails)",
    "servec\/servces": "Servces (servec\/servces)",
    "smallmessages": "الرئيسية (smallmessages)",
    "staff": "نموذج التوظيف (staff)",
    "team": "teams (team)",
    "teams\/posts-team": "team (teams\/posts-team)",
    "teams\/teamsdetails": "teamsdetails (teams\/teamsdetails)",
    "tgrbh-adafh-small": "تجربه اضافه small (tgrbh-adafh-small)",
    "ttttt": "ttttt (ttttt)",
    "videos\/video": "video (videos\/video)",
    "videos\/videos": "videos (videos\/videos)",
    "wn-block": "الرئيسية (wn-block)",
    "work": "work (work)",
    "works\/posts-work": "work (works\/posts-work)",
    "works\/workdetails": "workdetails (works\/workdetails)"
  }
}
```

### Get Data Cms Pages 

**لجلب بيانات صفحة معينه نقوم بستخدام الرابط التالي مع تمرير اسم الصفحة فى البراميتر name**

GET http://localhost:8006/api/v1/cms/cms-pages/data

Required Parameters: `name`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `name`           | `string`  | **Required**. The id          |


#### Example 2 get Data Cms Pages name=abouts

```
GET http://localhost:8006/api/v1/cms/cms-pages/data?name=abouts
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": {
    "url": "\/abouts\/",
    "layout": "default",
    "title": "عن المؤسسة",
    "description": "عن المؤسسة",
    "is_hidden": "0",
    "meta_title": "عن المؤسسة",
    "meta_description": "عن المؤسسة",
    "markup": "<!--<button type=\"button\" class=\"btn btn-sm btn-alt-primary min-width-150\"-->\n        <!--onclick=\"Codebase.blocks('#my-block', 'content_toggle');\">State Loading<\/button>-->\n<!--<button type=\"button\" class=\"btn btn-sm btn-alt-primary min-width-150\"-->\n        <!--data-toggle=\"show\" data-action=\"my-block\"  >ghjghjg<\/button>-->\n\n\n{# partial 'all_pages\/hero' #}\n\n    {% put advars %}\n    \n    <div class=\" row mb-10  px-1 px-sm-0\">\n        <div class=\"col-12\">\n            <!-- AdvertCarousel -->\n     \n            <!-- END AdvertCarousel -->\n        <\/div>\n\n    <\/div>\n    {% endput %}\n\n\n<div class=\"col-12 col-lg-12 col-md-12 col-sm-12 col-xl-12 col-xs-12 bg-white \">\n\n    {% partial 'all_pages\/btn' %}\n<\/div>\n\n   \n\n   \n\n    <div class=\"col-12 col-lg-12 col-md-12 col-sm-12 col-xl-12 col-xs-12 bg-secondary2 bg-white \">\n\n          <!-- AdvertCarousel -->\n            {% component 'AdvertCarousel' %}\n            <!-- END AdvertCarousel -->\n    <\/div>\n\n\n\n     {% component 'tssCount' %}\n\n  {% component 'tssAssociates' %}\n      {%component 'tssPostRecords' %}\n        {# partial 'section' #}\n    <!--<\/div>-->\n <div class=\"col-12 col-lg-12 col-md-12 col-sm-12 col-xl-12 col-xs-12 bg-white \">\n\n        {% partial 'all_pages\/contact' %}\n    <\/div>\n\n\n<!--\n<div class=\"col-sm-6 col-md-3 py-30\">\n    <div class=\"mb-20\">\n        <i class=\"si si-users fa-3x text-primary\"><\/i>\n    <\/div>\n    <div class=\"font-size-h1 font-w700 text-black mb-5 js-count-to-enabled2\" data-toggle=\"countTo\" data-to=\"760\" data-speed=\"2500\" data-after=\"+\">0<\/div>\n    <div class=\"font-w600 text-muted text-uppercase\">Clients<\/div>\n<\/div>-->",
    "settings": {
      "title": "عن المؤسسة",
      "url": "\/abouts\/",
      "layout": "default",
      "description": "عن المؤسسة",
      "meta_title": "عن المؤسسة",
      "meta_description": "عن المؤسسة",
      "is_hidden": "0",
      "robot_index": "index",
      "robot_follow": "follow",
      "components": {
        "viewBag": {
          "localeUrl": {
            "ar": "\/abouts\/",
            "en": "\/abouts\/"
          },
          "styleItem": "3",
          "localeTitle": {
            "en": "home"
          }
        },
        "tssProjectRecords tssCount": {
          "activeOnly": "1",
          "mainCssClass": "col-12 col-sm-12 col-md-12 bg-white",
          "areaSlug": "count",
          "is_title": "1",
          "title": "title_count",
          "categorySlug": "{{ :category }}",
          "tagSlug": "{{ :tag }}",
          "recordPage": "projects\/posts-project",
          "recordPageSlug": "{{ :slug }}",
          "recordKeyColumn": "slug",
          "limit": "10",
          "pageSlug": "{{ :page }}",
          "orderBy": "sort_order",
          "orderByDirection": "ASC",
          "content": "default",
          "itemStyle": "count",
          "itemClass": "col-6 col-sm-3"
        },
        "tssProjectRecords tssAssociates": {
          "activeOnly": "1",
          "mainCssClass": "col-12 col-sm-12 col-md-12 bg-white",
          "areaSlug": "associate",
          "is_title": "1",
          "title": "title_associates",
          "notLink": "1",
          "categorySlug": "{{ :category }}",
          "tagSlug": "{{ :tag }}",
          "recordPage": "projects\/posts-project",
          "recordPageSlug": "{{ :slug }}",
          "recordKeyColumn": "slug",
          "allowLimit": "1",
          "limit": "10",
          "pageSlug": "{{ :page }}",
          "orderBy": "sort_order",
          "orderByDirection": "ASC",
          "content": "swiper-associates",
          "itemStyle": "associates",
          "itemClass": "col-6 col-sm-3"
        },
        "contactForm": {
          "form_description": "contactForm",
          "ga_success_event_allow": "0"
        }
      }
    },
    "code": "use Tss\\Webbasic\\Models\\PostsAqer;\n    use Tss\\Webbasic\\Models\\PostsFeature;\n    use Tss\\Webbasic\\Models\\Categorie;\n    use RainLab\\Location\\Models\\Country;\n    use RainLab\\Location\\Models\\State;\n    use Tss\\Booking\\Models\\Assortment;\n    use Tss\\Basic\\Models\\Employee;\n        function onStart()\n        {\n        \/\/$this->prepareAssortment();\n        $this->prepareEmployee();\n        $this->preparePostsFeature();\n        $this->prepareCatProject();\n\n       \/\/ $this->prepareCategories();\n      \/\/  $this->prepareVars();\n        \/\/$this['Categories']=Categorie::isFront('aqer')->where('slug',$this->param('slug'));\n        \/\/trace_log($this['Categories']);\n\n        \/\/$this->controller->pageUrl('pagename',['slug'=>'id']);\n        }\n\n        function onFilterAqers() {\n            $this->prepareVars();\n        }\n\n\n        function prepareVars() {\n            $options = post('Filter', []);\n            $options['q']=post('q','');\n            $options['page']=post('mor',0)?($options['page']+1):1;\n\n           \/\/ trace_log($options);\n            $this['aqers'] = PostsAqer::IsFrontPost('aqer')\n    ->listFrontEnd($options);\n    \/\/->get();\n            \/\/$this['genres'] = Genre::all();\n            $this['sortOptions'] = PostsAqer::$allowedSortingOptions;\n\n            $this['pages'] = $this['aqers']->lastPage();\n            $this['page'] = $this['aqers']->currentPage();\n\n            $this['records'] = $this['aqers'];\n            $this['displayColumn'] = \"name\";\n            $this['noRecordsMessage'] = \"لا تتوفر عقارات حاليا \";\n            $this['detailsPage'] =  \"aqers\/posts-aqer\";\n            $this['detailsKeyColumn'] = \"slug\";\n            $this['detailsUrlParameter'] = \"slug\";\n\n        }\n\n        function prepareCategories() {\n                $this['Categories']=Categorie::isFront('aqer')->get();\n        }\n\n\n        function prepareAssortment() {\n\n            $Assortments= null;\n\n            $options = post('Filter', []);\n            $options['q']=post('q','');\n            $options['page']=post('mor',0)?($options['page']+1):1;\n            $this['sortOptions'] = Assortment::$allowedSortingOptions;\n\n\n            $Assortments=Assortment::isFront('aqer')\n                                    ->listFrontEnd($options);\n                \/\/->get();\n\n            $this['Assortments'] = $Assortments;\n            $this['assortmentsPage'] =  \"assortments\/assortmentdetails\";\n            $this['assortmentsKeyColumn'] = \"slug\";\n            $this['assortmentsUrlParameter'] = \"slug\";\n        }\n        function prepareCatProject() {\n\n            $CatProjects= null;\n            $options = post('Filter', []);\n            $options['q']=post('q','');\n            $options['page']=post('mor',0)?($options['page']+1):1;\n            \/\/$this['sortOptions'] = Assortment::$allowedSortingOptions;\n            $CatProjects=Categorie::isFrontProject('project')\n                        \/\/->isPublished()\n                        ->get();\n            $this['CatProjects'] = $CatProjects;\n            $this['catprojectsPage'] =  \"projects\/projectdetails\";\n            $this['catprojectsKeyColumn'] = \"slug\";\n            $this['catprojectsUrlParameter'] = \"slug\";\n        }\n        function prepareEmployee() {\n\n            $Employees= null;\n\n            $options = post('Filter', []);\n            $options['q']=post('q','');\n            $options['page']=post('mor',0)?($options['page']+1):1;\n            $this['sortOptions'] = Employee::$allowedSortingOptions;\n\n\n            $Employees=Employee::isFront('aqer')\n                                    ->listFrontEnd($options);\n                \/\/->get();\n\n            $this['Employees'] = $Employees;\n            $this['employeesPage'] =  \"teams\/posts-team\";\n            $this['employeesKeyColumn'] = \"id\";\n            $this['employeesUrlParameter'] = \"id\";\n        }\n        function preparePostsFeature() {\n\n            $PostsFeatures= null;\n\n            $options = post('Filter', []);\n            $options['q']=post('q','');\n            $options['page']=post('mor',0)?($options['page']+1):1;\n            $this['sortOptions'] = PostsFeature::$allowedSortingOptions;\n\n\n            $PostsFeatures=PostsFeature::isFrontPost('feature')\n                                    ->listFrontEnd($options);\n                \/\/->get();\n\n            $this['PostsFeatures'] = $PostsFeatures;\n            $this['postsFeaturesPage'] =  \"features\/posts-feature\";\n            $this['postsFeaturesKeyColumn'] = \"slug\";\n            $this['postsFeaturesUrlParameter'] = \"slug\";\n        }"
  }
}
```

**فى حالة تمرير اسم صفحة غير موجوده سيتم ارجاع الخطاء التالي**

```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "الصفحة \"name:\" ليست موجودة"
  }
}
```


### Render Cms Pages 

**ارجاع محتوي الصفحة القابل للعرض على الويب اي بشكل مرندر **

```
GET /api/v1/cms/cms-pages/render
```

Required Parameters: `name`

**يجيب تمرير اسم الصفحة المراد ارجاع محتوها ضمن المتغير name**

#### Example 3 Render Cms Pages name=abort

```
GET http://localhost:8006/api/v1/cms/cms-pages/render?name=abort
```

#### Response

```html
Status: 200 Ok
```

```json
{
    "data": "<!doctype html>
<html lang=\"ar\" class=\"no-focus\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, shrink-to-fit=no\">
    
                                    
    <title>Abort - \u0646\u0627\u0646\u0648 2 \u0633\u0648\u0641\u062a \u0644\u0644\u0628\u0631\u0645\u062c\u064a\u0627\u062a \u0648\u062a\u0642\u0646\u064a\u0629 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a<\/title>

    <meta name=\"title\" content=\"Abort\">

    <meta name=\"description\" content=\"Abort\">

    <meta name=\"keywords\" content=\"\u0646\u0627\u0646\u0648 \u0633\u0648\u0641\u062a , \u0628\u0631\u0645\u062c\u064a\u0627\u062a , \u0627\u0646\u0638\u0645\u0629 , \u0634\u0631\u0643\u0629 , \u062a\u0635\u0645\u064a\u0645 , \u0645\u0648\u0627\u0642\u0639\">

    <meta name=\"author\" content=\"Nano 2 Soft  Eng\/ Dheia Ali Al-Shami  00967770529482\">

    <link rel=\"canonical\" href=\"http:\/\/localhost:8006\" \/>
    <link rel=\"canonical\" href=\"http:\/\/localhost:8006\" \/>


    <meta name=\"robots\" content=\"index\">
    <meta name=\"robots\" content=\"follow\">


        
        
    

    <!-- Icons |resize(32,32)  media -->
    <!-- The following icons can be replaced with your own, they are used by desktop and mobile browsers -->
    <link rel=\"shortcut icon\" href=\"http:\/\/localhost:8006\/storage\/app\/uploads\/public\/639\/cc1\/9de\/639cc19de67d4476963946.png\">
    <link rel=\"icon\" type=\"image\/png\" sizes=\"192x192\" href=\"http:\/\/localhost:8006\/storage\/app\/uploads\/public\/639\/cc1\/9de\/639cc19de67d4476963946.png\">
    <link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"http:\/\/localhost:8006\/storage\/app\/uploads\/public\/639\/cc1\/9de\/639cc19de67d4476963946.png\">
    <!-- END Icons -->


     <!--Open Graph Meta-->
    <meta property=\"og:title\" content=\"Abort - \u0646\u0627\u0646\u0648 2 \u0633\u0648\u0641\u062a \u0644\u0644\u0628\u0631\u0645\u062c\u064a\u0627\u062a \u0648\u062a\u0642\u0646\u064a\u0629 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a\">
    <meta property=\"og:site_name\" content=\"\u0646\u0627\u0646\u0648 \u0633\u0648\u0641\u062a\">
    <meta property=\"og:description\" content=\"Abort\">
    <meta property=\"og:type\" content=\"website\">
    <meta property=\"og:url\" content=\"
http:\/\/localhost:8006\/api\/v1\/cms\/cms-pages\/render\">
    <meta property=\"og:image\" content=\"http:\/\/localhost:8006\/storage\/app\/uploads\/public\/639\/cc1\/9de\/639cc19de67d4476963946.png\">


    <!-- Stylesheets -->
    <!-- Fonts and Codebase framework -->
    <link rel=\"stylesheet\" href=\"https:\/\/fonts.googleapis.com\/css?family=Muli:300,400,400i,600,700\">

    <link rel=\"stylesheet\" id=\"css-main\" href=\" http:\/\/localhost:8006\/combine\/37c9b13dc30065947e3b7d7efbf47306-1657553506\">

    <link rel=\"stylesheet\" href=\"https:\/\/maxcdn.bootstrapcdn.com\/font-awesome\/4.7.0\/css\/font-awesome.min.css\" \/>
<link rel=\"stylesheet\" href=\"http:\/\/localhost:8006\/plugins\/martin\/ssbuttons\/assets\/css\/social-sharing-nb.css\" \/>
<link rel=\"stylesheet\" href=\"http:\/\/localhost:8006\/plugins\/tss\/scrolltop\/assets\/css\/default.css\" \/>
<link rel=\"stylesheet\" href=\"http:\/\/localhost:8006\/plugins\/tss\/scrolltop\/assets\/css\/scroll_top_lnx.css\" \/>
    <!--  'assets\/_scss\/main2.scss'
    'assets\/_scss\/codebase\/themes\/default.scss'
    -->


    
    <!---->

<!-- 'assets\/js\/plugins\/swiper\/dist\/css\/swiper.min.css',
          'assets\/js\/plugins\/swiper\/src\/swiper.scss',
-->

 <link rel=\"stylesheet\" id=\"css-main9\" href=\" http:\/\/localhost:8006\/combine\/198db73da946a7efacc6252651d4378a-1592281128\">
        \t
         <link rel=\"stylesheet\" id=\"css-venobox\" href=\" http:\/\/localhost:8006\/combine\/b8f3327038c6f4eea0359913b9c09695-1641445772\">
        \t
    <link rel=\"stylesheet\" id=\"css-main2\" href=\" http:\/\/localhost:8006\/combine\/f39d97a7070ac376cdf0bcb840c18612-1629296830\">

    

        <!-- You can include a specific file from css\/themes\/ folder to alter the default color theme of the template. eg: -->
    <!-- <link rel=\"stylesheet\" id=\"css-theme\" href=\"assets\/css\/themes\/flat.min.css\"> -->

    <!--
        Basic RTL CSS Overwrites (Please consider moving it in an external CSS file - it is added inline just for demostration)

        The UI elements will play nice with RTL in most cases. This file is provided as a get started point for RTL projects,
        so please have in mind that a few elements might require some further CSS adjustments.

        Moreover, .float-left\/.float-right and .text-left\/.text-right classes will come in handy
    -->
            <style>
            \/* Set Text Direction to RTL *\/
            html {
                direction: rtl;
            }

            body {
                text-align: right;
            }
            \/*
            .lg-css3.lg-slide.lg-use-css3 .lg-item.lg-current {
                -webkit-transform: translate3d(0,0,0);
                transform: translate3d(0,0,0);
                opacity: 1;
            }.lg-css3.lg-slide.lg-use-css3 .lg-item {
                 opacity: 1 !important;
             }
    *\/
            \/* Sidebar Mini *\/
            @media (min-width: 992px) {
                .sidebar-o.sidebar-mini #sidebar .sidebar-content {
                    -webkit-transform: translateX(0) translateY(0) translateZ(0);
                    transform: translateX(0) translateY(0) translateZ(0);
                }

                .sidebar-r.sidebar-o.sidebar-mini #sidebar .sidebar-content {
                    -webkit-transform: translateX(-166px) translateY(0) translateZ(0);
                    transform: translateX(-166px) translateY(0) translateZ(0);
                }

                .sidebar-r.sidebar-o.sidebar-mini #sidebar:hover .sidebar-content {
                    -webkit-transform: translateX(0) translateY(0) translateZ(0);
                    transform: translateX(0) translateY(0) translateZ(0);
                }
            }

            \/* Main Sidebar Navigation *\/
            .nav-main a {
                padding-right: 40px;
                padding-left: 18px;
            }

            .nav-main a > i {
                right: 19px;
                left: auto;
            }

            .nav-main a.nav-submenu {
                padding-right: 40px;
                padding-left: 35px;
            }

            .nav-main a.nav-submenu::before, .nav-main a.nav-submenu::after {
                right: auto;
                left: 15px;
            }

            .nav-main a.nav-submenu::before {
                content: '\\f105';
            }

            .nav-main a.nav-submenu::after {
                -webkit-transform: rotate(-90deg);
                -o-transform: rotate(-90deg);
                transform: rotate(-90deg);
            }

            .nav-main ul {
                padding-right: 40px;
                padding-left: 0;
            }

            .nav-main ul a,
            .nav-main ul a.nav-submenu {
                padding-right: 0;
                padding-left: 8px;
            }

            .nav-main ul a > i {
                margin-right: 0;
                margin-left: 15px;
            }

            .nav-main ul ul {
                padding-right: 12px;
            }

            \/* Main Header Navigation *\/
            @media (min-width: 992px) {
                .nav-main-header a > i {
                    margin-right: 0;
                    margin-left: 8px;
                }

                .nav-main-header a.nav-submenu {
                    padding-right: 14px;
                    padding-left: 28px;
                }

                .nav-main-header a.nav-submenu::before {
                    right: auto;
                    left: 6px;
                }

                .nav-main-header ul {
                    right: 0;
                    left: auto;
                }

                .nav-main-header ul a.nav-submenu::before {
                    content: '\\f104';
                }

                .nav-main-header ul ul {
                    right: 100%;
                    left: auto;
                }

                .nav-main-header > li:last-child ul {
                    right: auto;
                    left: 0;
                }

                .nav-main-header > li:last-child ul a.nav-submenu::before {
                    content: '\\f105';
                }

                .nav-main-header > li:last-child ul ul {
                    right: auto;
                    left: 100%;
                }
            }

            #gallery li {
                display: block;
                float: right;
                height: 70px;
                margin-bottom: 6px;
                margin-right: 6px;
                width: 100px;
            }


            #sno-id {
                position: fixed;
                top: 0;
                right: 0;
                bottom: 0;
                z-index: 99999;
                width: 100%;

                \/* background-color: #eeeeee;*\/

            }

            .side-overlay2 {
                position: fixed;
                top: 0;
                right: 0;
                bottom: 0;
                z-index: 999999;
                width: 100%;
                \/*background-color: #eeeeee;*\/
                overflow-x: auto;
                overflow-y: auto;
                height: 100%;
                margin: 0px;
                \/*display: none;*\/
                \/* background-color: $side-overlay-bg;
            *\/
                \/* overflow-y: auto;
                 transform: translateX(100%) translateY(0) translateZ(0);
                 -webkit-overflow-scrolling: touch;
                 will-change: transform;
             *\/

            }
            #content-btn-mobile-id{
                position: fixed;
                bottom: 0;
                right: 0;
                z-index: 99999;
                width: 100%;
                background-color: #eeeeee;

            }
            .mode-hidden{
                display: block !important;
            }
        <\/style>
        <!-- END Stylesheets -->
    


    <style>
        html, body {
            font-size: 14px;
        }

        a.block:hover {

            text-decoration: none;
        }
        a:hover, a:focus {
            text-decoration: none !important;
        }

        \/* \u062e\u0627\u0635\u0629 \u0628\u0627\u0644\u0635\u0648\u0631*\/
        #gallery {
            padding-left: 0;
            padding-right: 0;
        }
        #gallery li {
            display: contents;
            float: initial;
            height: 70px;
            margin-bottom: 6px;
            margin-right: 6px;
            width: 100px;
        }
        #lightGallery-outer {
            margin: auto;
            left: 1px !important;
            right: 1px !important;
            background: #0d0d0d;
        }
    <\/style>
<\/head>



    
    

<body>

    <!-- Page loader (functionality is initialized in Template._uiHandlePageLoader()) -->
        <!-- If #page-loader markup and also the \"show\" class is added, the loading screen will be enabled and auto hide once the page loads -->
        <!-- Default background color is the primary color but you can use a bg-* class for a custom bg color -->
        <div id=\"page-loader\" class=\"show \" >
<!--
<i class=\"fa fa-4x fa-sun-o fa-spin text-warning\"><\/i>

                             <i class=\"fa fa-4x fa-hourglass-half fa-spin text-success\"><\/i>
                               <!--
     <i class=\"fa fa-4x fa-cog fa-spin text-success\"><\/i>
                                    <i class=\"fa fa-4x fa-asterisk fa-spin text-info\"><\/i>
                                    -->      
            
                    <!-- END Loading Icons -->
        <\/div>
        
      <!-- END Page Loading  -->





    <!-- Page Container -->
    <!--
        Available classes for #page-container:

    GENERIC

        'enable-cookies'                            Remembers active color theme between pages (when set through color theme helper Codebase() -> uiHandleTheme())

    SIDEBAR & SIDE OVERLAY

        'sidebar-r'                                 Right Sidebar and left Side Overlay (default is left Sidebar and right Side Overlay)
        'sidebar-mini'                              Mini hoverable Sidebar (screen width > 991px)
        'sidebar-o'                                 Visible Sidebar by default (screen width > 991px)
        'sidebar-o-xs'                              Visible Sidebar by default (screen width < 992px)
        'sidebar-inverse'                           Dark themed sidebar

        'side-overlay-hover'                        Hoverable Side Overlay (screen width > 991px)
        'side-overlay-o'                            Visible Side Overlay by default

        'enable-page-overlay'                       Enables a visible clickable Page Overlay (closes Side Overlay on click) when Side Overlay opens

        'side-scroll'                               Enables custom scrolling on Sidebar and Side Overlay instead of native scrolling (screen width > 991px)

    HEADER

        ''                                          Static Header if no class is added
        'page-header-fixed'                         Fixed Header

    HEADER STYLE

        ''                                          Classic Header style if no class is added
        'page-header-modern'                        Modern Header style
        'page-header-inverse'                       Dark themed Header (works only with classic Header style)
        'page-header-glass'                         Light themed Header with transparency by default
                                                    (absolute position, perfect for light images underneath - solid light background on scroll if the Header is also set as fixed)
        'page-header-glass page-header-inverse'     Dark themed Header with transparency by default
                                                    (absolute position, perfect for dark images underneath - solid dark background on scroll if the Header is also set as fixed)

    MAIN CONTENT LAYOUT

        ''                                          Full width Main Content if no class is added
        'main-content-boxed'                        Full width Main Content with a specific maximum width (screen width > 1200px)
        'main-content-narrow'                       Full width Main Content with a percentage width (screen width > 1200px)
    -->
    <div id=\"page-container\" class=\"sidebar-r sidebar-inverse side-scroll


             page-header-fixed
      
     
     
      enable-page-overlay\">
        <!-- Sidebar -->
        <nav id=\"sidebar\">
    <!-- Sidebar Content -->
    <div class=\"sidebar-content\">
        <!-- Side Header -->
        <div class=\"content-header content-header-fullrow bg-black-op-10\">
            <div class=\"content-header-section text-center align-parent\">
                <!-- Close Sidebar, Visible only on mobile screens -->
                <!-- Layout API, functionality initialized in Codebase() -> uiApiLayout() -->
                <button type=\"button\" class=\"btn btn-circle btn-dual-secondary d-lg-none align-v-l\"
                        data-toggle=\"layout\" data-action=\"sidebar_close\">
                    <i class=\"fa fa-times text-danger\"><\/i>
                <\/button>
                <!-- END Close Sidebar -->

                <!-- Logo -->
                <div class=\"content-header-item\">
                    <a class=\"link-effect font-w700\" href=\"http:\/\/localhost:8006\">
                        <!--<i class=\"si si-fire text-primary\"><\/i>-->
                        <!--<span class=\"font-size-xl text-dual-primary-dark\">\u0646\u0627\u0646\u0648 \u0633\u0648\u0641\u062a<\/span>-->
                        <span class=\"font-size-xl text-primary\">
                            \u0646\u0627\u0646\u0648 \u0633\u0648\u0641\u062a
                                                    <\/span>
                    <\/a>
                <\/div>
                <!-- END Logo -->
            <\/div>
        <\/div>
        <!-- END Side Header -->

        <!-- Side Main Navigation -->
        <div class=\"content-side content-side-full\">
            <!--
            Mobile navigation, desktop navigation can be found in #page-header

            If you would like to use the same navigation in both mobiles and desktops, you can use exactly the same markup inside sidebar and header navigation ul lists
            -->
          
            <ul class=\"nav-main\">
            <!--
<ul class=\"nav-main\">
    <li>
        <a class=\"active\" href=\"\">
            <i class=\"si si-home\"><\/i>Home
        <\/a>
    <\/li>
    <li class=\"nav-main-heading\">Heading<\/li>
    <li>
        <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">
            <i class=\"si si-puzzle\"><\/i>Dropdown
        <\/a>
        <ul>
            <li>
                <a href=\"javascript:void(0)\">Link #1<\/a>
            <\/li>
            <li>
                <a href=\"javascript:void(0)\">Link #2<\/a>
            <\/li>
            <li>
                <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">Dropdown<\/a>
                <ul>
                    <li>
                        <a href=\"javascript:void(0)\">Link #1<\/a>
                    <\/li>
                    <li>
                        <a href=\"javascript:void(0)\">Link #2<\/a>
                    <\/li>
                <\/ul>
            <\/li>
        <\/ul>
    <\/li>
    <li class=\"nav-main-heading\">Vital<\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
<\/ul>
-->

            

    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/feature\"
            
            class=\"
            
            
            \">

                               \u0645\u0645\u064a\u0632\u0627\u062a\u0646\u0627
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/assortment\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0627\u0642\u0633\u0627\u0645
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/team\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0637\u0627\u0642\u0645
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/post\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0627\u062e\u0628\u0627\u0631
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/album\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0635\u0648\u0631
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/videos\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0641\u064a\u062f\u064a\u0648\u0647\u0627\u062a
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/staff\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u062a\u0648\u0636\u064a\u0641
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/contact\"
            
            class=\"
            
            
            \">

                               \u0644\u0644\u062a\u0648\u0627\u0635\u0644
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/bookings\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u062d\u062c\u0632 \u0627\u0644\u0627\u0644\u0643\u062a\u0631\u0648\u0646\u064a
            <\/a>

                    
    <\/li>

<!--<li class=\"nav-main-heading\">-->
    <!--<span class=\"sidebar-mini-visible\">PG<\/span>-->
    <!--<span class=\"sidebar-mini-hidden\">Pages<\/span>-->
<!--<\/li>-->
<!--<li>-->
    <!--<a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">-->
        <!--<i class=\"si si-puzzle\"><\/i>Dropdown-->
    <!--<\/a>-->
    <!--<ul>-->
        <!--<li>-->
            <!--<a href=\"javascript:void(0)\">Link #1<\/a>-->
        <!--<\/li>-->
        <!--<li>-->
            <!--<a href=\"javascript:void(0)\">Link #2<\/a>-->
        <!--<\/li>-->
        <!--<li>-->
            <!--<a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">Dropdown<\/a>-->
            <!--<ul>-->
                <!--<li>-->
                    <!--<a href=\"javascript:void(0)\">Link #1<\/a>-->
                <!--<\/li>-->
                <!--<li>-->
                    <!--<a href=\"javascript:void(0)\">Link #2<\/a>-->
                <!--<\/li>-->
            <!--<\/ul>-->
        <!--<\/li>-->
    <!--<\/ul>-->
<!--<\/li>-->            <\/ul>
        <\/div>
        <!-- END Side Main Navigation -->
    <\/div>
    <!-- Sidebar Content -->
<\/nav>        <!-- END Sidebar -->

        <!-- Header -->
        <header id=\"page-header\">
    <!-- Header Content -->
    <div class=\"content-header align-items-start  justify-content-around2 justify-content-between22 justify-content-md-center2\">
        <!-- Right Section -->
        <div class=\"content-header-section d-flex2  \">
            <!-- Logo -->
            <div class=\"content-header-item pt-0\">
                <a class=\"link-effect2 \" href=\"\">
                                        
                                                            <img class=\"log_img img-avatar img-responsive img-circle22 animated swing infinite5\" src=\"http:\/\/localhost:8006\/storage\/app\/uploads\/public\/639\/cbe\/d98\/639cbed986468081928893.png\">
                <\/a>
                <a class=\"link-effect font-w700 font-size-xl font-size-default2  log_name d-none2 d-sm-inline-block2  d-md-block2  ml-2 mb-4 pt-0 mt-0\"
                   href=\"http:\/\/localhost:8006\"
                >
                    <!--<i class=\"si si-fire text-primary\"><\/i>-->
                                        
                    <span class=\"font-size-xl2 text-dual-primary-dark text-btn-header\">
                        \u0646\u0627\u0646\u0648<\/span>
                    <!--<span class=\"font-size-xl text-primary\">\u0646\u0627\u0646\u0648 \u0633\u0648\u0641\u062a<\/span>-->
                    <span class=\"font-size-xl2 text-primary2 text-btn-header\">
                                                            \u0633\u0648\u0641\u062a
                            
                    <\/span>
                <\/a>
    
                 
            <\/div>
            <!-- END Logo -->
        <\/div>
        <!-- END Right Section -->

        <!-- Left Section -->
        <div class=\"content-header-section  mx-auto2 mx-md-auto   \">
            <!-- Header Navigation -->
            <!--
            Desktop Navigation, mobile navigation can be found in #sidebar

            If you would like to use the same navigation in both mobiles and desktops, you can use exactly the same markup inside sidebar and header navigation ul lists
            If your sidebar menu includes headings, they won't be visible in your header navigation by default
            If your sidebar menu includes icons and you would like to hide them, you can add the class 'nav-main-header-no-icons'
            -->
            <!--<ul class=\"nav-main-header nav-main-header-no-icons\">
                <li>
                    <a class=\"active\" href=\"\">
                        <i class=\"si si-home\"><\/i>Home
                    <\/a>
                <\/li>
                <li class=\"nav-main-heading\">Heading<\/li>
                <li>
                    <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">
                        <i class=\"si si-puzzle\"><\/i>Dropdown
                    <\/a>
                    <ul>
                        <li>
                            <a href=\"javascript:void(0)\">Link #1<\/a>
                        <\/li>
                        <li>
                            <a href=\"javascript:void(0)\">Link #2<\/a>
                        <\/li>
                        <li>
                            <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">Dropdown<\/a>
                            <ul>
                                <li>
                                    <a href=\"javascript:void(0)\">Link #1<\/a>
                                <\/li>
                                <li>
                                    <a href=\"javascript:void(0)\">Link #2<\/a>
                                <\/li>
                            <\/ul>
                        <\/li>
                    <\/ul>
                <\/li>
                <li class=\"nav-main-heading\">Vital<\/li>
                <li>
                    <a href=\"javascript:void(0)\">
                        <i class=\"si si-wrench\"><\/i>Page
                    <\/a>
                <\/li>
                <li>
                    <a href=\"javascript:void(0)\">
                        <i class=\"si si-wrench\"><\/i>Page
                    <\/a>
                <\/li>
                <li>
                    <a href=\"javascript:void(0)\">
                        <i class=\"si si-wrench\"><\/i>Page
                    <\/a>
                <\/li>
            <\/ul>-->
            <ul class=\"nav-main-header  nav-main-header-no-icons2 d-none2\">
            <!--
<ul class=\"nav-main\">
    <li>
        <a class=\"active\" href=\"\">
            <i class=\"si si-home\"><\/i>Home
        <\/a>
    <\/li>
    <li class=\"nav-main-heading\">Heading<\/li>
    <li>
        <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">
            <i class=\"si si-puzzle\"><\/i>Dropdown
        <\/a>
        <ul>
            <li>
                <a href=\"javascript:void(0)\">Link #1<\/a>
            <\/li>
            <li>
                <a href=\"javascript:void(0)\">Link #2<\/a>
            <\/li>
            <li>
                <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">Dropdown<\/a>
                <ul>
                    <li>
                        <a href=\"javascript:void(0)\">Link #1<\/a>
                    <\/li>
                    <li>
                        <a href=\"javascript:void(0)\">Link #2<\/a>
                    <\/li>
                <\/ul>
            <\/li>
        <\/ul>
    <\/li>
    <li class=\"nav-main-heading\">Vital<\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
<\/ul>
-->

            

    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/feature\"
            
            class=\"
            
            
            \">

                               \u0645\u0645\u064a\u0632\u0627\u062a\u0646\u0627
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/assortment\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0627\u0642\u0633\u0627\u0645
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/team\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0637\u0627\u0642\u0645
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/post\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0627\u062e\u0628\u0627\u0631
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/album\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0635\u0648\u0631
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/videos\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u0641\u064a\u062f\u064a\u0648\u0647\u0627\u062a
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/staff\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u062a\u0648\u0636\u064a\u0641
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/contact\"
            
            class=\"
            
            
            \">

                               \u0644\u0644\u062a\u0648\u0627\u0635\u0644
            <\/a>

                    
    <\/li>



    <li class=\"\">
                    
            <a 
               href=\"http:\/\/localhost:8006\/bookings\"
            
            class=\"
            
            
            \">

                               \u0627\u0644\u062d\u062c\u0632 \u0627\u0644\u0627\u0644\u0643\u062a\u0631\u0648\u0646\u064a
            <\/a>

                    
    <\/li>

<!--<li class=\"nav-main-heading\">-->
    <!--<span class=\"sidebar-mini-visible\">PG<\/span>-->
    <!--<span class=\"sidebar-mini-hidden\">Pages<\/span>-->
<!--<\/li>-->
<!--<li>-->
    <!--<a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">-->
        <!--<i class=\"si si-puzzle\"><\/i>Dropdown-->
    <!--<\/a>-->
    <!--<ul>-->
        <!--<li>-->
            <!--<a href=\"javascript:void(0)\">Link #1<\/a>-->
        <!--<\/li>-->
        <!--<li>-->
            <!--<a href=\"javascript:void(0)\">Link #2<\/a>-->
        <!--<\/li>-->
        <!--<li>-->
            <!--<a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">Dropdown<\/a>-->
            <!--<ul>-->
                <!--<li>-->
                    <!--<a href=\"javascript:void(0)\">Link #1<\/a>-->
                <!--<\/li>-->
                <!--<li>-->
                    <!--<a href=\"javascript:void(0)\">Link #2<\/a>-->
                <!--<\/li>-->
            <!--<\/ul>-->
        <!--<\/li>-->
    <!--<\/ul>-->
<!--<\/li>-->
            <\/ul>
<!--
            <ul class=\"nav-main-header  nav-main-header-no-icons2  mx-auto\">

                <li>
                       <div class=\"d-none2 d-sm-none2 input-group mx-auto\">
   <form method=\"POST\" action=\"http:\/\/localhost:8006\/api\/v1\/cms\/cms-pages\/render\" accept-charset=\"UTF-8\"><input name=\"_session_key\" type=\"hidden\" value=\"vEtwYAtFDY6fxmkd3B7FTrUsjEFBW9RsQMixr9Sq\"><input name=\"_token\" type=\"hidden\">
    <select name=\"locale\" data-request=\"onSwitchLocale\" class=\"form-control form-control-sm  mx-0 px-0\">
                    <option value=\"en\" >English<\/option>
                    <option value=\"ar\" selected>Arabic<\/option>
            <\/select>
<\/form>                     <\/div>
                <\/li>
            <\/ul>
-->
            <!-- END Header Navigation -->
          


            <!-- User Dropdown -->

            <!-- Color Themes (used just for demonstration) -->
            <!-- Themes functionality initialized in Codebase() -> uiHandleTheme() -->
      <!--     <div class=\"btn-group mr-5\" role=\"group\">
                <button type=\"button\" class=\"btn btn-circle btn-dual-secondary\" id=\"page-header-themes-dropdown\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                    <i class=\"fa fa-paint-brush\"><\/i>
                <\/button>
                <div class=\"dropdown-menu min-width-150\" aria-labelledby=\"page-header-themes-dropdown\">
                    <h6 class=\"dropdown-header text-center\">Color Themes<\/h6>
                    <div class=\"row no-gutters text-center\">
                        <div class=\"col-4 mb-5\">
                            <a class=\"text-default\" data-toggle=\"theme\" data-theme=\"default\" href=\"javascript:void(0)\">
                                <i class=\"fa fa-2x fa-circle\"><\/i>
                            <\/a>
                        <\/div>
                        <div class=\"col-4 mb-5\">
                            <a class=\"text-elegance\" data-toggle=\"theme\" data-theme=\"assets\/css\/themes\/elegance.min.css\" href=\"javascript:void(0)\">
                                <i class=\"fa fa-2x fa-circle\"><\/i>
                            <\/a>
                        <\/div>
                        <div class=\"col-4 mb-5\">
                            <a class=\"text-pulse\" data-toggle=\"theme\" data-theme=\"assets\/css\/themes\/pulse.min.css\" href=\"javascript:void(0)\">
                                <i class=\"fa fa-2x fa-circle\"><\/i>
                            <\/a>
                        <\/div>
                        <div class=\"col-4 mb-5\">
                            <a class=\"text-flat\" data-toggle=\"theme\" data-theme=\"assets\/css\/themes\/flat.min.css\" href=\"javascript:void(0)\">
                                <i class=\"fa fa-2x fa-circle\"><\/i>
                            <\/a>
                        <\/div>
                        <div class=\"col-4 mb-5\">
                            <a class=\"text-corporate\" data-toggle=\"theme\" data-theme=\"assets\/css\/themes\/corporate.min.css\" href=\"javascript:void(0)\">
                                <i class=\"fa fa-2x fa-circle\"><\/i>
                            <\/a>
                        <\/div>
                        <div class=\"col-4 mb-5\">
                            <a class=\"text-earth\" data-toggle=\"theme\" data-theme=\"assets\/css\/themes\/earth.min.css\" href=\"javascript:void(0)\">
                                <i class=\"fa fa-2x fa-circle\"><\/i>
                            <\/a>
                        <\/div>
                    <\/div>
                <\/div>
            <\/div> -->
            <!-- END Color Themes -->
        
    
            <!-- Toggle Sidebar -->
            <!-- Layout API, functionality initialized in Codebase() -> uiApiLayout() -->
            <button type=\"button\" class=\"btn btn-circle btn-dual-secondary d-lg-none\"
                    data-toggle=\"layout\" data-action=\"sidebar_toggle\">
                <i class=\"fa fa-navicon\"><\/i>
            <\/button>
            <!-- END Toggle Sidebar -->
        <\/div>
        <!-- END Left Section -->
    <\/div>
    <!-- END Header Content -->

    
    <!-- Header Loader -->
    <div id=\"page-header-loader\" class=\"overlay-header bg-primary\">
        <div class=\"content-header content-header-fullrow text-center\">
            <div class=\"content-header-item\">
                <i class=\"fa fa-sun-o fa-spin text-white\"><\/i>
            <\/div>
        <\/div>
    <\/div>
    <!-- END Header Loader -->
<\/header>        <!-- END Header -->

        <!-- Main Container -->
        <main id=\"main-container\" class=\"content2  content-full2 main-content-narrow2\">
            <!--<div  class=\"content content-full\">-->
            <!-- Hero -->
                              <!-- Hero -->
<!--
<div class=\"bg-primary overflow-hidden\">
    <div class=\"hero bg-black-op-25\">
        <div class=\"hero-inner\">
            <div class=\"content content-full text-center\">
                <h1 class=\"display-3 font-w700 text-white mb-10 invisible\" data-toggle=\"appear\" data-class=\"animated fadeInDown\">Hero Title<\/h1>
                <h2 class=\"font-w400 text-white-op mb-50 invisible\" data-toggle=\"appear\" data-class=\"animated fadeInDown\">Hero Subtitle.<\/h2>
                <a class=\"btn btn-hero btn-noborder btn-rounded btn-success ml-5 mb-10 invisible\" data-toggle=\"appear\" data-class=\"animated fadeInUp\" href=\"javascript:void(0)\">
                    <i class=\"fa fa-rocket ml-10\"><\/i> Call to Action
                <\/a>
                <a class=\"btn btn-hero btn-noborder btn-rounded btn-primary mb-10 invisible\" data-toggle=\"appear\" data-class=\"animated fadeInUp\" href=\"javascript:void(0)\">
                    <i class=\"fa fa-rocket ml-10\"><\/i> Call to Action
                <\/a>
            <\/div>
        <\/div>
    <\/div>
<\/div>
-->
 
            
<!-- Hero -->
                <div class=\"bg-image222 bg-hero55 bg-image-bottom22\" style=\"background-image: url('http:\/\/localhost:8006\/storage\/app\/media\/favicon.png');
background-size: 100% 100%;
   background-repeat: no-repeat;
   background-position2: 100% 100% !important; ;
background-attachment: fixed;
-webkit-background-size2: cover;
background-size2: contain !important; 
height: 500px !important;\">
                    <div class=\"d-none bg-black-op hero2 hero-static2 hero-promo2 \" style=\" height: 100% !important;\">
                        <div class=\"content content-top text-center\">
                            <div class=\"py-50\">
                                <h1 class=\"font-w700 text-white mb-10\">
     \u0645\u0631\u062d\u0628\u0627 \u0628\u0643\u0645
    <\/h1>
                                <p class=\"h4 font-w400 text-white-op\">
<span class=\"text-slider-items d-none\">
      \u0646\u062d\u0646 \u0641\u0649 \u062e\u062f\u0645\u0629 \u0627\u0644\u0639\u0644\u0645 \u0648\u0627\u0644\u0645\u062c\u062a\u0645\u0639
<\/span>
<strong class=\"text-slider\"><\/strong>
<\/p>


 <p class=\"pt-3 mt-15 d-none\">
                    <a class=\"btn btn-success btn js-scroll px-4 btn-noborder btn-rounded invisible\" 
href=\"tel:770529482\" role=\"button\" data-toggle=\"appear\" data-class=\"animated fadeInUp\">
       
\u0627\u062a\u0635\u0627\u0644
    <span class=\"comit\"><i class=\"fa fa-phone\"><\/i><\/span>
<\/a>
    

<\/p>  
<!--
          <a class=\"btn btn-hero btn-noborder btn-rounded btn-success ml-5 mb-10 invisible\" data-toggle=\"appear\" data-class=\"animated fadeInUp\" href=\"javascript:void(0)\">
                    <i class=\"fa fa-rocket ml-10\"><\/i> Call to Action
                <\/a>
                <a class=\"btn btn-hero btn-noborder btn-rounded btn-primary mb-10 invisible\" data-toggle=\"appear\" data-class=\"animated fadeInUp\" href=\"javascript:void(0)\">
                    <i class=\"fa fa-rocket ml-10\"><\/i> Call to Action
                <\/a>
-->
                            <\/div>
                        <\/div>
                    <\/div>
                <\/div>
                <!-- END Hero -->
            
            <!-- END Hero -->


            <!-- Page  -->
            <div class=\"content content-full m-md-1\">

                                <div class=\" row\">
                                   <\/div>

                <div class=\"row no-gutters \">
                                      
                   <!-- Content #1 -->
<div class=\"bg-white\">
    <div class=\"content content-full\">
        <div class=\"py-50 text-center\">
            <h3 class=\"font-w700 mb-10\">Title #1<\/h3>
            <h4 class=\"font-w400 text-muted mb-0\">Content..<\/h4>
        <\/div>
    <\/div>
<\/div>
<!-- END Content #1 -->

<!-- Content #2 -->
<div class=\"bg-body-light\">
    <div class=\"content content-full\">
        <div class=\"py-50 text-center\">
            <h3 class=\"font-w700 mb-10\">Title #2<\/h3>
            <h4 class=\"font-w400 text-muted mb-0\">Content..<\/h4>
        <\/div>
    <\/div>
<\/div>
<!-- END Content #2 -->

<!-- Content #3 -->
<div class=\"bg-white\">
    <div class=\"content content-full\">
        <div class=\"py-50 text-center\">
            <h3 class=\"font-w700 mb-10\">Title #3<\/h3>
            <h4 class=\"font-w400 text-muted mb-0\">Content..<\/h4>
        <\/div>
    <\/div>
<\/div>
<!-- END Content #3 -->

<!-- Call to Action -->
<div class=\"bg-body-light\">
    <div class=\"content content-full text-center\">
        <div class=\"py-50\">
            <h3 class=\"font-w700 mb-10\">Title<\/h3>
            <h4 class=\"font-w400 text-muted mb-30\">Subtitle.<\/h4>
            <a class=\"btn btn-hero btn-rounded btn-alt-primary\" href=\"\">Call to Action<\/a>
        <\/div>
    <\/div>
<\/div>
<!-- END Call to Action -->                   
                                     
                <\/div>
                
                 <div class=\" row\">
                                   <\/div>
            <\/div>
            <!-- END Page -->

        <!--<\/div>-->
<!-- AddToAny BEGIN -->
<div class=\"a2a_kit a2a_kit_size_32 a2a_floating_style a2a_vertical_style\" style=\"left:0px; top:150px;\" 

data-a2a-url=\"http:\/\/localhost:8006\/api\/v1\/cms\/cms-pages\/render\" 
data-a2a-title=\"\u0646\u0627\u0646\u0648 \u0633\u0648\u0641\u062a\"

data-a2a-icon-color22=\"lightseagreen\"
>
<a class=\"a2a_dd\" href=\"https:\/\/www.addtoany.com\/share\"><\/a>
<a class=\"a2a_button_facebook\"><\/a>
<a class=\"a2a_button_twitter\"><\/a>
<a class=\"a2a_button_email\"><\/a>
<a class=\"a2a_button_whatsapp\"><\/a>
<a class=\"a2a_button_copy_link\"><\/a>
<a class=\"a2a_button_sms\"><\/a>
<a class=\"a2a_button_telegram\"><\/a>
<a class=\"a2a_button_facebook_messenger\"><\/a>
<\/div>


   

<!-- AddToAny END -->

        <\/main>
        <!-- END Main Container -->

        <!-- Footer -->
        <!-- Footer -->
<footer id=\"page-footer\" class=\"bg-primary text-white opacity-055555 navbar-\">
    <div class=\"content content-full2\">
        <!-- Footer Navigation -->
        <div class=\"row items-push-2x mt-30\">
            <div class=\"col-12  col-md-4 text-center\">

                <ul class=\"nav text-white nav-tabs2 pr-0 nav-pills flex-column flex-sm-row justify-content-center  list2 list-simple-mini2 font-size-ml2 font-w600\">
                    <!--<li>-->
                        <!--<a class=\"link-effect font-w600\" href=\"javascript:void(0)\">Link #1<\/a>-->
                    <!--<\/li>-->
                    <li class=\"nav-item d-md-none my-0 py-0 border-bottom\">
 nano.footer.menu 
<\/li>
                    <!--
<ul class=\"nav-main\">
    <li>
        <a class=\"active\" href=\"\">
            <i class=\"si si-home\"><\/i>Home
        <\/a>
    <\/li>
    <li class=\"nav-main-heading\">Heading<\/li>
    <li>
        <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">
            <i class=\"si si-puzzle\"><\/i>Dropdown
        <\/a>
        <ul>
            <li>
                <a href=\"javascript:void(0)\">Link #1<\/a>
            <\/li>
            <li>
                <a href=\"javascript:void(0)\">Link #2<\/a>
            <\/li>
            <li>
                <a class=\"nav-submenu\" data-toggle=\"nav-submenu\" href=\"#\">Dropdown<\/a>
                <ul>
                    <li>
                        <a href=\"javascript:void(0)\">Link #1<\/a>
                    <\/li>
                    <li>
                        <a href=\"javascript:void(0)\">Link #2<\/a>
                    <\/li>
                <\/ul>
            <\/li>
        <\/ul>
    <\/li>
    <li class=\"nav-main-heading\">Vital<\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
    <li>
        <a href=\"javascript:void(0)\">
            <i class=\"si si-wrench\"><\/i>Page
        <\/a>
    <\/li>
<\/ul>
-->

            

<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/feature\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0645\u0645\u064a\u0632\u0627\u062a\u0646\u0627
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/assortment\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u0627\u0642\u0633\u0627\u0645
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/team\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u0637\u0627\u0642\u0645
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/post\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u0627\u062e\u0628\u0627\u0631
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/album\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u0635\u0648\u0631
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/videos\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u0641\u064a\u062f\u064a\u0648\u0647\u0627\u062a
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/staff\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u062a\u0648\u0636\u064a\u0641
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/contact\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0644\u0644\u062a\u0648\u0627\u0635\u0644
    <\/a>

    
<\/li>



<li class=\"nav-item 
\">
    
    <a 
    href=\"http:\/\/localhost:8006\/bookings\"
    
    class=\" text-white nav-link 
    
    
    
    \">

    

                  \u0627\u0644\u062d\u062c\u0632 \u0627\u0644\u0627\u0644\u0643\u062a\u0631\u0648\u0646\u064a
    <\/a>

    
<\/li>


                <\/ul>
            <\/div>
            <div class=\" col-12 col-md-4 text-center\">
                <h3 class=\"h5 font-w700\">
                    \u064a\u0645\u0643\u0646\u0643\u0645 \u0627\u0644\u062a\u0648\u0627\u0635\u0644 \u0645\u0639\u0646\u0627 \u0639\u0646 \u0637\u0631\u064a\u0642 :
                <\/h3>
                <div class=\"font-size-sm mb-30\">
                                             \u0627\u0644\u0639\u0646\u0648\u0627\u0646
                        <br>
                        Yemen IBB
                        <br>
                    

                                            <abbr title=\"Phone\">
                             \u0627\u0644\u0647\u0627\u062a\u0641
                        <\/abbr>
                                                                                     770529482
                            <br>
                                                                        
                    
                    
                <\/div>
                <!--<form>-->
                <!--<div class=\"input-group\">-->
                <!--<input type=\"email\" class=\"form-control\" id=\"ld-subscribe-email\" name=\"ld-subscribe-email\" placeholder=\"Your email..\">-->
                <!--<div class=\"input-group-append\">-->
                <!--<button type=\"submit\" class=\"btn btn-square btn-secondary\">Subscribe<\/button>-->
                <!--<\/div>-->
                <!--<\/div>-->
                <!--<\/form>-->
            <\/div>

            <div class=\"col-12 col-md-4 text-center text-white\">
<!--
                <ul class=\"list list-simple-mini font-size-sm\">
                    <li>
                        <a class=\"link-effect font-w600\" href=\"javascript:void(0)\">Link #1<\/a>
                    <\/li>
                    <li>
                        <a class=\"link-effect font-w600\" href=\"javascript:void(0)\">Link #2<\/a>
                    <\/li>
                    <li>
                        <a class=\"link-effect font-w600\" href=\"javascript:void(0)\">Link #3<\/a>
                    <\/li>
                    <li>
                        <a class=\"link-effect font-w600\" href=\"javascript:void(0)\">Link #4<\/a>
                    <\/li>
                    <li>
                        <a class=\"link-effect font-w600\" href=\"javascript:void(0)\">Link #5<\/a>
                    <\/li>
                    <li>
                        <a class=\"link-effect font-w600\" href=\"javascript:void(0)\">Link #6<\/a>
                    <\/li>
                <\/ul>
-->
                <h3 class=\"h5 font-w700 text-white\">\u0643\u0645\u0627 \u064a\u0645\u0643\u0646\u0643\u0645 \u0632\u064a\u0627\u0631\u062a\u0646\u0627 \u0639\u0644\u0649 \u0645\u0648\u0627\u0642\u0639 \u0627\u0644\u062a\u0648\u0627\u0635\u0644 \u0627\u0644\u062a\u0627\u0644\u064a\u0629<\/h3>

                
\t<!--<ul class=\"\">-->
\t\t\t\t\t<!--<li class=\"\">-->
\t\t\t\t<a class=\"btn text-white btn-ml2 btn-circle btn-outline-primary  btn-alt-secondary2   btn-rounded2 btn-square2    \" target=\"_blank\" href=\"http:\/\/nano2soft.com\" title=\"\u062c\u0648\u062c\u0644\">
\t\t\t\t\t<i class=\"fa fa-google-plus-g\"><\/i>
\t\t\t\t<\/a>
\t\t\t<!--<\/li>-->
\t\t\t\t\t<!--<li class=\"\">-->
\t\t\t\t<a class=\"btn text-white btn-ml2 btn-circle btn-outline-primary  btn-alt-secondary2   btn-rounded2 btn-square2    \" target=\"_blank\" href=\"http:\/\/nano2soft.com\" title=\"fasebokk\">
\t\t\t\t\t<i class=\"fa fa-facebook\"><\/i>
\t\t\t\t<\/a>
\t\t\t<!--<\/li>-->
\t\t\t<!--<\/ul>2-->
            <\/div>

        <\/div>
        <!-- END Footer Navigation -->

        <!-- Copyright Info -->
        <div class=\"font-size-xs clearfix border-t  pt-20 pb-30 pb-md-10\">
            <div class=\"float-right\">
                <a class=\"font-w600 text-white\" href=\"http:\/\/localhost:8006\" target=\"_blank\">
                    \u0646\u0627\u0646\u0648 \u0633\u0648\u0641\u062a
                    
                <\/a> &copy; 2020 - <span class=\"js-year-copy\"><\/span>
            <\/div>
            <div class=\"float-left\">
                \u062a\u0637\u0648\u064a\u0631
                <i class=\"fa fa-heart text-pulse\"><\/i>
                <a class=\"font-w600 text-white\" href=\"https:\/\/nano2soft.com\" target=\"_blank\">
                    Nano 2 Soft

                <\/a>
                <br>

                <abbr class=\"d-none\" title=\"Phone\">
                     \u0627\u0644\u0647\u0627\u062a\u0641
                    00967770529482
                <br>
                <\/abbr>    
                <abbr class=\"d-none\" title=\"Mail\">
                     \u0627\u0644\u0628\u0631\u064a\u062f
                <\/abbr>
                <a class=\" d-none font-w600 text-white\" href=\"mailTo:info@nano2soft.com\" title=\"Nano 2 Soft\" target=\"_blank\">
                    info@nano2soft.com

                <\/a>
                

                <abbr title=\"Website\">
                     website
                <\/abbr>
                <a class=\"font-w600 text-white\" href=\"https:\/\/nano2soft.com\" title=\"Nano 2 Soft\" target=\"_blank\">
                    https:\/\/nano2soft.com

                <\/a>
            <\/div>
        <\/div>
        <!-- END Copyright Info -->
    <\/div>
<\/footer>        <!-- END Footer -->

     
        <a class=\"lnxScrollToTop\" id=\"lnxScrollToTop\">
\t<i class=\"lnxScrollToTopArrow\" id=\"lnxScrollToTopArrow\"><\/i>
<\/a>
<script>
(function(){
\tvar mainObject = document.getElementById('lnxScrollToTop');
\tvar arrowObject = document.getElementById('lnxScrollToTopArrow'); 

\tvar op = 0.1;
\tvar isVisible = false;
\tvar timer;
\twindow.onscroll = function (e) {
\t\tvar scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
\t\tif (scrollTop > 200) {
\t\t\tif (!isVisible) {
\t\t\t\tfadeIn(mainObject);
\t\t\t\tisVisible = true;
\t\t\t}
\t\t} else {
\t\t\tif (isVisible) {
\t\t\t\tfadeOut(mainObject);
\t\t\t\tisVisible = false;
\t\t\t}
\t\t}
\t};

\tmainObject.onclick = clicked;
\tfunction clicked (event) {
\t\tvar element = (document.documentElement.scrollTop) ? document.documentElement : document.body;
\t\tscrollTo(element, 0, 300);
\t\tevent.preventDefault();
\t}

\tfunction scrollTo(element, to, duration) {
\t\tvar start = element.scrollTop,
\t\t\tchange = to - start,
\t\t\tcurrentTime = 0,
\t\t\tincrement = 20;
\t\t\t
\t\tvar animateScroll = function(){        
\t\t\tcurrentTime += increment;
\t\t\tvar val = Math.easeInOutQuad(currentTime, start, change, duration);
\t\t\telement.scrollTop = val;
\t\t\tif(currentTime < duration) {
\t\t\t\tsetTimeout(animateScroll, increment);
\t\t\t}
\t\t};
\t\tanimateScroll();
\t}

\tfunction fadeOut(element) {
\t\tclearInterval(timer)
\t\ttimer = setInterval(function () {
\t\t\tif (op <= 0.1){
\t\t\t\tclearInterval(timer);
\t\t\t\top = 0.1;
\t\t\t\telement.style.display = 'none';
\t\t\t}
\t\t\telement.style.opacity = op.toFixed(2);
\t\t\telement.style.filter = 'alpha(opacity=' + op * 100 + \")\";
\t\t\top -= op * 0.2;
\t\t}, 25);
\t}

\tfunction fadeIn(element) {
\t\telement.style.display = 'block';
\t\tclearInterval(timer)
\t\ttimer = setInterval(function () {
\t\t\tif (op >= 1){
\t\t\t\tclearInterval(timer);
\t\t\t\top = 1;
\t\t\t}
\t\t\telement.style.opacity = op.toFixed(2);
\t\t\telement.style.filter = 'alpha(opacity=' + op * 100 + \")\";
\t\t\top += op * 0.2;
\t\t}, 25);
\t}

\t\/\/t = current time
\t\/\/b = start value
\t\/\/c = change in value
\t\/\/d = duration
\tMath.easeInOutQuad = function (t, b, c, d) {
\t\tt \/= d\/2;
\t\tif (t < 1) return c\/2*t*t + b;
\t\tt--;
\t\treturn -c\/2 * (t*(t-2) - 1) + b;
\t};
})();
<\/script>

\t\t

<style>
\t.lnxScrollToTop {
\t\tbackground: #FFF;
\t\twidth: 30px;
\t\theight: 30px;
\t\tline-height: 30px;
\t\t\tbottom: 1%;
\t\t\tmargin: 1%;

\t}
\t.lnxScrollToTop:hover {
\t\tbackground: #E6E6E6;
\t}
\t.lnxScrollToTopArrow {
\t\tcolor: #000;
\t\tfont-size: 20px;
\t}
\t.lnxScrollToTop:hover .lnxScrollToTopArrow {
\t\tcolor: #2E2E2E;
\t}
<\/style>
        


        
    <\/div>
    <!-- END Page Container -->




<!-- Codebase JS -->
<!--
<script src=\"assets\/js\/core\/jquery.min.js\"><\/script>
<script src=\"assets\/js\/codebase.core.min.js\"><\/script>
<script src=\"assets\/js\/codebase.app.min.js\"><\/script>
<script src=\"http:\/\/localhost:8006\/combine\/b050b89525d1582d5acf3161697586f3-1636410626\"><\/script>
,
                
-->

    
<script src=\"http:\/\/localhost:8006\/combine\/1a1b5170f45329edb1a2904a96de7843-1657560414\"><\/script>
<script src=\"http:\/\/localhost:8006\/combine\/83bc13c07b3bde3ae63949baa2f13655-1581776556\"><\/script>

   
    <script src=\"\/modules\/system\/assets\/js\/framework.js\"><\/script>
    <script src=\"\/modules\/system\/assets\/js\/framework.js\"><\/script>
<script src=\"\/modules\/system\/assets\/js\/framework.extras.js\"><\/script>
<link rel=\"stylesheet\" property=\"stylesheet\" href=\"\/modules\/system\/assets\/css\/framework.extras.css\">

<!---->

<script src=\"http:\/\/localhost:8006\/themes\/nano-themes\/assets\/js\/plugins\/swiper\/dist\/js\/swiper.min.js\"><\/script>
<script src=\"http:\/\/localhost:8006\/themes\/nano-themes\/assets\/vendor\/typed.js\/typed.min.js\"><\/script>
<script src=\"http:\/\/localhost:8006\/themes\/nano-themes\/assets\/vendor\/venobox\/venobox.min.js\"><\/script>

<script src=\"https:\/\/maps.googleapis.com\/maps\/api\/js?key=&amp;libraries=places&amp;language=\"><\/script>
<script src=\"http:\/\/localhost:8006\/plugins\/nano\/broadcast\/assets\/js\/vendor\/pusher\/pusher.min.js?pusher-js\"><\/script>
<script src=\"http:\/\/localhost:8006\/plugins\/nano\/broadcast\/assets\/js\/vendor\/echo\/echo.iife.js?echo-js\"><\/script>
<script src=\"http:\/\/localhost:8006\/plugins\/nano\/broadcast\/assets\/js\/vendor\/push\/push.min.js?push-js\"><\/script>
<script src=\"http:\/\/localhost:8006\/plugins\/nano\/broadcast\/assets\/js\/broadcast.js?broadcast-js\"><\/script>
<script>
    $(function(){ 
    $(document).ready(function() { 
        Codebase.loader('show', 'bg-primary');

\/\/Codebase.layout('header_loader_on');
\/\/Codebase.layout('header_loader_off');

\/\/Codebase.loader('hide');
            setTimeout(function(){ 
                     \/\/$('body').addClass('loaded');
\/\/Codebase.layout('header_loader_off');

                     Codebase.loader('hide');
                     
               }, 700);
\/\/Codebase.layout('header_loader_off');
\/\/Codebase.loader('hide');

       }); 
}(jQuery));

<\/script>

<script type=\"text\/javascript\" >
var a2a_config = a2a_config || {};
a2a_config.onclick = 1;
a2a_config.locale = \"ar\";
a2a_config.num_services = 22;

\/*
a2a_config.icon_color = \"unset,#3f9ce8\";
a2a_config.color_bg = \"FFFFFF\";
a2a_config.color_main = \"D7E5ED\";
a2a_config.color_border = \"AECADB\";
a2a_config.color_link_text = \"333333\";
a2a_config.color_link_text_hover = \"333333\";

a2a_config.icon_color = \"#0166ff\";
a2a_config.icon_color = \"seashell,midnightblue\";

FacebookTwitterLinkedInShare
a2a_config.icon_color = \"deeppink\";
FacebookTwitterLinkedInShare
a2a_config.icon_color = \"transparent\";
*\/

<\/script>
<!--
<script async src=\"assets\/js\/page.js\"><\/script>
-->
<script async src=\"https:\/\/static.addtoany.com\/menu\/page.js\"><\/script>


<script>
    \/*
    $(document).ready(function(){
        var targetWidth = 980;
\/\/alert(\"dhyaa\");

        $('meta[name=\"viewport\"]').attr('content', 'width=' + targetWidth);

    });
Codebase.loader('show', 'bg-primary');
                                        setTimeout(function () {
                                            Codebase.loader('hide');
                                        }, 3000);

    *\/
    $(function(){ 
    $(document).ready(function() { 
      
            Codebase.loader('show', 'bg-primary');

\/\/Codebase.layout('header_loader_on');
\/\/Codebase.layout('header_loader_off');

\/\/Codebase.loader('hide');
            setTimeout(function(){ 
                     \/\/$('body').addClass('loaded');
\/\/Codebase.layout('header_loader_off');

                     Codebase.loader('hide');
                     
               }, 700);
\/\/Codebase.layout('header_loader_off');
\/\/Codebase.loader('hide');

       }); 
}(jQuery));


      if ($('.text-slider').length == 1) {

    var typed_strings = $('.text-slider-items').text();
    var typed = new Typed('.text-slider', {
      strings: typed_strings.split(','),
      typeSpeed: 80,
      loop: true,
      backDelay: 1100,
      backSpeed: 30
    });
  }

    
    
<\/script>

<\/body>
<\/html>"
}  

```

### Get list Layout Placeholders for Cms Pages 

**لجلب قائمه Placeholders نقوم بستخدام الرابط التالي مع تمرير اسم الصفحة فى البراميتر name**

GET http://localhost:8006/api/v1/cms/cms-pages/list/layout-placeholders

Required Parameters: `name`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `name`           | `string`  | **Required**. The id          |


#### Example 2 get list Layout Placeholders for Cms Pages name=index

```
GET http://localhost:8006/api/v1/cms/cms-pages/list/layout-placeholders?name=index
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": {
    "gmscript": {
      "title": "gmscript",
      "type": "html",
      "ignore": false
    },
    "hero": {
      "title": "hero",
      "type": "html",
      "ignore": false
    },
    "advars": {
      "title": "advars",
      "type": "html",
      "ignore": false
    },
    "page_header": {
      "title": "page_header",
      "type": "html",
      "ignore": false
    },
    "categories": {
      "title": "categories",
      "type": "html",
      "ignore": false
    },
    "page_left": {
      "title": "page_left",
      "type": "html",
      "ignore": false
    },
    "page_footer": {
      "title": "page_footer",
      "type": "html",
      "ignore": false
    }
  }
}
```

**فى حالة تمرير اسم صفحة غير موجوده سيتم ارجاع الخطاء التالي**

```json
{
  "data": []
}
```

### Get list Components for Cms Pages 

**لجلب قائمه Components نقوم بستخدام الرابط التالي مع تمرير اسم الصفحة فى البراميتر name**

GET http://localhost:8006/api/v1/cms/cms-pages/list/components

Required Parameters: `name`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `name`           | `string`  | **Required**. The id          |


#### Example 2 get list Layout Placeholders for Cms Pages name=index

```
GET http://localhost:8006/api/v1/cms/cms-pages/list/components?name=index
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": {
    "viewBag": {
      "localeUrl": {
        "ar": "\/",
        "en": "\/"
      },
      "styleItem": "3",
      "localeTitle": {
        "en": "home"
      }
    },
    "contactForm": {
      "form_description": "contactForm",
      "ga_success_event_allow": "0"
    },
    "tssProjectRecords tssAssociates": {
      "activeOnly": "1",
      "mainCssClass": "col-12 col-sm-12 col-md-12 bg-white",
      "areaSlug": "associate",
      "is_title": "1",
      "title": "title_associates",
      "notLink": "1",
      "categorySlug": "{{ :category }}",
      "tagSlug": "{{ :tag }}",
      "recordPage": "projects\/posts-project",
      "recordPageSlug": "{{ :slug }}",
      "recordKeyColumn": "slug",
      "allowLimit": "1",
      "limit": "10",
      "pageSlug": "{{ :page }}",
      "orderBy": "sort_order",
      "orderByDirection": "ASC",
      "content": "swiper-associates",
      "itemStyle": "associates",
      "itemClass": "col-6 col-sm-3"
    },
    "tssProjectRecords tssFeatures22": {
      "activeOnly": "1",
      "mainCssClass": "col-12 col-sm-12 col-md-12 bg-white",
      "areaSlug": "feature",
      "is_title": "1",
      "title": "title_features",
      "categorySlug": "{{ :category }}",
      "tagSlug": "{{ :tag }}",
      "recordPage": "features\/posts-feature",
      "recordPageSlug": "{{ :slug }}",
      "recordKeyColumn": "slug",
      "allowLimit": "1",
      "limit": "10",
      "pageSlug": "{{ :page }}",
      "orderBy": "sort_order",
      "orderByDirection": "ASC",
      "content": "swiper",
      "itemStyle": "style1",
      "itemClass": "col-6 col-sm-3"
    },
    "toolsEmployeeRecords tssFeatures": {
      "modelClass": "RainLab\\Blog\\Models\\Post",
      "scope": "-",
      "scopeValue": "{{ :scope }}",
      "noRecordsMessage": "لاتوجد بيانات لعرضها",
      "activeOnly": "0",
      "is_published": "0",
      "areaSlug": "0",
      "in_categories_id": "",
      "categorySlug": "{{ :category }}",
      "tagSlug": "{{ :tag }}",
      "recordPage": "blog\/post",
      "recordPageSlug": "{{ :slug }}",
      "recordKeyColumn": "slug",
      "allowLimit": "1",
      "limit": "10",
      "pageSlug": "{{ :page }}",
      "ColumnName": "title",
      "ColumnDescription": "excerpt",
      "ColumnImage": "image",
      "ColumnDate": "created_at",
      "orderBy": "created_at",
      "orderByDirection": "ASC",
      "is_title": "1",
      "title": "title_features",
      "mainCssClass": "col-12 col-sm-12 col-md-12 bg-white swiper2222",
      "content": "swiper",
      "itemStyle": "style1",
      "itemClass": "block block-link-shadow block-rounded  text-center   bg-gd-primary2"
    },
    "toolsEmployeeRecords tssEmployee": {
      "modelClass": "Tss\\Basic\\Models\\Employee",
      "scope": "-",
      "scopeValue": "{{ :scope }}",
      "noRecordsMessage": "لاتوجد بيانات لعرضها",
      "activeOnly": "1",
      "is_published": "0",
      "is_hidden": "0",
      "areaSlug": "0",
      "in_categories_id": "groups_class_id",
      "categorySlug": "{{ :category }}",
      "tagSlug": "{{ :tag }}",
      "recordPage": "teams\/teamsdetails",
      "recordPageSlug": "{{ :slug }}",
      "recordKeyColumn": "id",
      "allowLimit": "1",
      "limit": "10",
      "pageSlug": "{{ :page }}",
      "ColumnName": "full_name",
      "ColumnDescription": "degree",
      "ColumnImage": "employee_image",
      "ColumnDate": "created_at",
      "orderBy": "sort_order",
      "orderByDirection": "ASC",
      "is_title": "1",
      "title": "title_admin",
      "mainCssClass": "col-12 col-sm-12 col-md-12 bg-white",
      "content": "swiper",
      "itemStyle": "style-tem2-albed",
      "itemClass": "block block-link-shadow block-rounded  text-center   bg-gd-primary2"
    },
    "toolsEmployeeRecords tssWhats": {
      "modelClass": "Tss\\Webbasic\\Models\\PostsFeature",
      "scope": "-",
      "scopeValue": "{{ :scope }}",
      "noRecordsMessage": "لاتوجد بيانات لعرضها",
      "activeOnly": "1",
      "is_published": "1",
      "is_hidden": "0",
      "areaSlug": "feature",
      "in_categories_id": "categories_id",
      "in_categories_value": "13,0",
      "categorySlug": "{{ :category }}",
      "tagSlug": "{{ :tag }}",
      "recordPage": "features\/posts-feature",
      "recordPageSlug": "{{ :slug }}",
      "recordKeyColumn": "slug",
      "allowLimit": "0",
      "limit": "10",
      "pageSlug": "{{ :page }}",
      "ColumnName": "name",
      "ColumnDescription": "short_description",
      "ColumnImage": "image",
      "ColumnDate": "created_at",
      "orderBy": "created_at",
      "orderByDirection": "ASC",
      "is_title": "1",
      "title": "title_whats",
      "mainCssClass": "row  bg-white swiper2222 justify-content-md-center justify-content-md-around2 justify-content-md-between2",
      "content": "default",
      "itemStyle": "style1-circle",
      "itemClass": "col-12 col-sm-6 col-md-4 block block-link-shadow block-rounded  text-center   bg-gd-primary2"
    },
    "toolsEmployeeRecords tssEvents": {
      "modelClass": "Tss\\Webbasic\\Models\\PostsPost",
      "scope": "-",
      "scopeValue": "{{ :scope }}",
      "noRecordsMessage": "لاتوجد بيانات لعرضها",
      "activeOnly": "1",
      "is_published": "1",
      "is_hidden": "0",
      "areaSlug": "post",
      "in_categories_id": "categories_id",
      "in_categories_value": "15,0",
      "categorySlug": "{{ :category }}",
      "tagSlug": "{{ :tag }}",
      "recordPage": "posts\/posts-post",
      "recordPageSlug": "{{ :slug }}",
      "recordKeyColumn": "slug",
      "allowLimit": "0",
      "limit": "10",
      "pageSlug": "{{ :page }}",
      "ColumnName": "name",
      "ColumnDescription": "short_description",
      "ColumnImage": "image",
      "ColumnDate": "created_at",
      "orderBy": "created_at",
      "orderByDirection": "ASC",
      "is_title": "1",
      "title": "title_events",
      "mainCssClass": "row px-10 bg-white swiper2222",
      "content": "default",
      "itemStyle": "style1",
      "itemClass": "col-12 col-sm-6 col-md-3 block block-link-shadow block-rounded  text-center   bg-gd-primary2"
    },
    "tagList": {
      "displayEmpty": "1",
      "fetchPosts": "1",
      "orderBy": "name asc",
      "postSlug": "{{ :slug }}",
      "limit": "10",
      "enableTagFilter": "never",
      "tagPage": "blog\/tagpost",
      "tagsPage": "blog\/tag"
    },
    "blogPosts": {
      "pageNumber": "{{ :page }}",
      "postsPerPage": "5",
      "noPostsMessage": "No posts found",
      "sortOrder": "published_at desc",
      "categoryPage": "blog\/category",
      "postPage": "blog\/post"
    },
    "blogCategories": {
      "slug": "{{ :slug }}",
      "displayEmpty": "0",
      "categoryPage": "blog\/category"
    }
  }
}
```

**فى حالة تمرير اسم صفحة غير موجوده سيتم ارجاع الخطاء التالي**

```json
{
  "data": []
}
```

### Render Components for Cms Pages 

**لجب محتوي كمبوننت معين نقوم بتمرير اسم الصفحه واسم الكمبوننت والبرامترات المطلوبه للكمبوننت ضمن الطلب **

GET http://localhost:8006/api/v1/cms/cms-pages/list/components/render

Required Parameters: `name`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `name`           | `string`  | **Required**. The Component name          |
| `page_name`           | `string`  | **Required**. The Page name          |
| `param`           | `array`  | The other param in Component          |


#### Example 2 get render Component for Cms Pages page_name=index and name=contactForm

```
GET http://localhost:8006/api/v1/cms/cms-pages/components/render?page_name=index&name=contactForm&form_description=contactForm&ga_success_event_allow=0
```

##### Response

```html
Status: 200 OK
```

```json
{
    "data": "<div id=\"scf-contactForm\">

\t<div id=\"scf-message-contactForm\">
\t\t
\t<\/div>

\t<div id=\"scf-form-contactForm\">
\t\t
\t<form method=\"POST\" action=\"http:\/\/localhost:8006\/api\/v1\/cms\/cms-pages\/components\/render\" accept-charset=\"UTF-8\" class=\" was-validated\" id=\"scf-form-id-contactForm\" data-request=\"contactForm::onFormSend\" data-request-validate=\"data-request-validate\" data-request-files=\"data-request-files\" data-request-update=\"&#039;contactForm::scf-message&#039;:&#039;#scf-message-contactForm&#039;,&#039;contactForm::scf-form&#039;:&#039;#scf-form-contactForm&#039;\" enctype=\"multipart\/form-data\"><input name=\"_handler\" type=\"hidden\" value=\"contactForm::onFormSend\"><input name=\"_session_key\" type=\"hidden\" value=\"PoZXoQEZ91jRrKwc6DgzSiIaASo2nLxTvqpbq73u\"><input name=\"_token\" type=\"hidden\">

\t\t
\t\t\t<div class=\"form-group\"><label class=\"control-label  required\" for=\"contactForm-name\"  style=\"display: none;\" >\u0627\u0644\u0627\u0633\u0645<\/label><input id=\"contactForm-name\" class=\"form-control\" name=\"name\" placeholder=\"\u0627\u0644\u0627\u0633\u0645\" autofocus=\"\" type=\"text\" required=\"\"><\/div>

\t\t
\t\t\t<div class=\"form-group\"><label class=\"control-label  required\" for=\"contactForm-email\"  style=\"display: none;\" >\u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0627\u0644\u0643\u062a\u0631\u0648\u0646\u064a<\/label><input id=\"contactForm-email\" class=\"form-control\" name=\"email\" placeholder=\"\u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0627\u0644\u0643\u062a\u0631\u0648\u0646\u064a\" type=\"email\" required=\"\"><\/div>

\t\t
\t\t\t<div class=\"form-group\"><label class=\"control-label  required\" for=\"contactForm-phone\"  style=\"display: none;\" >\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u0644\u062a\u0641<\/label><input id=\"contactForm-phone\" class=\"form-control\" name=\"phone\" placeholder=\"\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u0644\u062a\u0641\" type=\"text\" required=\"\"><\/div>

\t\t
\t\t\t<div class=\"form-group\"><label class=\"control-label  required\" for=\"contactForm-mesg\"  style=\"display: none;\" >\u0627\u0644\u0645\u0648\u0636\u0648\u0639<\/label><textarea id=\"contactForm-mesg\" class=\"form-control\" name=\"mesg\" placeholder=\"\u0627\u0644\u0645\u0648\u0636\u0648\u0639\" rows=\"5\" required=\"\"><\/textarea><\/div>

\t\t
\t\t

\t\t
\t\t
\t\t

\t\t
\t\t<div id=\"submit-wrapper-contactForm\" class=\"form-group\"><button type=\"submit\" data-attach-loading class=\"oc-loader btn btn-primary\">Send<\/button><\/div>

\t<\/form>

\t
\t<\/div>

<\/div>"
}
```

**فى حالة تمرير اسم صفحة غير موجوده سيتم ارجاع الخطاء التالي**

```json
{
  "data": false
}
```

### Find Components for Cms Pages 

**لجب بيانات كمبوننت معين نقوم بتمرير اسم الصفحه واسم الكمبوننت ضمن الطلب **

GET http://localhost:8006/api/v1/cms/cms-pages/list/components/find

Required Parameters: `name`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `name`           | `string`  | **Required**. The Component name          |
| `page_name`           | `string`  | **Required**. The Page name          |


#### Example 2 get data Component for Cms Pages page_name=index and name=contactForm

```
GET http://localhost:8006/api/v1/cms/cms-pages/components/render?page_name=index&name=contactForm
```

##### Response

```html
Status: 200 OK
```

```json
{
    "data": {
        "id": null,
        "alias": "contactForm",
        "name": "contactForm",
        "isHidden": false,
        "pluginIcon": null,
        "componentCssClass": null,
        "inspectorEnabled": true,
        "implement": [],
        "assetPath": "\/plugins\/tss\/smallcontactform"
    }
}  
```

**فى حالة تمرير اسم صفحة غير موجوده سيتم ارجاع الخطاء التالي**

```json
{
  "data": false
}
```