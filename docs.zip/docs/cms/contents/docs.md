## Static Contents Language

This endpoint allows you to `list`, `show` your Static Contents.

/cms/contents

**الجز الخاص بالمحتوي الديناميكي فى النظام يمكنك من خلال هذا الجزء جلب كافه المحتوي الديناميكي فى النظام **

### The Accept-Language 

**يمكن تهية الصفحة حسب اللغة فى النظام من خلال  تمرير كود اللغة فى راس الطلب ضمن المتغير  Accept-Language**

Header Parameters
```json
{
  "Accept-Language":"ar"
}
```

### List Contents

Returns a list of Contents.

**لجلب الصفحات نستخدم الرابط التالي **

```
GET /api/v1/cms/contents
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Response

```html
Status: 200 OK
```

```json
{
  "data": {
    "static-pages-en\/about-en.htm": "About En",
    "static-pages-en\/about.htm": "About",
    "static-pages\/about.htm": "About",
    "static-pages\/videos.htm": "Videos",
    "static-pages\/wn-blocks.htm": "Wn Blocks",
    "con_useing.en.htm": "Con Useing.en",
    "con_useing.htm": "Con Useing",
    "contact.htm": "Contact",
    "docs\/hh.htm": "Hh",
    "docs\/docs1.md": "Docs1",
    "docs\/docs.md": "Docs",
    "privets.htm": "Privets",
    "video.htm": "Video",
    "welcome.en.htm": "Welcome.en",
    "welcome.htm": "Welcome",
    "welcome_client.en.htm": "Welcome Client.en",
    "welcome_client.htm": "Welcome Client"
  }
}
```

### Get Data Static Pages 

**لجلب بيانات صفحة معينه نقوم بستخدام الرابط التالي مع تمرير اسم الصفحة فى البراميتر name**

GET http://localhost:8006/api/v1/cms/contents/data

Required Parameters: `name`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `name`           | `string`  | **Required**. The id          |


#### Example 2 get Data Static Pages name=abouts

```
GET http://localhost:8006/api/v1/cms/contents/data?name=about
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": {
    "markup": "<hr>\r\n<hr>\r\n\r\n<h1>من نحن<\/h1><pre><strong>متخصصة في مجال تطوير البرمجيات والأنظمة المحاسبية المختلفة وتطوير المواقع الالكترونية و تسعى الى ان تصبح رائدة في هذا المجال على المستوي الوطني.<\/strong><\/pre>",
    "settings": {
      "components": {
        "viewBag": {
          "title": "من نحن",
          "url": "\/about",
          "layout": "default",
          "is_hidden": "0",
          "navigation_hidden": "0",
          "meta_title": "من نحن",
          "meta_description": "من نحن",
          "localeUrl": {
            "en": "\/about-en"
          }
        }
      }
    },
    "placeholders": []
  }
}
```

**فى حالة تمرير اسم صفحة غير موجوده سيتم ارجاع الخطاء التالي**

```json
{
  "data": null
}
```


### Render Static Pages 

**ارجاع محتوي الصفحة القابل للعرض على الويب اي بشكل مرندر **

```
GET /api/v1/cms/contents/render
```

Required Parameters: `name`

**يجيب تمرير اسم الصفحة المراد ارجاع محتوها ضمن المتغير name**

#### Example 3 Render Static Pages name=welcome_client

```
GET http://localhost:8006/api/v1/cms/contents/render?name=welcome_client
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "data": "<h3 class=\"bg-primary pb-10 \">مرحبا بك عزيزي المستخدم<\/h3>\n<h4 data-wow-delay=\"0.6s\" data-wow-offset=\"0\">يمكنك عبر موقعنا الاعلان عن عقاراتك او طلب عقارات معينه  .<\/h4>\n<br>"
}
```

```
GET http://localhost:8006/api/v1/cms/contents/render?name=welcome.en.htm
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "data": "<h3>متخصصة في مجال تطوير البرمجيات والأنظمة المحاسبية المختلفة وتطوير المواقع الالكترونية و تسعى الى ان تصبح رائدة في هذا المجال على المستوي الوطني.<\/h3>\r\n<figure data-wow-delay=\"0.3s\" data-wow-offset=\"0\"><img src=\"images\/slide\/%D8%A7%D9%84%D8%B4%D8%B9%D8%A7%D8%B1.jpg\" alt=\"\" class=\"fr-fic fr-dii\"><\/figure>\r\n\r\n<h2 data-wow-delay=\"0.2s\" data-wow-offset=\"0\">لماذا نانو سوفت<\/h2>\r\n\r\n<h4 data-wow-delay=\"0.6s\" data-wow-offset=\"0\">نستطيع القول وبثقة كبيرة بأن اختيارك لتكنوسوفت ستارز و لاحد برامجها أو لإحدى خدماتها هو الاختيار الذي يمنحك الامان و الضمانة الكاملة لاستمرارية التحديث والتطوير و الصيانة والدعم.<\/h4>\r\n\r\n<h3><strong> التميز في المنتج البرمجي<\/strong><\/h3>\r\n\r\n<h4>أنظمتنا المعلوماتية و المحاسبية معدة بأحدث اللغات البرمجية المتوفرة عالميا في سوق الادوات البرمجية كما أنها تستخدم قاعدة بيانات تم تحليلها و تصميمها و تطويرها من قبل فريق عمل متخصص ومؤهل, عالي القدرة والكفاءة في مجالات التحليل المالي والبرمجي,كما تتميز أنظمتنا عن غيرها بالسهوله و الدقة و المرونة والادارة والسيطرة التي توفرها لك الادوات الذكية المزودة بها برامجنا , كما انها قابلة للصيانة و التطوير والدعم الفني و التقني المستمر. .<\/h4>\r\n\r\n<h3> <strong>كفاءة فريق العمل<\/strong><\/h3>\r\n\r\n<h4>تحتضن عددا من محللي ومصممي ومنفذي النظم المعلوماتية والمحاسبية ومهندسي البرمجيات و مصممي المواقع الالكترونية الذين يتمتعون بكفاءة عالية كما يمتلكون مؤهلات عالية في مجال الحاسبات و تقنية المعلومات.<\/h4>\r\n\r\n<h3> <strong>التميز بالخدمة<\/strong><\/h3>\r\n\r\n<h4>نقدم خدمات التحديث والصيانة المستمرة وبشكل دوري لكل منتجاتنا البرمجية .<\/h4>\r\n\r\n<h3><strong> الدعم الفني السريع<\/strong><\/h3>\r\n\r\n<h4>يمكنكم الاتصال بنا بالطريقة المناسبة لكم عبر الوسائل الالكترونية كما يستطيع فريق عملنا الوصول اليكم في اقل وقت ممكن .<\/h4>"
}
```
