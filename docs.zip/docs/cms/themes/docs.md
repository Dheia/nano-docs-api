## CMS Themes

This endpoint allows you to `list`, `show` your Themes.

/cms/themes

**الجزء الخاص بجلب الثيمات  **

### The Accept-Language 

**يمكن تهية البيانات الراجعة حسب اللغة فى النظام من خلال  تمرير كود اللغة فى راس الطلب ضمن المتغير  Accept-Language**

Header Parameters
```json
{
  "Accept-Language":"ar"
}
```

### List Themes

Returns a list of Themes.

**لجلب الثيمات نستخدم الرابط التالي **

```
GET /api/v1/cms/themes
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": "tss",
      "dirName": "tss",
      "path": "\/storage\/emulated\/0\/htdocs\/october_demo\/themes\/tss",
      "is_active": false,
      "is_locked": false,
      "hasCustomData": true,
      "custom_data": {
        "id": 1,
        "theme": "tss",
        "data": {
          "website_name": "Nano Soft Web Systems",
          "website_author": "Nano Soft  Eng\/ Dheia Ali Al-Shami",
          "website_url": "http:\/\/nanosoft.com",
          "description": "Free Modern Theme based on",
          "keywords": "nano,soft,web,systems,themes,templates",
          "contact": "قالوا عنا كذا وكذا وكذا وكذا",
          "phone": "770529482",
          "email": "kddd90@gmail.com",
          "meta_title": "Squad",
          "meta_description": "Squad Bootstrap Template",
          "load_google_fonts": true,
          "google_font_family": "Roboto+Slab:300,400,700|Raleway:300,300i,400,400i,700,700i",
          "load_fontawesome": true,
          "load_material_icons": true,
          "load_stroke7_icons": true,
          "load_jQuery": true,
          "jQuery_version": "2.2.4",
          "load_octobercms_framework": true,
          "main_content_layout": "",
          "page_header_style": "",
          "website_theme": "",
          "page_header_fixed": true,
          "brand_primary": "#3f9ce8",
          "body_bg": "#f0f2f5",
          "body_color": "#575757",
          "body_color_dark": "#171717",
          "header_bg": "#ffffff",
          "sidebar_bg": "#ffffff",
          "load_animate_css": true,
          "load_wow_js": true,
          "load_owl_carousel": true
        },
        "created_at": "2022-01-10 14:06:51",
        "updated_at": "2022-01-10 14:06:51",
        "website_name": "Nano Soft Web Systems",
        "website_author": "Nano Soft  Eng\/ Dheia Ali Al-Shami",
        "website_url": "http:\/\/nanosoft.com",
        "description": "Free Modern Theme based on",
        "keywords": "nano,soft,web,systems,themes,templates",
        "contact": "قالوا عنا كذا وكذا وكذا وكذا",
        "phone": "770529482",
        "email": "kddd90@gmail.com",
        "meta_title": "Squad",
        "meta_description": "Squad Bootstrap Template",
        "load_google_fonts": true,
        "google_font_family": "Roboto+Slab:300,400,700|Raleway:300,300i,400,400i,700,700i",
        "load_fontawesome": true,
        "load_material_icons": true,
        "load_stroke7_icons": true,
        "load_jQuery": true,
        "jQuery_version": "2.2.4",
        "load_octobercms_framework": true,
        "main_content_layout": "",
        "page_header_style": "",
        "website_theme": "",
        "page_header_fixed": true,
        "brand_primary": "#3f9ce8",
        "body_bg": "#f0f2f5",
        "body_color": "#575757",
        "body_color_dark": "#171717",
        "header_bg": "#ffffff",
        "sidebar_bg": "#ffffff",
        "load_animate_css": true,
        "load_wow_js": true,
        "load_owl_carousel": true
      },
      "hasParent": false,
      "parent": null,
      "preview_image": "http:\/\/localhost:8006\/themes\/tss\/assets\/images\/theme-preview.png",
      "product_code": "october.demo",
      "composer_code": "october\/demo-theme",
      "latest_version": "0.0.0",
      "version_history": []
    },
    {
      "id": "nano-themes",
      "dirName": "nano-themes",
      "path": "\/storage\/emulated\/0\/htdocs\/october_demo\/themes\/nano-themes",
      "is_active": true,
      "is_locked": false,
      "hasCustomData": true,
      "custom_data": {
        "id": 2,
        "theme": "nano-themes",
        "data": {
          "website_name": "نانو سوفت",
          "website_url": "http:\/\/naon2soft.com",
          "meta_title": "نانو 2 سوفت للبرمجيات وتقنية المعلومات",
          "meta_description": "نانو 2 سوفت للبرمجيات وتقنية المعلومات",
          "meta_keywords": "نانو سوفت , برمجيات , انظمة , شركة , تصميم , مواقع",
          "website_baner_type": "text",
          "address": "Yemen IBB",
          "work_time": "",
          "map_type": "link",
          "map_link": "",
          "map_content": "",
          "website_author": "Nano 2 Soft",
          "website_author_name": "Nano 2 Soft  Eng\/ Dheia Ali Al-Shami  00967770529482",
          "author_web": "https:\/\/nano2soft.com",
          "author_phone": "00967770529482",
          "author_email": "info@nano2soft.com",
          "author_address": "Yemen IBB",
          "load_google_fonts": "1",
          "google_font_family": "Roboto+Slab:300,400,700|Raleway:300,300i,400,400i,700,700i",
          "load_fontawesome": "1",
          "load_material_icons": "1",
          "load_stroke7_icons": "1",
          "load_jQuery": "1",
          "jQuery_version": "2.2.4",
          "load_octobercms_framework": "1",
          "main_content_layout": "",
          "page_header_style": "",
          "website_theme": "",
          "page_header_fixed": "1",
          "brand_primary": "#3f9ce8",
          "brand_secondary": "#3f9ce8",
          "body_bg": "#f0f2f5",
          "body_color": "#575757",
          "body_color_dark": "#171717",
          "header_bg": "#ffffff",
          "sidebar_bg": "#ffffff",
          "load_animate_css": "1",
          "load_wow_js": "1",
          "load_owl_carousel": "1",
          "website_baner": "\/favicon.png",
          "website_baner_about": "",
          "website_baner_story": "",
          "website_baner_goles": "",
          "phone": "[{\"phone_label\":\"\",\"phone_number\":\"770529482\",\"phone_type\":\"mobile\",\"sort_show\":\"1\",\"is_default\":\"1\",\"is_show\":\"1\",\"phone_note\":\"\"}]",
          "email": null,
          "accounts": null,
          "custom_css": "",
          "custom_js": "",
          "is_allow_locale_picker": "0",
          "is_allow_header_search": "0",
          "is_allow_user_nav": "0",
          "is_allow_icon_share": "0",
          "is_allow_scroll_call": "0",
          "is_allow_floating_whatsapp": "0",
          "is_allow_scroll_top": "0",
          "is_allow_loader": "0",
          "is_allow_subscribe": "0",
          "is_allow_unsubscribe": "0"
        },
        "created_at": "2022-06-26 13:07:42",
        "updated_at": "2023-08-21 19:23:49",
        "website_name": "نانو سوفت",
        "website_url": "http:\/\/naon2soft.com",
        "meta_title": "نانو 2 سوفت للبرمجيات وتقنية المعلومات",
        "meta_description": "نانو 2 سوفت للبرمجيات وتقنية المعلومات",
        "meta_keywords": "نانو سوفت , برمجيات , انظمة , شركة , تصميم , مواقع",
        "website_baner_type": "text",
        "address": "Yemen IBB",
        "work_time": "",
        "map_type": "link",
        "map_link": "",
        "map_content": "",
        "website_author": "Nano 2 Soft",
        "website_author_name": "Nano 2 Soft  Eng\/ Dheia Ali Al-Shami  00967770529482",
        "author_web": "https:\/\/nano2soft.com",
        "author_phone": "00967770529482",
        "author_email": "info@nano2soft.com",
        "author_address": "Yemen IBB",
        "load_google_fonts": "1",
        "google_font_family": "Roboto+Slab:300,400,700|Raleway:300,300i,400,400i,700,700i",
        "load_fontawesome": "1",
        "load_material_icons": "1",
        "load_stroke7_icons": "1",
        "load_jQuery": "1",
        "jQuery_version": "2.2.4",
        "load_octobercms_framework": "1",
        "main_content_layout": "",
        "page_header_style": "",
        "website_theme": "",
        "page_header_fixed": "1",
        "brand_primary": "#3f9ce8",
        "brand_secondary": "#3f9ce8",
        "body_bg": "#f0f2f5",
        "body_color": "#575757",
        "body_color_dark": "#171717",
        "header_bg": "#ffffff",
        "sidebar_bg": "#ffffff",
        "load_animate_css": "1",
        "load_wow_js": "1",
        "load_owl_carousel": "1",
        "website_baner": "\/favicon.png",
        "website_baner_about": "",
        "website_baner_story": "",
        "website_baner_goles": "",
        "phone": [
          {
            "phone_label": "",
            "phone_number": "770529482",
            "phone_type": "mobile",
            "sort_show": "1",
            "is_default": "1",
            "is_show": "1",
            "phone_note": ""
          }
        ],
        "email": null,
        "accounts": null,
        "custom_css": "",
        "custom_js": "",
        "is_allow_locale_picker": "0",
        "is_allow_header_search": "0",
        "is_allow_user_nav": "0",
        "is_allow_icon_share": "0",
        "is_allow_scroll_call": "0",
        "is_allow_floating_whatsapp": "0",
        "is_allow_scroll_top": "0",
        "is_allow_loader": "0",
        "is_allow_subscribe": "0",
        "is_allow_unsubscribe": "0",
        "is_allow_header": 1,
        "is_allow_hero": 1,
        "is_allow_sidebar": 1
      },
      "hasParent": false,
      "parent": null,
      "preview_image": "http:\/\/localhost:8006\/themes\/nano-themes\/assets\/images\/theme-preview.png",
      "product_code": "",
      "composer_code": "",
      "latest_version": "1.0.1",
      "version_history": {
        "1.0.7": "Added PDF export for Wishlists",
        "1.0.6": "Added styles for reviews",
        "1.0.5": "Added terms and conditions checkbox",
        "1.0.4": "Added wishlists",
        "1.0.3": "Added default checkbox styles for custom fields",
        "1.0.2": "Added new on_sale filter",
        "1.0.1": "Initial release"
      }
    },
    {
      "id": "hollingworth",
      "dirName": "hollingworth",
      "path": "\/storage\/emulated\/0\/htdocs\/october_demo\/themes\/hollingworth",
      "is_active": false,
      "is_locked": false,
      "hasCustomData": false,
      "custom_data": {
        "id": 5,
        "theme": "hollingworth",
        "data": [],
        "created_at": "2023-11-16 19:38:28",
        "updated_at": "2023-11-16 19:38:28"
      },
      "hasParent": false,
      "parent": null,
      "preview_image": "http:\/\/localhost:8006\/modules\/cms\/assets\/images\/default-theme-preview.png",
      "product_code": "",
      "composer_code": "",
      "latest_version": "0.0.0",
      "version_history": []
    },
    {
      "id": "vanilla-theme",
      "dirName": "vanilla-theme",
      "path": "\/storage\/emulated\/0\/htdocs\/october_demo\/themes\/vanilla-theme",
      "is_active": false,
      "is_locked": false,
      "hasCustomData": false,
      "custom_data": {
        "id": 6,
        "theme": "vanilla-theme",
        "data": [],
        "created_at": "2023-11-16 19:38:29",
        "updated_at": "2023-11-16 19:38:29"
      },
      "hasParent": false,
      "parent": null,
      "preview_image": "http:\/\/localhost:8006\/themes\/vanilla-theme\/assets\/images\/theme-preview.png",
      "product_code": "rainlab.vanilla",
      "composer_code": "rainlab\/vanilla-theme",
      "latest_version": "1.0.1",
      "version_history": {
        "1.0.3": "Added the password reset page.",
        "1.0.2": "Fix for pagination on blog pages.",
        "1.0.1": "First version of Vanilla theme."
      }
    },
    {
      "id": "andreyvasilev-minimalist",
      "dirName": "andreyvasilev-minimalist",
      "path": "\/storage\/emulated\/0\/htdocs\/october_demo\/themes\/andreyvasilev-minimalist",
      "is_active": false,
      "is_locked": false,
      "hasCustomData": true,
      "custom_data": {
        "id": 3,
        "theme": "andreyvasilev-minimalist",
        "data": {
          "site_name": "Minimalist",
          "site_description": "This is an OctoberCMS Minimalist theme.",
          "theme_color": "#58595a"
        },
        "created_at": "2022-06-27 20:11:36",
        "updated_at": "2022-06-27 20:11:36",
        "site_name": "Minimalist",
        "site_description": "This is an OctoberCMS Minimalist theme.",
        "theme_color": "#58595a"
      },
      "hasParent": false,
      "parent": null,
      "preview_image": "http:\/\/localhost:8006\/themes\/andreyvasilev-minimalist\/assets\/images\/theme-preview.png",
      "product_code": "",
      "composer_code": "",
      "latest_version": "0.0.0",
      "version_history": []
    },
    {
      "id": "postsdemo",
      "dirName": "postsdemo",
      "path": "\/storage\/emulated\/0\/htdocs\/october_demo\/themes\/postsdemo",
      "is_active": false,
      "is_locked": false,
      "hasCustomData": true,
      "custom_data": {
        "id": 7,
        "theme": "postsdemo",
        "data": [],
        "created_at": "2023-11-16 19:38:29",
        "updated_at": "2023-11-16 19:38:29"
      },
      "hasParent": false,
      "parent": null,
      "preview_image": "http:\/\/localhost:8006\/themes\/postsdemo\/assets\/images\/theme-preview.png",
      "product_code": "dynamedia.postsdemo",
      "composer_code": "dynamedia\/postsdemo-theme",
      "latest_version": "v1.0.1",
      "version_history": {
        "v1.0.4": "Remove content and meta from .gitignore to avoid removal from package",
        "v1.0.3": "Set no parent",
        "v1.0.2": "Fix incorrect language strings",
        "v1.0.1": "Initial version"
      }
    },
    {
      "id": "demo",
      "dirName": "demo",
      "path": "\/storage\/emulated\/0\/htdocs\/october_demo\/themes\/demo",
      "is_active": false,
      "is_locked": false,
      "hasCustomData": false,
      "custom_data": {
        "id": 8,
        "theme": "demo",
        "data": [],
        "created_at": "2023-11-16 19:38:29",
        "updated_at": "2023-11-16 19:38:29"
      },
      "hasParent": false,
      "parent": null,
      "preview_image": "http:\/\/localhost:8006\/themes\/demo\/assets\/images\/theme-preview.png",
      "product_code": "october.demo",
      "composer_code": "october\/demo-theme",
      "latest_version": "0.0.0",
      "version_history": []
    },
    {
      "id": "nanosoft_gamal",
      "dirName": "nanosoftGamal",
      "path": "\/storage\/emulated\/0\/htdocs\/october_demo\/themes\/nanosoftGamal",
      "is_active": false,
      "is_locked": false,
      "hasCustomData": false,
      "custom_data": {
        "id": 9,
        "theme": "nanosoftGamal",
        "data": [],
        "created_at": "2023-11-16 19:38:29",
        "updated_at": "2023-11-16 19:38:29"
      },
      "hasParent": false,
      "parent": null,
      "preview_image": "http:\/\/localhost:8006\/modules\/cms\/assets\/images\/default-theme-preview.png",
      "product_code": "",
      "composer_code": "",
      "latest_version": "0.0.0",
      "version_history": []
    }
  ]
}
```

### Get Data Themes 

**لجلب بيانات ثيم معين  بستخدام الرابط التالي مع تمرير اسم الثيم ضمن  البراميتر name**

GET http://localhost:8006/api/v1/cms/themes/data

Required Parameters: `name`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `name`           | `string`  | **Required**. The id          |

**فى حالة عدم تمرير اسم الثيم يتم ارجاع بينات الثيم النشط **
#### Example 2 get Data Static Pages name=abouts

```
GET http://localhost:8006/api/v1/cms/themes/data?name=tss
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": {
    "id": "tss",
    "dirName": "tss",
    "path": "\/storage\/emulated\/0\/htdocs\/october_demo\/themes\/tss",
    "is_active": false,
    "is_locked": false,
    "hasCustomData": true,
    "custom_data": {
      "id": 1,
      "theme": "tss",
      "data": {
        "website_name": "Nano Soft Web Systems",
        "website_author": "Nano Soft  Eng\/ Dheia Ali Al-Shami",
        "website_url": "http:\/\/nanosoft.com",
        "description": "Free Modern Theme based on",
        "keywords": "nano,soft,web,systems,themes,templates",
        "contact": "قالوا عنا كذا وكذا وكذا وكذا",
        "phone": "770529482",
        "email": "kddd90@gmail.com",
        "meta_title": "Squad",
        "meta_description": "Squad Bootstrap Template",
        "load_google_fonts": true,
        "google_font_family": "Roboto+Slab:300,400,700|Raleway:300,300i,400,400i,700,700i",
        "load_fontawesome": true,
        "load_material_icons": true,
        "load_stroke7_icons": true,
        "load_jQuery": true,
        "jQuery_version": "2.2.4",
        "load_octobercms_framework": true,
        "main_content_layout": "",
        "page_header_style": "",
        "website_theme": "",
        "page_header_fixed": true,
        "brand_primary": "#3f9ce8",
        "body_bg": "#f0f2f5",
        "body_color": "#575757",
        "body_color_dark": "#171717",
        "header_bg": "#ffffff",
        "sidebar_bg": "#ffffff",
        "load_animate_css": true,
        "load_wow_js": true,
        "load_owl_carousel": true
      },
      "created_at": "2022-01-10 14:06:51",
      "updated_at": "2022-01-10 14:06:51",
      "website_name": "Nano Soft Web Systems",
      "website_author": "Nano Soft  Eng\/ Dheia Ali Al-Shami",
      "website_url": "http:\/\/nanosoft.com",
      "description": "Free Modern Theme based on",
      "keywords": "nano,soft,web,systems,themes,templates",
      "contact": "قالوا عنا كذا وكذا وكذا وكذا",
      "phone": "770529482",
      "email": "kddd90@gmail.com",
      "meta_title": "Squad",
      "meta_description": "Squad Bootstrap Template",
      "load_google_fonts": true,
      "google_font_family": "Roboto+Slab:300,400,700|Raleway:300,300i,400,400i,700,700i",
      "load_fontawesome": true,
      "load_material_icons": true,
      "load_stroke7_icons": true,
      "load_jQuery": true,
      "jQuery_version": "2.2.4",
      "load_octobercms_framework": true,
      "main_content_layout": "",
      "page_header_style": "",
      "website_theme": "",
      "page_header_fixed": true,
      "brand_primary": "#3f9ce8",
      "body_bg": "#f0f2f5",
      "body_color": "#575757",
      "body_color_dark": "#171717",
      "header_bg": "#ffffff",
      "sidebar_bg": "#ffffff",
      "load_animate_css": true,
      "load_wow_js": true,
      "load_owl_carousel": true
    },
    "hasParent": false,
    "parent": null,
    "preview_image": "http:\/\/localhost:8006\/themes\/tss\/assets\/images\/theme-preview.png",
    "product_code": "october.demo",
    "composer_code": "october\/demo-theme",
    "latest_version": "0.0.0",
    "version_history": []
  }
}
```


**فى حالة استخدام تعدد اللغات وارجع المحتوي بالغه الانجليزية نقوم بتمرير وسم اللغه ضمن الهيدار الخاص بالطلب  **

Header Parameters
```json
{
  "Accept-Language":"en"
}
```

```
GET http://localhost:8006/api/v1/cms/themes/data?name=tss
```

```json
{
  "data": {
    "id": "tss",
    "dirName": "tss",
    "path": "\/storage\/emulated\/0\/htdocs\/october_demo\/themes\/tss",
    "is_active": false,
    "is_locked": false,
    "hasCustomData": true,
    "custom_data": {
      "id": 1,
      "theme": "tss",
      "data": {
        "website_name": "Nano Soft Web Systems",
        "website_author": "Nano Soft  Eng\/ Dheia Ali Al-Shami",
        "website_url": "http:\/\/nanosoft.com",
        "description": "Free Modern Theme based on",
        "keywords": "nano,soft,web,systems,themes,templates",
        "contact": "قالوا عنا كذا وكذا وكذا وكذا",
        "phone": "770529482",
        "email": "kddd90@gmail.com",
        "meta_title": "Squad",
        "meta_description": "Squad Bootstrap Template",
        "load_google_fonts": true,
        "google_font_family": "Roboto+Slab:300,400,700|Raleway:300,300i,400,400i,700,700i",
        "load_fontawesome": true,
        "load_material_icons": true,
        "load_stroke7_icons": true,
        "load_jQuery": true,
        "jQuery_version": "2.2.4",
        "load_octobercms_framework": true,
        "main_content_layout": "",
        "page_header_style": "",
        "website_theme": "",
        "page_header_fixed": true,
        "brand_primary": "#3f9ce8",
        "body_bg": "#f0f2f5",
        "body_color": "#575757",
        "body_color_dark": "#171717",
        "header_bg": "#ffffff",
        "sidebar_bg": "#ffffff",
        "load_animate_css": true,
        "load_wow_js": true,
        "load_owl_carousel": true
      },
      "created_at": "2022-01-10 14:06:51",
      "updated_at": "2022-01-10 14:06:51",
      "website_name": "Nano Soft Web Systems",
      "website_author": "Nano Soft  Eng\/ Dheia Ali Al-Shami",
      "website_url": "http:\/\/nanosoft.com",
      "description": "Free Modern Theme based on",
      "keywords": "nano,soft,web,systems,themes,templates",
      "contact": "قالوا عنا كذا وكذا وكذا وكذا",
      "phone": "770529482",
      "email": "kddd90@gmail.com",
      "meta_title": "Squad",
      "meta_description": "Squad Bootstrap Template",
      "load_google_fonts": true,
      "google_font_family": "Roboto+Slab:300,400,700|Raleway:300,300i,400,400i,700,700i",
      "load_fontawesome": true,
      "load_material_icons": true,
      "load_stroke7_icons": true,
      "load_jQuery": true,
      "jQuery_version": "2.2.4",
      "load_octobercms_framework": true,
      "main_content_layout": "",
      "page_header_style": "",
      "website_theme": "",
      "page_header_fixed": true,
      "brand_primary": "#3f9ce8",
      "body_bg": "#f0f2f5",
      "body_color": "#575757",
      "body_color_dark": "#171717",
      "header_bg": "#ffffff",
      "sidebar_bg": "#ffffff",
      "load_animate_css": true,
      "load_wow_js": true,
      "load_owl_carousel": true
    },
    "hasParent": false,
    "parent": null,
    "preview_image": "http:\/\/localhost:8006\/themes\/tss\/assets\/images\/theme-preview.png",
    "product_code": "october.demo",
    "composer_code": "october\/demo-theme",
    "latest_version": "0.0.0",
    "version_history": []
  }
}
```


**فى حالة عدم تمرير اسم الثيم يتم ارجع بيانات الثيم النشط كالتالي **

```
GET http://localhost:8006/api/v1/cms/themes/data
```

```json
{
  "data": {
    "id": "nano-themes",
    "dirName": "nano-themes",
    "path": "\/storage\/emulated\/0\/htdocs\/october_demo\/themes\/nano-themes",
    "is_active": true,
    "is_locked": false,
    "hasCustomData": true,
    "custom_data": {
      "id": 2,
      "theme": "nano-themes",
      "data": {
        "website_name": "نانو سوفت",
        "website_url": "http:\/\/naon2soft.com",
        "meta_title": "نانو 2 سوفت للبرمجيات وتقنية المعلومات",
        "meta_description": "نانو 2 سوفت للبرمجيات وتقنية المعلومات",
        "meta_keywords": "نانو سوفت , برمجيات , انظمة , شركة , تصميم , مواقع",
        "website_baner_type": "text",
        "address": "Yemen IBB",
        "work_time": "",
        "map_type": "link",
        "map_link": "",
        "map_content": "",
        "website_author": "Nano 2 Soft",
        "website_author_name": "Nano 2 Soft  Eng\/ Dheia Ali Al-Shami  00967770529482",
        "author_web": "https:\/\/nano2soft.com",
        "author_phone": "00967770529482",
        "author_email": "info@nano2soft.com",
        "author_address": "Yemen IBB",
        "load_google_fonts": "1",
        "google_font_family": "Roboto+Slab:300,400,700|Raleway:300,300i,400,400i,700,700i",
        "load_fontawesome": "1",
        "load_material_icons": "1",
        "load_stroke7_icons": "1",
        "load_jQuery": "1",
        "jQuery_version": "2.2.4",
        "load_octobercms_framework": "1",
        "main_content_layout": "",
        "page_header_style": "",
        "website_theme": "",
        "page_header_fixed": "1",
        "brand_primary": "#3f9ce8",
        "brand_secondary": "#3f9ce8",
        "body_bg": "#f0f2f5",
        "body_color": "#575757",
        "body_color_dark": "#171717",
        "header_bg": "#ffffff",
        "sidebar_bg": "#ffffff",
        "load_animate_css": "1",
        "load_wow_js": "1",
        "load_owl_carousel": "1",
        "website_baner": "\/favicon.png",
        "website_baner_about": "",
        "website_baner_story": "",
        "website_baner_goles": "",
        "phone": "[{\"phone_label\":\"\",\"phone_number\":\"770529482\",\"phone_type\":\"mobile\",\"sort_show\":\"1\",\"is_default\":\"1\",\"is_show\":\"1\",\"phone_note\":\"\"}]",
        "email": null,
        "accounts": null,
        "custom_css": "",
        "custom_js": "",
        "is_allow_locale_picker": "0",
        "is_allow_header_search": "0",
        "is_allow_user_nav": "0",
        "is_allow_icon_share": "0",
        "is_allow_scroll_call": "0",
        "is_allow_floating_whatsapp": "0",
        "is_allow_scroll_top": "0",
        "is_allow_loader": "0",
        "is_allow_subscribe": "0",
        "is_allow_unsubscribe": "0"
      },
      "created_at": "2022-06-26 13:07:42",
      "updated_at": "2023-08-21 19:23:49",
      "website_name": "نانو سوفت",
      "website_url": "http:\/\/naon2soft.com",
      "meta_title": "نانو 2 سوفت للبرمجيات وتقنية المعلومات",
      "meta_description": "نانو 2 سوفت للبرمجيات وتقنية المعلومات",
      "meta_keywords": "نانو سوفت , برمجيات , انظمة , شركة , تصميم , مواقع",
      "website_baner_type": "text",
      "address": "Yemen IBB",
      "work_time": "",
      "map_type": "link",
      "map_link": "",
      "map_content": "",
      "website_author": "Nano 2 Soft",
      "website_author_name": "Nano 2 Soft  Eng\/ Dheia Ali Al-Shami  00967770529482",
      "author_web": "https:\/\/nano2soft.com",
      "author_phone": "00967770529482",
      "author_email": "info@nano2soft.com",
      "author_address": "Yemen IBB",
      "load_google_fonts": "1",
      "google_font_family": "Roboto+Slab:300,400,700|Raleway:300,300i,400,400i,700,700i",
      "load_fontawesome": "1",
      "load_material_icons": "1",
      "load_stroke7_icons": "1",
      "load_jQuery": "1",
      "jQuery_version": "2.2.4",
      "load_octobercms_framework": "1",
      "main_content_layout": "",
      "page_header_style": "",
      "website_theme": "",
      "page_header_fixed": "1",
      "brand_primary": "#3f9ce8",
      "brand_secondary": "#3f9ce8",
      "body_bg": "#f0f2f5",
      "body_color": "#575757",
      "body_color_dark": "#171717",
      "header_bg": "#ffffff",
      "sidebar_bg": "#ffffff",
      "load_animate_css": "1",
      "load_wow_js": "1",
      "load_owl_carousel": "1",
      "website_baner": "\/favicon.png",
      "website_baner_about": "",
      "website_baner_story": "",
      "website_baner_goles": "",
      "phone": [
        {
          "phone_label": "",
          "phone_number": "770529482",
          "phone_type": "mobile",
          "sort_show": "1",
          "is_default": "1",
          "is_show": "1",
          "phone_note": ""
        }
      ],
      "email": null,
      "accounts": null,
      "custom_css": "",
      "custom_js": "",
      "is_allow_locale_picker": "0",
      "is_allow_header_search": "0",
      "is_allow_user_nav": "0",
      "is_allow_icon_share": "0",
      "is_allow_scroll_call": "0",
      "is_allow_floating_whatsapp": "0",
      "is_allow_scroll_top": "0",
      "is_allow_loader": "0",
      "is_allow_subscribe": "0",
      "is_allow_unsubscribe": "0",
      "is_allow_header": 1,
      "is_allow_hero": 1,
      "is_allow_sidebar": 1
    },
    "hasParent": false,
    "parent": null,
    "preview_image": "http:\/\/localhost:8006\/themes\/nano-themes\/assets\/images\/theme-preview.png",
    "product_code": "",
    "composer_code": "",
    "latest_version": "1.0.1",
    "version_history": {
      "1.0.7": "Added PDF export for Wishlists",
      "1.0.6": "Added styles for reviews",
      "1.0.5": "Added terms and conditions checkbox",
      "1.0.4": "Added wishlists",
      "1.0.3": "Added default checkbox styles for custom fields",
      "1.0.2": "Added new on_sale filter",
      "1.0.1": "Initial release"
    }
  }
}
```

