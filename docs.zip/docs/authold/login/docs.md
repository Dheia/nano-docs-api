## auth/login

This endpoint allows you to `login user`.

/auth/login
### The Login object

#### Require Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `loginAttribute`           | `string`  |  login Attribute Name [username,email,mobile] deafult value in setting web  |
| `login`           | `string`  |  enter data login  |
| `password`           | `string`  |  password  |



#### other  Parameters  

** يمكن استخدام هذه البراميترات عند عدم استخدام البراميتر  login **



| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `username`           | `string`  |  username |
| `email`           | `string`  |  email |
| `mobile`           | `string`  |  mobile number  |


#### Response Type 

** في حالة الفشل سيتم ارجاع رقم الخطاء ورساله الخطاء كا التالي **


```
POST http://localhost:8006/api/v1/auth/login?login=dheiaAli6&loginAttribute=mobile
```

```html
Status: 400 error 
```

```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "رقم الهاتف غير صحيح "
  }
}
```

```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "تنسيق الخاصية  رقم الهاتف غير صالح"
  }
}
```
```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "تنسيق الخاصية  البريد الالكتروني غير صالح"
  }
}
```
### Example 1 login user

```
POST /api/v1/auth/login
```
```
http://localhost:8006/api/v1/auth/login?password=123456Dd&username=kddd90335@gmail.com&login2=dheiaAli5&email=kddd90335@gmail.com&mobile=7705294825
```

تسجيل الدخول عن طريق رقم الهاتف 
```
http://localhost:8006/api/v1/auth/login?password=123456Dd&login=7705294826&loginAttribute=mobile
```

#### Response

```html
Status: 400 error 
```

```json
{
  "code": "200",
  "message": "Login Success Full.",
  "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiMWM2OWMwNmQ1ODk2NWU3OTljNzQ4MzRmMmZjNDEyYjkzZWViMjAwNmY5MGU0OTdiZWI1MTYwNThkNjQ4MmQyNDU3YWM2MDRjZTAxNzYwNTUiLCJpYXQiOjE2NjU4NTY0MDAuOTE1MTkwOSwibmJmIjoxNjY1ODU2NDAwLjkxNTIyNjksImV4cCI6MTY5NzM5MjQwMC44ODMxNzQ5LCJzdWIiOiI1NDkiLCJzY29wZXMiOltdfQ.vGmWfmYNKYo3wz3q_SCxIm4x5Kv7yhfVQM5_UB5bjlxkTrabqoWNO3gzQ_ZrhjNJsP0s_uYu-l0AGfOdt_0WTTDP0qQ7PfT0RcGXugMubgRdOV36DjY8lfmfKha9ZfxGN-VKFsd3GWzMg4vMNpvzjdqNlXsD3NIXJPkIngUbd-KaJQ3jshutjksxWcm_cPE-6QF8iPamhkNrycBsSPzvfxB9qHVG66A_k2oPg3ByrNwUXJ5YLfueCCFkm3X_N0YWysoM2M-Ltc8BYjrOApuu7mQcMhj6CsJ3ebeTIn-by_7OwC1KuD1zDD489bogCbbkoVoyD2DN3cqSy9yhE0MhHjiYfv2S7xNQYn_0yU5Y6wtsMUfMQeoqhrVCpg5VRylPWYlCxsPZPeoQQ6KvRP71mQS_FiySABEFLLCJazjsoBnS1qXNWtbJVSvEMHO3TabgK1cyymOXpr4Y0PR8X7B7BMrWhIFMDzp9UgY7I8wGa4Z7JkO0HWvWs1R6CTNkkMx7D34kG0384ekN4vRh947Gy051UJ1T8zCeU-klmysdp8mAeY1EthDQmo9rjtlErHw4eleb5x14ZCZ533l0jkpS6aD9Y7Z6s86ND5zQkYzsrpCNZPz-gL2d6rHme4Jc2hFHpW9UlseXj1cOeTn43EDKEkqormhZvghWjeW3fE0axl4",
  "token_type": "Bearer",
  "expires_at": "2023-10-15T17:53:20.000000Z",
  "revoked": false,
  "user_id": 549,
  "persist_code": "$2y$10$S0oMYQMudrFzvVC0D9iXH.jjG9S3P6i99s7yY7UGbB94VfLbZO63m"
}
```

### Example 2 Register user

```
POST /api/v1/auth/login
```
```
http://localhost:8006/api/v1/auth/login?password=123456Dd&username=kddd90336@gmail.com&login2=dheiaAli6&email=kddd90336@gmail.com&mobile=7705294826
```

#### Response

```html
Status: 200 Ok 
```

```json
{
  "code": "200",
  "message": "Login Success Full.",
  "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiOTJiYjhkNWJjZjE4MWYxMjcyMjhlZjc5ODFmYzE5ZWFmOGY1ZjVjMWUxZjg5ZWEzMDVhMDNiMzMxZjM2OWUxYjMzZDA3NWFkM2FlMGE3YTMiLCJpYXQiOjE2NjU4NTUyODcuOTM4NDI1MSwibmJmIjoxNjY1ODU1Mjg3LjkzODQ3NDksImV4cCI6MTY5NzM5MTI4Ny45MDM3Mzk5LCJzdWIiOiI1NDkiLCJzY29wZXMiOltdfQ.uKRNZo1MNtDmdjR3pk00JjPoyE6IcJMvqdqMEOhR7syyw_a584gH4rMW9Jp4Rqq7Rc6ttM9UvKoDUk6Y38oA6elU96PcSk8nRsWZ_grSR7EwSX4DgW8qhEfVGUUm8GRceen12OBYnB3-sHOluVGWotFJdYYjWtWc9pw9otX3a8ZcC1kM3FZDqusYkPRuQiG4PiCsaRL1dRiMyp5cEc1JPma0aZL9iOBqwwB9sJYd9_wYz8S-ZEWBAGXwqbOkhZ9_GYwnfckQlgKiO1pDuX_Au_F138E659BFKNXibvU8rUTi9q15smFJ8icUBHrUhzIcQFjfdgqPQfGXkanJr5BcpByZbQMEqPhe18IBGduNaE53wClR4UL3ighFSmZWUa1ebdq6oKama5-DWDUVF18pi_owiTlkfHyXF-2aEvT-myxC7_9jvfbC3KVrOGCRuHiwWBALcdYP45ogSo7-RVCAupQi9TGrkzU85tEKCuo-JYQ3ATHjCmuW0bHsazM9je2vIe6j_-56v7YBaMR7vxoJ1kk-1rLoiEOg_IbRJ9XuQDCMk7gCOZLS9TmYvLm2oBe4VjTw7GVB8GxwB3mC8OwrcVyubTvNHTgvZH8BOrJDF349uQea4PGvXgySNktMo490zUQqn56uCCcBry3glHpdw-MYbBD5mGt5ma3AP4riLXE",
  "token_type": "Bearer",
  "expires_at": "2023-10-15T17:34:47.000000Z",
  "revoked": false,
  "user_id": 549,
  "persist_code": "$2y$10$S0oMYQMudrFzvVC0D9iXH.jjG9S3P6i99s7yY7UGbB94VfLbZO63m"
}
```

## Useing token in login 

add Parameters Authorization in headr request 

Authorization = [token_type token]

** Require Authorization in Header Request**

```html
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiOTJiYjhkNWJjZjE4MWYxMjcyMjhlZjc5ODFmYzE5ZWFmOGY1ZjVjMWUxZjg5ZWEzMDVhMDNiMzMxZjM2OWUxYjMzZDA3NWFkM2FlMGE3YTMiLCJpYXQiOjE2NjU4NTUyODcuOTM4NDI1MSwibmJmIjoxNjY1ODU1Mjg3LjkzODQ3NDksImV4cCI6MTY5NzM5MTI4Ny45MDM3Mzk5LCJzdWIiOiI1NDkiLCJzY29wZXMiOltdfQ.uKRNZo1MNtDmdjR3pk00JjPoyE6IcJMvqdqMEOhR7syyw_a584gH4rMW9Jp4Rqq7Rc6ttM9UvKoDUk6Y38oA6elU96PcSk8nRsWZ_grSR7EwSX4DgW8qhEfVGUUm8GRceen12OBYnB3-sHOluVGWotFJdYYjWtWc9pw9otX3a8ZcC1kM3FZDqusYkPRuQiG4PiCsaRL1dRiMyp5cEc1JPma0aZL9iOBqwwB9sJYd9_wYz8S-ZEWBAGXwqbOkhZ9_GYwnfckQlgKiO1pDuX_Au_F138E659BFKNXibvU8rUTi9q15smFJ8icUBHrUhzIcQFjfdgqPQfGXkanJr5BcpByZbQMEqPhe18IBGduNaE53wClR4UL3ighFSmZWUa1ebdq6oKama5-DWDUVF18pi_owiTlkfHyXF-2aEvT-myxC7_9jvfbC3KVrOGCRuHiwWBALcdYP45ogSo7-RVCAupQi9TGrkzU85tEKCuo-JYQ3ATHjCmuW0bHsazM9je2vIe6j_-56v7YBaMR7vxoJ1kk-1rLoiEOg_IbRJ9XuQDCMk7gCOZLS9TmYvLm2oBe4VjTw7GVB8GxwB3mC8OwrcVyubTvNHTgvZH8BOrJDF349uQea4PGvXgySNktMo490zUQqn56uCCcBry3glHpdw-MYbBD5mGt5ma3AP4riLXE
```

## Useing token in login 

add Parameters Authorization in headr request 

Authorization = [token_type token]

** Require Authorization in Header Request**

```html
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiOTJiYjhkNWJjZjE4MWYxMjcyMjhlZjc5ODFmYzE5ZWFmOGY1ZjVjMWUxZjg5ZWEzMDVhMDNiMzMxZjM2OWUxYjMzZDA3NWFkM2FlMGE3YTMiLCJpYXQiOjE2NjU4NTUyODcuOTM4NDI1MSwibmJmIjoxNjY1ODU1Mjg3LjkzODQ3NDksImV4cCI6MTY5NzM5MTI4Ny45MDM3Mzk5LCJzdWIiOiI1NDkiLCJzY29wZXMiOltdfQ.uKRNZo1MNtDmdjR3pk00JjPoyE6IcJMvqdqMEOhR7syyw_a584gH4rMW9Jp4Rqq7Rc6ttM9UvKoDUk6Y38oA6elU96PcSk8nRsWZ_grSR7EwSX4DgW8qhEfVGUUm8GRceen12OBYnB3-sHOluVGWotFJdYYjWtWc9pw9otX3a8ZcC1kM3FZDqusYkPRuQiG4PiCsaRL1dRiMyp5cEc1JPma0aZL9iOBqwwB9sJYd9_wYz8S-ZEWBAGXwqbOkhZ9_GYwnfckQlgKiO1pDuX_Au_F138E659BFKNXibvU8rUTi9q15smFJ8icUBHrUhzIcQFjfdgqPQfGXkanJr5BcpByZbQMEqPhe18IBGduNaE53wClR4UL3ighFSmZWUa1ebdq6oKama5-DWDUVF18pi_owiTlkfHyXF-2aEvT-myxC7_9jvfbC3KVrOGCRuHiwWBALcdYP45ogSo7-RVCAupQi9TGrkzU85tEKCuo-JYQ3ATHjCmuW0bHsazM9je2vIe6j_-56v7YBaMR7vxoJ1kk-1rLoiEOg_IbRJ9XuQDCMk7gCOZLS9TmYvLm2oBe4VjTw7GVB8GxwB3mC8OwrcVyubTvNHTgvZH8BOrJDF349uQea4PGvXgySNktMo490zUQqn56uCCcBry3glHpdw-MYbBD5mGt5ma3AP4riLXE
```

