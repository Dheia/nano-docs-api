## Accounts Balances

This endpoint allows you to `list`, `show` your balances.

/accounts/balances

**الجزء الخاص بجلب الرصيد المالي **

### The balances object

#### Public Parameters
| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `periods_id`           | `integer`  |  Number  periods accounts default value current periods |
| `departments_id`           | `integer`  |  Number  department id  default value current department |
| `cost_centers_id`           | `integer`  |  Number  cost_centers id  default value  * all|
| `currencys_id`           | `integer`  |  Number  currencys id  default value current|
| `person_id`           | `integer`  |  Number  person id  default value current user id|
| `person_type`           | `string`  | person type  default value current user type|
| `return_value`           | `string`  | [stock,debit,credit,all] default value = stock|


### get balances current user

```
POST /api/v1/accounts/balances
```

#### Response

```html
Status: 200 OK
```

```json```

### Example 1 get Balances User Accounts

POST http://localhost:8006/api/v1/accounts/balances

#### Response

```html
Status: 200 OK
```
**فى الحالة الافتراضية وعند عدم تمرير القيمة المطلوب ارجاعه سيتم ارجاع الرصيد النهائي للعميل ضمن المتغير data**
```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب رصيد الحساب  بنجاح",
  "error": null,
  "errors": [],
  "data": -8300,
  "input_data": [],
  "process_data": {
    "departments_id": "*",
    "cost_centers_id": "*",
    "is_relay": false,
    "person": null,
    "person_id": 3,
    "person_type": "RainLab\\User\\Models\\User",
    "with_currency": false,
    "return_value": "stock"
  }
}
```

**فى حالة كانت القيمة الراجعه بالسالب فان رصؤد الحساب دائن اما اذا كانت موجبه فان رصيد الحساب مدين**

**فى حالة اردنا ارجاع مجموع الحركات المدينه فقط نقوم بتمرير المتغير return_value بالقيمة debit**

```json
{
  "return_value": "debit"
}
```

```
POST https://alnaeem.nano2soft.com/api/v1/accounts/balances?return_value=debit
```
```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب رصيد الحساب  بنجاح",
  "error": null,
  "errors": [],
  "data": 0,
  "input_data": {
    "return_value": "debit"
  },
  "process_data": {
    "departments_id": "*",
    "cost_centers_id": "*",
    "is_relay": false,
    "person": null,
    "person_id": 3,
    "person_type": "RainLab\\User\\Models\\User",
    "with_currency": false,
    "return_value": "debit"
  }
}
```


**فى حالة اردنا ارجاع مجموع الحركات الدائنة فقط نقوم بتمرير المتغير return_value بالقيمة credit**

```json
{
  "return_value": "credit"
}
```

```
POST https://alnaeem.nano2soft.com/api/v1/accounts/balances?return_value=credit
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب رصيد الحساب  بنجاح",
  "error": null,
  "errors": [],
  "data": 8300,
  "input_data": {
    "return_value": "credit"
  },
  "process_data": {
    "departments_id": "*",
    "cost_centers_id": "*",
    "is_relay": false,
    "person": null,
    "person_id": 3,
    "person_type": "RainLab\\User\\Models\\User",
    "with_currency": false,
    "return_value": "credit"
  }
}
```

**فى حلة الرغبه بارجاع الرصيد الدائن والمدين بنفس الوقت **

```json
{
  "return_value": "*"
}
```

```
POST https://alnaeem.nano2soft.com/api/v1/accounts/balances?return_value=*
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب رصيد الحساب  بنجاح",
  "error": null,
  "errors": [],
  "data": {
    "accounts_id": "2-2-1231010001",
    "person_type": "RainLab\\User\\Models\\User",
    "periods_id": "1",
    "debit": "0.00000",
    "credit": "8300.00000",
    "stock": "-8300.00000",
    "debit_alien": null,
    "credit_alien": null,
    "stock_alien": null
  },
  "input_data": {
    "return_value": "*"
  },
  "process_data": {
    "departments_id": "*",
    "cost_centers_id": "*",
    "is_relay": false,
    "person": null,
    "person_id": 3,
    "person_type": "RainLab\\User\\Models\\User",
    "with_currency": false,
    "return_value": "*"
  }
}
```


**فى حلة الرغبه بارجاع الرصيد الدائن والمدين بنفس الوقت مع بيانات العملة **

```json
{
  "return_value": "*",
  "with_currency": 1
}
```

```
POST https://alnaeem.nano2soft.com/api/v1/accounts/balances?return_value=*&with_currency=1
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب رصيد الحساب  بنجاح",
  "error": null,
  "errors": [],
  "data": {
    "currency": {
      "id": 1,
      "code": "2-2-1",
      "name": "ريال يمني",
      "part_name": "فلس",
      "currency_code": "RYL",
      "currency_symbol": "ريال",
      "decimal_point": ".",
      "thousand_separator": ",",
      "place_symbol_before": 0,
      "factor": 2,
      "format": null,
      "rate": null,
      "min_rate": null,
      "max_rate": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_default": 1,
      "is_active": 1,
      "status": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 1,
      "created_by": null,
      "updated_by": null,
      "deleted_by": null,
      "created_at": "2022-10-24 21:34:39",
      "updated_at": "2022-10-24 21:34:39",
      "deleted_at": null
    },
    "accounts_id": "2-2-1231010001",
    "person_type": "RainLab\\User\\Models\\User",
    "periods_id": "1",
    "debit": "0.00000",
    "credit": "8300.00000",
    "stock": "-8300.00000",
    "debit_alien": null,
    "credit_alien": null,
    "stock_alien": null
  },
  "input_data": {
    "return_value": "*",
    "with_currency": "1"
  },
  "process_data": {
    "departments_id": "*",
    "cost_centers_id": "*",
    "is_relay": false,
    "person": null,
    "person_id": 3,
    "person_type": "RainLab\\User\\Models\\User",
    "with_currency": "1",
    "return_value": "*"
  }
}
```
