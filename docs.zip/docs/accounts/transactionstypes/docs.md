## TransactionsTypes

This endpoint allows you to `list`, `show` your transactionstypes.

/accounts/transactionstypes

**من خلال هذا الجزء يمكنك جلب انواع الحركات المالية بعدة طرق **


### The transactionstypes object

#### Public Parameters
| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in transactionstypes records |
| `orderBy`           | `string`  |  using orderBy transactionstypes records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy transactionstypes records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  transactionstypes default value true    |
| `isFavorites`           | `boolean` | useing get products where my Favorites default value false 
| 
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/accounts/transactionstypes?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `department`           | `belongsTo`  | The get department | 


### List transactionstypes

Returns a list of transactionstypes you’ve previously created.

```
GET /api/v1/accounts/transactionstypes
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": null,
      "name": "الارصدة الافتتاحية",
      "description": "الارصدة الافتتاحية",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 2,
      "code": null,
      "name": "سنند قبض",
      "description": " سند قبض",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 3,
      "code": null,
      "name": " سند دفع",
      "description": "  سند دفع",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 4,
      "code": null,
      "name": "قيود يومية",
      "description": "قيود يومية",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 5,
      "code": null,
      "name": " بيع",
      "description": "مبيعات",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 6,
      "code": null,
      "name": "شراء",
      "description": "مشتريات",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 7,
      "code": null,
      "name": "مرتجع بيع",
      "description": "مرتجع بيع",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 8,
      "code": null,
      "name": "مرتجع شراء",
      "description": "مرتجع شراء",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 9,
      "code": null,
      "name": "تحويل من الى",
      "description": "تحويل من الى",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 10,
      "code": null,
      "name": "بضاعة اول المدة",
      "description": "بضاعة اول المدة",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 11,
      "code": null,
      "name": "\tسند قيد",
      "description": "\tسند قيد",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 12,
      "code": null,
      "name": "الايرادات",
      "description": "الايرادات",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 13,
      "code": null,
      "name": "المصروفات",
      "description": "المصروفات",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 15,
      "code": null,
      "name": "اشعار دائن",
      "description": "اشعار دائن",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 16,
      "code": null,
      "name": "اشعار مدين",
      "description": "اشعار مدين",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    }
  ],
  "meta": {
    "pagination": {
      "total": 15,
      "count": 15,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

### Example 1 get List TransactionsType 

```
GET http://localhost:8006/api/v1/accounts/transactionstypes
```
#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": null,
      "name": "الارصدة الافتتاحية",
      "description": "الارصدة الافتتاحية",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 2,
      "code": null,
      "name": "سنند قبض",
      "description": " سند قبض",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 3,
      "code": null,
      "name": " سند دفع",
      "description": "  سند دفع",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 4,
      "code": null,
      "name": "قيود يومية",
      "description": "قيود يومية",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 5,
      "code": null,
      "name": " بيع",
      "description": "مبيعات",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 6,
      "code": null,
      "name": "شراء",
      "description": "مشتريات",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 7,
      "code": null,
      "name": "مرتجع بيع",
      "description": "مرتجع بيع",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 8,
      "code": null,
      "name": "مرتجع شراء",
      "description": "مرتجع شراء",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 9,
      "code": null,
      "name": "تحويل من الى",
      "description": "تحويل من الى",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 10,
      "code": null,
      "name": "بضاعة اول المدة",
      "description": "بضاعة اول المدة",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 11,
      "code": null,
      "name": "\tسند قيد",
      "description": "\tسند قيد",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 12,
      "code": null,
      "name": "الايرادات",
      "description": "الايرادات",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 13,
      "code": null,
      "name": "المصروفات",
      "description": "المصروفات",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 15,
      "code": null,
      "name": "اشعار دائن",
      "description": "اشعار دائن",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    },
    {
      "id": 16,
      "code": null,
      "name": "اشعار مدين",
      "description": "اشعار مدين",
      "ref_type": null,
      "ref_key_name": null,
      "ref_key_values": null,
      "max_transactions": null,
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "companys_id": null,
      "departments_id": null,
      "is_show": 1,
      "is_active": 1,
      "other_data": null,
      "config_data": null,
      "sort_order": null,
      "created_at": "",
      "updated_at": "",
      "object_type": "Tss\\Accounts\\Models\\TransactionsType"
    }
  ],
  "meta": {
    "pagination": {
      "total": 15,
      "count": 15,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```


### Show Data Record TransactionsType 

```
GET /api/v1/accounts/transactionstypes/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 3 Show Data Record TransactionsType 2

```
GET http://localhost:8006/api/v1/accounts/transactionstypes/2
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "id": 2,
  "code": null,
  "name": "سنند قبض",
  "description": " سند قبض",
  "ref_type": null,
  "ref_key_name": null,
  "ref_key_values": null,
  "max_transactions": null,
  "is_allow_add": 1,
  "is_allow_edit": 1,
  "is_allow_delete": 1,
  "companys_id": null,
  "departments_id": null,
  "is_show": 1,
  "is_active": 1,
  "other_data": null,
  "config_data": null,
  "sort_order": null,
  "created_at": "",
  "updated_at": "",
  "object_type": "Tss\\Accounts\\Models\\TransactionsType"
}
```
