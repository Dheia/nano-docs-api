## Deliverys  Api

This endpoint allows you to `list`, `show` your deliverys.

/deliverys/deliverys

**الجزء الخاص بالموصلين يمكنك من جلب بياناتهم والمركبات الخاصه بهم وعناوينهم**


### The deliverys object

#### Public Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in deliverys  records |
| `orderBy`           | `string`  |  using orderBy departments records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy departments records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  deliverys default value true    |
| `companys_id`           | `integer`  |  get records deliverys to companys_id default value false.         |
| `departments_id`           | `integer`  | get records deliverys to departments_id default value true.          |
| `isFavorites`           | `boolean `  | useing get deliverys where my Favorites default value false 
| 
| `include`           | `string `  | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/deliverys/deliverys?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `department`           | `belongsTo`  | The get department | 
| `cars`           | `hasMany`  | The get Deliverys   |
| `user`           | `belongsTo`  | The get user   | 
| `country`           | `belongsTo`  | The get country   | 
| `state`           | `belongsTo`  | The get state   | 
| `directorate`           | `belongsTo`  | The get directorate.   | 
| `address`           | `hasMany`  | The get address.   | 


### List deliverys

Returns a list of Deliverys’

```
GET /api/v1/deliverys/deliverys
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Example 1 get List Deliverys  

```
GET http://localhost:8006/api/v1/deliverys/deliverys
```

#### Response

```html
Status: 200 OK
```

```json```


### Show Data Record Delivery 

```
GET /api/v1/deliverys/deliverys/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record Delivery 2

```
GET http://localhost:8006/api/v1/deliverys/deliverys/2
```

##### Response

```html
Status: 200 Ok
```

```json```

### Check Last Update Delivery Data 

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/deliverys/deliverys/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/deliverys/deliverys/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": null
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2022-12-20 18:17:04",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": null
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **

### Get Data Record Delivery To Current User

** جلب بيانات الموصل بالاعتماد على حساب المستخدم الحالي **
```
GET /api/v1/deliverys/deliverys/me
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 3 Show Data Record Delivery To Current User

```
GET http://localhost:8006/api/v1/deliverys/deliverys/me
```

##### Response

```html
Status: 200 Ok
```

```json

```
### Create Account Delivery To Current User

** انشاء حساب موصل للمستخدم الحالي **

```
POST /api/v1/deliverys/deliverys/create
```


#### Example 4 Create Account Delivery To Current User

```
POST http://localhost:8006/api/v1/deliverys/deliverys/create
```
**نقوم بتمرير البيانات المطلوبه لنشاء حساب موصل ضمن الطلب **

** يجب تمرير بيانات المركبه ضمن مصفوفه باسم  car**

```
POST http://localhost:8006/api/v1/deliverys/deliverys/create?full_name=%D8%B6%D9%8A%D8%A7%D8%A1%20%D8%B9%D9%84%D9%8A%20%D9%85%D8%AD%D9%85%D8%AF%20%D8%A7%D9%84%D8%B4%D8%A7%D9%85%D9%8A&gender=male&marital_status=single&passport_type=card&passport_issuer=ibb&passport_number=1234567897&passport_release_at=2010-5-5&passport_expiry_at=2024-5-5&date_of_birth=1995-4-5&place_of_birth=ibb&country_id=246&state_id=636&image_passport_front2=&image_passport_behind2=&car[vehicle_type_id]=2

```

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم انشاء حساب موصل بنجاح ",
  "error": null,
  "errors": null,
  "delivery": {
    "companys_id": "2",
    "departments_id": "2",
    "is_active": false,
    "full_name": "سيف علي محمد الشامي",
    "user_id": 2,
    "gender": "male",
    "marital_status": "single",
    "passport_type": "card",
    "passport_issuer": "ibb",
    "passport_number": "1234567897",
    "passport_release_at": "2010-05-05 00:00:00",
    "passport_expiry_at": "2024-05-05 00:00:00",
    "date_of_birth": "1995-04-05 00:00:00",
    "place_of_birth": "ibb",
    "country_id": "246",
    "state_id": "636",
    "user_type": "RainLab\\User\\Models\\User",
    "mobile": "732993471",
    "email": "[{\"email_label\":\"\",\"email_text\":\"sssbas@gmail.com\",\"sort_show\":\"1\",\"is_default\":\"1\",\"is_show\":\"1\",\"email_note\":\"\",\"_group\":\"email\"}]",
    "status": "active",
    "type": "person",
    "groups_class_id": 2,
    "is_one_currency": false,
    "currencys_id": 1,
    "first_name": "سيف علي محمد الشامي",
    "last_name": "سيف علي محمد الشامي",
    "created_at": "2023-08-10 21:13:37",
    "updated_at": "2023-08-10 21:13:37",
    "id": 15,
    "image_passport_front": {
      "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/64d\/553\/015\/64d5530151db6827009378.png",
      "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/64d\/553\/015\/thumb_1584_160_160_0_0_crop.png",
      "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/64d\/553\/015\/thumb_1584_240_240_0_0_crop.png",
      "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/64d\/553\/015\/thumb_1584_800_800_0_0_crop.png",
      "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/64d\/553\/015\/thumb_1584_480_480_0_0_auto.png"
    },
    "image_passport_behind": {
      "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/64d\/553\/015\/64d55301521fc440117038.png",
      "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/64d\/553\/015\/thumb_1585_160_160_0_0_crop.png",
      "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/64d\/553\/015\/thumb_1585_240_240_0_0_crop.png",
      "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/64d\/553\/015\/thumb_1585_800_800_0_0_crop.png",
      "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/64d\/553\/015\/thumb_1585_480_480_0_0_auto.png"
    },
    "image": null,
    "images": [],
    "files": [],
    "ratings_count": 0,
    "countRating": 0,
    "sumRating": null,
    "averageRating": null,
    "user_is_rating": false,
    "user_object_rating": null,
    "favorites_count": 0,
    "user_is_favorite": false,
    "user_object_favorite": null,
    "object_type": "Nano\\Deliverys\\Models\\Delivery",
    "user": {
      "id": 2,
      "name": "",
      "username": "bashar",
      "email": "sssbas@gmail.com",
      "mobile": "732993471",
      "gender": null,
      "address_1": null,
      "address_2": null,
      "street_name": null,
      "street_number": null,
      "latitude": null,
      "longitude": null,
      "geo_components": null,
      "city": "",
      "zip": "",
      "postcode": null,
      "country_long": null,
      "country_id": null,
      "state_id": null,
      "directorate_id": null,
      "formataddress": null,
      "vicinity": null,
      "avatar": null,
      "companys_id": "2",
      "departments_id": "2",
      "employees_id": null,
      "ref_type": "user",
      "ref_id": null,
      "permissions": null,
      "is_guest": false,
      "is_superuser": false,
      "is_activated": true,
      "activated_at": "2022-11-13 22:28:27",
      "last_login": "2022-11-14 00:18:11",
      "created_at": "2022-11-13 22:28:27",
      "updated_at": "2022-11-14 00:18:11",
      "deleted_at": "",
      "created_ip_address": "5.255.11.253",
      "last_ip_address": "5.255.11.253",
      "object_type": "RainLab\\User\\Models\\User"
    }
  },
  "car": {
    "companys_id": "2",
    "departments_id": "2",
    "is_active": true,
    "vehicle_type_id": "2",
    "load_people": 2,
    "color": "'",
    "delivery_id": 15,
    "status": "active",
    "ref_type_vehicle_type": "LAND_MOTORCYCLES",
    "fuel_type": "petroleum",
    "name": "دراجة نارية متر",
    "created_at": "2023-08-10 21:13:37",
    "updated_at": "2023-08-10 21:13:37",
    "id": 4,
    "code": "2-2-4",
    "image": {
      "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/64d\/553\/015\/64d5530155d59476709309.png",
      "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/64d\/553\/015\/thumb_1586_160_160_0_0_crop.png",
      "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/64d\/553\/015\/thumb_1586_240_240_0_0_crop.png",
      "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/64d\/553\/015\/thumb_1586_800_800_0_0_crop.png",
      "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/64d\/553\/015\/thumb_1586_480_480_0_0_auto.png"
    },
    "image_front": null,
    "image_behind": null,
    "image_right": null,
    "image_left": null,
    "image_top": null,
    "images": [],
    "files": [],
    "object_type": "Nano\\Deliverys\\Models\\Car"
  }
}
```

**في حاله تم انشاء حساب موصل مسبقا سيتم ارجاع البيانات التاليه**

```json
{
  "code": 200,
  "status": true,
  "message": "تم انشاء حساب موصل من قبل بنجاح ",
  "error": null,
  "errors": null
}
```

**فى حالة وجود نفس الاسم سيتم ارجاع البيانات التاليه **

```json
{
  "code": 0,
  "status": false,
  "message": "لم يتم انشاء حساب موصل بنجاح ",
  "error": "الاسم موجود مسبقا لايمكن تكرار نفس الاسم ",
  "errors": null,
  "delivery_data_process": {
    "full_name": "ضياء علي محمد الشامي",
    "user_id": 2,
    "gender": "male",
    "marital_status": "single",
    "passport_type": "card",
    "passport_issuer": "ibb",
    "passport_number": "1234567897",
    "passport_release_at": "2010-5-5",
    "passport_expiry_at": "2024-5-5",
    "date_of_birth": "1995-4-5",
    "place_of_birth": "ibb",
    "country_id": "246",
    "state_id": "636",
    "image_passport_front2": "",
    "image_passport_behind2": "",
    "user_type": "RainLab\\User\\Models\\User",
    "mobile": "732993471",
    "email": "[{\"email_label\":\"\",\"email_text\":\"sssbas@gmail.com\",\"sort_show\":\"1\",\"is_default\":\"1\",\"is_show\":\"1\",\"email_note\":\"\",\"_group\":\"email\"}]",
    "companys_id": "2",
    "departments_id": "2",
    "is_active": false,
    "status": "active",
    "type": "person",
    "groups_class_id": 2,
    "is_one_currency": false,
    "currencys_id": 1
  },
  "input_data": {
    "full_name": "ضياء علي محمد الشامي",
    "user_id": "2",
    "gender": "male",
    "marital_status": "single",
    "passport_type": "card",
    "passport_issuer": "ibb",
    "passport_number": "1234567897",
    "passport_release_at": "2010-5-5",
    "passport_expiry_at": "2024-5-5",
    "date_of_birth": "1995-4-5",
    "place_of_birth": "ibb",
    "country_id": "246",
    "state_id": "636",
    "image_passport_front2": "",
    "image_passport_behind2": "",
    "car": {
      "vehicle_type_id": "2",
      "load_people": "4",
      "color": "'"
    }
  },
  "data_delivery": {
    "full_name": "ضياء علي محمد الشامي",
    "user_id": 2,
    "gender": "male",
    "marital_status": "single",
    "passport_type": "card",
    "passport_issuer": "ibb",
    "passport_number": "1234567897",
    "passport_release_at": "2010-5-5",
    "passport_expiry_at": "2024-5-5",
    "date_of_birth": "1995-4-5",
    "place_of_birth": "ibb",
    "country_id": "246",
    "state_id": "636",
    "image_passport_front2": "",
    "image_passport_behind2": "",
    "user_type": "RainLab\\User\\Models\\User",
    "mobile": "732993471",
    "email": "sssbas@gmail.com"
  },
  "data_car": {
    "vehicle_type_id": "2",
    "load_people": "4",
    "color": "'"
  },
  "debug": {
    "line": 690,
    "file": "\/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/deliverys\/models\/Delivery.php",
    "class": "October\\Rain\\Exception\\ApplicationException",
    "trace": [
      "#0 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/deliverys\/models\/Delivery.php(667): Nano\\Deliverys\\Models\\Delivery->preperName()",
      "#1 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/october\/rain\/src\/Database\/Traits\/Validation.php(233): Nano\\Deliverys\\Models\\Delivery->beforeValidate()",
      "#2 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/october\/rain\/src\/Database\/Traits\/Validation.php(82): Nano\\Deliverys\\Models\\Delivery->validate()",
      "#3 [internal function]: Nano\\Deliverys\\Models\\Delivery->October\\Rain\\Database\\Traits\\{closure}()",
      "#4 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/october\/rain\/src\/Support\/Traits\/Emitter.php(141): call_user_func_array()",
      "#5 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/october\/rain\/src\/Database\/Model.php(761): October\\Rain\\Database\\Model->fireEvent()",
      "#6 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/october\/rain\/src\/Database\/Model.php(814): October\\Rain\\Database\\Model->saveInternal()",
      "#7 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/deliverysapi\/apicontrollers\/Deliverys.php(511): October\\Rain\\Database\\Model->save()",
      "#8 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/deliverysapi\/apicontrollers\/Deliverys.php(279): Nano\\DeliverysApi\\APIControllers\\Deliverys->createDelivery()",
      "#9 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Database\/Concerns\/ManagesTransactions.php(29): Nano\\DeliverysApi\\APIControllers\\Deliverys->Nano\\DeliverysApi\\APIControllers\\{closure}()",
      "#10 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Database\/DatabaseManager.php(349): Illuminate\\Database\\Connection->transaction()",
      "#11 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Support\/Facades\/Facade.php(261): Illuminate\\Database\\DatabaseManager->__call()",
      "#12 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/deliverysapi\/apicontrollers\/Deliverys.php(343): Illuminate\\Support\\Facades\\Facade::__callStatic()",
      "#13 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Controller.php(54): Nano\\DeliverysApi\\APIControllers\\Deliverys->create()",
      "#14 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()",
      "#15 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Route.php(219): Illuminate\\Routing\\ControllerDispatcher->dispatch()",
      "#16 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Route.php(176): Illuminate\\Routing\\Route->runController()",
      "#17 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Router.php(681): Illuminate\\Routing\\Route->run()",
      "#18 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(130): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()",
      "#19 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/cart\/middleware\/CartMiddleware.php(10): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#20 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Nano\\Cart\\Middleware\\CartMiddleware->handle()",
      "#21 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/broadcast\/middleware\/UserAppId.php(34): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#22 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Nano\\Broadcast\\Middleware\\UserAppId->handle()",
      "#23 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Cookie\/Middleware\/AddQueuedCookiesToResponse.php(37): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#24 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()",
      "#25 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Cookie\/Middleware\/EncryptCookies.php(67): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#26 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()",
      "#27 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Middleware\/SubstituteBindings.php(41): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#28 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()",
      "#29 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Middleware\/ShareErrorsFromSession.php(49): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#30 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()",
      "#31 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Session\/Middleware\/StartSession.php(56): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#32 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Illuminate\\Session\\Middleware\\StartSession->handle()",
      "#33 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Middleware\/ThrottleRequests.php(59): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#34 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Illuminate\\Routing\\Middleware\\ThrottleRequests->handle()",
      "#35 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/cors\/classes\/HandleCors.php(38): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#36 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Nano\\CORS\\Classes\\HandleCors->handle()",
      "#37 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(105): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#38 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Router.php(683): Illuminate\\Pipeline\\Pipeline->then()",
      "#39 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Router.php(658): Illuminate\\Routing\\Router->runRouteWithinStack()",
      "#40 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Router.php(624): Illuminate\\Routing\\Router->runRoute()",
      "#41 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/october\/rain\/src\/Router\/CoreRouter.php(31): Illuminate\\Routing\\Router->dispatchToRoute()",
      "#42 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Foundation\/Http\/Kernel.php(170): October\\Rain\\Router\\CoreRouter->dispatch()",
      "#43 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(130): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()",
      "#44 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/securityheaders\/classes\/SecurityHeaderMiddleware.php(18): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#45 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Nano\\SecurityHeaders\\Classes\\SecurityHeaderMiddleware->handle()",
      "#46 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Foundation\/Http\/Middleware\/CheckForMaintenanceMode.php(63): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#47 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/october\/rain\/src\/Foundation\/Http\/Middleware\/CheckForMaintenanceMode.php(23): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()",
      "#48 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()",
      "#49 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/broadcast\/middleware\/UserAppId.php(34): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#50 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Nano\\Broadcast\\Middleware\\UserAppId->handle()",
      "#51 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/cors\/classes\/HandleCors.php(38): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#52 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Nano\\CORS\\Classes\\HandleCors->handle()",
      "#53 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/securityheaders\/classes\/NonceGeneratorMiddleware.php(19): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#54 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Nano\\SecurityHeaders\\Classes\\NonceGeneratorMiddleware->handle()",
      "#55 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(105): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#56 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Foundation\/Http\/Kernel.php(145): Illuminate\\Pipeline\\Pipeline->then()",
      "#57 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Foundation\/Http\/Kernel.php(110): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()",
      "#58 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()",
      "#59 {main}"
    ]
  }
}
```

**فى حالة عدم ارسال كافة الحقو المطلوبه سيتم ارجاع البيانات التاليه **

```json
{
  "code": 0,
  "status": false,
  "message": "لم يتم انشاء حساب موصل بنجاح ",
  "error": "The country id field is required.",
  "errors": {
    "country_id": [
      "The country id field is required."
    ],
    "state_id": [
      "The state id field is required."
    ]
  },
  "delivery_data_process": {
    "full_name": "ضياء علي محمد الشامي",
    "user_id": 3,
    "gender": "male",
    "marital_status": "single",
    "passport_type": "card",
    "passport_issuer": "ibb",
    "passport_number": "1234567897",
    "passport_release_at": "2010-5-5",
    "passport_expiry_at": "2024-5-5",
    "date_of_birth": "1995-4-5",
    "place_of_birth": "ibb",
    "country_id2": "246",
    "state_id2": "636",
    "image_passport_front2": "",
    "image_passport_behind2": "",
    "user_type": "RainLab\\User\\Models\\User",
    "mobile": "770821911",
    "email": "[{\"email_label\":\"\",\"email_text\":\"test@gmail.com\",\"sort_show\":\"1\",\"is_default\":\"1\",\"is_show\":\"1\",\"email_note\":\"\",\"_group\":\"email\"}]",
    "companys_id": "2",
    "departments_id": "2",
    "is_active": false,
    "status": "active",
    "type": "person",
    "groups_class_id": 2,
    "is_one_currency": false,
    "currencys_id": 1,
    "image_passport_front": "data:image\/png;base64,\/9j\/4AAQSkZJRgABAQAAAQABAAD\/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH\/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH\/wAARCAAyADIDASIAAhEBAxEB\/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL\/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6\/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL\/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6\/9oADAMBAAIRAxEAPwD+\/iivn+b9pb4Y2v7Tlt+yZe3V7YfFLUPhYnxf0eK+m8O2ula74V\/4SDUfD88Ghxy+Il8Q6pqtjc6Xe3V9Fa+HX0220+CeeTVjLFPAtj4b\/tF\/Dn4q2nx1vfCr6jJF+z98SvF\/wq8erctoLSP4m8HeGvD\/AIm1abSBp2v6ip02Ww8QWkdlJrLaTqL3cV6l1pltbxRXMvS8Hiox53QqKHsqNbmcfd9jXm6dGpe9uWpOLjF\/zJpu6d+KOY4CdR0oYqjKoq+Iwzgpe8sRhaaq4ik1vz0abVSa6Qad2nzP3iv52v2hPhZ+2n+3v+3l+054R+Dv7THxJ\/ZX+Hv7E2n\/AAu0XwxH4F1LxtfaJ8dPiH4w8D6T8TrrQvFWl6T8avhbYaOtrFfaVpUl19l1C3Gm3jve6nHJcLCn65eD\/wBs74PeOf2Qbz9tbw9D4kuvhLY+E\/HHjGe1EfhWbxX\/AGZ4C1zxFoHiG2WCy8XXnhv+0Yr\/AMNaikUL+KFt0AjS\/vLS4W5gj+NviR420r4d+L\/hj+2B8FPirYeBfBH\/AAUTt\/gz8IhpsmkeD9QC\/GPxp4K1rVfg\/wDHG8m1XxBrPhzX9f8ADvg3SLjwjrXhLw\/JajxQth4asdS1zXLLSdIlsffyGONy7E4+cMPCnjVTr5fhKmLw0cRRoZhRxOHq4ulOlKlXh7V4Gji6S56U0pVLxcai9rH5LiiWW5zgcrpzxlWtlkq+EzfH0cBjJYTEYzKK2HxlDAV6VenXw1VYf+06+ArydOvTcoQSm50lUpT+2v2J\/iz4z+Of7JvwM+KXxG8OHwp498ReC7e38b+HzdX12bDxd4d1HUfCviE+fqJe+\/0zVNEur4Q3dxeXFuJxayarqLRHU5vyN\/YN\/wCC5sX7Zn7d\/iL9li6+F\/hTwx4B8Sf8LD\/4UX460nX\/ABde+IPE\/wDwgVlqmvJ\/bmn6l4ZtLYf8Jd4Q0XWPFtp9qtfDH\/COxWD6Def2trFzaA\/Tuq\/t9+B\/2cL7xZ8Afgh+y38afjB4L\/Zv0+38OeNfGvw1gn8VeGPDt7p9rqF5r8\/ivxFHN4rvoNSS5stXv\/FGueNdXTxDfa5D4i1LxFPNqcWp38n50\/8ABJT\/AIJFWPws\/aW8Fft7eH\/i14R8U\/CiDSfH+pfCTwdpum+IB4n0OfxroXiXwRLpWvaivibVtH\/tDwdpOsa14f1aCbVvETyX4kNylrq8Md1D2ZbT4bnhOLcTmtJ4erVw858OUr1r061SeMq0qaVKc1GcWsHB+3k4+wlX96V5yXk5pi+L\/wC0eAsBw9io4yhhsZTo8aVeWh+9w1D6jh8RWcq9Km505JY+fNg48yxTw14pqKP6jaKKK+LP1A\/l+\/4KM\/Efxn8Jf29dd\/aR8N2qXqfsT6x8FvjTrUccGm3F4\/wf+KWk\/Dv4P\/HjR7PTNS1DTbXXtW1\/SpfBSeH7dr\/Tb\/TLyzvNQ03XrFHvobjb+FX7Qw8F\/sl\/8FWPiJ8Nby1u9T+MX\/BQTxL4N+Gs2q6ReSWeoxfFT4ffBOKeS8tJ5LKTTJm8D3OvX1lNqRjjs9Whs47y3mkIspP1Ff8AZvtvEP7df7RfjHxpYaJ48+Ffx0\/Z0034QeJ\/DI0661Wz0uYWmgw634c+IIeBdNsLfxB4esYrvS7Q3cmo6hZ6vFIbK2t0hvp\/zi\/Y1\/4JUeLPhNZaZ+z946+I\/wAOvF3w\/wDBP7ZXjX9ofVrHR9R8XyWPjXwLbfD7wl4O8JeGtOhurSyudT8X+EPEfhQaf8R9LudUfSfCMeq20La74jv5JdJk+0w+Y5fU4cr4TETUMZhPqNOho5fWcDPFxxlSilaylhcTTrTabSmsY2k3Gcn+UYnJ88o8VrHYKk6mBzGvnE8Q+dReDzJYavluHxTfNrDG4CvhoqUVKdJ5dFTbTjA4L9mXxL4s\/Z9\/Zr\/4K+fsoeKLexj8Qfs+\/Fe\/+KHh7SLhE1IzeCvjNB4e8V2Carr2j3VvY6jDqVpFBdfZLd7LXdMOp3trPdJLFaRWvybcaxqfwZ0P9n\/\/AIJ8eK7iP7b+zJ\/wWP8A2YfF3wjhEMd7f337OXxj0b47eNPh9qniDxLp8VvpepeI2nvr0azZyadpWp2N1O1v9jnsI7ecfoM3\/BNvRtM8UftL\/Ef9jbw9qXww+C3xU\/ZF8Q\/CfxF4D8Wat8Vde1T4kfF6P4i+G\/Fvgj4k6Bca3rPxGi8U+GU8NaTqujJrllrNtqmkNdxRaRoOo2Ota1NH7N+1V\/wTovP2ufjz+wj+2R4Ev\/C3wp1D4B+JfCd\/8aIPiPous6B4o8YfD7wF4h03xHoV7ZT6XHqlhd6jo8+l6tbaLFr\/APZdtL4f8RS6lP4ohg0200Kf2cLnOUrNcTOrin9UzHDYbGzrVKHs6mHzvCZe6fNVoQq4hU3i5\/XqTjCrVcfrtK9aahOUvCr8OcQTyXDUqGDX17J8TUy6lh6WJdahjeGsbntStKOHxVWjg\/axy+msqruVWhQUv7Pqxhh4uVNro\/2RJ9Jb4N\/Bq7Gr6ynxK+JPxn+N3jqwsLS30s6PrviIfHf4fTeKdc1t7zTHg0zTdJ0mIRHT9JvLGaazv7\/+zNNv9Zj06W3+o\/8AgnXbR6T8K\/jR4Wsyy6P4Q\/ak+PGhaBbud72elN4jtNZ+zNcMPPuit9rF9Is908tzslSJ5mSOMD89\/EFz8df2SfG3jjwj4E\/Z5+NX7RHgyfxL41+Kv7Mfjj9nXW\/i\/YeB\/h3pPxH8Vy65deAPG8fgjwreaH4\/tdO1rwxo97qHhjxff+MvDUumrAi6TDY6jqOly\/ef7G3iH4U\/AHSPD\/7J\/wAQfj78Gde\/ar8R6p4z+JfxE8F6N8QfCsXjfWPGPjDULrxnflvAl9qWmeLxfw+GriyuUiXwnp8DaBpkuqwafa6ZFg\/Czo1KlPEeypyqf8vmqcXNxpQlUnOrOME3ThSjKMJOpblk5pPlV3+k5fXpUcThYV5woOlTWEcqrdKE8RUjRpUqFOdRxhXrYupSq1qSoOanSpwlLlqLX9EKKKK8w+rPk7x14n8BeBfjbY61Bepouv3sulf8LB1S5ttev4Lrw1D4e1S3s9PtbaCDUIYr55f7EkSTT7OEeTHL9pvlkNzG\/LaD8XvA\/wDwn2l6lq\/iC3tNJ8Oal8WLqzv4dJ8QvHqNt4y8Q2t\/pIWBNNubz7QlnvN6Li2sYobiKZYnnjNuZPzy\/bd\/4JE\/D\/8Aay\/aY+L\/AMYdW\/aS1\/4e6p8XPA\/gHwBqnhSy8A2msWlhb+F\/+ES+w3Fjq8\/ifS0ur69uNE0yWW1nt3FoL6HMe6Wznb491X\/ghB8N\/Heuay2g\/t6fEyyl8V6x41m1LTtC+G832i7bxF4esV8Wad4gaHxtH5ljrGk+C4jerq0EMOtNElpM17JNplqfrsHl\/ClXD0JYriWvh686EHiKayjF1Y0KrpRc6SqQhJTUZzqU4zXuuNPnTtJRPzbH5tx1h8ZjaeB4NwuLw0MbU+qVXnuAoPFUYYqqqdeVKpUhKk6tOjQxM6b9\/wBpVlSk3KDm\/wB6vhB8WPhr4I+EvhPwfr\/xBmvtY0vw3YafdRy6BrL2+nzw6bDbNpen3Gm+EbBbjTrWSNvstxei61F1d2utQnxGB4v+2P4l8P8Axq\/Yj+OHwN+GnjfS7f4i+OfhHe+DfDh1bSvE1npDavPY29vLbXd\/N4U1CG2guoo57UXT2rrGZUkDwkfak\/Kjwh\/wQk+Efh298Can4Z\/bH161tfAXjvw9qNglt8OdIsYr3xNpf9q\/2ZYXdzb+NrWL7VJc6lrNzpktvGtxGdSvGtHke8uLifmZv+CAPwj8Ja58M\/GGr\/tteI9OXwMYDo9tqnw60W0t7+yXxXrHiS807U4pvHsc9tBqsut3mm6paFbcXNlNJDPAZJp9\/ZhsFwhhsVTxVPinEe0w9aliKPPkeMlGdWjUnUhGcFHSLnGnzLm+Go9W4yb4cVmfiBicvrYCrwRhPZYrC1MBXdPiTBRnTw9anToVJ06sp3dSMK1eUG4J89KCt+8uv0w\/4JZxJ+yb+xL8L\/gb8dfHmgz+PfC134qkuoPDmn+JNV0vTdJ1LxFfX2jaWmpW3gzSorue0spIvtEojum8xir6jdOrPX5gTf8ABPzxN4w\/4Ld6H+17ZePdDb4HX\/xj8OfFW01G31TUYPG0\/iey0GzfS\/CY0C++GjQR6bf+M7Oz0a9850kXwpPdzw+LbTWRDrMdmT\/g3\/8AhE3w+Twrd\/toeLrfStQ0HQrZdS1P4VWNhLcaXoGreOPFFl9oj1DxnBGf7Ph127L2k6q2lWOn6VcSQQI8Lyd3+zh\/wQJ+HXwt+LvwN+IHh39s7xp4wsfgn8aPhx8eLPwK3gbR7XRNV1jw34h8N+JLVriCLxtcRabJ4hsfCVvpr65DYy332FXRBOLMWw9mjjchweIz7MsNxTNYrOKGPw9eH+r2OVGdPFudWU6GqVCbq8sKftHONNOU5ubbPna2XcV5hhOFMlxvA1N4Hh3FZPisNVXFeXvE06uX3w8IYnSUsVCOHbq1vZxpzqytGmoqVz+m+iiivyw\/eTAvtG0e5vVu7nStNuLlSky3M9hay3CzIFMcyzSRNIJUNlZlJA29TbWuGBgiasTR\/CvhbTZZ7vTvDeg2F0weRrmy0bTrW4aR7K5geQzQWySF3hmmidyxZopZY2Zkd8lFNbT9F\/6Ucz\/iR\/x\/+3EMXhbwvDatFD4b0KKL+1ND1Ly4tH05I\/7RivrVItQ2LbBftsSsyx3WPtCKzKsoBYmp4g8L+F9Yt7qPV\/DmhapHElmYo9R0fTr1I2dgzmNLm2lVC7KGYqAWYAsSRuJRVLp6r\/3GZv8Agy9P\/bqhf1bw34cubF7e50DRZ4IdPuo4YZtKsJYYo5rO6tJkjjkt2SNJrVmtpVUAPbs0D7oiwN\/StE0TStYkbS9H0vTWbTdNiZrDT7S0ZorZ9ahto2NvDGTHbwlooEJKxRM0cYCEhiit\/wDmHl\/hh\/6cMI\/71\/3Eh\/6TUOtooorlPUP\/2Q==",
    "image_passport_behind": "data:image\/png;base64,\/9j\/4AAQSkZJRgABAQAAAQABAAD\/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH\/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH\/wAARCAAyADIDASIAAhEBAxEB\/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL\/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6\/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL\/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6\/9oADAMBAAIRAxEAPwD+\/iivn+b9pb4Y2v7Tlt+yZe3V7YfFLUPhYnxf0eK+m8O2ula74V\/4SDUfD88Ghxy+Il8Q6pqtjc6Xe3V9Fa+HX0220+CeeTVjLFPAtj4b\/tF\/Dn4q2nx1vfCr6jJF+z98SvF\/wq8erctoLSP4m8HeGvD\/AIm1abSBp2v6ip02Ww8QWkdlJrLaTqL3cV6l1pltbxRXMvS8Hiox53QqKHsqNbmcfd9jXm6dGpe9uWpOLjF\/zJpu6d+KOY4CdR0oYqjKoq+Iwzgpe8sRhaaq4ik1vz0abVSa6Qad2nzP3iv52v2hPhZ+2n+3v+3l+054R+Dv7THxJ\/ZX+Hv7E2n\/AAu0XwxH4F1LxtfaJ8dPiH4w8D6T8TrrQvFWl6T8avhbYaOtrFfaVpUl19l1C3Gm3jve6nHJcLCn65eD\/wBs74PeOf2Qbz9tbw9D4kuvhLY+E\/HHjGe1EfhWbxX\/AGZ4C1zxFoHiG2WCy8XXnhv+0Yr\/AMNaikUL+KFt0AjS\/vLS4W5gj+NviR420r4d+L\/hj+2B8FPirYeBfBH\/AAUTt\/gz8IhpsmkeD9QC\/GPxp4K1rVfg\/wDHG8m1XxBrPhzX9f8ADvg3SLjwjrXhLw\/JajxQth4asdS1zXLLSdIlsffyGONy7E4+cMPCnjVTr5fhKmLw0cRRoZhRxOHq4ulOlKlXh7V4Gji6S56U0pVLxcai9rH5LiiWW5zgcrpzxlWtlkq+EzfH0cBjJYTEYzKK2HxlDAV6VenXw1VYf+06+ArydOvTcoQSm50lUpT+2v2J\/iz4z+Of7JvwM+KXxG8OHwp498ReC7e38b+HzdX12bDxd4d1HUfCviE+fqJe+\/0zVNEur4Q3dxeXFuJxayarqLRHU5vyN\/YN\/wCC5sX7Zn7d\/iL9li6+F\/hTwx4B8Sf8LD\/4UX460nX\/ABde+IPE\/wDwgVlqmvJ\/bmn6l4ZtLYf8Jd4Q0XWPFtp9qtfDH\/COxWD6Def2trFzaA\/Tuq\/t9+B\/2cL7xZ8Afgh+y38afjB4L\/Zv0+38OeNfGvw1gn8VeGPDt7p9rqF5r8\/ivxFHN4rvoNSS5stXv\/FGueNdXTxDfa5D4i1LxFPNqcWp38n50\/8ABJT\/AIJFWPws\/aW8Fft7eH\/i14R8U\/CiDSfH+pfCTwdpum+IB4n0OfxroXiXwRLpWvaivibVtH\/tDwdpOsa14f1aCbVvETyX4kNylrq8Md1D2ZbT4bnhOLcTmtJ4erVw858OUr1r061SeMq0qaVKc1GcWsHB+3k4+wlX96V5yXk5pi+L\/wC0eAsBw9io4yhhsZTo8aVeWh+9w1D6jh8RWcq9Km505JY+fNg48yxTw14pqKP6jaKKK+LP1A\/l+\/4KM\/Efxn8Jf29dd\/aR8N2qXqfsT6x8FvjTrUccGm3F4\/wf+KWk\/Dv4P\/HjR7PTNS1DTbXXtW1\/SpfBSeH7dr\/Tb\/TLyzvNQ03XrFHvobjb+FX7Qw8F\/sl\/8FWPiJ8Nby1u9T+MX\/BQTxL4N+Gs2q6ReSWeoxfFT4ffBOKeS8tJ5LKTTJm8D3OvX1lNqRjjs9Whs47y3mkIspP1Ff8AZvtvEP7df7RfjHxpYaJ48+Ffx0\/Z0034QeJ\/DI0661Wz0uYWmgw634c+IIeBdNsLfxB4esYrvS7Q3cmo6hZ6vFIbK2t0hvp\/zi\/Y1\/4JUeLPhNZaZ+z946+I\/wAOvF3w\/wDBP7ZXjX9ofVrHR9R8XyWPjXwLbfD7wl4O8JeGtOhurSyudT8X+EPEfhQaf8R9LudUfSfCMeq20La74jv5JdJk+0w+Y5fU4cr4TETUMZhPqNOho5fWcDPFxxlSilaylhcTTrTabSmsY2k3Gcn+UYnJ88o8VrHYKk6mBzGvnE8Q+dReDzJYavluHxTfNrDG4CvhoqUVKdJ5dFTbTjA4L9mXxL4s\/Z9\/Zr\/4K+fsoeKLexj8Qfs+\/Fe\/+KHh7SLhE1IzeCvjNB4e8V2Carr2j3VvY6jDqVpFBdfZLd7LXdMOp3trPdJLFaRWvybcaxqfwZ0P9n\/\/AIJ8eK7iP7b+zJ\/wWP8A2YfF3wjhEMd7f337OXxj0b47eNPh9qniDxLp8VvpepeI2nvr0azZyadpWp2N1O1v9jnsI7ecfoM3\/BNvRtM8UftL\/Ef9jbw9qXww+C3xU\/ZF8Q\/CfxF4D8Wat8Vde1T4kfF6P4i+G\/Fvgj4k6Bca3rPxGi8U+GU8NaTqujJrllrNtqmkNdxRaRoOo2Ota1NH7N+1V\/wTovP2ufjz+wj+2R4Ev\/C3wp1D4B+JfCd\/8aIPiPous6B4o8YfD7wF4h03xHoV7ZT6XHqlhd6jo8+l6tbaLFr\/APZdtL4f8RS6lP4ohg0200Kf2cLnOUrNcTOrin9UzHDYbGzrVKHs6mHzvCZe6fNVoQq4hU3i5\/XqTjCrVcfrtK9aahOUvCr8OcQTyXDUqGDX17J8TUy6lh6WJdahjeGsbntStKOHxVWjg\/axy+msqruVWhQUv7Pqxhh4uVNro\/2RJ9Jb4N\/Bq7Gr6ynxK+JPxn+N3jqwsLS30s6PrviIfHf4fTeKdc1t7zTHg0zTdJ0mIRHT9JvLGaazv7\/+zNNv9Zj06W3+o\/8AgnXbR6T8K\/jR4Wsyy6P4Q\/ak+PGhaBbud72elN4jtNZ+zNcMPPuit9rF9Is908tzslSJ5mSOMD89\/EFz8df2SfG3jjwj4E\/Z5+NX7RHgyfxL41+Kv7Mfjj9nXW\/i\/YeB\/h3pPxH8Vy65deAPG8fgjwreaH4\/tdO1rwxo97qHhjxff+MvDUumrAi6TDY6jqOly\/ef7G3iH4U\/AHSPD\/7J\/wAQfj78Gde\/ar8R6p4z+JfxE8F6N8QfCsXjfWPGPjDULrxnflvAl9qWmeLxfw+GriyuUiXwnp8DaBpkuqwafa6ZFg\/Czo1KlPEeypyqf8vmqcXNxpQlUnOrOME3ThSjKMJOpblk5pPlV3+k5fXpUcThYV5woOlTWEcqrdKE8RUjRpUqFOdRxhXrYupSq1qSoOanSpwlLlqLX9EKKKK8w+rPk7x14n8BeBfjbY61Bepouv3sulf8LB1S5ttev4Lrw1D4e1S3s9PtbaCDUIYr55f7EkSTT7OEeTHL9pvlkNzG\/LaD8XvA\/wDwn2l6lq\/iC3tNJ8Oal8WLqzv4dJ8QvHqNt4y8Q2t\/pIWBNNubz7QlnvN6Li2sYobiKZYnnjNuZPzy\/bd\/4JE\/D\/8Aay\/aY+L\/AMYdW\/aS1\/4e6p8XPA\/gHwBqnhSy8A2msWlhb+F\/+ES+w3Fjq8\/ifS0ur69uNE0yWW1nt3FoL6HMe6Wznb491X\/ghB8N\/Heuay2g\/t6fEyyl8V6x41m1LTtC+G832i7bxF4esV8Wad4gaHxtH5ljrGk+C4jerq0EMOtNElpM17JNplqfrsHl\/ClXD0JYriWvh686EHiKayjF1Y0KrpRc6SqQhJTUZzqU4zXuuNPnTtJRPzbH5tx1h8ZjaeB4NwuLw0MbU+qVXnuAoPFUYYqqqdeVKpUhKk6tOjQxM6b9\/wBpVlSk3KDm\/wB6vhB8WPhr4I+EvhPwfr\/xBmvtY0vw3YafdRy6BrL2+nzw6bDbNpen3Gm+EbBbjTrWSNvstxei61F1d2utQnxGB4v+2P4l8P8Axq\/Yj+OHwN+GnjfS7f4i+OfhHe+DfDh1bSvE1npDavPY29vLbXd\/N4U1CG2guoo57UXT2rrGZUkDwkfak\/Kjwh\/wQk+Efh298Can4Z\/bH161tfAXjvw9qNglt8OdIsYr3xNpf9q\/2ZYXdzb+NrWL7VJc6lrNzpktvGtxGdSvGtHke8uLifmZv+CAPwj8Ja58M\/GGr\/tteI9OXwMYDo9tqnw60W0t7+yXxXrHiS807U4pvHsc9tBqsut3mm6paFbcXNlNJDPAZJp9\/ZhsFwhhsVTxVPinEe0w9aliKPPkeMlGdWjUnUhGcFHSLnGnzLm+Go9W4yb4cVmfiBicvrYCrwRhPZYrC1MBXdPiTBRnTw9anToVJ06sp3dSMK1eUG4J89KCt+8uv0w\/4JZxJ+yb+xL8L\/gb8dfHmgz+PfC134qkuoPDmn+JNV0vTdJ1LxFfX2jaWmpW3gzSorue0spIvtEojum8xir6jdOrPX5gTf8ABPzxN4w\/4Ld6H+17ZePdDb4HX\/xj8OfFW01G31TUYPG0\/iey0GzfS\/CY0C++GjQR6bf+M7Oz0a9850kXwpPdzw+LbTWRDrMdmT\/g3\/8AhE3w+Twrd\/toeLrfStQ0HQrZdS1P4VWNhLcaXoGreOPFFl9oj1DxnBGf7Ph127L2k6q2lWOn6VcSQQI8Lyd3+zh\/wQJ+HXwt+LvwN+IHh39s7xp4wsfgn8aPhx8eLPwK3gbR7XRNV1jw34h8N+JLVriCLxtcRabJ4hsfCVvpr65DYy332FXRBOLMWw9mjjchweIz7MsNxTNYrOKGPw9eH+r2OVGdPFudWU6GqVCbq8sKftHONNOU5ubbPna2XcV5hhOFMlxvA1N4Hh3FZPisNVXFeXvE06uX3w8IYnSUsVCOHbq1vZxpzqytGmoqVz+m+iiivyw\/eTAvtG0e5vVu7nStNuLlSky3M9hay3CzIFMcyzSRNIJUNlZlJA29TbWuGBgiasTR\/CvhbTZZ7vTvDeg2F0weRrmy0bTrW4aR7K5geQzQWySF3hmmidyxZopZY2Zkd8lFNbT9F\/6Ucz\/iR\/x\/+3EMXhbwvDatFD4b0KKL+1ND1Ly4tH05I\/7RivrVItQ2LbBftsSsyx3WPtCKzKsoBYmp4g8L+F9Yt7qPV\/DmhapHElmYo9R0fTr1I2dgzmNLm2lVC7KGYqAWYAsSRuJRVLp6r\/3GZv8Agy9P\/bqhf1bw34cubF7e50DRZ4IdPuo4YZtKsJYYo5rO6tJkjjkt2SNJrVmtpVUAPbs0D7oiwN\/StE0TStYkbS9H0vTWbTdNiZrDT7S0ZorZ9ahto2NvDGTHbwlooEJKxRM0cYCEhiit\/wDmHl\/hh\/6cMI\/71\/3Eh\/6TUOtooorlPUP\/2Q=="
  },
  "input_data": {
    "full_name": "ضياء علي محمد الشامي",
    "user_id": "3",
    "gender": "male",
    "marital_status": "single",
    "passport_type": "card",
    "passport_issuer": "ibb",
    "passport_number": "1234567897",
    "passport_release_at": "2010-5-5",
    "passport_expiry_at": "2024-5-5",
    "date_of_birth": "1995-4-5",
    "place_of_birth": "ibb",
    "country_id2": "246",
    "state_id2": "636",
    "image_passport_front2": "",
    "image_passport_behind2": "",
    "car": {
      "vehicle_type_id": "2",
      "load_people": "4",
      "color": "'"
    }
  },
  "data_delivery": {
    "full_name": "ضياء علي محمد الشامي",
    "user_id": 3,
    "gender": "male",
    "marital_status": "single",
    "passport_type": "card",
    "passport_issuer": "ibb",
    "passport_number": "1234567897",
    "passport_release_at": "2010-5-5",
    "passport_expiry_at": "2024-5-5",
    "date_of_birth": "1995-4-5",
    "place_of_birth": "ibb",
    "country_id2": "246",
    "state_id2": "636",
    "image_passport_front2": "",
    "image_passport_behind2": "",
    "user_type": "RainLab\\User\\Models\\User",
    "mobile": "770821911",
    "email": "test@gmail.com"
  },
  "data_car": {
    "vehicle_type_id": "2",
    "load_people": "4",
    "color": "'"
  },
  "debug": {
    "line": 478,
    "file": "\/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/deliverysapi\/apicontrollers\/Deliverys.php",
    "class": "October\\Rain\\Exception\\ValidationException",
    "trace": [
      "#0 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/deliverysapi\/apicontrollers\/Deliverys.php(279): Nano\\DeliverysApi\\APIControllers\\Deliverys->createDelivery()",
      "#1 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Database\/Concerns\/ManagesTransactions.php(29): Nano\\DeliverysApi\\APIControllers\\Deliverys->Nano\\DeliverysApi\\APIControllers\\{closure}()",
      "#2 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Database\/DatabaseManager.php(349): Illuminate\\Database\\Connection->transaction()",
      "#3 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Support\/Facades\/Facade.php(261): Illuminate\\Database\\DatabaseManager->__call()",
      "#4 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/deliverysapi\/apicontrollers\/Deliverys.php(335): Illuminate\\Support\\Facades\\Facade::__callStatic()",
      "#5 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Controller.php(54): Nano\\DeliverysApi\\APIControllers\\Deliverys->create()",
      "#6 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction()",
      "#7 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Route.php(219): Illuminate\\Routing\\ControllerDispatcher->dispatch()",
      "#8 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Route.php(176): Illuminate\\Routing\\Route->runController()",
      "#9 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Router.php(681): Illuminate\\Routing\\Route->run()",
      "#10 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(130): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}()",
      "#11 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/cart\/middleware\/CartMiddleware.php(10): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#12 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Nano\\Cart\\Middleware\\CartMiddleware->handle()",
      "#13 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/broadcast\/middleware\/UserAppId.php(34): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#14 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Nano\\Broadcast\\Middleware\\UserAppId->handle()",
      "#15 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Cookie\/Middleware\/AddQueuedCookiesToResponse.php(37): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#16 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle()",
      "#17 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Cookie\/Middleware\/EncryptCookies.php(67): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#18 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle()",
      "#19 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Middleware\/SubstituteBindings.php(41): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#20 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle()",
      "#21 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/View\/Middleware\/ShareErrorsFromSession.php(49): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#22 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle()",
      "#23 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Session\/Middleware\/StartSession.php(56): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#24 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Illuminate\\Session\\Middleware\\StartSession->handle()",
      "#25 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Middleware\/ThrottleRequests.php(59): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#26 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Illuminate\\Routing\\Middleware\\ThrottleRequests->handle()",
      "#27 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/cors\/classes\/HandleCors.php(38): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#28 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Nano\\CORS\\Classes\\HandleCors->handle()",
      "#29 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(105): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#30 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Router.php(683): Illuminate\\Pipeline\\Pipeline->then()",
      "#31 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Router.php(658): Illuminate\\Routing\\Router->runRouteWithinStack()",
      "#32 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Routing\/Router.php(624): Illuminate\\Routing\\Router->runRoute()",
      "#33 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/october\/rain\/src\/Router\/CoreRouter.php(31): Illuminate\\Routing\\Router->dispatchToRoute()",
      "#34 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Foundation\/Http\/Kernel.php(170): October\\Rain\\Router\\CoreRouter->dispatch()",
      "#35 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(130): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}()",
      "#36 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/securityheaders\/classes\/SecurityHeaderMiddleware.php(18): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#37 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Nano\\SecurityHeaders\\Classes\\SecurityHeaderMiddleware->handle()",
      "#38 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Foundation\/Http\/Middleware\/CheckForMaintenanceMode.php(63): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#39 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/october\/rain\/src\/Foundation\/Http\/Middleware\/CheckForMaintenanceMode.php(23): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()",
      "#40 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle()",
      "#41 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/broadcast\/middleware\/UserAppId.php(34): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#42 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Nano\\Broadcast\\Middleware\\UserAppId->handle()",
      "#43 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/cors\/classes\/HandleCors.php(38): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#44 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Nano\\CORS\\Classes\\HandleCors->handle()",
      "#45 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/plugins\/nano\/securityheaders\/classes\/NonceGeneratorMiddleware.php(19): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#46 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(171): Nano\\SecurityHeaders\\Classes\\NonceGeneratorMiddleware->handle()",
      "#47 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Pipeline\/Pipeline.php(105): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}()",
      "#48 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Foundation\/Http\/Kernel.php(145): Illuminate\\Pipeline\\Pipeline->then()",
      "#49 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/vendor\/laravel\/framework\/src\/Illuminate\/Foundation\/Http\/Kernel.php(110): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter()",
      "#50 \/home\/u506607449\/domains\/nano2soft.com\/public_html\/alnaeem\/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle()",
      "#51 {main}"
    ]
  }
}
```

### Get Options Delivery 

** جلب خيارات الحقول  اثناء انشاء حساب  موصل للمستخدم الحالي **

```
GET /api/v1/deliverys/deliverys/options
```

#### Example 5 Get Options Fields Delivery 

```
GET http://localhost:8006/api/v1/deliverys/deliverys/options
```


##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب الخيارات بنجاح ",
  "error": "",
  "data": {
    "type": [
      {
        "id": "person",
        "name": "Person"
      },
      {
        "id": "company",
        "name": "Company"
      }
    ],
    "gender": [
      {
        "id": "male",
        "name": "Male"
      },
      {
        "id": "female",
        "name": "female"
      }
    ],
    "passport_type": [
      {
        "id": "card",
        "name": "بطاقة شخصيه"
      },
      {
        "id": "passport",
        "name": "جواز سفر"
      },
      {
        "id": "other",
        "name": "اخرى"
      }
    ],
    "marital_status": [
      {
        "id": "single",
        "name": "Single"
      },
      {
        "id": "married",
        "name": "Married"
      },
      {
        "id": "divorce",
        "name": "divorce"
      },
      {
        "id": "widow",
        "name": "Widow"
      },
      {
        "id": "other",
        "name": "Other"
      }
    ],
    "fuel_type": [
      {
        "id": "petroleum",
        "name": "بترول"
      },
      {
        "id": "diesel",
        "name": "ديزل او مازوت"
      },
      {
        "id": "gas",
        "name": "غاز"
      },
      {
        "id": "electricity",
        "name": "كهرباء"
      },
      {
        "id": "other",
        "name": "اخرى"
      }
    ]
  }
}
```

**لجلب خيارات حقل معين نقوم بتمري، اسم الحقل ضمن متغير fields **

```
GET http://localhost:8006/api/v1/deliverys/deliverys/options?fields=passport_type
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب الخيارات بنجاح ",
  "error": "",
  "data": {
    "passport_type": [
      {
        "id": "card",
        "name": "بطاقة شخصيه"
      },
      {
        "id": "passport",
        "name": "جواز سفر"
      },
      {
        "id": "other",
        "name": "اخرى"
      }
    ]
  }
}
```

#### جلب الخيارات على شكل مصفوفه

** نقوم بتمرير المتغير is_collection بالقيمه 0 ضمن الطلب كالتالي **

```
GET http://localhost:8006/api/v1/deliverys/deliverys/options?is_collection=0
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب الخيارات بنجاح ",
  "error": "",
  "data": {
    "type": {
      "person": "Person",
      "company": "Company"
    },
    "gender": {
      "male": "Male",
      "female": "female"
    },
    "passport_type": {
      "card": "بطاقة شخصيه",
      "passport": "جواز سفر",
      "other": "اخرى"
    },
    "marital_status": {
      "single": "Single",
      "married": "Married",
      "divorce": "divorce",
      "widow": "Widow",
      "other": "Other"
    },
    "fuel_type": {
      "petroleum": "بترول",
      "diesel": "ديزل او مازوت",
      "gas": "غاز",
      "electricity": "كهرباء",
      "other": "اخرى"
    }
  }
}
```

** لجلب خيارات حقل معين نقوم بتمرير اسم الحقل كالتالي **
```
GET http://localhost:8006/api/v1/deliverys/deliverys/options?is_collection=0&fields=type
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب الخيارات بنجاح ",
  "error": "",
  "data": {
    "type": {
      "person": "Person",
      "company": "Company"
    }
  }
}
```

### Update Account Delivery To Current User 

** تعديل بيانات حساب الموصل الحالي  **

```
PUT /api/v1/deliverys/deliverys/update/{id}
```

#### Example 6 Update Fields Delivery 

```
PUT http://localhost:8006/api/v1/deliverys/deliverys/update/5
```
Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |

```
put http://localhost:8006/api/v1/deliverys/cars/update/5
```
**فى المثال التالى سنقوم بتعديل بيانات مركبه   الموصل بالاعتماد على المستخدم الحالى    **


##### Response

```html
Status: 200 Ok
```

```json

```