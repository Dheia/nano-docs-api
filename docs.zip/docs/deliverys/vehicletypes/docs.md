## VehicleTypes  Api

This endpoint allows you to `list`, `show` your Vehicle Type.

/deliverys/vehicletypes

** الجزء الخاص بجلب انواع المركبات   **

### The Vehicle Type object

#### Public Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in Vehicle Type  records |
| `orderBy`           | `string`  |  using orderBy departments records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy departments records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  VehicleTypes default value true    |
| `isDefault`           | `boolean`  | The get is Is default  VehicleType default value
false    |
| `companys_id`           | `integer`  |  get records VehicleType to companys_id default value false.         |
| `departments_id`           | `integer`  | get records VehicleTypes to departments_id
default value false.          |
| `isFavorites`           | `boolean `  | useing get VehicleTypes where my Favorites default value false 
| 
| `include`           | `string `  | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/deliverys/vehicletypes?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `department`           | `belongsTo`  | The get department | 
| `cars`           | `hasMany`  | The get Cars   | 



### List Vehicle Type

Returns a list of VehicleTypes’

```
GET /api/v1/deliverys/vehicletypes
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

### Example 1 get List VehicleTypes  

```
GET http://localhost:8006/api/v1/deliverys/vehicletypes
```

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 3,
      "code": "2-2-3",
      "transports_type": "LAND",
      "ref_type": "LAND_BUSES_SMALL",
      "name": "بر - باص - صغير كاري سوزوكي",
      "color": "#552153",
      "description": "بر - باص - صغير كاري سوزوكي",
      "companys_id": "2",
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "is_default": 0,
      "is_hidden": 0,
      "is_active": 1,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "flag": "LAND_BUSES_SMALL",
      "sort_order": 3,
      "created_by": "1",
      "created_at": "2023-07-07 22:53:13",
      "updated_at": "2023-07-07 22:53:13",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano\\Deliverys\\Models\\VehicleType"
    },
    {
      "id": 4,
      "code": "2-2-4",
      "transports_type": "LAND",
      "ref_type": "LAND_BUSES_MIDDLE",
      "name": "بر - باص - متوسط زلومه عفريت عكبار",
      "color": "#803053",
      "description": "بر - باص - متوسط زلومه عفريت عكبار",
      "companys_id": "2",
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "is_default": 0,
      "is_hidden": 0,
      "is_active": 1,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "flag": "LAND_BUSES_MIDDLE",
      "sort_order": 4,
      "created_by": "1",
      "created_at": "2023-07-07 22:53:13",
      "updated_at": "2023-07-07 22:53:13",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano\\Deliverys\\Models\\VehicleType"
    },
    {
      "id": 5,
      "code": "2-2-5",
      "transports_type": "LAND",
      "ref_type": "LAND_BUSES_LARGE",
      "name": "بر - باص - كبير هيص بلكة",
      "color": "#125868",
      "description": "بر - باص - كبير هيص بلكة",
      "companys_id": "2",
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "is_default": 0,
      "is_hidden": 0,
      "is_active": 1,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "flag": "LAND_BUSES_LARGE",
      "sort_order": 5,
      "created_by": "1",
      "created_at": "2023-07-07 22:53:13",
      "updated_at": "2023-07-07 22:53:13",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano\\Deliverys\\Models\\VehicleType"
    },
    {
      "id": 6,
      "code": "2-2-6",
      "transports_type": "LAND",
      "ref_type": "LAND_BUSES_XLARGE",
      "name": "بر - باص - كبير نقل جماعي",
      "color": "#710834",
      "description": "بر - باص - كبير نقل جماعي",
      "companys_id": "2",
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "is_default": 0,
      "is_hidden": 0,
      "is_active": 1,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "flag": "LAND_BUSES_XLARGE",
      "sort_order": 6,
      "created_by": "1",
      "created_at": "2023-07-07 22:53:13",
      "updated_at": "2023-07-07 22:53:13",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano\\Deliverys\\Models\\VehicleType"
    },
    {
      "id": 7,
      "code": "2-2-7",
      "transports_type": "LAND",
      "ref_type": "LAND_CARS_SMALL",
      "name": "بر - سيارة - صغيرة تكسي كامري فيتارا",
      "color": "#478903",
      "description": "بر - سيارة - صغيرة تكسي كامري فيتارا",
      "companys_id": "2",
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "is_default": 0,
      "is_hidden": 0,
      "is_active": 1,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "flag": "LAND_CARS_SMALL",
      "sort_order": 7,
      "created_by": "1",
      "created_at": "2023-07-07 22:53:13",
      "updated_at": "2023-07-07 22:53:13",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano\\Deliverys\\Models\\VehicleType"
    },
    {
      "id": 8,
      "code": "2-2-8",
      "transports_type": "LAND",
      "ref_type": "LAND_CARS_SALON",
      "name": "بر - سيارة - صالون منيكاء",
      "color": "#307869",
      "description": "بر - سيارة - صالون منيكاء",
      "companys_id": "2",
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "is_default": 0,
      "is_hidden": 0,
      "is_active": 1,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "flag": "LAND_CARS_SALON",
      "sort_order": 8,
      "created_by": "1",
      "created_at": "2023-07-07 22:53:13",
      "updated_at": "2023-07-07 22:53:13",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano\\Deliverys\\Models\\VehicleType"
    },
    {
      "id": 9,
      "code": "2-2-9",
      "transports_type": "LAND",
      "ref_type": "LAND_CARS_CHASSIS",
      "name": "بر - سيارة - شبح او شاص",
      "color": "#255262",
      "description": "بر - سيارة - شبح او شاص",
      "companys_id": "2",
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "is_default": 0,
      "is_hidden": 0,
      "is_active": 1,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "flag": "LAND_CARS_CHASSIS",
      "sort_order": 9,
      "created_by": "1",
      "created_at": "2023-07-07 22:53:13",
      "updated_at": "2023-07-07 22:53:13",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano\\Deliverys\\Models\\VehicleType"
    },
    {
      "id": 10,
      "code": "2-2-10",
      "transports_type": "LAND",
      "ref_type": "LAND_CARS_HILUX",
      "name": "بر - سيارة - هيلوكس",
      "color": "#947856",
      "description": "بر - سيارة - هيلوكس",
      "companys_id": "2",
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "is_default": 0,
      "is_hidden": 0,
      "is_active": 1,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "flag": "LAND_CARS_HILUX",
      "sort_order": 10,
      "created_by": "1",
      "created_at": "2023-07-07 22:53:13",
      "updated_at": "2023-07-07 22:53:13",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano\\Deliverys\\Models\\VehicleType"
    },
    {
      "id": 11,
      "code": "2-2-11",
      "transports_type": "LAND",
      "ref_type": "LAND_CARS_JEEP",
      "name": "بر - سيارة - حبه او جيب",
      "color": "#300529",
      "description": "بر - سيارة - حبه او جيب",
      "companys_id": "2",
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "is_default": 0,
      "is_hidden": 0,
      "is_active": 1,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "flag": "LAND_CARS_JEEP",
      "sort_order": 11,
      "created_by": "1",
      "created_at": "2023-07-07 22:53:13",
      "updated_at": "2023-07-07 22:53:13",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano\\Deliverys\\Models\\VehicleType"
    },
    {
      "id": 12,
      "code": "2-2-12",
      "transports_type": "LAND",
      "ref_type": "LAND_CARS_XLARGE",
      "name": "بر - سيارة - كبيره همر",
      "color": "#155236",
      "description": "بر - سيارة - كبيره همر",
      "companys_id": "2",
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "is_default": 0,
      "is_hidden": 0,
      "is_active": 1,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "flag": "LAND_CARS_XLARGE",
      "sort_order": 12,
      "created_by": "1",
      "created_at": "2023-07-07 22:53:13",
      "updated_at": "2023-07-07 22:53:13",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano\\Deliverys\\Models\\VehicleType"
    },
    {
      "id": 13,
      "code": "2-2-13",
      "transports_type": "LAND",
      "ref_type": "LAND_CARS_AMBULANCE",
      "name": "بر - سيارة - اسعاف",
      "color": "#696893",
      "description": "بر - سيارة - اسعاف",
      "companys_id": "2",
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "is_default": 0,
      "is_hidden": 0,
      "is_active": 1,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "flag": "LAND_CARS_AMBULANCE",
      "sort_order": 13,
      "created_by": "1",
      "created_at": "2023-07-07 22:53:13",
      "updated_at": "2023-07-07 22:53:13",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano\\Deliverys\\Models\\VehicleType"
    },
    {
      "id": 14,
      "code": "2-2-14",
      "transports_type": "LAND",
      "ref_type": "LAND_TRICKS_SMALL",
      "name": "بر - شاحنات - صغيرة عربيه",
      "color": "#353515",
      "description": "بر - شاحنات - صغيرة عربيه",
      "companys_id": "2",
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "is_default": 0,
      "is_hidden": 0,
      "is_active": 1,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "flag": "LAND_TRICKS_SMALL",
      "sort_order": 14,
      "created_by": "1",
      "created_at": "2023-07-07 22:53:13",
      "updated_at": "2023-07-07 22:53:13",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano\\Deliverys\\Models\\VehicleType"
    },
    {
      "id": 15,
      "code": "2-2-15",
      "transports_type": "LAND",
      "ref_type": "LAND_TRICKS_MIDDLE",
      "name": "بر - شاحنات - متوسطه تويوتا الاميره",
      "color": "#778776",
      "description": "بر - شاحنات - متوسطه تويوتا الاميره",
      "companys_id": "2",
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "is_default": 0,
      "is_hidden": 0,
      "is_active": 1,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "flag": "LAND_TRICKS_MIDDLE",
      "sort_order": 15,
      "created_by": "1",
      "created_at": "2023-07-07 22:53:13",
      "updated_at": "2023-07-07 22:53:13",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano\\Deliverys\\Models\\VehicleType"
    },
    {
      "id": 16,
      "code": "2-2-16",
      "transports_type": "LAND",
      "ref_type": "LAND_TRICKS_LARGE",
      "name": "بر - شاحنات - كبيره فيلفو مرسيدس",
      "color": "#136250",
      "description": "بر - شاحنات - كبيره فيلفو مرسيدس",
      "companys_id": "2",
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "is_default": 0,
      "is_hidden": 0,
      "is_active": 1,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "flag": "LAND_TRICKS_LARGE",
      "sort_order": 16,
      "created_by": "1",
      "created_at": "2023-07-07 22:53:13",
      "updated_at": "2023-07-07 22:53:13",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano\\Deliverys\\Models\\VehicleType"
    },
    {
      "id": 17,
      "code": "2-2-17",
      "transports_type": "LAND",
      "ref_type": "LAND_TRICKS_XLARGE",
      "name": "بر - شاحنات - ضخمة جسرين وشيولات وغيرها",
      "color": "#520462",
      "description": "بر - شاحنات - ضخمة جسرين وشيولات وغيرها",
      "companys_id": "2",
      "is_allow_add": 1,
      "is_allow_edit": 1,
      "is_allow_delete": 1,
      "is_default": 0,
      "is_hidden": 0,
      "is_active": 1,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "flag": "LAND_TRICKS_XLARGE",
      "sort_order": 17,
      "created_by": "1",
      "created_at": "2023-07-07 22:53:13",
      "updated_at": "2023-07-07 22:53:13",
      "image": null,
      "images": [],
      "files": [],
      "object_type": "Nano\\Deliverys\\Models\\VehicleType"
    }
  ],
  "meta": {
    "pagination": {
      "total": 25,
      "count": 15,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 2,
      "links": {
        "next": "https:\/\/alnaeem.nano2soft.com\/api\/v1\/deliverys\/vehicletypes?page=2"
      }
    }
  }
}
```


### Show Data Record VehicleType 

```
GET /api/v1/deliverys/vehicletypes/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record VehicleType 2

```
GET http://localhost:8006/api/v1/deliverys/vehicletypes/2
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "id": 2,
  "code": "2-2-2",
  "transports_type": "LAND",
  "ref_type": "LAND_MOTORCYCLES",
  "name": "بر - دراجة نارية متر",
  "color": "#812963",
  "description": "بر - دراجة نارية متر",
  "companys_id": "2",
  "is_allow_add": 1,
  "is_allow_edit": 1,
  "is_allow_delete": 1,
  "is_default": 0,
  "is_hidden": 0,
  "is_active": 1,
  "status": "active",
  "other_data": null,
  "config_data": null,
  "flag": "LAND_MOTORCYCLES",
  "sort_order": 2,
  "created_by": "1",
  "created_at": "2023-07-07 22:53:12",
  "updated_at": "2023-07-07 22:53:13",
  "image": null,
  "images": [],
  "files": [],
  "object_type": "Nano\\Deliverys\\Models\\VehicleType"
}
```

### Check Last Update VehicleType Data 

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/deliverys/vehicletypes/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/deliverys/vehicletypes/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": null
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2022-12-20 18:17:04",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": null
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **