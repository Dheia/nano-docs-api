## Cars  Api

This endpoint allows you to `list`, `show` your cars.

/deliverys/cars

** الجزء الخاص بجلب المركبات  **

### The cars object

#### Public Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in cars  records |
| `orderBy`           | `string`  |  using orderBy departments records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy departments records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  Cars default value true    |
| `isDefault`           | `boolean`  | The get is Is default  Car default value
false    |
| `companys_id`           | `integer`  |  get records cars to companys_id default value false.         |
| `departments_id`           | `integer`  | get records cars to departments_id
default value false.          |
| `delivery_d`           | `integer`  | get records cars to delivery_id default
value false.          |
| `vehicle_type_id`           | `integer`  | get records cars to vehicle_type_id default
value false.          |
| `ref_type_vehicle_type`           | `integer`  | get records cars to ref_type_vehicle_type default
value false.          |
| `isFavorites`           | `boolean `  | useing get cars where my Favorites default value false 
| 
| `include`           | `string `  | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/deliverys/cars?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `department`           | `belongsTo`  | The get department | 
 `delivery`           | `belongsTo`  | The get delivery   | 
| `vehicle_type`           | `belongsTo`  | The get vehicle_type   | 
| `country`           | `belongsTo`  | The get country   | 
| `state`           | `belongsTo`  | The get state   | 



### List cars

Returns a list of Cars’

```
GET /api/v1/deliverys/cars
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

### Example 1 get List Cars  

```
GET http://localhost:8006/api/v1/deliverys/cars
```

#### Response

```html
Status: 200 OK
```

```json```


### Show Data Record Car 

```
GET /api/v1/deliverys/cars/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record Car 2

```
GET http://localhost:8006/api/v1/deliverys/cars/2
```

##### Response

```html
Status: 200 Ok
```

```json```

### Check Last Update Car Data 

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/deliverys/cars/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/deliverys/cars/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": null
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2022-12-20 18:17:04",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": null
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **

### Get Last Cars Data Current Delivery

** لجلب المركبات التابعه لحساب الموصل الحالي  **

```
GET /api/v1/deliverys/cars/me
```

```
GET http://localhost:8006/api/v1/deliverys/cars/me
```
**فى المثال التالى سنقوم بجلب كافة المركبات التابعه للموصل الحالي   **

#### Response

```html
Status: 200 Ok
```

```json
```
### Add Cars To Current Delivery

** لاضافة مركبات جديدة للموصل الحالي   **

```
POST /api/v1/deliverys/cars/create
```

```
POST http://localhost:8006/api/v1/deliverys/cars/create
```
**فى المثال التالى سنقوم باضافة مركبه جديده للموصل  الحالي   **

#### Response

```html
Status: 200 Ok
```

```json
```
### Update Cars To Current Delivery

** لتعديل بيانات مركبه معينه تابعه للموصل الحالي نقوم بتمرير رقم المركبه والبيانات المراد تعديلها  **

```
PUT /api/v1/deliverys/cars/update/{id}
```
Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |

```
put http://localhost:8006/api/v1/deliverys/cars/update/5
```
**فى المثال التالى سنقوم بتعديل بيانات مركبه تابعه  للموصل  الحالي   **

#### Response

```html
Status: 200 Ok
```

```json
```
