## Adverts Api

This endpoint allows you to `list`, `show` your adverts.

/advert/madverts
### The adverts object

#### Public Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in departments records |
| `orderBy`           | `string`  |  using orderBy departments records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy departments records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `type`           | `string`  | **Required**. The get Adverts type [slide,alert,popup,content,down,all] default value all    |
| `type_process`           | `string`  | **Required**. The get Adverts type_process [image,text,video,image_text,video_text,all] default value all    |
| `isActive`           | `boolean`  | **Required**. The get is Active  departments default value true    |
| `isPublished`           | `boolean`  | The get is Published in Web records adverts default value true  | 
| `categories_id`           | `integer`  | The get adverts in to categories_id  default value false  | 
| `companys_id`           | `integer`  |  get records adverts to companys_id default value false.         |
| `departments_id`           | `integer`  | get records adverts to departments_id default value true.          |
| `categorysId`           | `string` | useing get adverts where categorysId [2,3,4] default value ''
| 
| `tagsId`           | `string` | useing get adverts where tagsId [2,3,4] default value ''
| 
| `isFavorites`           | `boolean` | useing get adverts where my Favorites default value false 
| 
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/advert/madverts?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `department`           | `belongsTo`  | The get department | 
| `Categorie`           | `belongsTo`  | The get categorie advert    | 
| `tags`           | `hasMany`  | The get tags   | 
| `categories`           | `hasMany`  | The get Public categories in the Tags    | 
| `targets`           | `hasMany`  | The get Public targets in the Advert    | 


### List adverts

Returns a list of adverts you’ve previously created.

```
GET /api/v1/advert/madverts
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

### Example 1 get List Adverts 

```
GET http://localhost:8006/api/v1/advert/madverts
```

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 2,
      "code": "2-2-2",
      "barcode": null,
      "slug": "alaaalan-althany",
      "name": "الاعلان الثاني",
      "title": "",
      "sub_title": "",
      "link": "http:\/\/localhost:8006\/",
      "short_description": "",
      "description": "<p>وصف لالاعلان<\/p>",
      "meta_title": "الاعلان الثاني",
      "meta_description": "",
      "keywords": "",
      "type": "popup",
      "type_process": "image",
      "categories_id": "2",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "phone": null,
      "email": null,
      "website": null,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": {
        "is_link": "0",
        "bg_image": "0",
        "bg_color": "",
        "opacity": "",
        "text_align": "right",
        "title": {
          "is_title": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        },
        "sub_title": {
          "is_sub_title": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        },
        "short_description": {
          "is_short_description": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        }
      },
      "sort_order": 2,
      "created_at": "2022-10-24 18:18:15",
      "updated_at": "2022-10-24 18:18:15",
      "image": {
        "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/6356acade9120239006531.png",
        "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_160_160_0_0_crop.png",
        "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_240_240_0_0_crop.png",
        "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_800_800_0_0_crop.png",
        "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_480_480_0_0_auto.png"
      },
      "images": [],
      "files": [],
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null
    },
    {
      "id": 1,
      "code": "2-2-1",
      "barcode": null,
      "slug": "alaaalan-alaol",
      "name": "الاعلان الاول",
      "title": "عنوان الاعلان الرئسيس",
      "sub_title": "عنوان فرع",
      "link": "",
      "short_description": "",
      "description": "<p>نص الاعلان<\/p>",
      "meta_title": "عنوان الاعلان",
      "meta_description": "وصف للاعلان",
      "keywords": "",
      "type": "slide",
      "type_process": "image",
      "categories_id": "2",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "2022-10-22 15:15:13",
      "unpublished_at": "",
      "phone": null,
      "email": null,
      "website": null,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": {
        "is_link": "1",
        "bg_image": "1",
        "bg_color": "#ffc107",
        "opacity": "",
        "text_align": "right",
        "title": {
          "is_title": "0",
          "bg_color": "#ffc107",
          "opacity": "",
          "text_color": "#ffc107",
          "text_align": "right"
        },
        "sub_title": {
          "is_sub_title": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        },
        "short_description": {
          "is_short_description": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        }
      },
      "sort_order": 1,
      "created_at": "2022-10-24 18:16:47",
      "updated_at": "2022-10-24 18:16:47",
      "image": {
        "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/6356ac253380a184947265.png",
        "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_160_160_0_0_crop.png",
        "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_240_240_0_0_crop.png",
        "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_800_800_0_0_crop.png",
        "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_480_480_0_0_auto.png"
      },
      "images": [],
      "files": [],
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Example 2 get List Adverts type=services

** جلب الاعلانات بتحديد النوع slide  **

```
GET http://localhost:8006/api/v1/advert/madverts?type=slide
```

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": "2-2-1",
      "barcode": null,
      "slug": "alaaalan-alaol",
      "name": "الاعلان الاول",
      "title": "عنوان الاعلان الرئسيس",
      "sub_title": "عنوان فرع",
      "link": "",
      "short_description": "",
      "description": "<p>نص الاعلان<\/p>",
      "meta_title": "عنوان الاعلان",
      "meta_description": "وصف للاعلان",
      "keywords": "",
      "type": "slide",
      "type_process": "image",
      "categories_id": "2",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "2022-10-22 15:15:13",
      "unpublished_at": "",
      "phone": null,
      "email": null,
      "website": null,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": {
        "is_link": "1",
        "bg_image": "1",
        "bg_color": "#ffc107",
        "opacity": "",
        "text_align": "right",
        "title": {
          "is_title": "0",
          "bg_color": "#ffc107",
          "opacity": "",
          "text_color": "#ffc107",
          "text_align": "right"
        },
        "sub_title": {
          "is_sub_title": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        },
        "short_description": {
          "is_short_description": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        }
      },
      "sort_order": 1,
      "created_at": "2022-10-24 18:16:47",
      "updated_at": "2022-10-24 18:16:47",
      "image": {
        "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/6356ac253380a184947265.png",
        "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_160_160_0_0_crop.png",
        "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_240_240_0_0_crop.png",
        "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_800_800_0_0_crop.png",
        "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_480_480_0_0_auto.png"
      },
      "images": [],
      "files": [],
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Example 3 get data Adverts 

** لجب بيانات اعلان  معين نقوم بتمرير رقم الاعلان  فى الرابط كا التالى **

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


```
GET /api/v1/advert/madverts/{id}
```
```
GET http://localhost:8006/api/v1/advert/madverts/2
```

#### Response

```html
Status: 200 OK
```

```json
{
  "id": 2,
  "code": "2-2-2",
  "barcode": null,
  "slug": "alaaalan-althany",
  "name": "الاعلان الثاني",
  "title": "",
  "sub_title": "",
  "link": "http:\/\/localhost:8006\/",
  "short_description": "",
  "description": "<p>وصف لالاعلان<\/p>",
  "meta_title": "الاعلان الثاني",
  "meta_description": "",
  "keywords": "",
  "type": "popup",
  "type_process": "image",
  "categories_id": "2",
  "companys_id": "2",
  "departments_id": "2",
  "is_effective": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "phone": null,
  "email": null,
  "website": null,
  "properties": null,
  "links": null,
  "other_data": null,
  "config_data": {
    "is_link": "0",
    "bg_image": "0",
    "bg_color": "",
    "opacity": "",
    "text_align": "right",
    "title": {
      "is_title": "0",
      "bg_color": "",
      "opacity": "",
      "text_color": "",
      "text_align": "right"
    },
    "sub_title": {
      "is_sub_title": "0",
      "bg_color": "",
      "opacity": "",
      "text_color": "",
      "text_align": "right"
    },
    "short_description": {
      "is_short_description": "0",
      "bg_color": "",
      "opacity": "",
      "text_color": "",
      "text_align": "right"
    }
  },
  "sort_order": 2,
  "created_at": "2022-10-24 18:18:15",
  "updated_at": "2022-10-24 18:18:15",
  "image": {
    "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/6356acade9120239006531.png",
    "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_160_160_0_0_crop.png",
    "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_240_240_0_0_crop.png",
    "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_800_800_0_0_crop.png",
    "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_480_480_0_0_auto.png"
  },
  "images": [],
  "files": [],
  "ratings_count": 0,
  "countRating": 0,
  "sumRating": null,
  "averageRating": null,
  "user_is_rating": false,
  "user_object_rating": null,
  "favorites_count": 0,
  "user_is_favorite": false,
  "user_object_favorite": null
}
```

### Example get data Adverts and Include Relation

**لتضمين العلاقات اثناء جلب بيانات الاعلان يمكننا استخدام البراميتر  include**

```
GET http://localhost:8006/api/v1/advert/madverts/2?include=companys,department,Categorie,tags,categories
```

#### Response

```html
Status: 200 OK
```

```json
{
  "id": 2,
  "code": "2-2-2",
  "barcode": null,
  "slug": "alaaalan-althany",
  "name": "الاعلان الثاني",
  "title": "",
  "sub_title": "",
  "link": "http:\/\/localhost:8006\/",
  "short_description": "",
  "description": "<p>وصف لالاعلان<\/p>",
  "meta_title": "الاعلان الثاني",
  "meta_description": "",
  "keywords": "",
  "type": "popup",
  "type_process": "image",
  "categories_id": "2",
  "companys_id": "2",
  "departments_id": "2",
  "is_effective": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "phone": null,
  "email": null,
  "website": null,
  "properties": null,
  "links": null,
  "other_data": null,
  "config_data": {
    "is_link": "0",
    "bg_image": "0",
    "bg_color": "",
    "opacity": "",
    "text_align": "right",
    "title": {
      "is_title": "0",
      "bg_color": "",
      "opacity": "",
      "text_color": "",
      "text_align": "right"
    },
    "sub_title": {
      "is_sub_title": "0",
      "bg_color": "",
      "opacity": "",
      "text_color": "",
      "text_align": "right"
    },
    "short_description": {
      "is_short_description": "0",
      "bg_color": "",
      "opacity": "",
      "text_color": "",
      "text_align": "right"
    }
  },
  "sort_order": 2,
  "created_at": "2022-10-24 18:18:15",
  "updated_at": "2022-10-24 18:18:15",
  "image": {
    "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/6356acade9120239006531.png",
    "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_160_160_0_0_crop.png",
    "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_240_240_0_0_crop.png",
    "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_800_800_0_0_crop.png",
    "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_480_480_0_0_auto.png"
  },
  "images": [],
  "files": [],
  "ratings_count": 0,
  "countRating": 0,
  "sumRating": null,
  "averageRating": null,
  "user_is_rating": false,
  "user_object_rating": null,
  "favorites_count": 0,
  "user_is_favorite": false,
  "user_object_favorite": null,
  "companys": {
    "id": 2,
    "code": "2",
    "name": "مدارس الوفاء الأهلية النموذجية",
    "short_description": "شركة رقم 1",
    "description": "شركة رقم 1",
    "meta_title": "",
    "meta_description": "",
    "keywords": null,
    "business_number": null,
    "vat_number": null,
    "mobile": null,
    "phone": [],
    "email": [],
    "website": [],
    "address": "إب - الدليل - جوار محطة المشدود",
    "address_1": null,
    "address_2": null,
    "street_name": null,
    "street_number": null,
    "latitude": null,
    "longitude": null,
    "geo_components": null,
    "city": null,
    "zip": null,
    "postcode": null,
    "country_long": null,
    "country_id": "1",
    "state_id": null,
    "directorate_id": null,
    "formataddress": null,
    "vicinity": null,
    "is_active": 1,
    "tags_type_id": null,
    "links": [],
    "properties": [],
    "created_at": "2018-04-05 16:54:53",
    "updated_at": "2019-12-04 13:08:14",
    "image": null,
    "images": [],
    "files": []
  },
  "department": {
    "id": 2,
    "code": "1-2",
    "name": "مدارس الوفاء الأهلية النموذجية",
    "short_description": "مدارس الوفاء الاهلية",
    "description": "مدارس الوفاء الاهلية",
    "meta_title": "مدارس الوفاء الاهلية",
    "meta_description": "مدارس الوفاء الاهلية",
    "keywords": "مدارس الوفاء الاهلية",
    "business_number": "",
    "vat_number": "",
    "mobile": "770429482",
    "phone": [
      {
        "phone_label": "هاتف المكتب",
        "phone_number": "04461300",
        "phone_type": "home",
        "sort_show": "1",
        "is_default": "1",
        "is_show": "1",
        "phone_note": "هاتف المكتب",
        "geo_components": {
          "address": "",
          "city": "",
          "province": "",
          "country": "",
          "zip": ""
        },
        "latitude": "",
        "longitude": "",
        "_group": "phone"
      }
    ],
    "email": [
      {
        "email_label": "البريد الرسمي",
        "email_text": "kddd90@gmail.com",
        "sort_show": "1",
        "is_default": "1",
        "is_show": "1",
        "email_note": "",
        "geo_components": {
          "address": "",
          "city": "",
          "province": "",
          "country": "",
          "zip": ""
        },
        "latitude": "",
        "longitude": "",
        "_group": "email"
      }
    ],
    "website": [
      {
        "website_label": "الموقع الرسمي",
        "website_url": "www.tss-y.com",
        "website_type": "website",
        "sort_show": "1",
        "is_default": "1",
        "is_show": "1",
        "website_note": "",
        "geo_components": {
          "address": "",
          "city": "",
          "province": "",
          "country": "",
          "zip": ""
        },
        "latitude": "",
        "longitude": "",
        "_group": "website"
      }
    ],
    "companys_id": "2",
    "address": "مدارس الوفاء الأهلية النموذجية",
    "address_1": null,
    "address_2": null,
    "street_name": null,
    "street_number": null,
    "latitude": 13.957069,
    "longitude": 44.182149,
    "geo_components": {
      "address": "",
      "city": "",
      "province": "",
      "country": "",
      "zip": ""
    },
    "city": null,
    "zip": null,
    "postcode": null,
    "country_long": null,
    "country_id": "249",
    "state_id": "1067",
    "directorate_id": null,
    "formataddress": null,
    "vicinity": null,
    "is_default": 1,
    "is_hidden": 0,
    "is_active": 1,
    "main_sub": "main",
    "parent_id": null,
    "level": "1",
    "tags_type_id": "1",
    "links": null,
    "properties": null,
    "created_at": "2018-06-29 17:17:24",
    "updated_at": "2022-10-17 18:40:21",
    "image": null,
    "images": [],
    "files": [],
    "ratings_count": 0,
    "countRating": 0,
    "sumRating": null,
    "averageRating": null,
    "user_is_rating": false,
    "user_object_rating": null,
    "favorites_count": 1,
    "user_is_favorite": true,
    "user_object_favorite": {
      "user_id": 543,
      "favoriteable_type": "Tss\\Basic\\Models\\Department",
      "favoriteable_id": 2,
      "created_at": "2022-10-17 20:13:53",
      "updated_at": "2022-10-17 20:13:53"
    }
  },
  "Categorie": {
    "id": 2,
    "code": "2-2-2",
    "name": "علانات عامه",
    "short_description": "",
    "description": "<p>علانات عامه <\/p>",
    "meta_title": "علانات عامه",
    "meta_description": "علانات عامه",
    "keywords": "علانات عامه",
    "ref_type_class": null,
    "ref_key_values_class": null,
    "companys_id": "2",
    "departments_id": "2",
    "is_default": 0,
    "is_active": 1,
    "main_sub": "sub",
    "parent_id": "1",
    "level": "2",
    "properties": null,
    "created_at": "2022-10-24 18:06:55",
    "updated_at": "2022-10-24 18:06:56"
  },
  "tags": {
    "data": [
      {
        "id": 1,
        "code": "2-4-1",
        "name": "منوعات",
        "slug": "mnoaaat",
        "type": null,
        "user_id": null,
        "user_type": null,
        "companys_id": "2",
        "departments_id": "4",
        "is_public": 1,
        "is_default": 0,
        "is_active": 0,
        "is_published": 1,
        "published_at": "",
        "unpublished_at": "",
        "properties": null,
        "created_at": "2022-09-11 13:52:27",
        "updated_at": "2022-10-23 15:10:11"
      }
    ]
  },
  "categories": {
    "data": [
      {
        "id": 1,
        "code": "2-4-1",
        "name": "عامه",
        "slug": "aaamh",
        "type": "1",
        "user_id": null,
        "user_type": null,
        "companys_id": "2",
        "departments_id": "4",
        "country_id": null,
        "is_public": 1,
        "is_default": 0,
        "is_active": 1,
        "is_published": 1,
        "published_at": "",
        "unpublished_at": "",
        "main_sub": "main",
        "parent_id": null,
        "level": "1",
        "properties": null,
        "created_at": "2022-09-26 19:55:19",
        "updated_at": "2022-10-03 20:13:13"
      }
    ]
  }
}
```

### Example 4 Get My Favorites Adverts

**لجلب الاعلانات المفضله للمستخدم الحالى نقوم بتمرير المتغير isFavorites = true **

```
GET /api/v1/advert/madverts
```

Required Parameters: `isFavorites = true`

```
GET http://localhost:8006/api/v1/advert/madverts?isFavorites=true
```

#### Response

```html
Status: 200 Ok
```

** من خلال السجلات الراجعه فى الاسفل نلاحظ ان الخاصيه  user_is_favorite=true 
بمعنا ان هذا الاعلان  مضاف الى مفضله المستخدم الحالى **

*فى المثال التالي لاتوجد اعلانات مضافه الى مفضله المستخدم *
```json
{
  "data": [],
  "meta": {
    "pagination": {
      "total": 0,
      "count": 0,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```



### Example 5 Get Adverts with companys_id or departments_id

** لجلب الاعلانات االتابعه لفرع معين او لمتجر معين نستخدم البراميتر companys_id
او البراميتر departments_id**

**ملاحظه يمكنك جلب قيمه companys_id من بيانات الاقسام departmentsوالذي تمثل المتاجر **
```
GET /api/v1/advert/madverts
```

Required Parameters: `companys_id`

```
http://localhost:8006/api/v1/advert/madverts?companys_id=2
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "data": [
    {
      "id": 2,
      "code": "2-2-2",
      "barcode": null,
      "slug": "alaaalan-althany",
      "name": "الاعلان الثاني",
      "title": "",
      "sub_title": "",
      "link": "http:\/\/localhost:8006\/",
      "short_description": "",
      "description": "<p>وصف لالاعلان<\/p>",
      "meta_title": "الاعلان الثاني",
      "meta_description": "",
      "keywords": "",
      "type": "popup",
      "type_process": "image",
      "categories_id": "2",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "phone": null,
      "email": null,
      "website": null,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": {
        "is_link": "0",
        "bg_image": "0",
        "bg_color": "",
        "opacity": "",
        "text_align": "right",
        "title": {
          "is_title": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        },
        "sub_title": {
          "is_sub_title": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        },
        "short_description": {
          "is_short_description": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        }
      },
      "sort_order": 2,
      "created_at": "2022-10-24 18:18:15",
      "updated_at": "2022-10-24 18:18:15",
      "image": {
        "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/6356acade9120239006531.png",
        "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_160_160_0_0_crop.png",
        "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_240_240_0_0_crop.png",
        "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_800_800_0_0_crop.png",
        "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_480_480_0_0_auto.png"
      },
      "images": [],
      "files": [],
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null
    },
    {
      "id": 1,
      "code": "2-2-1",
      "barcode": null,
      "slug": "alaaalan-alaol",
      "name": "الاعلان الاول",
      "title": "عنوان الاعلان الرئسيس",
      "sub_title": "عنوان فرع",
      "link": "",
      "short_description": "",
      "description": "<p>نص الاعلان<\/p>",
      "meta_title": "عنوان الاعلان",
      "meta_description": "وصف للاعلان",
      "keywords": "",
      "type": "slide",
      "type_process": "image",
      "categories_id": "2",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "2022-10-22 15:15:13",
      "unpublished_at": "",
      "phone": null,
      "email": null,
      "website": null,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": {
        "is_link": "1",
        "bg_image": "1",
        "bg_color": "#ffc107",
        "opacity": "",
        "text_align": "right",
        "title": {
          "is_title": "0",
          "bg_color": "#ffc107",
          "opacity": "",
          "text_color": "#ffc107",
          "text_align": "right"
        },
        "sub_title": {
          "is_sub_title": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        },
        "short_description": {
          "is_short_description": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        }
      },
      "sort_order": 1,
      "created_at": "2022-10-24 18:16:47",
      "updated_at": "2022-10-24 18:16:47",
      "image": {
        "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/6356ac253380a184947265.png",
        "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_160_160_0_0_crop.png",
        "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_240_240_0_0_crop.png",
        "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_800_800_0_0_crop.png",
        "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_480_480_0_0_auto.png"
      },
      "images": [],
      "files": [],
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```


### Example 6 Get Adverts with tagsId

** لجلب الاعلانات التابعه لهشتاجات معينه نستخدم البراميتر tagsId كا التالى  **

```
GET /api/v1/advert/madverts
```

Required Parameters: `tagsId = true`

```
http://localhost:8006/api/v1/advert/madverts?tagsId=4,6
```

** لاظهار اسماء الهشتاجات التابعه لكل صنف  نقوم بتضمين العلاقه tags كا التالى **
```
http://localhost:8006/api/v1/advert/madverts?tagsId=3,9,6&include=tags
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "data": [
    {
      "id": 1,
      "code": "2-2-1",
      "barcode": null,
      "slug": "alaaalan-alaol",
      "name": "الاعلان الاول",
      "title": "عنوان الاعلان الرئسيس",
      "sub_title": "عنوان فرع",
      "link": "",
      "short_description": "",
      "description": "<p>نص الاعلان<\/p>",
      "meta_title": "عنوان الاعلان",
      "meta_description": "وصف للاعلان",
      "keywords": "",
      "type": "slide",
      "type_process": "image",
      "categories_id": "2",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "2022-10-22 15:15:13",
      "unpublished_at": "",
      "phone": null,
      "email": null,
      "website": null,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": {
        "is_link": "1",
        "bg_image": "1",
        "bg_color": "#ffc107",
        "opacity": "",
        "text_align": "right",
        "title": {
          "is_title": "0",
          "bg_color": "#ffc107",
          "opacity": "",
          "text_color": "#ffc107",
          "text_align": "right"
        },
        "sub_title": {
          "is_sub_title": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        },
        "short_description": {
          "is_short_description": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        }
      },
      "sort_order": 1,
      "created_at": "2022-10-24 18:16:47",
      "updated_at": "2022-10-24 18:16:47",
      "image": {
        "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/6356ac253380a184947265.png",
        "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_160_160_0_0_crop.png",
        "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_240_240_0_0_crop.png",
        "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_800_800_0_0_crop.png",
        "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_480_480_0_0_auto.png"
      },
      "images": [],
      "files": [],
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null,
      "tags": {
        "data": [
          {
            "id": 2,
            "code": "2-4-2",
            "name": "مشروبات",
            "slug": "mshrobat",
            "type": null,
            "user_id": null,
            "user_type": null,
            "companys_id": "2",
            "departments_id": "4",
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "is_published": 1,
            "published_at": "",
            "unpublished_at": "",
            "properties": null,
            "created_at": "2022-09-11 13:52:27",
            "updated_at": "2022-09-11 13:52:27"
          },
          {
            "id": 3,
            "code": "2-4-3",
            "name": "عصائر",
            "slug": "aasaer",
            "type": null,
            "user_id": null,
            "user_type": null,
            "companys_id": "2",
            "departments_id": "4",
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "is_published": 1,
            "published_at": "",
            "unpublished_at": "",
            "properties": null,
            "created_at": "2022-09-11 13:52:27",
            "updated_at": "2022-09-11 13:52:27"
          }
        ]
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```
### Example 7 Get Adverts with categorysId


```
GET /api/v1/advert/madverts
```

Required Parameters: `categorysId = true`

```
GET http://localhost:8006/api/v1/advert/madverts?categorysId=1,4
```

** لاظهار اسماء التصنيفات التابعه لكل صنف  نقوم بتضمين العلاقه categories كا التالى **
```
GET http://localhost:8006/api/v1/advert/madverts?categorysId=1,4&include=categories
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "data": [
    {
      "id": 2,
      "code": "2-2-2",
      "barcode": null,
      "slug": "alaaalan-althany",
      "name": "الاعلان الثاني",
      "title": "",
      "sub_title": "",
      "link": "http:\/\/localhost:8006\/",
      "short_description": "",
      "description": "<p>وصف لالاعلان<\/p>",
      "meta_title": "الاعلان الثاني",
      "meta_description": "",
      "keywords": "",
      "type": "popup",
      "type_process": "image",
      "categories_id": "2",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "phone": null,
      "email": null,
      "website": null,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": {
        "is_link": "0",
        "bg_image": "0",
        "bg_color": "",
        "opacity": "",
        "text_align": "right",
        "title": {
          "is_title": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        },
        "sub_title": {
          "is_sub_title": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        },
        "short_description": {
          "is_short_description": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        }
      },
      "sort_order": 2,
      "created_at": "2022-10-24 18:18:15",
      "updated_at": "2022-10-24 18:18:15",
      "image": {
        "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/6356acade9120239006531.png",
        "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_160_160_0_0_crop.png",
        "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_240_240_0_0_crop.png",
        "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_800_800_0_0_crop.png",
        "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/ade\/thumb_569_480_480_0_0_auto.png"
      },
      "images": [],
      "files": [],
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null,
      "categories": {
        "data": [
          {
            "id": 1,
            "code": "2-4-1",
            "name": "عامه",
            "slug": "aaamh",
            "type": "1",
            "user_id": null,
            "user_type": null,
            "companys_id": "2",
            "departments_id": "4",
            "country_id": null,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "is_published": 1,
            "published_at": "",
            "unpublished_at": "",
            "main_sub": "main",
            "parent_id": null,
            "level": "1",
            "properties": null,
            "created_at": "2022-09-26 19:55:19",
            "updated_at": "2022-10-03 20:13:13"
          }
        ]
      }
    },
    {
      "id": 1,
      "code": "2-2-1",
      "barcode": null,
      "slug": "alaaalan-alaol",
      "name": "الاعلان الاول",
      "title": "عنوان الاعلان الرئسيس",
      "sub_title": "عنوان فرع",
      "link": "",
      "short_description": "",
      "description": "<p>نص الاعلان<\/p>",
      "meta_title": "عنوان الاعلان",
      "meta_description": "وصف للاعلان",
      "keywords": "",
      "type": "slide",
      "type_process": "image",
      "categories_id": "2",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "2022-10-22 15:15:13",
      "unpublished_at": "",
      "phone": null,
      "email": null,
      "website": null,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": {
        "is_link": "1",
        "bg_image": "1",
        "bg_color": "#ffc107",
        "opacity": "",
        "text_align": "right",
        "title": {
          "is_title": "0",
          "bg_color": "#ffc107",
          "opacity": "",
          "text_color": "#ffc107",
          "text_align": "right"
        },
        "sub_title": {
          "is_sub_title": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        },
        "short_description": {
          "is_short_description": "0",
          "bg_color": "",
          "opacity": "",
          "text_color": "",
          "text_align": "right"
        }
      },
      "sort_order": 1,
      "created_at": "2022-10-24 18:16:47",
      "updated_at": "2022-10-24 18:16:47",
      "image": {
        "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/6356ac253380a184947265.png",
        "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_160_160_0_0_crop.png",
        "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_240_240_0_0_crop.png",
        "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_800_800_0_0_crop.png",
        "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/635\/6ac\/253\/thumb_568_480_480_0_0_auto.png"
      },
      "images": [],
      "files": [],
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null,
      "categories": {
        "data": [
          {
            "id": 1,
            "code": "2-4-1",
            "name": "عامه",
            "slug": "aaamh",
            "type": "1",
            "user_id": null,
            "user_type": null,
            "companys_id": "2",
            "departments_id": "4",
            "country_id": null,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "is_published": 1,
            "published_at": "",
            "unpublished_at": "",
            "main_sub": "main",
            "parent_id": null,
            "level": "1",
            "properties": null,
            "created_at": "2022-09-26 19:55:19",
            "updated_at": "2022-10-03 20:13:13"
          }
        ]
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Check Last Update Categorie Daa 

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/advert/madverts/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/advert/madverts/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2022-12-16 16:55:13",
    "other_updated": {
      "activity_cache.madvert": "2022-12-16 16:55:13"
    }
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2022-12-16 17:31:26",
    "last_updated": "2022-12-16 16:55:13",
    "other_updated": {
      "activity_cache.madvert": "2022-12-16 16:55:13"
    }
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **
