{
  "code": "200",
  "message": "تم تحديث السله بنجاح ",
  "data": {
    "content": [
      {
        "rowId": "de5289438c44cdd0f7b0d8f1b8eeb86e",
        "id": 2,
        "name": "الصنف الثاني",
        "units_id": "",
        "units_name": "",
        "qty": "5",
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 2",
        "subtotal": 0
      },
      {
        "rowId": "6f69fdee69f598ba0627e6bb6018ee41",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "4",
        "units_name": "نص",
        "qty": "3",
        "price": 300,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 1900
      },
      {
        "rowId": "6f69fdee69f598ba0627e6bb6018ee41",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "5",
        "units_name": "ربع",
        "qty": "5",
        "price": 200,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 1900
      }
    ],
    "conditions": {
      "coupon": {
        "name": "coupon",
        "label": "nano.coupons::default.text_coupon",
        "priority": "",
        "removeable": true,
        "metaData": {
          "code": "2222"
        }
      }
    },
    "count": 6,
    "subtotalWithoutConditions": 1900,
    "subtotal": 1900,
    "total": 1800,
    "total_other": {
      "coupon": {
        "code": "coupon",
        "title": "Coupon [2222]",
        "value": -100,
        "priority": 1,
        "is_summable": true
      }
    }
  }
}