
http://localhost:8006/api/v1/shop/carts/add?quantity=2&menuId=13&comment=%D9%85%D9%84%D8%A7%D8%AD%D8%B8%D8%A7%D8%AA%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%B5%D9%86%D9%81%204&units_id=34&price=500&units_name=%D9%86%D8%B5&options[0][id]=2&options[0][name]=opion_nMe&options[0][values][0][id]=3&options[0][values][0][qty]=5&options[1][id]=1&options[1][name]=jjn&options[1][values][0][id]=2&options[1][values][0][name]=hjjj


{
  "code": "200",
  "message": "تم تحديث السله بنجاح ",
  "data": {
    "content": [
      {
        "rowId": "ccf0de2302ac915a465650590bd372a4",
        "id": 2,
        "name": "الصنف الثاني",
        "qty": "2",
        "price": 500,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 1000,
        "is_new": false,
        "units_id": "3",
        "units_name": "ربع"
      },
      {
        "rowId": "aa389762d7cc2beaf235379668418cb3",
        "id": 13,
        "name": "منتج رقم 8889",
        "qty": "2",
        "price": 700,
        "options": {
          "1": {
            "id": 1,
            "name": "التوابع",
            "values": {
              "2": {
                "id": 2,
                "name": "بدون التوابع",
                "qty": 1,
                "price": 0,
                "subtotal": 0
              }
            },
            "subtotal": 0
          },
          "2": {
            "id": 2,
            "name": "Drinks",
            "values": {
              "3": {
                "id": 3,
                "name": "Coke",
                "qty": 5,
                "price": 0,
                "subtotal": 0
              }
            },
            "subtotal": 0
          }
        },
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 1400,
        "is_new": false,
        "units_id": "34",
        "units_name": "نص"
      }
    ],
    "conditions": {
      "\u0000*\u0000items": {
        "tax": {
          "priority": "300",
          "name": "tax",
          "label": "nano.cart::default.text_vat",
          "removeable": false
        }
      }
    },
    "count": 4,
    "subtotalWithoutConditions": 2400,
    "subtotal": 2400,
    "total": 2760,
    "total_other": {
      "tax": {
        "code": "tax",
        "title": "VAT [15%]",
        "value": 360,
        "priority": "300",
        "is_summable": true
      }
    }
  }
}

{
  "code": "200",
  "message": "تم تحديث السله بنجاح ",
  "data": {
    "content": [
      {
        "rowId": "8f45bd0ab8d1eebd267765416b2d0474",
        "id": 13,
        "name": "منتج رقم 8889",
        "qty": "2",
        "price": 500,
        "options": [
          {
            "id": 1,
            "name": "التوابع",
            "values": [
              {
                "id": 2,
                "name": "بدون التوابع",
                "qty": 1,
                "price": 0,
                "subtotal": 0
              }
            ],
            "subtotal": 0
          },
          {
            "id": 2,
            "name": "Drinks",
            "values": [
              {
                "id": 3,
                "name": "Coke",
                "qty": 5,
                "price": 0,
                "subtotal": 0
              }
            ],
            "subtotal": 0
          }
        ],
        "conditions": [],
        "comment": "comment item",
        "subtotal": 1000,
        "is_new": false,
        "units_id": "34",
        "units_name": "part"
      },
      {
        "rowId": "b28b030d2e9ccc32477d01d486799627",
        "id": 13,
        "name": "منتج رقم 8889",
        "qty": "2",
        "price": 300,
        "options": [],
        "conditions": [],
        "comment": null,
        "subtotal": 600,
        "is_new": false,
        "units_id": "5",
        "units_name": "part2"
      },
      {
        "rowId": "ce3e4d25723939c8f0db7347a5c093e2",
        "id": 12,
        "name": "منتج رقم 88",
        "qty": "2",
        "price": 500,
        "options": [
          {
            "id": 3,
            "name": "التوابع",
            "values": [
              {
                "id": 5,
                "name": "مع التوابع",
                "qty": 2,
                "price": 100,
                "subtotal": 200
              }
            ],
            "subtotal": 200
          }
        ],
        "conditions": [],
        "comment": null,
        "subtotal": 1400,
        "is_new": false,
        "units_id": "",
        "units_name": ""
      }
    ],
    "conditions": {
      "\u0000*\u0000items": {
        "tax": {
          "priority": "300",
          "name": "tax",
          "label": "nano.cart::default.text_vat",
          "removeable": false
        }
      }
    },
    "count": 6,
    "subtotalWithoutConditions": 3000,
    "subtotal": 3000,
    "total": 3450,
    "total_other": {
      "tax": {
        "code": "tax",
        "title": "VAT [15%]",
        "value": 450,
        "priority": "300",
        "is_summable": true
      }
    }
  },
  "count_success": 3,
  "count_error": 0,
  "items_error": []
}