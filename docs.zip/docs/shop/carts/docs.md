## Carts Api

This endpoint allows you to `Manage Carts products`, `show`,  `add`, `update`, `update`, `delete` your carts.

```
 /api/v1/shop/carts
```

### Public Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `rowId`           | `string`  |  rowId in carts Item Identify |
| `menuId or id `           | `integer`  | **Required** Identify Products Id |
| `quantity`           | `integer`  | **Required** Quantity |
| `comment`           | `string`  |  comment in the item  |
| `options`           | `array`  |  Other  Options in the item |
| `units_id`           | `integer`  |  units_id  |
| `units_name`           | `string`  |  units_name  |
| `price or units_price`           | `integer`  |  units_price or price  |

### get Carts Data

Returns a list of items in carts and subtotal and other total 

```
GET /api/v1/shop/carts
```
#### Returns Attributes In Data Carts 

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `content`           | `array`  |  ritems in carts |
| `conditions `           | `array`  | conditions aplly to carts  |
| `count`           | `integer`  | sum Quantity all items |
| `subtotalWithoutConditions`           | `integer`  |  المجموع الفرعي قبل الخصوم او الضرائب  |
| `subtotal`           | `integer`  |  subtotal |
| `total`           | `integer`  |  total |


#### Example 1 get List Carts 

```
GET http://localhost:8006/api/v1/shop/carts
```

##### Response

```html
Status: 200 OK
```

```json
{
  "content": {
    "c4bdc41d31462c9c59e3648c711b7bd6": {
      "rowId": "c4bdc41d31462c9c59e3648c711b7bd6",
      "id": 2,
      "name": "الصنف الثاني",
      "qty": 8,
      "price": 0,
      "options": [],
      "conditions": [],
      "comment": "comment this",
      "subtotal": 0
    },
    "a775bac9cff7dec2b984e023b95206aa": {
      "rowId": "a775bac9cff7dec2b984e023b95206aa",
      "id": 3,
      "name": "نفر رز",
      "qty": 28,
      "price": 0,
      "options": [],
      "conditions": [],
      "comment": null,
      "subtotal": 0
    }
  },
  "conditions": {
    "tip": {
      "name": "tip",
      "label": "nano.cart::default.text_tip",
      "priority": "",
      "removeable": false,
      "metaData": {
        "amount": 40,
        "amountType": "amount"
      }
    }
  },
  "count": 36,
  "subtotalWithoutConditions": 0,
  "subtotal": 0,
  "total": 40
}
```
### Add Item to Carts 

```
POST /api/v1/shop/carts/add
```
** يتم استخدام هذه الداله لاضافه صنف الى السله وذلك بتمرير رقم الصنف والكميه والملاحظه ان وجدت  **

**عند استخدام نفس الداله لاكثر من مره بنفس القيم الممرره سيتم اضافه الكميه الممرره الى الكميه السابقه كعمليه زياده للكميه بالقيمه الممرره **

**ايضا يمكن استخدام نفس الداله لتعديل صنف فى السله وذلك بتمرير رقم الصنف والكميه  **


#### Parameters  

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `rowId`           | `string`  |  rowId in carts Item Identify |
| `menuId or id `           | `integer`  | **Required** Identify Products Id |
| `quantity`           | `integer`  | **Required** Quantity |
| `comment`           | `string`  |  comment in the item  |
| `options`           | `array`  |  Other  Options in the item |
| `units_id`           | `integer`  |  units_id  |
| `units_name`           | `string`  |  units_name  |
| `units_qty`           | `integer`  |  units_qty or quantity  |
| `price or units_price`           | `integer`  |  units_price or price  |


#### Example 2 Add Item to Carts 

**اضافه صنف الى السله   **

**فى المثال التالى قمنا بتمرير رقم الصنف 3 والكميه 4  معا كتابه ملاحظه للصنف **

##### البيانات التي تم تمريرها فى الطلب كا التالي  

```json
{
  "menuId": 3,
  "quantity": 4,
  "comment": "ملاحظات على الصنف ",
}
```
  
  
```
POST http://localhost:8006/api/v1/shop/carts/add?quantity=4&menuId=3&comment=%D9%85%D9%84%D8%A7%D8%AD%D8%B8%D8%A7%D8%AA%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%B5%D9%86%D9%81
```

##### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم تحديث السله بنجاح ",
  "data": {
    "content": {
      "c4bdc41d31462c9c59e3648c711b7bd6": {
        "rowId": "c4bdc41d31462c9c59e3648c711b7bd6",
        "id": 2,
        "name": "الصنف الثاني",
        "units_id": "",
        "units_name": "",
        "qty": 8,
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "comment this",
        "subtotal": 0
      },
      "a5d953bd82541f216e265c50b7c6e879": {
        "rowId": "a5d953bd82541f216e265c50b7c6e879",
        "id": 3,
        "name": "نفر رز",
        "units_id": "",
        "units_name": "",
        "qty": 8,
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف",
        "subtotal": 0
      }
    },
    "conditions": [],
    "count": 16,
    "subtotalWithoutConditions": 0,
    "subtotal": 0,
    "total": 0
  }
}
```

#### يمكن ايضا استخدام الداله السابقه للحذف والتعديل فاذا اردنا حذف صنف من السله ما علينا سوي تمرير الكمية بالقيمة صفر  

quantity = 0

#### Add Item Units to Carts 

**فى حاله احتوى المنتج على وحدات نقوم بتمرير رقم الوحده واسم الوحده والكميه والسعر كالتالي **

##### البيانات التي تم تمريرها فى الطلب كا التالي  

```json
{
  "menuId": 4,
  "units_id": 4,
  "units_name": "نص",
  "quantity": 3,
  "price": 300,
  "comment": "ملاحظات على الصنف 4 ",
}
```

```
POST http://localhost:8006/api/v1/shop/carts/add?quantity=3&menuId=4&comment=%D9%85%D9%84%D8%A7%D8%AD%D8%B8%D8%A7%D8%AA%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%B5%D9%86%D9%81%204&units_id=3&price=300&units_name=%D9%86%D8%B5
```
##### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم تحديث السله بنجاح ",
  "data": {
    "content": [
      {
        "rowId": "6af92b25bd6941645ea8a775dec37f90",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "4",
        "units_name": "ربع",
        "qty": 3,
        "price": 300,
        "options": []
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 900
      }
    ],
    "conditions": [],
    "count": 3,
    "subtotalWithoutConditions": 900,
    "subtotal": 900,
    "total": 900,
    "total_other": []
  }
}
```

#### يمكن ايضا استخدام الداله السابقه للحذف والتعديل فاذا اردنا حذف صنف من السله ما علينا سوي وجلع الخاصيه quantityصفر 

### Add Options Item Carts 

**فى حاله احتوى المنتج على خيارات اضافية options يجب تمريرها مع بيانات الصنف كالتالي **

**فى حالة احتوي الصنف على خيارات اضافة الزاميه ولم يتم تمريرها مع الصنف فلن يتم اضافة الصنف للسله **

**فى حالة تمرير خيارات لاتنتمي للصنف لن يتم اضافتها للصنف **

**يجب تمرير الخيارات الاضافية على شكل مصفوفة **

**لنلقي نظرة على صنف يحتوي على خيارات اضافية  **

```json
{
  "id": 13,
  "code": "2-2-13",
  "barcode": "7-13",
  "name": "منتج رقم 8889",
  "emblem": "",
  "short_description": "",
  "description": "",
  "users_manual": "",
  "composition": "",
  "indication": "",
  "meta_title": "",
  "meta_description": "",
  "keywords": "",
  "ref_type_class": "products",
  "ref_key_values_class": "3",
  "is_offer": 0,
  "groups_products_id": "7",
  "companys_id": "2",
  "departments_id": "2",
  "is_effective": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "manage_stock": 0,
  "shop_stock": 0,
  "min_qty": 1,
  "max_qty": 1,
  "min_qty_in_stock": 1,
  "max_qty_in_stock": 1,
  "default_qty": 1,
  "old_price": 800,
  "price": 700,
  "is_show_old_price": 1,
  "is_parleying": 1,
  "is_sold": 1,
  "is_purchased": 1,
  "is_composite": 0,
  "is_units": 0,
  "is_downloadable": 1,
  "properties": null,
  "links": null,
  "other_data": null,
  "config_data": null,
  "sort_order": 13,
  "created_at": "2023-06-28 23:55:26",
  "updated_at": "2023-10-11 15:46:51",
  "image": null,
  "images": [],
  "files": [],
  "ratings_count": 0,
  "countRating": 0,
  "sumRating": 0,
  "averageRating": 0,
  "user_is_rating": 0,
  "user_object_rating": null,
  "favorites_count": 0,
  "user_is_favorite": 0,
  "likes_count": 0,
  "bookmarks_count": 0,
  "reactions_count": 0,
  "object_type": "Nano\\Shop\\Models\\Product",
  "qty": 6,
  "children": {
    "data": [],
    "meta": {
      "pagination": {
        "total": 0,
        "count": 0,
        "per_page": 10,
        "current_page": 1,
        "total_pages": 1,
        "links": {}
      }
    }
  },
  "prices_units": {
    "data": []
  },
  "product_options": {
    "data": [
      {
        "id": 1,
        "options_id": 5,
        "products_id": 13,
        "name": "التوابع",
        "type": "radio",
        "required": 0,
        "is_public": 1,
        "is_default": 0,
        "is_active": 1,
        "min_selected": 0,
        "max_selected": 0,
        "sort_order": 1,
        "companys_id": "2",
        "departments_id": "2",
        "other_data": [],
        "config_data": [],
        "created_at": "2023-10-05 19:35:43",
        "updated_at": "2023-10-05 19:35:43",
        "products_options_values": {
          "data": [
            {
              "id": 1,
              "options_id": 5,
              "options_values_id": 2,
              "products_options_id": 1,
              "products_id": 13,
              "value": "مع التوابع",
              "default_value": 0,
              "old_price": 0,
              "price": 0,
              "is_public": 1,
              "is_default": 1,
              "is_active": 1,
              "sort_order": 1,
              "companys_id": "2",
              "departments_id": "2",
              "created_at": "2023-10-05 20:06:08",
              "updated_at": "2023-10-05 20:06:08"
            },
            {
              "id": 2,
              "options_id": 5,
              "options_values_id": 3,
              "products_options_id": 1,
              "products_id": 13,
              "value": "بدون التوابع",
              "default_value": 0,
              "old_price": 0,
              "price": 0,
              "is_public": 0,
              "is_default": 0,
              "is_active": 1,
              "sort_order": 2,
              "companys_id": "2",
              "departments_id": "2",
              "created_at": "2023-10-05 20:06:08",
              "updated_at": "2023-10-05 20:06:08"
            }
          ]
        }
      },
      {
        "id": 2,
        "options_id": 6,
        "products_id": 13,
        "name": "Drinks",
        "type": "checkbox",
        "required": 0,
        "is_public": 1,
        "is_default": 0,
        "is_active": 1,
        "min_selected": 0,
        "max_selected": 0,
        "sort_order": 2,
        "companys_id": "2",
        "departments_id": "2",
        "other_data": [],
        "config_data": [],
        "created_at": "2023-10-05 21:07:51",
        "updated_at": "2023-10-05 21:07:51",
        "products_options_values": {
          "data": [
            {
              "id": 3,
              "options_id": 6,
              "options_values_id": 4,
              "products_options_id": 2,
              "products_id": 13,
              "value": "Coke",
              "default_value": 0,
              "old_price": 0,
              "price": 0,
              "is_public": 1,
              "is_default": 1,
              "is_active": 1,
              "sort_order": 3,
              "companys_id": "2",
              "departments_id": "2",
              "created_at": "2023-10-05 21:07:51",
              "updated_at": "2023-10-05 21:07:51"
            },
            {
              "id": 4,
              "options_id": 6,
              "options_values_id": 5,
              "products_options_id": 2,
              "products_id": 13,
              "value": "Diet Coke",
              "default_value": 0,
              "old_price": 0,
              "price": 0,
              "is_public": 1,
              "is_default": 0,
              "is_active": 1,
              "sort_order": 4,
              "companys_id": "2",
              "departments_id": "2",
              "created_at": "2023-10-05 21:07:51",
              "updated_at": "2023-10-05 21:07:51"
            }
          ]
        }
      }
    ]
  }
}
```

**فى بيانات الصنف السابق نلاحظ احتوي الصنف على خيارات اضافية  product_options **

يحتوي الصنف السابق على خيارانا الاول باسم التوابع والثاني باسم Drinks لكل منهم خصائص products_options_values

عند تمرير الخيارات الاضافية يجب تمرير رقم الخيار id واسمه وقيمة values

```json
"options": {
  "1": {
    "id": 1,
    "name": "التوابع",
    "values": {
      "2": {
        "id": 2,
        "name": "بدون التوابع",
        "qty": 1,
        "price": 0,
        "subtotal": 0
      }
    },
    "subtotal": 0
  },
  "2": {
    "id": 2,
    "name": "التوابع",
    "values": {
      "3": {
        "id": 3,
        "name": "Coke",
        "qty": 5,
        "price": 0,
        "subtotal": 0
      }
    },
    "subtotal": 0
  }
}
```

يتم تمرير قيم الخيار values على شكل مصفوفة من الخصائص 
values 

```json
"values": {
  "2": {
    "id": 2,
    "name": "بدون التوابع",
    "qty": 1,
    "price": 0,
    "subtotal": 0
  }
}
```

**يجب ان نلاحظ ايضا ان لكل خيار اضافي نوع معين  فمثلا الخيار التوابع من النوع radio**
**بمعن انه لايمكن اختير سوي قيمه واحده من قيم الخيار ام بدون توتبع او مع التوابع **

#### Add Item with options in Carts

**فى المثال التالي سنقوم باضافة الصنف السابق الذي يحتوي على خيارات اضافية الى السلة **

**سنقوم بتمرير خيارات الصنف على شكل مصفوفة options **

##### البيانات التي تم تمريرها فى الطلب كا التالي  

```json
{
  "menuId": 13,
  "units_id": 34,
  "units_name": "نص",
  "quantity": 2,
  "price": 500,
  "comment": "ملاحظات على الصنف 4 ",
  "options": {
    "1": {
      "id": 1,
      "name": "التوابع",
      "values": {
        "2": {
          "id": 2,
          "name": "بدون التوابع",
          "qty": 1,
          "price": 0
        }
      },
    },
    "2": {
      "id": 2,
      "name": "Drinks",
      "values": {
        "3": {
          "id": 3,
          "name": "Coke",
          "qty": 5,
          "price": 0
        }
      },
    }
  }
}
```

**لتصبح البيانات الممررة كالتالي **

```
http://localhost:8006/api/v1/shop/carts/add?quantity=2&menuId=13&comment=%D9%85%D9%84%D8%A7%D8%AD%D8%B8%D8%A7%D8%AA%20%D8%B9%D9%84%D9%89%20%D8%A7%D9%84%D8%B5%D9%86%D9%81%204&units_id=34&price=500&units_name=%D9%86%D8%B5&options[0][id]=2&options[0][name]=opion_nMe&options[0][values][0][id]=3&options[0][values][0][qty]=5&options[1][id]=1&options[1][name]=jjn&options[1][values][0][id]=2&options[1][values][0][name]=hjjj
```

##### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم تحديث السله بنجاح ",
  "data": {
    "content": [
      {
        "rowId": "ccf0de2302ac915a465650590bd372a4",
        "id": 2,
        "name": "الصنف الثاني",
        "qty": "2",
        "price": 500,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 1000,
        "is_new": false,
        "units_id": "3",
        "units_name": "ربع"
      },
      {
        "rowId": "aa389762d7cc2beaf235379668418cb3",
        "id": 13,
        "name": "منتج رقم 8889",
        "qty": "2",
        "price": 700,
        "options": {
          "1": {
            "id": 1,
            "name": "التوابع",
            "values": {
              "2": {
                "id": 2,
                "name": "بدون التوابع",
                "qty": 1,
                "price": 0,
                "subtotal": 0
              }
            },
            "subtotal": 0
          },
          "2": {
            "id": 2,
            "name": "Drinks",
            "values": {
              "3": {
                "id": 3,
                "name": "Coke",
                "qty": 5,
                "price": 0,
                "subtotal": 0
              }
            },
            "subtotal": 0
          }
        },
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 1400,
        "is_new": false,
        "units_id": "34",
        "units_name": "نص"
      }
    ],
    "conditions": {
      "\u0000*\u0000items": {
        "tax": {
          "priority": "300",
          "name": "tax",
          "label": "nano.cart::default.text_vat",
          "removeable": false
        }
      }
    },
    "count": 4,
    "subtotalWithoutConditions": 2400,
    "subtotal": 2400,
    "total": 2760,
    "total_other": {
      "tax": {
        "code": "tax",
        "title": "VAT [15%]",
        "value": 360,
        "priority": "300",
        "is_summable": true
      }
    }
  }
}
```

**لاحظ انه فى الاصدارات الاخيره يتم ارجاع بالبيانات بالشكل التالي **

**يتم ارجاع الخيارات opions على شكل كائنات json**

```json
{
  "code": "200",
  "message": "تم تحديث السله بنجاح ",
  "data": {
    "content": [
      {
        "rowId": "ccf0de2302ac915a465650590bd372a4",
        "id": 2,
        "name": "الصنف الثاني",
        "qty": "2",
        "price": 500,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 1000,
        "is_new": false,
        "units_id": "3",
        "units_name": "ربع"
      },
      {
        "rowId": "aa389762d7cc2beaf235379668418cb3",
        "id": 13,
        "name": "منتج رقم 8889",
        "qty": "2",
        "price": 700,
        "options": [
          {
            "id": 1,
            "name": "التوابع",
            "values": [
              {
                "id": 2,
                "name": "بدون التوابع",
                "qty": 1,
                "price": 0,
                "subtotal": 0
              }
            ],
            "subtotal": 0
          },
          {
            "id": 2,
            "name": "Drinks",
            "values": [
              {
                "id": 3,
                "name": "Coke",
                "qty": 5,
                "price": 0,
                "subtotal": 0
              }
            ],
            "subtotal": 0
          }
        ],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 1400,
        "is_new": false,
        "units_id": "34",
        "units_name": "نص"
      }
    ],
    "conditions": {
      "\u0000*\u0000items": {
        "tax": {
          "priority": "300",
          "name": "tax",
          "label": "nano.cart::default.text_vat",
          "removeable": false
        }
      }
    },
    "count": 4,
    "subtotalWithoutConditions": 2400,
    "subtotal": 2400,
    "total": 2760,
    "total_other": {
      "tax": {
        "code": "tax",
        "title": "VAT [15%]",
        "value": 360,
        "priority": "300",
        "is_summable": true
      }
    }
  }
}
```

#### Add Item with options Impact on price in Carts
**مثال اخر على اضافة اصناف مع خياراتها دفعه واحدة **
**فى هذه المثال يرجاء التركيز على ان السعر يتاثر بالخيارات فى حال كان الخيار لدية سعر اضافي **

**لتصبح البيانات الممررة كالتالي **

```
POST http://localhost:8006/api/v1/shop/carts/addmany?items[0][quantity]=2&items[0][menuId]=13&items[0][comment]=comment%20item&items[0][units_id]=34&items[0][price]=500&items[0][units_name]=part&items[0][options][0][id]=2&items[0][options][0][name]=opion_nMe&items[0][options][0][values][0][id]=3&items[0][options][0][values][0][qty]=5&items[0][options][1][id]=1&items[0][options][1][name]=jjn&items[0][options][1][values][0][id]=2&items[0][options][1][values][0][name]=hjjj&is_destroy_cart=0&items[1][menuId]=12&items[1][quantity]=2&items[1][options][0][id]=3&items[1][options][0][values][0][id]=5&items[1][options][0][values][0][qty]=2&items[2][menuId]=13&items[2][units_id]=5&items[2][units_name]=part2&items[2][quantity]=2&items[2][price]=300
```

##### Response

```html
Status: 200 OK
```
```json
{
  "code": "200",
  "message": "تم تحديث السله بنجاح ",
  "data": {
    "content": [
      {
        "rowId": "8f45bd0ab8d1eebd267765416b2d0474",
        "id": 13,
        "name": "منتج رقم 8889",
        "qty": "2",
        "price": 500,
        "options": {
          "1": {
            "id": 1,
            "name": "التوابع",
            "values": {
              "2": {
                "id": 2,
                "name": "بدون التوابع",
                "qty": 1,
                "price": 0,
                "subtotal": 0
              }
            },
            "subtotal": 0
          },
          "2": {
            "id": 2,
            "name": "Drinks",
            "values": {
              "3": {
                "id": 3,
                "name": "Coke",
                "qty": 5,
                "price": 0,
                "subtotal": 0
              }
            },
            "subtotal": 0
          }
        },
        "conditions": [],
        "comment": "comment item",
        "subtotal": 1000,
        "is_new": false,
        "units_id": "34",
        "units_name": "part"
      },
      {
        "rowId": "b28b030d2e9ccc32477d01d486799627",
        "id": 13,
        "name": "منتج رقم 8889",
        "qty": "2",
        "price": 300,
        "options": [],
        "conditions": [],
        "comment": null,
        "subtotal": 600,
        "is_new": false,
        "units_id": "5",
        "units_name": "part2"
      },
      {
        "rowId": "ce3e4d25723939c8f0db7347a5c093e2",
        "id": 12,
        "name": "منتج رقم 88",
        "qty": "2",
        "price": 500,
        "options": {
          "3": {
            "id": 3,
            "name": "التوابع",
            "values": {
              "5": {
                "id": 5,
                "name": "مع التوابع",
                "qty": 2,
                "price": 100,
                "subtotal": 200
              }
            },
            "subtotal": 200
          }
        },
        "conditions": [],
        "comment": null,
        "subtotal": 1400,
        "is_new": false,
        "units_id": "",
        "units_name": ""
      }
    ],
    "conditions": {
      "\u0000*\u0000items": {
        "tax": {
          "priority": "300",
          "name": "tax",
          "label": "nano.cart::default.text_vat",
          "removeable": false
        }
      }
    },
    "count": 6,
    "subtotalWithoutConditions": 3000,
    "subtotal": 3000,
    "total": 3450,
    "total_other": {
      "tax": {
        "code": "tax",
        "title": "VAT [15%]",
        "value": 450,
        "priority": "300",
        "is_summable": true
      }
    }
  },
  "count_success": 3,
  "count_error": 0,
  "items_error": []
}
```

### Add Many Items on Carts

**لاضافة مجموعة من الاصنفة دفعة واحدة الى السلة نستخدم الرابط التالي **

```
POST /api/v1/shop/carts/addmany
```
#### Attributes 

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `order_type`           | `string`  |  default value delivery |
| `is_destroy_cart`           | `boolean`  |  default value false |
| `items `           | `array`  | items []  |

**is_destroy_cart يستخدم فى حال اردنا تفريغ السلة من الاصناف السابقة واضافة الاصناف المرسلة **

**items يتم من خلالة تمرير الاصناف المراد اضافتها على شكل مصفوفة من الاصناف**
#### Example 2.1 Add Many Items



```json
{
  "is_destroy_cart": true,
  "items": [],
}
```
```
POST http://localhost:8006/api/v1/shop/carts/addmany
```

**فى المثال التالي سنقوم باضافة عدة اصناف دفعة واحدة مع تفريغ السلة من الاصناف السابقة **

```
POST http://localhost:8006/api/v1/shop/carts/addmany?is_destroy_cart=1&items[0][quantity]=6&items[0][menuId]=13&items[0][comment]=comment%20item&items[0][units_id]=34&items[0][price]=500&items[0][units_name]=part&items[1][menuId]=4&items[1][quantity]=2
```

##### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم تحديث السله بنجاح ",
  "data": {
    "content": [
      {
        "rowId": "a1ac6318aa8800a9803d513c0a0d63dc",
        "id": 13,
        "name": "منتج رقم 8889",
        "qty": "6",
        "price": 500,
        "options": [],
        "conditions": [],
        "comment": "comment item",
        "subtotal": 3000,
        "is_new": false,
        "units_id": "34",
        "units_name": "part"
      },
      {
        "rowId": "efb26e2c6ab6bd4d1323288923522d4e",
        "id": 4,
        "name": "حبة دجاج برست",
        "qty": "2",
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": null,
        "subtotal": 0,
        "is_new": false,
        "units_id": "",
        "units_name": ""
      }
    ],
    "conditions": {
      "\u0000*\u0000items": {
        "coupon": {
          "removeable": true,
          "priority": "200",
          "name": "coupon",
          "label": "Coupon  [%s]"
        },
        "tax": {
          "priority": "300",
          "name": "tax",
          "label": "nano.cart::default.text_vat",
          "removeable": false
        }
      }
    },
    "count": 8,
    "subtotalWithoutConditions": 3000,
    "subtotal": 3000,
    "total": 3335,
    "total_other": {
      "coupon": {
        "code": "coupon",
        "title": "Coupon  [2222]",
        "value": -100,
        "priority": "200",
        "is_summable": true
      },
      "tax": {
        "code": "tax",
        "title": "VAT [15%]",
        "value": 435,
        "priority": "300",
        "is_summable": true
      }
    }
  },
  "count_success": 2,
  "count_error": 0,
  "items_error": []
}
```
#### Example 2.2 Add Many Items and Error in items




**فى المثال التالي سنقوم باضافة عدة اصناف دفعة واحدة مع تفريغ السلة من الاصناف السابقة **

**فى المثال التالي سنحاول اضافة صنف يحتوي على خيارات الزامية بدون تمرير الخيارات بحيث يحدث خطاء فى هذه الصنف ولايتم اضافتة الى السلة **

```
POST http://localhost:8006/api/v1/shop/carts/addmany?is_destroy_cart=1&items[0][quantity]=6&items[0][menuId]=13&items[0][comment]=comment%20item&items[0][units_id]=34&items[0][price]=500&items[0][units_name]=part&items[1][menuId]=12&items[1][quantity]=2
```

##### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم تحديث السله بنجاح ",
  "data": {
    "content": [
      {
        "rowId": "a1ac6318aa8800a9803d513c0a0d63dc",
        "id": 13,
        "name": "منتج رقم 8889",
        "qty": "6",
        "price": 500,
        "options": [],
        "conditions": [],
        "comment": "comment item",
        "subtotal": 3000,
        "is_new": false,
        "units_id": "34",
        "units_name": "part"
      }
    ],
    "conditions": {
      "\u0000*\u0000items": {
        "coupon": {
          "removeable": true,
          "priority": "200",
          "name": "coupon",
          "label": "Coupon  [%s]"
        },
        "tax": {
          "priority": "300",
          "name": "tax",
          "label": "nano.cart::default.text_vat",
          "removeable": false
        }
      }
    },
    "count": 6,
    "subtotalWithoutConditions": 3000,
    "subtotal": 3000,
    "total": 3335,
    "total_other": {
      "coupon": {
        "code": "coupon",
        "title": "Coupon  [2222]",
        "value": -100,
        "priority": "200",
        "is_summable": true
      },
      "tax": {
        "code": "tax",
        "title": "VAT [15%]",
        "value": 435,
        "priority": "300",
        "is_summable": true
      }
    }
  },
  "count_success": 1,
  "count_error": 1,
  "items_error": [
    {
      "rowId": null,
      "menuId": "12",
      "quantity": "2",
      "name": null,
      "price": null,
      "comment": null,
      "options": null,
      "units_id": null,
      "units_name": null,
      "units_price": null,
      "error": "Please choose from the <b>التوابع<\/b> option."
    }
  ]
}
```

**من خلال النتيجة الرجعة نلاحظ انه تم اضافة الصنف الاول رقم 13 ولم يتم اضافة الصنف الثاني رقم 12 **

**توضح النتيجة الراجعة عدد الاصناف التي تم اضافتها فى المتغير count_success**

**count_error يوضح عدد الاصناف التي لم يتم ااضافتها **

**items_error يوضح بيانات الصنف الذي لم يتم اضافته وماهي المشكلة **
#### Example 2.3 Add Many Items with options in Carts

**فى المثال التالي سنقوم باضافة عدة اصناف دفعة واحدة مع تفريغ السلة من الاصناف السابقة **

**فى المثال التالي سنقوم باضافة الاصناف مع الخياررات الاضافية التابعة لها  **

```
POST http://localhost:8006/api/v1/shop/carts/addmany?items[0][quantity]=6&items[0][menuId]=13&items[0][comment]=comment%20item&items[0][units_id]=34&items[0][price]=500&items[0][units_name]=part&items[0][options][0][id]=2&items[0][options][0][name]=opion_nMe&items[0][options][0][values][0][id]=3&items[0][options][0][values][0][qty]=5&items[0][options][1][id]=1&items[0][options][1][name]=jjn&items[0][options][1][values][0][id]=2&items[0][options][1][values][0][name]=hjjj&is_destroy_cart=1&items[1][menuId]=12&items[1][quantity]=2&items[1][options][0][id]=3&items[1][options][0][values][0][id]=5&items[1][options][0][values][0][qty]=2
```

##### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم تحديث السله بنجاح ",
  "data": {
    "content": [
      {
        "rowId": "96b65f203523623797285d5d771c92e6",
        "id": 13,
        "name": "منتج رقم 8889",
        "qty": "6",
        "price": 500,
        "options": {
          "1": {
            "id": 1,
            "name": "التوابع",
            "values": {
              "2": {
                "id": 2,
                "name": "بدون التوابع",
                "qty": 1,
                "price": 0,
                "subtotal": 0
              }
            },
            "subtotal": 0
          },
          "2": {
            "id": 2,
            "name": "Drinks",
            "values": {
              "3": {
                "id": 3,
                "name": "Coke",
                "qty": 5,
                "price": 0,
                "subtotal": 0
              }
            },
            "subtotal": 0
          }
        },
        "conditions": [],
        "comment": "comment item",
        "subtotal": 3000,
        "is_new": false,
        "units_id": "34",
        "units_name": "part"
      },
      {
        "rowId": "b035fabfe3e68a5bd98891176583d6e4",
        "id": 12,
        "name": "منتج رقم 88",
        "qty": "2",
        "price": 78777,
        "options": {
          "3": {
            "id": 3,
            "name": "التوابع",
            "values": {
              "5": {
                "id": 5,
                "name": "مع التوابع",
                "qty": 2,
                "price": 0,
                "subtotal": 0
              }
            },
            "subtotal": 0
          }
        },
        "conditions": [],
        "comment": null,
        "subtotal": 157554,
        "is_new": false,
        "units_id": "",
        "units_name": ""
      }
    ],
    "conditions": {
      "\u0000*\u0000items": {
        "coupon": {
          "removeable": true,
          "priority": "200",
          "name": "coupon",
          "label": "Coupon  [%s]"
        },
        "tax": {
          "priority": "300",
          "name": "tax",
          "label": "nano.cart::default.text_vat",
          "removeable": false
        }
      }
    },
    "count": 8,
    "subtotalWithoutConditions": 160554,
    "subtotal": 160554,
    "total": 184522.1,
    "total_other": {
      "coupon": {
        "code": "coupon",
        "title": "Coupon  [2222]",
        "value": -100,
        "priority": "200",
        "is_summable": true
      },
      "tax": {
        "code": "tax",
        "title": "VAT [15%]",
        "value": 24068.1,
        "priority": "300",
        "is_summable": true
      }
    }
  },
  "count_success": 2,
  "count_error": 0,
  "items_error": []
}
```

**لاحظ انه فى الاصدارات الاخيره يتم ارجاع بالبيانات بالشكل التالي **

**يتم ارجاع الخيارات opions على شكل كائنات json**

```json
{
  "code": "200",
  "message": "تم تحديث السله بنجاح ",
  "data": {
    "content": [
      {
        "rowId": "96b65f203523623797285d5d771c92e6",
        "id": 13,
        "name": "منتج رقم 8889",
        "qty": "6",
        "price": 500,
        "options": [
          {
            "id": 1,
            "name": "التوابع",
            "values": [
              {
                "id": 2,
                "name": "بدون التوابع",
                "qty": 1,
                "price": 0,
                "subtotal": 0
              }
            ],
            "subtotal": 0
          },
          {
            "id": 2,
            "name": "Drinks",
            "values": [
              {
                "id": 3,
                "name": "Coke",
                "qty": 5,
                "price": 0,
                "subtotal": 0
              }
            ],
            "subtotal": 0
          }
        ],
        "conditions": [],
        "comment": "comment item",
        "subtotal": 3000,
        "is_new": false,
        "units_id": "34",
        "units_name": "part"
      },
      {
        "rowId": "b035fabfe3e68a5bd98891176583d6e4",
        "id": 12,
        "name": "منتج رقم 88",
        "qty": "2",
        "price": 78777,
        "options": [
          {
            "id": 3,
            "name": "التوابع",
            "values": [
              {
                "id": 5,
                "name": "مع التوابع",
                "qty": 2,
                "price": 0,
                "subtotal": 0
              }
            ],
            "subtotal": 0
          }
        ],
        "conditions": [],
        "comment": null,
        "subtotal": 157554,
        "is_new": false,
        "units_id": "",
        "units_name": ""
      }
    ],
    "conditions": {
      "\u0000*\u0000items": {
        "coupon": {
          "removeable": true,
          "priority": "200",
          "name": "coupon",
          "label": "Coupon  [%s]"
        },
        "tax": {
          "priority": "300",
          "name": "tax",
          "label": "nano.cart::default.text_vat",
          "removeable": false
        }
      }
    },
    "count": 8,
    "subtotalWithoutConditions": 160554,
    "subtotal": 160554,
    "total": 184522.1,
    "total_other": {
      "coupon": {
        "code": "coupon",
        "title": "Coupon  [2222]",
        "value": -100,
        "priority": "200",
        "is_summable": true
      },
      "tax": {
        "code": "tax",
        "title": "VAT [15%]",
        "value": 24068.1,
        "priority": "300",
        "is_summable": true
      }
    }
  },
  "count_success": 2,
  "count_error": 0,
  "items_error": []
}
```


### Update Quantity Items 

**لتعديل الكميه الخاصه بصنف معين تم اضافته الى السله نستخدم الرابط التالى معا تمرير معرف الصنف فى السله والكميه **

```
POST /api/v1/shop/carts/updateqty/{rowId?}/{quantity?}
```
#### Attributes 

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `rowId`           | `string`  |  rowId Items |
| `units_id`           | `string`  |  units_id |
| `quantity `           | `integer|string`  | quantity [integer|plus|minus]  |

** فى متغير الكميه يمكن تمرير الكميه كا رقم او يمكن تمرير قيمه نصيه معبره عن الزياده او النقصان **
#### Example 3 Update quantity

** فى المثال التالى سنقوم بتغيير كميه الصنف الى 3  **


```json
{
  "rowId": "a5d953bd82541f216e265c50b7c6e879",
  "quantity": 3,
}
```
```
POST http://localhost:8006/api/v1/shop/carts/updateqty?rowId=a5d953bd82541f216e265c50b7c6e879&quantity=3
```

#### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم تحديث الكمية بنجاح ",
  "data": {
    "content": {
      "c4bdc41d31462c9c59e3648c711b7bd6": {
        "rowId": "c4bdc41d31462c9c59e3648c711b7bd6",
        "id": 2,
        "name": "الصنف الثاني",
        "units_id": "",
        "units_name": "",
        "qty": 8,
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "comment this",
        "subtotal": 0
      },
      "a5d953bd82541f216e265c50b7c6e879": {
        "rowId": "a5d953bd82541f216e265c50b7c6e879",
        "id": 3,
        "name": "نفر رز",
        "units_id": "",
        "units_name": "",
        "qty": "3",
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف",
        "subtotal": 0
      }
    },
    "conditions": [],
    "count": 11,
    "subtotalWithoutConditions": 0,
    "subtotal": 0,
    "total": 0
  }
}
```

**لزياده الصنف بمقدار واحد نقوم بتمرير البيانات كا التالي  :- **

```json
{
  "rowId": "a5d953bd82541f216e265c50b7c6e879",
  "quantity": "plus",
}
```

```
POST http://localhost:8006/api/v1/shop/carts/updateqty?rowId=a5d953bd82541f216e265c50b7c6e879&quantity=plus
```

#### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم تحديث الكمية بنجاح ",
  "data": {
    "content": {
      "c4bdc41d31462c9c59e3648c711b7bd6": {
        "rowId": "c4bdc41d31462c9c59e3648c711b7bd6",
        "id": 2,
        "name": "الصنف الثاني",
        "units_id": "",
        "units_name": "",
        "qty": 8,
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "comment this",
        "subtotal": 0
      },
      "a5d953bd82541f216e265c50b7c6e879": {
        "rowId": "a5d953bd82541f216e265c50b7c6e879",
        "id": 3,
        "name": "نفر رز",
        "units_id": "",
        "units_name": "",
        "qty": 4,
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف",
        "subtotal": 0
      }
    },
    "conditions": [],
    "count": 12,
    "subtotalWithoutConditions": 0,
    "subtotal": 0,
    "total": 0
  }
}
```

### Destroy Carts 

**لتفريغ السلة نستخدم الرابط التالي **

```
DELETE /api/v1/shop/carts/destroy
```

```
DELETE http://localhost:8006/api/v1/shop/carts/destroy
```

#### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم تفريغ السلة بنجاح  "
}
```

### Delete Item in Carts 

**لحذف صنف معين من السله نستخدم الرابط التالى معا تمرير معرف الصنف فى السله **

```
DELETE /api/v1/shop/carts/delete/{rowId?}
```
#### Example 3 DELETE Items in Carts

** فى المثال التالى سنقوم  بحذف صنف معين من السله   **



```json
{
  "rowId": "a5d953bd82541f216e265c50b7c6e879",
}
```

```
DELETE http://localhost:8006/api/v1/shop/carts/delete?rowId=a5d953bd82541f216e265c50b7c6e879
```

#### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "message": "تم حذف الصنف من السله بنجاح  ",
  "data": {
    "content": {
      "c4bdc41d31462c9c59e3648c711b7bd6": {
        "rowId": "c4bdc41d31462c9c59e3648c711b7bd6",
        "id": 2,
        "name": "الصنف الثاني",
        "units_id": "",
        "units_name": "",
        "qty": 8,
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "comment this",
        "subtotal": 0
      }
    },
    "conditions": [],
    "count": 8,
    "subtotalWithoutConditions": 0,
    "subtotal": 0,
    "total": 0
  }
}
```



