## ProductsOptions Shop 

This endpoint allows you to `list`, `show` your option.

/shop/productsoptions

**الجزء الخاص بجلب الخيارات او الخصائص الاضافية العامه التي يمكن ان ترتبط بالاصناف والمنتجات **

### The productsoptions object

#### Public Parameters
| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in products options records |
| `orderBy`           | `string`  |  using orderBy products options records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy products options records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  products options default value true    |
| `isPublic`           | `boolean`  | The get is Public in Web records products options default value true  | 
| `isDefault`           | `integer`  | The get is default records products options default value false  | 

| `type`           | `string`  | get records products options with type default value null.          |
| `options_id`           | `string`  | get records products options with options_id default value null.          |
| `products_id`           | `string`  | get records products options with products_id default value null.          |
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `departments`           | `belongsTo`  | The get departments |
| `option`           | `belongsTo`  | The get option |
| `products_options_values`           | `hasMny`  | The get products_options_values |

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/shop/productsoptions?exclude=created_at,updated_at
```

##### Response

```html
Status: 200 OK
```
```json
{
  "data": [
    {
      "id": 3,
      "options_id": 5,
      "products_id": 12,
      "name": "التوابع",
      "type": "radio",
      "required": 1,
      "is_public": 1,
      "is_default": 1,
      "is_active": 1,
      "min_selected": 0,
      "max_selected": 0,
      "sort_order": 3,
      "companys_id": "2",
      "departments_id": "2",
      "other_data": [],
      "config_data": [],
      "products_options_values": {
        "data": [
          {
            "id": 5,
            "options_id": 5,
            "options_values_id": 1,
            "products_options_id": 3,
            "products_id": 12,
            "value": "مع التوابع",
            "default_value": 0,
            "old_price": 100,
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 5,
            "companys_id": "2",
            "departments_id": "2"
          },
          {
            "id": 6,
            "options_id": 5,
            "options_values_id": 3,
            "products_options_id": 3,
            "products_id": 12,
            "value": "بدون التوابع",
            "default_value": 0,
            "old_price": 0,
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 6,
            "companys_id": "2",
            "departments_id": "2"
          }
        ]
      }
    },
    {
      "id": 2,
      "options_id": 6,
      "products_id": 13,
      "name": "Drinks",
      "type": "checkbox",
      "required": 0,
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "min_selected": 0,
      "max_selected": 0,
      "sort_order": 2,
      "companys_id": "2",
      "departments_id": "2",
      "other_data": [],
      "config_data": [],
      "products_options_values": {
        "data": [
          {
            "id": 3,
            "options_id": 6,
            "options_values_id": 4,
            "products_options_id": 2,
            "products_id": 13,
            "value": "Coke",
            "default_value": 0,
            "old_price": 0,
            "price": 0,
            "is_public": 1,
            "is_default": 1,
            "is_active": 1,
            "sort_order": 3,
            "companys_id": "2",
            "departments_id": "2"
          },
          {
            "id": 4,
            "options_id": 6,
            "options_values_id": 5,
            "products_options_id": 2,
            "products_id": 13,
            "value": "Diet Coke",
            "default_value": 0,
            "old_price": 0,
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 4,
            "companys_id": "2",
            "departments_id": "2"
          }
        ]
      }
    },
    {
      "id": 1,
      "options_id": 5,
      "products_id": 13,
      "name": "التوابع",
      "type": "radio",
      "required": 0,
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "min_selected": 0,
      "max_selected": 0,
      "sort_order": 1,
      "companys_id": "2",
      "departments_id": "2",
      "other_data": [],
      "config_data": [],
      "products_options_values": {
        "data": [
          {
            "id": 1,
            "options_id": 5,
            "options_values_id": 2,
            "products_options_id": 1,
            "products_id": 13,
            "value": "مع التوابع",
            "default_value": 0,
            "old_price": 0,
            "price": 0,
            "is_public": 1,
            "is_default": 1,
            "is_active": 1,
            "sort_order": 1,
            "companys_id": "2",
            "departments_id": "2"
          },
          {
            "id": 2,
            "options_id": 5,
            "options_values_id": 3,
            "products_options_id": 1,
            "products_id": 13,
            "value": "بدون التوابع",
            "default_value": 0,
            "old_price": 0,
            "price": 0,
            "is_public": 0,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 2,
            "companys_id": "2",
            "departments_id": "2"
          }
        ]
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 3,
      "count": 3,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```


### List products options

Returns a list of products options

```
GET /api/v1/shop/productsoptions
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |


### Example 1.1 get List Products Options 

GET http://localhost:8006/api/v1/shop/productsoptions

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 3,
      "options_id": 5,
      "products_id": 12,
      "name": "التوابع",
      "type": "radio",
      "required": 1,
      "is_public": 1,
      "is_default": 1,
      "is_active": 1,
      "min_selected": 0,
      "max_selected": 0,
      "sort_order": 3,
      "companys_id": "2",
      "departments_id": "2",
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-13 19:01:08",
      "updated_at": "2023-10-13 19:01:08",
      "products_options_values": {
        "data": [
          {
            "id": 5,
            "options_id": 5,
            "options_values_id": 1,
            "products_options_id": 3,
            "products_id": 12,
            "value": "مع التوابع",
            "default_value": 0,
            "old_price": 100,
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 5,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-13 19:01:08",
            "updated_at": "2023-10-13 19:01:08"
          },
          {
            "id": 6,
            "options_id": 5,
            "options_values_id": 3,
            "products_options_id": 3,
            "products_id": 12,
            "value": "بدون التوابع",
            "default_value": 0,
            "old_price": 0,
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 6,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-13 19:01:08",
            "updated_at": "2023-10-13 19:01:08"
          }
        ]
      }
    },
    {
      "id": 2,
      "options_id": 6,
      "products_id": 13,
      "name": "Drinks",
      "type": "checkbox",
      "required": 0,
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "min_selected": 0,
      "max_selected": 0,
      "sort_order": 2,
      "companys_id": "2",
      "departments_id": "2",
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-05 21:07:51",
      "updated_at": "2023-10-05 21:07:51",
      "products_options_values": {
        "data": [
          {
            "id": 3,
            "options_id": 6,
            "options_values_id": 4,
            "products_options_id": 2,
            "products_id": 13,
            "value": "Coke",
            "default_value": 0,
            "old_price": 0,
            "price": 0,
            "is_public": 1,
            "is_default": 1,
            "is_active": 1,
            "sort_order": 3,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-05 21:07:51",
            "updated_at": "2023-10-05 21:07:51"
          },
          {
            "id": 4,
            "options_id": 6,
            "options_values_id": 5,
            "products_options_id": 2,
            "products_id": 13,
            "value": "Diet Coke",
            "default_value": 0,
            "old_price": 0,
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 4,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-05 21:07:51",
            "updated_at": "2023-10-05 21:07:51"
          }
        ]
      }
    },
    {
      "id": 1,
      "options_id": 5,
      "products_id": 13,
      "name": "التوابع",
      "type": "radio",
      "required": 0,
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "min_selected": 0,
      "max_selected": 0,
      "sort_order": 1,
      "companys_id": "2",
      "departments_id": "2",
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-05 19:35:43",
      "updated_at": "2023-10-05 19:35:43",
      "products_options_values": {
        "data": [
          {
            "id": 1,
            "options_id": 5,
            "options_values_id": 2,
            "products_options_id": 1,
            "products_id": 13,
            "value": "مع التوابع",
            "default_value": 0,
            "old_price": 0,
            "price": 0,
            "is_public": 1,
            "is_default": 1,
            "is_active": 1,
            "sort_order": 1,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-05 20:06:08",
            "updated_at": "2023-10-05 20:06:08"
          },
          {
            "id": 2,
            "options_id": 5,
            "options_values_id": 3,
            "products_options_id": 1,
            "products_id": 13,
            "value": "بدون التوابع",
            "default_value": 0,
            "old_price": 0,
            "price": 0,
            "is_public": 0,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 2,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-05 20:06:08",
            "updated_at": "2023-10-05 20:06:08"
          }
        ]
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 3,
      "count": 3,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

### Example 1.2 get List Products Options where type = radio,number

GET http://localhost:8006/api/v1/shop/productsoptions?type=radio,number

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 3,
      "options_id": 5,
      "products_id": 12,
      "name": "التوابع",
      "type": "radio",
      "required": 1,
      "is_public": 1,
      "is_default": 1,
      "is_active": 1,
      "min_selected": 0,
      "max_selected": 0,
      "sort_order": 3,
      "companys_id": "2",
      "departments_id": "2",
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-13 19:01:08",
      "updated_at": "2023-10-13 19:01:08",
      "products_options_values": {
        "data": [
          {
            "id": 5,
            "options_id": 5,
            "options_values_id": 1,
            "products_options_id": 3,
            "products_id": 12,
            "value": "مع التوابع",
            "default_value": 0,
            "old_price": 100,
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 5,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-13 19:01:08",
            "updated_at": "2023-10-13 19:01:08"
          },
          {
            "id": 6,
            "options_id": 5,
            "options_values_id": 3,
            "products_options_id": 3,
            "products_id": 12,
            "value": "بدون التوابع",
            "default_value": 0,
            "old_price": 0,
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 6,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-13 19:01:08",
            "updated_at": "2023-10-13 19:01:08"
          }
        ]
      }
    },
    {
      "id": 1,
      "options_id": 5,
      "products_id": 13,
      "name": "التوابع",
      "type": "radio",
      "required": 0,
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "min_selected": 0,
      "max_selected": 0,
      "sort_order": 1,
      "companys_id": "2",
      "departments_id": "2",
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-05 19:35:43",
      "updated_at": "2023-10-05 19:35:43",
      "products_options_values": {
        "data": [
          {
            "id": 1,
            "options_id": 5,
            "options_values_id": 2,
            "products_options_id": 1,
            "products_id": 13,
            "value": "مع التوابع",
            "default_value": 0,
            "old_price": 0,
            "price": 0,
            "is_public": 1,
            "is_default": 1,
            "is_active": 1,
            "sort_order": 1,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-05 20:06:08",
            "updated_at": "2023-10-05 20:06:08"
          },
          {
            "id": 2,
            "options_id": 5,
            "options_values_id": 3,
            "products_options_id": 1,
            "products_id": 13,
            "value": "بدون التوابع",
            "default_value": 0,
            "old_price": 0,
            "price": 0,
            "is_public": 0,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 2,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-05 20:06:08",
            "updated_at": "2023-10-05 20:06:08"
          }
        ]
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

### Example 1.3 get List Products Options exclude = products_options_values and where type = radio,checkbox

GET http://localhost:8006/api/v1/shop/productsoptions?type=radio,checkbox&exclude=products_options_values

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 3,
      "options_id": 5,
      "products_id": 12,
      "name": "التوابع",
      "type": "radio",
      "required": 1,
      "is_public": 1,
      "is_default": 1,
      "is_active": 1,
      "min_selected": 0,
      "max_selected": 0,
      "sort_order": 3,
      "companys_id": "2",
      "departments_id": "2",
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-13 19:01:08",
      "updated_at": "2023-10-13 19:01:08"
    },
    {
      "id": 2,
      "options_id": 6,
      "products_id": 13,
      "name": "Drinks",
      "type": "checkbox",
      "required": 0,
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "min_selected": 0,
      "max_selected": 0,
      "sort_order": 2,
      "companys_id": "2",
      "departments_id": "2",
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-05 21:07:51",
      "updated_at": "2023-10-05 21:07:51"
    },
    {
      "id": 1,
      "options_id": 5,
      "products_id": 13,
      "name": "التوابع",
      "type": "radio",
      "required": 0,
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "min_selected": 0,
      "max_selected": 0,
      "sort_order": 1,
      "companys_id": "2",
      "departments_id": "2",
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-05 19:35:43",
      "updated_at": "2023-10-05 19:35:43"
    }
  ],
  "meta": {
    "pagination": {
      "total": 3,
      "count": 3,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

### Example 1.4 get List Products Options where products_id=12

GET http://localhost:8006/api/v1/shop/productsoptions?products_id=12

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 3,
      "options_id": 5,
      "products_id": 12,
      "name": "التوابع",
      "type": "radio",
      "required": 1,
      "is_public": 1,
      "is_default": 1,
      "is_active": 1,
      "min_selected": 0,
      "max_selected": 0,
      "sort_order": 3,
      "companys_id": "2",
      "departments_id": "2",
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-13 19:01:08",
      "updated_at": "2023-10-13 19:01:08",
      "products_options_values": {
        "data": [
          {
            "id": 5,
            "options_id": 5,
            "options_values_id": 1,
            "products_options_id": 3,
            "products_id": 12,
            "value": "مع التوابع",
            "default_value": 0,
            "old_price": 100,
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 5,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-13 19:01:08",
            "updated_at": "2023-10-13 19:01:08"
          },
          {
            "id": 6,
            "options_id": 5,
            "options_values_id": 3,
            "products_options_id": 3,
            "products_id": 12,
            "value": "بدون التوابع",
            "default_value": 0,
            "old_price": 0,
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 6,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-13 19:01:08",
            "updated_at": "2023-10-13 19:01:08"
          }
        ]
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

### Example 1.5 get List Products Options exclude = products_options_values and where products_id=12,13 and type = checkbox

GET http://localhost:8006/api/v1/shop/productsoptions?type=checkbox&exclude=products_options_values&products_id=12,13

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 2,
      "options_id": 6,
      "products_id": 13,
      "name": "Drinks",
      "type": "checkbox",
      "required": 0,
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "min_selected": 0,
      "max_selected": 0,
      "sort_order": 2,
      "companys_id": "2",
      "departments_id": "2",
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-05 21:07:51",
      "updated_at": "2023-10-05 21:07:51"
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

### Example 1.6 get List Products Options exclude = products_options_values and where products_id=12,13 and type = radio

GET http://localhost:8006/api/v1/shop/productsoptions?type=radio&exclude=products_options_values&products_id=12,13

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 3,
      "options_id": 5,
      "products_id": 12,
      "name": "التوابع",
      "type": "radio",
      "required": 1,
      "is_public": 1,
      "is_default": 1,
      "is_active": 1,
      "min_selected": 0,
      "max_selected": 0,
      "sort_order": 3,
      "companys_id": "2",
      "departments_id": "2",
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-13 19:01:08",
      "updated_at": "2023-10-13 19:01:08"
    },
    {
      "id": 1,
      "options_id": 5,
      "products_id": 13,
      "name": "التوابع",
      "type": "radio",
      "required": 0,
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "min_selected": 0,
      "max_selected": 0,
      "sort_order": 1,
      "companys_id": "2",
      "departments_id": "2",
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-05 19:35:43",
      "updated_at": "2023-10-05 19:35:43"
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

### Show Data Record Products Options 

```
GET /api/v1/shop/productsoptions/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record Products Options 3

```
GET http://localhost:8006/api/v1/shop/productsoptions/3
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "id": 3,
  "options_id": 5,
  "products_id": 12,
  "name": "التوابع",
  "type": "radio",
  "required": 1,
  "is_public": 1,
  "is_default": 1,
  "is_active": 1,
  "min_selected": 0,
  "max_selected": 0,
  "sort_order": 3,
  "companys_id": "2",
  "departments_id": "2",
  "other_data": [],
  "config_data": [],
  "created_at": "2023-10-13 19:01:08",
  "updated_at": "2023-10-13 19:01:08",
  "products_options_values": {
    "data": [
      {
        "id": 5,
        "options_id": 5,
        "options_values_id": 1,
        "products_options_id": 3,
        "products_id": 12,
        "value": "مع التوابع",
        "old_price": 100,
        "price": 0,
        "is_public": 1,
        "is_default": 0,
        "is_active": 1,
        "sort_order": 5,
        "companys_id": "2",
        "departments_id": "2",
        "created_at": "2023-10-13 19:01:08",
        "updated_at": "2023-10-13 19:01:08"
      },
      {
        "id": 6,
        "options_id": 5,
        "options_values_id": 3,
        "products_options_id": 3,
        "products_id": 12,
        "value": "بدون التوابع",
        "old_price": 0,
        "price": 0,
        "is_public": 1,
        "is_default": 0,
        "is_active": 1,
        "sort_order": 6,
        "companys_id": "2",
        "departments_id": "2",
        "created_at": "2023-10-13 19:01:08",
        "updated_at": "2023-10-13 19:01:08"
      }
    ]
  }
}
```

### Check Last Update Products Options Data

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/shop/productsoptions/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/shop/productsoptions/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2023-10-13 19:16:38",
    "other_updated": {
      "activity_cache.productsoption": "2023-10-13 19:16:38",
      "activity_cache.product": "2023-10-13 19:16:38",
      "activity_cache.productsoptionsvalue": "2023-10-13 19:16:38"
    }
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2023-10-13 19:15:52",
    "last_updated": "2023-10-13 19:15:52",
    "other_updated": {
      "activity_cache.productsoption": "2023-10-13 19:15:52",
      "activity_cache.product": "2023-10-13 19:15:52",
      "activity_cache.productsoptionsvalue": "2023-10-13 19:15:52"
    }
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **

