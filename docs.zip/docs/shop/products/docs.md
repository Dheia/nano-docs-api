## Products Api

This endpoint allows you to `list`, `show` your products.

/shop/products
### The products object

#### Public Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in products records |
| `orderBy`           | `string`  |  using orderBy departments records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy departments records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `reftype`           | `string`  | **Required**. The get Products type [products,services,all] default value products    |
| `isActive`           | `boolean`  | **Required**. The get is Active  products default value true    |
| `isOffer`           | `boolean`  | **Required**. The get is Active  products
default value false    |
| `isPublished`           | `boolean`  | The get is Published in Web records products default value true  | 
| `isDefaultPricesUnits`           | `boolean`  | The get default prices_units all item  default value true  | 
| `groups_products_id`           | `integer`  | The get products in to groups_products_id  default value false  | 
| `companys_id`           | `integer`  |  get records products to companys_id default value false.         |
| `departments_id`           | `integer`  | get records products to departments_id default value true.          |
| `categorysId`           | `string `  | useing get products where categorysId [2,3,4] default value ''
| 
| `tagsId`           | `string `  | useing get products where tagsId [2,3,4] default value ''
| 
| `menus_id`           | `string `  | useing get products where menus_id  default value 'null'
| 
| `order_type`           | `string `  | useing get products where order_type  default value 'null'
| 
| `country_id`           | `string `  | useing get products where country_id  default value 'null'
| 
| `state_id`           | `string `  | useing get products where state_id  default value 'null'
| 
| `isFavorites`           | `boolean `  | useing get products where my Favorites default value false 
| 
| `include`           | `string `  | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/shop/products?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `department`           | `belongsTo`  | The get department | 
| `groups_product`           | `belongsTo`  | The get groups_product   | 
| `tags`           | `hasMany`  | The get tags   | 
| `categories`           | `hasMany`  | The get categories   | 
| `children`           | `hasMany`  | The get children   | 
| `prices_units`           | `hasMany`  | The get prices_units | 
| `product_options`           | `hasMany`  | The get product_options  default | 
| `product_options_values`           | `hasMany`  | The get product_options_values| 


### List products

Returns a list of products you’ve previously created.

```
GET /api/v1/shop/products
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

### Example 1 get List Products 

```
GET http://localhost:8006/api/v1/shop/products
```

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 4,
      "code": "2-2-4",
      "barcode": "2-4",
      "name": "حبة دجاج برست",
      "emblem": "",
      "short_description": "",
      "description": "",
      "users_manual": "",
      "composition": "",
      "indication": "",
      "meta_title": "",
      "meta_description": "",
      "keywords": "",
      "ref_type_class": "products",
      "ref_key_values_class": "3",
      "groups_products_id": "2",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": null,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "manage_stock": 0,
      "shop_stock": 0,
      "min_qty": 1,
      "max_qty": 1,
      "min_qty_in_stock": 1,
      "max_qty_in_stock": 1,
      "default_qty": 1,
      "old_price": null,
      "price": 0,
      "is_show_old_price": 1,
      "is_parleying": 1,
      "is_sold": 1,
      "is_purchased": 1,
      "is_composite": 0,
      "is_units": 1,
      "is_downloadable": 1,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 4,
      "created_at": "2022-10-02 15:22:20",
      "updated_at": "2022-10-02 15:22:20",
      "image": {
        "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/633b47a8bee36870039097.png",
        "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_160_160_0_0_crop.png",
        "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_240_240_0_0_crop.png",
        "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_800_800_0_0_crop.png",
        "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_480_480_0_0_auto.png"
      },
      "images": [],
      "files": [],
      "ratings_count": 4,
      "countRating": 4,
      "sumRating": "13",
      "averageRating": "3.2500",
      "user_is_rating": true,
      "user_object_rating": {
        "id": 15,
        "code": "2-4-15",
        "is_recommended": true,
        "rating": 3,
        "title": "543منتج رائع",
        "content": "التعليق 543",
        "approved": true,
        "reviewrateable_type": "products",
        "reviewrateable_id": 4,
        "user_type": "RainLab\\User\\Models\\User",
        "user_id": 543,
        "name": null,
        "email": null,
        "url": "\/api\/v1\/shop\/products",
        "hash": "8a20d49df9a87ab7c4fe945097bcca27",
        "locale": "ar",
        "ip": "127.0.0.1",
        "ip_forwarded": null,
        "user_agent": "okhttp\/3.8.1",
        "companys_id": "2",
        "departments_id": "4",
        "is_active": true,
        "other_data": null,
        "config_data": null,
        "sort_order": 15,
        "created_by": null,
        "updated_by": null,
        "deleted_by": null,
        "created_at": "2022-10-11 19:12:46",
        "updated_at": "2022-10-11 19:23:31",
        "deleted_at": null
      },
      "favorites_count": 3,
      "user_is_favorite": true,
      "user_object_favorite": {
        "user_id": 543,
        "favoriteable_type": "products",
        "favoriteable_id": 4,
        "created_at": "2022-10-09 23:46:35",
        "updated_at": "2022-10-09 23:46:35"
      }
    },
    {
      "id": 3,
      "code": "2-2-3",
      "barcode": "2-3",
      "name": "نفر رز",
      "emblem": "",
      "short_description": "",
      "description": "",
      "users_manual": "",
      "composition": "",
      "indication": "",
      "meta_title": "",
      "meta_description": "",
      "keywords": "",
      "ref_type_class": "products",
      "ref_key_values_class": "3",
      "groups_products_id": "2",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": null,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "manage_stock": 0,
      "shop_stock": 0,
      "min_qty": 1,
      "max_qty": 1,
      "min_qty_in_stock": 1,
      "max_qty_in_stock": 1,
      "default_qty": 1,
      "old_price": null,
      "price": 0,
      "is_show_old_price": 1,
      "is_parleying": 1,
      "is_sold": 1,
      "is_purchased": 1,
      "is_composite": 0,
      "is_units": 1,
      "is_downloadable": 1,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 3,
      "created_at": "2022-10-02 15:21:13",
      "updated_at": "2022-10-02 15:21:13",
      "image": null,
      "images": [],
      "files": [],
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Example 2 get List Products reftype=services

** جلب الخدمات بتحديد النوع خدمه **

```
GET http://localhost:8006/api/v1/shop/products?reftype=services
```

#### Response

```html
Status: 200 OK
```

```json
```

### Example 3.1 get data Products 

** لجب بيانات منتج معين نقوم بتمرير رقم المنتج فى الرابط كا التالى **

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


```
GET /api/v1/shop/products/{id}
```
```
GET http://localhost:8006/api/v1/shop/products/4
```

#### Response

```html
Status: 200 OK
```

```json
{
  "id": 4,
  "code": "2-2-4",
  "barcode": "2-4",
  "name": "حبة دجاج برست",
  "emblem": "",
  "short_description": "",
  "description": "",
  "users_manual": "",
  "composition": "",
  "indication": "",
  "meta_title": "",
  "meta_description": "",
  "keywords": "",
  "ref_type_class": "products",
  "ref_key_values_class": "3",
  "groups_products_id": "2",
  "companys_id": "2",
  "departments_id": "2",
  "is_effective": 1,
  "is_default": null,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "manage_stock": 0,
  "shop_stock": 0,
  "min_qty": 1,
  "max_qty": 1,
  "min_qty_in_stock": 1,
  "max_qty_in_stock": 1,
  "default_qty": 1,
  "old_price": null,
  "price": 0,
  "is_show_old_price": 1,
  "is_parleying": 1,
  "is_sold": 1,
  "is_purchased": 1,
  "is_composite": 0,
  "is_units": 1,
  "is_downloadable": 1,
  "properties": null,
  "links": null,
  "other_data": null,
  "config_data": null,
  "sort_order": 4,
  "created_at": "2022-10-02 15:22:20",
  "updated_at": "2022-10-02 15:22:20",
  "image": {
    "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/633b47a8bee36870039097.png",
    "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_160_160_0_0_crop.png",
    "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_240_240_0_0_crop.png",
    "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_800_800_0_0_crop.png",
    "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_480_480_0_0_auto.png"
  },
  "images": [],
  "files": [],
  "ratings_count": 4,
  "countRating": 4,
  "sumRating": "13",
  "averageRating": "3.2500",
  "user_is_rating": true,
  "user_object_rating": {
    "id": 15,
    "code": "2-4-15",
    "is_recommended": true,
    "rating": 3,
    "title": "543منتج رائع",
    "content": "التعليق 543",
    "approved": true,
    "reviewrateable_type": "products",
    "reviewrateable_id": 4,
    "user_type": "RainLab\\User\\Models\\User",
    "user_id": 543,
    "name": null,
    "email": null,
    "url": "\/api\/v1\/shop\/products",
    "hash": "8a20d49df9a87ab7c4fe945097bcca27",
    "locale": "ar",
    "ip": "127.0.0.1",
    "ip_forwarded": null,
    "user_agent": "okhttp\/3.8.1",
    "companys_id": "2",
    "departments_id": "4",
    "is_active": true,
    "other_data": null,
    "config_data": null,
    "sort_order": 15,
    "created_by": null,
    "updated_by": null,
    "deleted_by": null,
    "created_at": "2022-10-11 19:12:46",
    "updated_at": "2022-10-11 19:23:31",
    "deleted_at": null
  },
  "favorites_count": 3,
  "user_is_favorite": true,
  "user_object_favorite": {
    "user_id": 543,
    "favoriteable_type": "products",
    "favoriteable_id": 4,
    "created_at": "2022-10-09 23:46:35",
    "updated_at": "2022-10-09 23:46:35"
  }
}
```
### Example 3.2 get data Products with default 

** فى المثال التالي سنقوم بجلب بيانات منتج معين لايحتوي على وحدات مع تمرير المتغير isDefaultPricesUnits بالقيمة 1 **

Required Parameters: `id`
Required Parameters: `isDefaultPricesUnits`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |
| `isDefaultPricesUnits`           | `integer`  | . The isDefaultPricesUnits          |


```
GET /api/v1/shop/products/{id}
```
```
GET https://alnaeem.nano2soft.com/api/v1/shop/products/1585?isDefaultPricesUnits=1
```
**من خلال النتيجه فى الاسفل نلاحض انه تم ارجاع قيم افتراضية ضمن prices_units بالرغم ان المنتج لايحتوي على وحدات **

#### Response

```html
Status: 200 OK
```

```json
{
  "id": 1585,
  "code": "2-2-1585",
  "barcode": "0-1585",
  "name": "ماء شملان كبير",
  "emblem": "كبير",
  "short_description": "",
  "description": "",
  "users_manual": "",
  "composition": "",
  "indication": "",
  "meta_title": "",
  "meta_description": "",
  "keywords": "",
  "ref_type_class": "products",
  "ref_key_values_class": "3",
  "is_offer": 0,
  "groups_products_id": "0",
  "companys_id": "2",
  "departments_id": "2",
  "is_effective": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "manage_stock": 0,
  "shop_stock": 0,
  "min_qty": 1,
  "max_qty": 1,
  "min_qty_in_stock": 1,
  "max_qty_in_stock": 1,
  "default_qty": 1,
  "old_price": 250,
  "price": 240,
  "is_show_old_price": 1,
  "is_parleying": 1,
  "is_sold": 1,
  "is_purchased": 1,
  "is_composite": 0,
  "is_units": 0,
  "is_downloadable": 1,
  "properties": null,
  "links": null,
  "other_data": null,
  "config_data": null,
  "sort_order": 1585,
  "created_at": "2023-09-12 21:31:19",
  "updated_at": "2023-09-12 21:33:01",
  "image": null,
  "images": [],
  "files": [],
  "ratings_count": 0,
  "countRating": 0,
  "sumRating": 0,
  "averageRating": 0,
  "user_is_rating": 0,
  "user_object_rating": null,
  "favorites_count": 0,
  "user_is_favorite": 0,
  "likes_count": 0,
  "bookmarks_count": 0,
  "reactions_count": 0,
  "object_type": "Nano\\Shop\\Models\\Product",
  "qty": 0,
  "children": {
    "data": [],
    "meta": {
      "pagination": {
        "total": 0,
        "count": 0,
        "per_page": 10,
        "current_page": 1,
        "total_pages": 1,
        "links": {}
      }
    }
  },
  "prices_units": {
    "data": [
      {
        "id": 0,
        "products_id": "1585",
        "units_id": "0",
        "units_name": "حبة",
        "is_main": 1,
        "rate": 1,
        "prices_id": "0",
        "prices_name": "التسعيره الإفتراضية",
        "is_show_old_price": 1,
        "old_price": 250,
        "price": 240,
        "costed_amount": 0,
        "is_parleying": 1,
        "manage_stock": 0,
        "shop_stock": 0,
        "currencys_id": "1",
        "currencys_id_name": "ريال يمني",
        "is_default": 1,
        "is_active": 1,
        "qty": 0
      }
    ]
  }
}
```

**فى حالة عدم تمرير المتغير isDefaultPricesUnits ستكون النتيجه كالتالي **

```json
{
  "id": 1585,
  "code": "2-2-1585",
  "barcode": "0-1585",
  "name": "ماء شملان كبير",
  "emblem": "كبير",
  "short_description": "",
  "description": "",
  "users_manual": "",
  "composition": "",
  "indication": "",
  "meta_title": "",
  "meta_description": "",
  "keywords": "",
  "ref_type_class": "products",
  "ref_key_values_class": "3",
  "is_offer": 0,
  "groups_products_id": "0",
  "companys_id": "2",
  "departments_id": "2",
  "is_effective": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "manage_stock": 0,
  "shop_stock": 0,
  "min_qty": 1,
  "max_qty": 1,
  "min_qty_in_stock": 1,
  "max_qty_in_stock": 1,
  "default_qty": 1,
  "old_price": 250,
  "price": 240,
  "is_show_old_price": 1,
  "is_parleying": 1,
  "is_sold": 1,
  "is_purchased": 1,
  "is_composite": 0,
  "is_units": 0,
  "is_downloadable": 1,
  "properties": null,
  "links": null,
  "other_data": null,
  "config_data": null,
  "sort_order": 1585,
  "created_at": "2023-09-12 21:31:19",
  "updated_at": "2023-09-12 21:33:01",
  "image": null,
  "images": [],
  "files": [],
  "ratings_count": 0,
  "countRating": 0,
  "sumRating": 0,
  "averageRating": 0,
  "user_is_rating": 0,
  "user_object_rating": null,
  "favorites_count": 0,
  "user_is_favorite": 0,
  "likes_count": 0,
  "bookmarks_count": 0,
  "reactions_count": 0,
  "object_type": "Nano\\Shop\\Models\\Product",
  "qty": 0,
  "children": {
    "data": [],
    "meta": {
      "pagination": {
        "total": 0,
        "count": 0,
        "per_page": 10,
        "current_page": 1,
        "total_pages": 1,
        "links": {}
      }
    }
  },
  "prices_units": {
    "data": []
  }
}
```
### Example 3.3 get data Products with product_options

**الخيارات الاضافية للاصنف فى الاصدارة الاخيرة تم اضافة جزء الخيارات او الخصائص الاضافية للاصناف**

**تستخدم الخيارات الاضافية عند اضافة الصنف الى السلة وتاثر على السعر فى بعض الحالات **

**تم تضمين العااقة product_options بشكل افتراصي عند جلب بيانات الاصناف **

**فى المثال التالي سنستعرض صنف يحتوي على خيارات اضافية للاطلاع على بيانات الخيارات**

```
GET /api/v1/shop/products/{id}
```
```
GET https://alnaeem.nano2soft.com/api/v1/shop/products/13
```

#### Response

```html
Status: 200 OK
```

**لنلقي نظرة على صنف يحتوي على خيارات اضافية  **

```json
{
  "id": 13,
  "code": "2-2-13",
  "barcode": "7-13",
  "name": "منتج رقم 8889",
  "emblem": "",
  "short_description": "",
  "description": "",
  "users_manual": "",
  "composition": "",
  "indication": "",
  "meta_title": "",
  "meta_description": "",
  "keywords": "",
  "ref_type_class": "products",
  "ref_key_values_class": "3",
  "is_offer": 0,
  "groups_products_id": "7",
  "companys_id": "2",
  "departments_id": "2",
  "is_effective": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "manage_stock": 0,
  "shop_stock": 0,
  "min_qty": 1,
  "max_qty": 1,
  "min_qty_in_stock": 1,
  "max_qty_in_stock": 1,
  "default_qty": 1,
  "old_price": 800,
  "price": 700,
  "is_show_old_price": 1,
  "is_parleying": 1,
  "is_sold": 1,
  "is_purchased": 1,
  "is_composite": 0,
  "is_units": 0,
  "is_downloadable": 1,
  "properties": null,
  "links": null,
  "other_data": null,
  "config_data": null,
  "sort_order": 13,
  "created_at": "2023-06-28 23:55:26",
  "updated_at": "2023-10-11 15:46:51",
  "image": null,
  "images": [],
  "files": [],
  "ratings_count": 0,
  "countRating": 0,
  "sumRating": 0,
  "averageRating": 0,
  "user_is_rating": 0,
  "user_object_rating": null,
  "favorites_count": 0,
  "user_is_favorite": 0,
  "likes_count": 0,
  "bookmarks_count": 0,
  "reactions_count": 0,
  "object_type": "Nano\\Shop\\Models\\Product",
  "qty": 6,
  "children": {
    "data": [],
    "meta": {
      "pagination": {
        "total": 0,
        "count": 0,
        "per_page": 10,
        "current_page": 1,
        "total_pages": 1,
        "links": {}
      }
    }
  },
  "prices_units": {
    "data": []
  },
  "product_options": {
    "data": [
      {
        "id": 1,
        "options_id": 5,
        "products_id": 13,
        "name": "التوابع",
        "type": "radio",
        "required": 0,
        "is_public": 1,
        "is_default": 0,
        "is_active": 1,
        "min_selected": 0,
        "max_selected": 0,
        "sort_order": 1,
        "companys_id": "2",
        "departments_id": "2",
        "other_data": [],
        "config_data": [],
        "created_at": "2023-10-05 19:35:43",
        "updated_at": "2023-10-05 19:35:43",
        "products_options_values": {
          "data": [
            {
              "id": 1,
              "options_id": 5,
              "options_values_id": 2,
              "products_options_id": 1,
              "products_id": 13,
              "value": "مع التوابع",
              "default_value": 0,
              "old_price": 0,
              "price": 0,
              "is_public": 1,
              "is_default": 1,
              "is_active": 1,
              "sort_order": 1,
              "companys_id": "2",
              "departments_id": "2",
              "created_at": "2023-10-05 20:06:08",
              "updated_at": "2023-10-05 20:06:08"
            },
            {
              "id": 2,
              "options_id": 5,
              "options_values_id": 3,
              "products_options_id": 1,
              "products_id": 13,
              "value": "بدون التوابع",
              "default_value": 0,
              "old_price": 0,
              "price": 0,
              "is_public": 0,
              "is_default": 0,
              "is_active": 1,
              "sort_order": 2,
              "companys_id": "2",
              "departments_id": "2",
              "created_at": "2023-10-05 20:06:08",
              "updated_at": "2023-10-05 20:06:08"
            }
          ]
        }
      },
      {
        "id": 2,
        "options_id": 6,
        "products_id": 13,
        "name": "Drinks",
        "type": "checkbox",
        "required": 0,
        "is_public": 1,
        "is_default": 0,
        "is_active": 1,
        "min_selected": 0,
        "max_selected": 0,
        "sort_order": 2,
        "companys_id": "2",
        "departments_id": "2",
        "other_data": [],
        "config_data": [],
        "created_at": "2023-10-05 21:07:51",
        "updated_at": "2023-10-05 21:07:51",
        "products_options_values": {
          "data": [
            {
              "id": 3,
              "options_id": 6,
              "options_values_id": 4,
              "products_options_id": 2,
              "products_id": 13,
              "value": "Coke",
              "default_value": 0,
              "old_price": 0,
              "price": 0,
              "is_public": 1,
              "is_default": 1,
              "is_active": 1,
              "sort_order": 3,
              "companys_id": "2",
              "departments_id": "2",
              "created_at": "2023-10-05 21:07:51",
              "updated_at": "2023-10-05 21:07:51"
            },
            {
              "id": 4,
              "options_id": 6,
              "options_values_id": 5,
              "products_options_id": 2,
              "products_id": 13,
              "value": "Diet Coke",
              "default_value": 0,
              "old_price": 0,
              "price": 0,
              "is_public": 1,
              "is_default": 0,
              "is_active": 1,
              "sort_order": 4,
              "companys_id": "2",
              "departments_id": "2",
              "created_at": "2023-10-05 21:07:51",
              "updated_at": "2023-10-05 21:07:51"
            }
          ]
        }
      }
    ]
  }
}
```

**مثال اخر مع تضمين العلاقة product_options_values**

**جلب قيم الخيارات التابعة للصنف **

```
GET http://localhost:8006/api/v1/shop/products/12?include=product_options,product_options_values
```

```json
{
  "id": 12,
  "code": "2-2-12",
  "barcode": "7-12",
  "name": "منتج رقم 88",
  "emblem": "",
  "short_description": "",
  "description": "",
  "users_manual": "",
  "composition": "",
  "indication": "",
  "meta_title": "",
  "meta_description": "",
  "keywords": "",
  "ref_type_class": "products",
  "ref_key_values_class": "3",
  "is_offer": 0,
  "groups_products_id": "7",
  "companys_id": "2",
  "departments_id": "2",
  "is_effective": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "manage_stock": 0,
  "shop_stock": 0,
  "min_qty": 1,
  "max_qty": 1,
  "min_qty_in_stock": 1,
  "max_qty_in_stock": 1,
  "default_qty": 1,
  "old_price": 66,
  "price": 78777,
  "is_show_old_price": 1,
  "is_parleying": 1,
  "is_sold": 1,
  "is_purchased": 1,
  "is_composite": 0,
  "is_units": 0,
  "is_downloadable": 1,
  "properties": null,
  "links": null,
  "other_data": null,
  "config_data": null,
  "sort_order": 12,
  "created_at": "2023-06-28 23:53:55",
  "updated_at": "2023-06-28 23:53:56",
  "image": null,
  "images": [],
  "files": [],
  "ratings_count": 0,
  "countRating": 0,
  "sumRating": 0,
  "averageRating": 0,
  "user_is_rating": 0,
  "user_object_rating": null,
  "favorites_count": 0,
  "user_is_favorite": 0,
  "likes_count": 0,
  "bookmarks_count": 0,
  "reactions_count": 0,
  "object_type": "Nano\\Shop\\Models\\Product",
  "qty": 2,
  "children": {
    "data": [],
    "meta": {
      "pagination": {
        "total": 0,
        "count": 0,
        "per_page": 10,
        "current_page": 1,
        "total_pages": 1,
        "links": {}
      }
    }
  },
  "prices_units": {
    "data": []
  },
  "product_options": {
    "data": [
      {
        "id": 3,
        "options_id": 5,
        "products_id": 12,
        "name": "التوابع",
        "type": "radio",
        "required": 1,
        "is_public": 1,
        "is_default": 1,
        "is_active": 1,
        "min_selected": 0,
        "max_selected": 0,
        "sort_order": 3,
        "companys_id": "2",
        "departments_id": "2",
        "other_data": [],
        "config_data": [],
        "created_at": "2023-10-13 19:01:08",
        "updated_at": "2023-10-13 19:01:08",
        "products_options_values": {
          "data": [
            {
              "id": 5,
              "options_id": 5,
              "options_values_id": 1,
              "products_options_id": 3,
              "products_id": 12,
              "value": "مع التوابع",
              "default_value": 0,
              "old_price": 100,
              "price": 0,
              "is_public": 1,
              "is_default": 0,
              "is_active": 1,
              "sort_order": 5,
              "companys_id": "2",
              "departments_id": "2",
              "created_at": "2023-10-13 19:01:08",
              "updated_at": "2023-10-13 19:01:08"
            },
            {
              "id": 6,
              "options_id": 5,
              "options_values_id": 3,
              "products_options_id": 3,
              "products_id": 12,
              "value": "بدون التوابع",
              "default_value": 0,
              "old_price": 0,
              "price": 0,
              "is_public": 1,
              "is_default": 0,
              "is_active": 1,
              "sort_order": 6,
              "companys_id": "2",
              "departments_id": "2",
              "created_at": "2023-10-13 19:01:08",
              "updated_at": "2023-10-13 19:01:08"
            }
          ]
        }
      }
    ]
  },
  "product_options_values": {
    "data": [
      {
        "id": 5,
        "options_id": 5,
        "options_values_id": 1,
        "products_options_id": 3,
        "products_id": 12,
        "value": "مع التوابع",
        "default_value": 0,
        "old_price": 100,
        "price": 0,
        "is_public": 1,
        "is_default": 0,
        "is_active": 1,
        "sort_order": 5,
        "companys_id": "2",
        "departments_id": "2",
        "created_at": "2023-10-13 19:01:08",
        "updated_at": "2023-10-13 19:01:08"
      },
      {
        "id": 6,
        "options_id": 5,
        "options_values_id": 3,
        "products_options_id": 3,
        "products_id": 12,
        "value": "بدون التوابع",
        "default_value": 0,
        "old_price": 0,
        "price": 0,
        "is_public": 1,
        "is_default": 0,
        "is_active": 1,
        "sort_order": 6,
        "companys_id": "2",
        "departments_id": "2",
        "created_at": "2023-10-13 19:01:08",
        "updated_at": "2023-10-13 19:01:08"
      }
    ]
  }
}
```

**استثناء جلب الخيارات وقيم الخيارات  **

```
GET http://localhost:8006/api/v1/shop/products/12?exclude=product_options,product_options_values
```

```json
{
  "id": 12,
  "code": "2-2-12",
  "barcode": "7-12",
  "name": "منتج رقم 88",
  "emblem": "",
  "short_description": "",
  "description": "",
  "users_manual": "",
  "composition": "",
  "indication": "",
  "meta_title": "",
  "meta_description": "",
  "keywords": "",
  "ref_type_class": "products",
  "ref_key_values_class": "3",
  "is_offer": 0,
  "groups_products_id": "7",
  "companys_id": "2",
  "departments_id": "2",
  "is_effective": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "manage_stock": 0,
  "shop_stock": 0,
  "min_qty": 1,
  "max_qty": 1,
  "min_qty_in_stock": 1,
  "max_qty_in_stock": 1,
  "default_qty": 1,
  "old_price": 66,
  "price": 78777,
  "is_show_old_price": 1,
  "is_parleying": 1,
  "is_sold": 1,
  "is_purchased": 1,
  "is_composite": 0,
  "is_units": 0,
  "is_downloadable": 1,
  "properties": null,
  "links": null,
  "other_data": null,
  "config_data": null,
  "sort_order": 12,
  "created_at": "2023-06-28 23:53:55",
  "updated_at": "2023-06-28 23:53:56",
  "image": null,
  "images": [],
  "files": [],
  "ratings_count": 0,
  "countRating": 0,
  "sumRating": 0,
  "averageRating": 0,
  "user_is_rating": 0,
  "user_object_rating": null,
  "favorites_count": 0,
  "user_is_favorite": 0,
  "likes_count": 0,
  "bookmarks_count": 0,
  "reactions_count": 0,
  "object_type": "Nano\\Shop\\Models\\Product",
  "qty": 2,
  "children": {
    "data": [],
    "meta": {
      "pagination": {
        "total": 0,
        "count": 0,
        "per_page": 10,
        "current_page": 1,
        "total_pages": 1,
        "links": {}
      }
    }
  },
  "prices_units": {
    "data": []
  }
}
```

### Example 4 Get My Favorites Products

**لجلب المنتجات المفضله للمستخدم الحالى نقوم بتمرير المتغير isFavorites = true **

```
GET /api/v1/shop/products
```

Required Parameters: `isFavorites = true`

```
GET http://localhost:8006/api/v1/shop/products?isFavorites=true
```

#### Response

```html
Status: 200 Ok
```

** من خلال السجلات الراجعه فى الاسفل نلاحظ ان الخاصيه  user_is_favorite=true 
بمعنا ان هذا المنتج مضاف الى مفضله المستخدم الحالى **


```json
{
  "data": [
    {
      "id": 4,
      "code": "2-2-4",
      "barcode": "2-4",
      "name": "حبة دجاج برست",
      "emblem": "",
      "short_description": "",
      "description": "",
      "users_manual": "",
      "composition": "",
      "indication": "",
      "meta_title": "",
      "meta_description": "",
      "keywords": "",
      "ref_type_class": "products",
      "ref_key_values_class": "3",
      "groups_products_id": "2",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": null,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "manage_stock": 0,
      "shop_stock": 0,
      "min_qty": 1,
      "max_qty": 1,
      "min_qty_in_stock": 1,
      "max_qty_in_stock": 1,
      "default_qty": 1,
      "old_price": null,
      "price": 0,
      "is_show_old_price": 1,
      "is_parleying": 1,
      "is_sold": 1,
      "is_purchased": 1,
      "is_composite": 0,
      "is_units": 1,
      "is_downloadable": 1,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 4,
      "created_at": "2022-10-02 15:22:20",
      "updated_at": "2022-10-02 15:22:20",
      "image": {
        "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/633b47a8bee36870039097.png",
        "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_160_160_0_0_crop.png",
        "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_240_240_0_0_crop.png",
        "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_800_800_0_0_crop.png",
        "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_480_480_0_0_auto.png"
      },
      "images": [],
      "files": [],
      "ratings_count": 4,
      "countRating": 4,
      "sumRating": "13",
      "averageRating": "3.2500",
      "user_is_rating": true,
      "user_object_rating": {
        "id": 15,
        "code": "2-4-15",
        "is_recommended": true,
        "rating": 3,
        "title": "543منتج رائع",
        "content": "التعليق 543",
        "approved": true,
        "reviewrateable_type": "products",
        "reviewrateable_id": 4,
        "user_type": "RainLab\\User\\Models\\User",
        "user_id": 543,
        "name": null,
        "email": null,
        "url": "\/api\/v1\/shop\/products",
        "hash": "8a20d49df9a87ab7c4fe945097bcca27",
        "locale": "ar",
        "ip": "127.0.0.1",
        "ip_forwarded": null,
        "user_agent": "okhttp\/3.8.1",
        "companys_id": "2",
        "departments_id": "4",
        "is_active": true,
        "other_data": null,
        "config_data": null,
        "sort_order": 15,
        "created_by": null,
        "updated_by": null,
        "deleted_by": null,
        "created_at": "2022-10-11 19:12:46",
        "updated_at": "2022-10-11 19:23:31",
        "deleted_at": null
      },
      "favorites_count": 3,
      "user_is_favorite": true,
      "user_object_favorite": {
        "user_id": 543,
        "favoriteable_type": "products",
        "favoriteable_id": 4,
        "created_at": "2022-10-09 23:46:35",
        "updated_at": "2022-10-09 23:46:35"
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```



### Example 5 Get Products with companys_id or departments_id

** لجلب االاصناف االتابعه لفرع معين او لمتجر معين نستخدم البراميتر companys_id
او البراميتر departments_id**

**ملاحظه يمكنك جلب قيمه companys_id من بيانات الاقسام departmentsوالذي تمثل المتاجر **
```
GET /api/v1/shop/products
```

Required Parameters: `companys_id`

```
http://localhost:8006/api/v1/shop/products?companys_id=2
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "data": [
    {
      "id": 4,
      "code": "2-2-4",
      "barcode": "2-4",
      "name": "حبة دجاج برست",
      "emblem": "",
      "short_description": "",
      "description": "",
      "users_manual": "",
      "composition": "",
      "indication": "",
      "meta_title": "",
      "meta_description": "",
      "keywords": "",
      "ref_type_class": "products",
      "ref_key_values_class": "3",
      "groups_products_id": "2",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": null,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "manage_stock": 0,
      "shop_stock": 0,
      "min_qty": 1,
      "max_qty": 1,
      "min_qty_in_stock": 1,
      "max_qty_in_stock": 1,
      "default_qty": 1,
      "old_price": null,
      "price": 0,
      "is_show_old_price": 1,
      "is_parleying": 1,
      "is_sold": 1,
      "is_purchased": 1,
      "is_composite": 0,
      "is_units": 1,
      "is_downloadable": 1,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 4,
      "created_at": "2022-10-02 15:22:20",
      "updated_at": "2022-10-02 15:22:20",
      "image": {
        "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/633b47a8bee36870039097.png",
        "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_160_160_0_0_crop.png",
        "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_240_240_0_0_crop.png",
        "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_800_800_0_0_crop.png",
        "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_480_480_0_0_auto.png"
      },
      "images": [],
      "files": [],
      "ratings_count": 4,
      "countRating": 4,
      "sumRating": "13",
      "averageRating": "3.2500",
      "user_is_rating": true,
      "user_object_rating": {
        "id": 15,
        "code": "2-4-15",
        "is_recommended": true,
        "rating": 3,
        "title": "543منتج رائع",
        "content": "التعليق 543",
        "approved": true,
        "reviewrateable_type": "products",
        "reviewrateable_id": 4,
        "user_type": "RainLab\\User\\Models\\User",
        "user_id": 543,
        "name": null,
        "email": null,
        "url": "\/api\/v1\/shop\/products",
        "hash": "8a20d49df9a87ab7c4fe945097bcca27",
        "locale": "ar",
        "ip": "127.0.0.1",
        "ip_forwarded": null,
        "user_agent": "okhttp\/3.8.1",
        "companys_id": "2",
        "departments_id": "4",
        "is_active": true,
        "other_data": null,
        "config_data": null,
        "sort_order": 15,
        "created_by": null,
        "updated_by": null,
        "deleted_by": null,
        "created_at": "2022-10-11 19:12:46",
        "updated_at": "2022-10-11 19:23:31",
        "deleted_at": null
      },
      "favorites_count": 3,
      "user_is_favorite": true,
      "user_object_favorite": {
        "user_id": 543,
        "favoriteable_type": "products",
        "favoriteable_id": 4,
        "created_at": "2022-10-09 23:46:35",
        "updated_at": "2022-10-09 23:46:35"
      }
    },
    {
      "id": 3,
      "code": "2-2-3",
      "barcode": "2-3",
      "name": "نفر رز",
      "emblem": "",
      "short_description": "",
      "description": "",
      "users_manual": "",
      "composition": "",
      "indication": "",
      "meta_title": "",
      "meta_description": "",
      "keywords": "",
      "ref_type_class": "products",
      "ref_key_values_class": "3",
      "groups_products_id": "2",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": null,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "manage_stock": 0,
      "shop_stock": 0,
      "min_qty": 1,
      "max_qty": 1,
      "min_qty_in_stock": 1,
      "max_qty_in_stock": 1,
      "default_qty": 1,
      "old_price": null,
      "price": 0,
      "is_show_old_price": 1,
      "is_parleying": 1,
      "is_sold": 1,
      "is_purchased": 1,
      "is_composite": 0,
      "is_units": 1,
      "is_downloadable": 1,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 3,
      "created_at": "2022-10-02 15:21:13",
      "updated_at": "2022-10-02 15:21:13",
      "image": null,
      "images": [],
      "files": [],
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

####فى حال تمرير رقم فرع او متجر غير موجود سيتم ارجاع الخطاء التالى 


```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "المتجر المحدد غير موجود ضمن المتاجر تاكد من رقم المتجر "
  }
}
```

### Example 6 Get Products with tagsId

** لجلب االاصناف التابعه لهشتاجات معينه نستخدم البراميتر tagsId كا التالى  **

```
GET /api/v1/shop/products
```

Required Parameters: `tagsId = true`

```
http://localhost:8006/api/v1/shop/products?tagsId=4,6
```

** لاظهار اسماء الهشتاجات التابعه لكل صنف  نقوم بتضمين العلاقه tags كا التالى **
```
http://localhost:8006/api/v1/shop/products?tagsId=4,6&include=tags
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "data": [
    {
      "id": 4,
      "code": "2-2-4",
      "barcode": "2-4",
      "name": "حبة دجاج برست",
      "emblem": "",
      "short_description": "",
      "description": "",
      "users_manual": "",
      "composition": "",
      "indication": "",
      "meta_title": "",
      "meta_description": "",
      "keywords": "",
      "ref_type_class": "products",
      "ref_key_values_class": "3",
      "groups_products_id": "2",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": null,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "manage_stock": 0,
      "shop_stock": 0,
      "min_qty": 1,
      "max_qty": 1,
      "min_qty_in_stock": 1,
      "max_qty_in_stock": 1,
      "default_qty": 1,
      "old_price": null,
      "price": 0,
      "is_show_old_price": 1,
      "is_parleying": 1,
      "is_sold": 1,
      "is_purchased": 1,
      "is_composite": 0,
      "is_units": 1,
      "is_downloadable": 1,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 4,
      "created_at": "2022-10-02 15:22:20",
      "updated_at": "2022-10-02 15:22:20",
      "image": {
        "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/633b47a8bee36870039097.png",
        "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_160_160_0_0_crop.png",
        "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_240_240_0_0_crop.png",
        "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_800_800_0_0_crop.png",
        "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_480_480_0_0_auto.png"
      },
      "images": [],
      "files": [],
      "ratings_count": 4,
      "countRating": 4,
      "sumRating": "13",
      "averageRating": "3.2500",
      "user_is_rating": true,
      "user_object_rating": {
        "id": 15,
        "code": "2-4-15",
        "is_recommended": true,
        "rating": 3,
        "title": "543منتج رائع",
        "content": "التعليق 543",
        "approved": true,
        "reviewrateable_type": "products",
        "reviewrateable_id": 4,
        "user_type": "RainLab\\User\\Models\\User",
        "user_id": 543,
        "name": null,
        "email": null,
        "url": "\/api\/v1\/shop\/products",
        "hash": "8a20d49df9a87ab7c4fe945097bcca27",
        "locale": "ar",
        "ip": "127.0.0.1",
        "ip_forwarded": null,
        "user_agent": "okhttp\/3.8.1",
        "companys_id": "2",
        "departments_id": "4",
        "is_active": true,
        "other_data": null,
        "config_data": null,
        "sort_order": 15,
        "created_by": null,
        "updated_by": null,
        "deleted_by": null,
        "created_at": "2022-10-11 19:12:46",
        "updated_at": "2022-10-11 19:23:31",
        "deleted_at": null
      },
      "favorites_count": 3,
      "user_is_favorite": true,
      "user_object_favorite": {
        "user_id": 543,
        "favoriteable_type": "products",
        "favoriteable_id": 4,
        "created_at": "2022-10-09 23:46:35",
        "updated_at": "2022-10-09 23:46:35"
      },
      "tags": {
        "data": [
          {
            "id": 4,
            "code": "2-2-4",
            "name": "هشتاج تجريبي",
            "slug": "hshtag-tgryby",
            "type": null,
            "user_id": null,
            "user_type": null,
            "companys_id": "2",
            "departments_id": "2",
            "is_public": 0,
            "is_default": 0,
            "is_active": 1,
            "is_published": 1,
            "published_at": "",
            "unpublished_at": "",
            "properties": null,
            "created_at": "2022-09-26 19:56:21",
            "updated_at": "2022-09-26 19:56:21"
          },
          {
            "id": 6,
            "code": "2-2-6",
            "name": "لحوم طازجه",
            "slug": "lhom-tazgh",
            "type": null,
            "user_id": null,
            "user_type": null,
            "companys_id": "2",
            "departments_id": "2",
            "is_public": 0,
            "is_default": 0,
            "is_active": 1,
            "is_published": 1,
            "published_at": "",
            "unpublished_at": "",
            "properties": null,
            "created_at": "2022-10-03 18:50:29",
            "updated_at": "2022-10-03 18:50:29"
          }
        ]
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```
### Example 7 Get Products with categorysId


```
GET /api/v1/shop/products
```

Required Parameters: `categorysId = true`

```
GET http://localhost:8006/api/v1/shop/products?categorysId=1,4
```

** لاظهار اسماء التصنيفات التابعه لكل صنف  نقوم بتضمين العلاقه categories كا التالى **
```
GET http://localhost:8006/api/v1/shop/products?categorysId=1,4&include=categories
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "data": [
    {
      "id": 4,
      "code": "2-2-4",
      "barcode": "2-4",
      "name": "حبة دجاج برست",
      "emblem": "",
      "short_description": "",
      "description": "",
      "users_manual": "",
      "composition": "",
      "indication": "",
      "meta_title": "",
      "meta_description": "",
      "keywords": "",
      "ref_type_class": "products",
      "ref_key_values_class": "3",
      "groups_products_id": "2",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": null,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "manage_stock": 0,
      "shop_stock": 0,
      "min_qty": 1,
      "max_qty": 1,
      "min_qty_in_stock": 1,
      "max_qty_in_stock": 1,
      "default_qty": 1,
      "old_price": null,
      "price": 0,
      "is_show_old_price": 1,
      "is_parleying": 1,
      "is_sold": 1,
      "is_purchased": 1,
      "is_composite": 0,
      "is_units": 1,
      "is_downloadable": 1,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 4,
      "created_at": "2022-10-02 15:22:20",
      "updated_at": "2022-10-02 15:22:20",
      "image": {
        "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/633b47a8bee36870039097.png",
        "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_160_160_0_0_crop.png",
        "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_240_240_0_0_crop.png",
        "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_800_800_0_0_crop.png",
        "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/633\/b47\/a8b\/thumb_567_480_480_0_0_auto.png"
      },
      "images": [],
      "files": [],
      "ratings_count": 4,
      "countRating": 4,
      "sumRating": "13",
      "averageRating": "3.2500",
      "user_is_rating": true,
      "user_object_rating": {
        "id": 15,
        "code": "2-4-15",
        "is_recommended": true,
        "rating": 3,
        "title": "543منتج رائع",
        "content": "التعليق 543",
        "approved": true,
        "reviewrateable_type": "products",
        "reviewrateable_id": 4,
        "user_type": "RainLab\\User\\Models\\User",
        "user_id": 543,
        "name": null,
        "email": null,
        "url": "\/api\/v1\/shop\/products",
        "hash": "8a20d49df9a87ab7c4fe945097bcca27",
        "locale": "ar",
        "ip": "127.0.0.1",
        "ip_forwarded": null,
        "user_agent": "okhttp\/3.8.1",
        "companys_id": "2",
        "departments_id": "4",
        "is_active": true,
        "other_data": null,
        "config_data": null,
        "sort_order": 15,
        "created_by": null,
        "updated_by": null,
        "deleted_by": null,
        "created_at": "2022-10-11 19:12:46",
        "updated_at": "2022-10-11 19:23:31",
        "deleted_at": null
      },
      "favorites_count": 3,
      "user_is_favorite": true,
      "user_object_favorite": {
        "user_id": 543,
        "favoriteable_type": "products",
        "favoriteable_id": 4,
        "created_at": "2022-10-09 23:46:35",
        "updated_at": "2022-10-09 23:46:35"
      },
      "categories": {
        "data": [
          {
            "id": 1,
            "code": "2-4-1",
            "name": "عامه",
            "slug": "aaamh",
            "type": "1",
            "user_id": null,
            "user_type": null,
            "companys_id": "2",
            "departments_id": "4",
            "country_id": null,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "is_published": 1,
            "published_at": "",
            "unpublished_at": "",
            "main_sub": "main",
            "parent_id": null,
            "level": "1",
            "properties": null,
            "created_at": "2022-09-26 19:55:19",
            "updated_at": "2022-10-03 20:13:13"
          }
        ]
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```
### Example 8 Get Products Offer


```
GET /api/v1/shop/products
```

Required Parameters: `isOffer = true`

```
GET http://localhost:8006/api/v1/shop/products?isOffer=1
```
** لجلب الاصناف فقط نقوم بتمرير المتغير isOffer **
```
GET http://localhost:8006/api/v1/shop/products?isOffer=1
```

** فى الحاله السابقه سيقوم بجلب كافه العروض حتي العروض المنتهيه ولجلب العروض
الغير منتهيه فققط نقوم بتمرير المتغري isPublished كالتالي **

```
GET http://localhost:8006/api/v1/shop/products?isOffer=1&isPublished=true
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "data": [
    {
      "id": 1576,
      "code": "2-2-1576",
      "barcode": "0-1576",
      "name": "عرض جديد حبه دجاج + نفر رز + سلطه",
      "emblem": "",
      "short_description": "عرض جديد حبه دجاج + نفر رز + سلطه",
      "description": "<p>عرض جديد حبه دجاج + نفر رز + سلطه <\/p>",
      "users_manual": "عرض جديد حبه دجاج + نفر رز + سلطه",
      "composition": "",
      "indication": "",
      "meta_title": "",
      "meta_description": "",
      "keywords": "",
      "ref_type_class": "products",
      "ref_key_values_class": "3",
      "is_offer": 1,
      "groups_products_id": "0",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": null,
      "is_active": 1,
      "is_published": 1,
      "published_at": "2023-08-01 20:00:57",
      "unpublished_at": "2024-08-01 20:01:04",
      "manage_stock": 0,
      "shop_stock": 0,
      "min_qty": 1,
      "max_qty": 1,
      "min_qty_in_stock": 1,
      "max_qty_in_stock": 1,
      "default_qty": 1,
      "old_price": 3000,
      "price": 2500,
      "is_show_old_price": 1,
      "is_parleying": 1,
      "is_sold": 1,
      "is_purchased": 1,
      "is_composite": 0,
      "is_units": 0,
      "is_downloadable": 1,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 1576,
      "created_at": "2023-08-08 20:03:28",
      "updated_at": "2023-08-08 20:03:28",
      "image": null,
      "images": [],
      "files": [],
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null,
      "object_type": "Nano\\Shop\\Models\\Product",
      "qty": 0,
      "children": {
        "data": [],
        "meta": {
          "pagination": {
            "total": 0,
            "count": 0,
            "per_page": 10,
            "current_page": 1,
            "total_pages": 1,
            "links": []
          }
        }
      },
      "prices_units": {
        "data": []
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Example 9 Get Products With Menus


```
GET /api/v1/shop/products
```

Required Parameters: `menus_id = 9`

```
GET http://localhost:8006/api/v1/shop/products?menus_id=9
```
** لجلب المنتجات او الاصناف التابعه لقائمه معينه نقوم بتمرير رقم القائمه ضمن المتغير menus_id **

```
GET http://localhost:8006/api/v1/shop/products?menus_id=9
```


#### Response

```html
Status: 200 Ok
```

```json
{
  "data": [
    {
      "id": 1430,
      "code": "2-2-1430",
      "barcode": "0-1430",
      "name": "شاهي",
      "emblem": "",
      "short_description": "",
      "description": "",
      "users_manual": "",
      "composition": "",
      "indication": "",
      "meta_title": "",
      "meta_description": "",
      "keywords": "",
      "ref_type_class": "products",
      "ref_key_values_class": "3",
      "is_offer": 0,
      "groups_products_id": "0",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": null,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "manage_stock": 1,
      "shop_stock": 0,
      "min_qty": 1,
      "max_qty": 100,
      "min_qty_in_stock": 1,
      "max_qty_in_stock": 100,
      "default_qty": 1,
      "old_price": 0,
      "price": 50,
      "is_show_old_price": 0,
      "is_parleying": 1,
      "is_sold": 1,
      "is_purchased": 1,
      "is_composite": 0,
      "is_units": 1,
      "is_downloadable": 1,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 1430,
      "created_at": "2022-11-09 15:53:47",
      "updated_at": "2023-08-09 13:59:03",
      "image": {
        "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/636bccf4b203d617442273.jpg",
        "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_160_160_0_0_crop.jpg",
        "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_240_240_0_0_crop.jpg",
        "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_800_800_0_0_crop.jpg",
        "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_480_480_0_0_auto.jpg"
      },
      "images": [],
      "files": [],
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null,
      "object_type": "Nano\\Shop\\Models\\Product",
      "qty": 0,
      "children": {
        "data": [
          {
            "id": 1431,
            "code": "2-2-1431",
            "barcode": "0-1431",
            "name": "شاهي احمر",
            "emblem": "شاهي",
            "short_description": "شاهي احمر",
            "description": "<p>شاهي احمر<\/p>",
            "users_manual": "دليل الاستخدام",
            "composition": "التركيبة",
            "indication": "الامور الاخري المتعلقة بالصنف",
            "meta_title": "شاهي",
            "meta_description": "وصف للبحث",
            "keywords": "كلمات مفتاحية",
            "ref_type_class": "products",
            "ref_key_values_class": "3",
            "is_offer": 0,
            "groups_products_id": "0",
            "companys_id": "2",
            "departments_id": "2",
            "is_effective": 1,
            "is_default": null,
            "is_active": 1,
            "is_published": 0,
            "published_at": "",
            "unpublished_at": "",
            "manage_stock": 1,
            "shop_stock": 1,
            "min_qty": 1,
            "max_qty": 100,
            "min_qty_in_stock": 1,
            "max_qty_in_stock": 100,
            "default_qty": 1,
            "old_price": 0,
            "price": 50,
            "is_show_old_price": 0,
            "is_parleying": 1,
            "is_sold": 1,
            "is_purchased": 1,
            "is_composite": 0,
            "is_units": 1,
            "is_downloadable": 1,
            "properties": [
              {
                "title": "الاضافات",
                "code": "extention",
                "value": "10",
                "is_default": "1",
                "is_show": "1",
                "sort_show": "1",
                "_group": "properties"
              }
            ],
            "links": [
              {
                "title": "url",
                "url": "test.com",
                "target": "_blank",
                "sort_show": "1",
                "is_download": "0",
                "is_default": "1",
                "is_show": "1",
                "_group": "links"
              }
            ],
            "other_data": null,
            "config_data": null,
            "sort_order": 1431,
            "created_at": "2022-11-09 15:54:58",
            "updated_at": "2023-07-15 00:31:17",
            "image": {
              "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/636bcd2f87ee1059528054.jpg",
              "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_160_160_0_0_crop.jpg",
              "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_240_240_0_0_crop.jpg",
              "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_800_800_0_0_crop.jpg",
              "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_480_480_0_0_auto.jpg"
            },
            "images": [],
            "files": [],
            "ratings_count": 0,
            "countRating": 0,
            "sumRating": null,
            "averageRating": null,
            "user_is_rating": false,
            "user_object_rating": null,
            "favorites_count": 0,
            "user_is_favorite": false,
            "user_object_favorite": null,
            "object_type": "Nano\\Shop\\Models\\Product",
            "qty": 0,
            "children": {
              "data": [],
              "meta": {
                "pagination": {
                  "total": 0,
                  "count": 0,
                  "per_page": 10,
                  "current_page": 1,
                  "total_pages": 1,
                  "links": []
                }
              }
            },
            "prices_units": {
              "data": []
            }
          },
          {
            "id": 1432,
            "code": "2-2-1432",
            "barcode": "0-1432",
            "name": "شاهي حليب",
            "emblem": "",
            "short_description": "",
            "description": "",
            "users_manual": "",
            "composition": "",
            "indication": "",
            "meta_title": "",
            "meta_description": "",
            "keywords": "",
            "ref_type_class": "products",
            "ref_key_values_class": "3",
            "is_offer": 0,
            "groups_products_id": "0",
            "companys_id": "2",
            "departments_id": "2",
            "is_effective": 1,
            "is_default": null,
            "is_active": 1,
            "is_published": 0,
            "published_at": "",
            "unpublished_at": "",
            "manage_stock": 1,
            "shop_stock": 0,
            "min_qty": 1,
            "max_qty": 100,
            "min_qty_in_stock": 1,
            "max_qty_in_stock": 100,
            "default_qty": 1,
            "old_price": 0,
            "price": 100,
            "is_show_old_price": 0,
            "is_parleying": 1,
            "is_sold": 1,
            "is_purchased": 1,
            "is_composite": 0,
            "is_units": 1,
            "is_downloadable": 1,
            "properties": null,
            "links": null,
            "other_data": null,
            "config_data": null,
            "sort_order": 1432,
            "created_at": "2022-11-09 15:55:41",
            "updated_at": "2023-08-08 19:58:38",
            "image": {
              "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/6372c9c8b9cff519686397.jpg",
              "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_160_160_0_0_crop.jpg",
              "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_240_240_0_0_crop.jpg",
              "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_800_800_0_0_crop.jpg",
              "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_480_480_0_0_auto.jpg"
            },
            "images": [],
            "files": [],
            "ratings_count": 0,
            "countRating": 0,
            "sumRating": null,
            "averageRating": null,
            "user_is_rating": false,
            "user_object_rating": null,
            "favorites_count": 0,
            "user_is_favorite": false,
            "user_object_favorite": null,
            "object_type": "Nano\\Shop\\Models\\Product",
            "qty": 0,
            "children": {
              "data": [],
              "meta": {
                "pagination": {
                  "total": 0,
                  "count": 0,
                  "per_page": 10,
                  "current_page": 1,
                  "total_pages": 1,
                  "links": []
                }
              }
            },
            "prices_units": {
              "data": []
            }
          }
        ],
        "meta": {
          "pagination": {
            "total": 2,
            "count": 2,
            "per_page": 10,
            "current_page": 1,
            "total_pages": 1,
            "links": []
          }
        }
      },
      "prices_units": {
        "data": []
      }
    },
    {
      "id": 1423,
      "code": "2-2-1423",
      "barcode": "0-1423",
      "name": "فتة سادة مع قشطة مع العسل",
      "emblem": "",
      "short_description": "",
      "description": "",
      "users_manual": "",
      "composition": "",
      "indication": "",
      "meta_title": "",
      "meta_description": "",
      "keywords": "",
      "ref_type_class": "products",
      "ref_key_values_class": "3",
      "is_offer": 0,
      "groups_products_id": "0",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": null,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "manage_stock": 1,
      "shop_stock": 0,
      "min_qty": 1,
      "max_qty": 100,
      "min_qty_in_stock": 1,
      "max_qty_in_stock": 100,
      "default_qty": 1,
      "old_price": 0,
      "price": 1500,
      "is_show_old_price": 0,
      "is_parleying": 1,
      "is_sold": 1,
      "is_purchased": 1,
      "is_composite": 0,
      "is_units": 1,
      "is_downloadable": 1,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 1423,
      "created_at": "2022-11-09 15:45:44",
      "updated_at": "2023-08-09 14:00:44",
      "image": {
        "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcb\/120\/636bcb120c691781143614.jpg",
        "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcb\/120\/thumb_1376_160_160_0_0_crop.jpg",
        "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcb\/120\/thumb_1376_240_240_0_0_crop.jpg",
        "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcb\/120\/thumb_1376_800_800_0_0_crop.jpg",
        "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcb\/120\/thumb_1376_480_480_0_0_auto.jpg"
      },
      "images": [],
      "files": [],
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null,
      "object_type": "Nano\\Shop\\Models\\Product",
      "qty": 0,
      "children": {
        "data": [],
        "meta": {
          "pagination": {
            "total": 0,
            "count": 0,
            "per_page": 10,
            "current_page": 1,
            "total_pages": 1,
            "links": []
          }
        }
      },
      "prices_units": {
        "data": []
      }
    },
    {
      "id": 1417,
      "code": "2-2-1417",
      "barcode": "0-1417",
      "name": "معصوب",
      "emblem": "",
      "short_description": "",
      "description": "",
      "users_manual": "",
      "composition": "",
      "indication": "",
      "meta_title": "",
      "meta_description": "",
      "keywords": "",
      "ref_type_class": "products",
      "ref_key_values_class": "3",
      "is_offer": 0,
      "groups_products_id": "0",
      "companys_id": "2",
      "departments_id": "2",
      "is_effective": 1,
      "is_default": null,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "manage_stock": 1,
      "shop_stock": 0,
      "min_qty": 1,
      "max_qty": 100,
      "min_qty_in_stock": 1,
      "max_qty_in_stock": 100,
      "default_qty": 1,
      "old_price": 0,
      "price": 1500,
      "is_show_old_price": 0,
      "is_parleying": 1,
      "is_sold": 1,
      "is_purchased": 1,
      "is_composite": 0,
      "is_units": 1,
      "is_downloadable": 1,
      "properties": null,
      "links": null,
      "other_data": null,
      "config_data": null,
      "sort_order": 1417,
      "created_at": "2022-11-09 15:34:56",
      "updated_at": "2023-08-09 14:01:46",
      "image": {
        "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bc8\/874\/636bc8874aa80274472786.jpg",
        "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bc8\/874\/thumb_1370_160_160_0_0_crop.jpg",
        "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bc8\/874\/thumb_1370_240_240_0_0_crop.jpg",
        "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bc8\/874\/thumb_1370_800_800_0_0_crop.jpg",
        "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bc8\/874\/thumb_1370_480_480_0_0_auto.jpg"
      },
      "images": [],
      "files": [],
      "ratings_count": 0,
      "countRating": 0,
      "sumRating": null,
      "averageRating": null,
      "user_is_rating": false,
      "user_object_rating": null,
      "favorites_count": 0,
      "user_is_favorite": false,
      "user_object_favorite": null,
      "object_type": "Nano\\Shop\\Models\\Product",
      "qty": 0,
      "children": {
        "data": [],
        "meta": {
          "pagination": {
            "total": 0,
            "count": 0,
            "per_page": 10,
            "current_page": 1,
            "total_pages": 1,
            "links": []
          }
        }
      },
      "prices_units": {
        "data": []
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 3,
      "count": 3,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

** عند استخدام القوئم يجب الاخذ بالاعتبار بقيه الشروط التي قد توثر على النتائج كا جلب العروض الغير منتهيه فقط او التابعه لتصنيف معين **

**مثلا لو اردنا جلب الاصناف التابعه لقائمه معينه بشرط ان تكون الاصنافه او العروض غير منتهيه سنقوم بتمرير المتغيرات الازمه كالتالي **

```
GET http://localhost:8006/api/v1/shop/products?menus_id=9&isPublished=1
```


### Check Last Update Products Daa 

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/shop/products/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/shop/products/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على الاصناف بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2022-12-16 16:29:28",
    "other_updated": {
      "activity_cache.product": "2022-12-16 16:29:28",
      "activity_cache.productsunit": "2022-12-16 16:49:49",
      "activity_cache.productsprice": "2022-12-16 17:19:51",
      "activity_cache.productspricesunit": "2022-12-16 16:49:49"
    }
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2022-12-16 17:12:20",
    "last_updated": "2022-12-16 16:29:28",
    "other_updated": {
      "activity_cache.product": "2022-12-16 16:29:28",
      "activity_cache.productsunit": "2022-12-16 16:49:49",
      "activity_cache.productsprice": "2022-12-16 17:19:51",
      "activity_cache.productspricesunit": "2022-12-16 16:49:49"
    }
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **