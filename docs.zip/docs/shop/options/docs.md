## Options Shop 

This endpoint allows you to `list`, `show` your option.

/shop/options

**الجزء الخاص بجلب الخيارات او الخصائص الاضافية العامه التي يمكن ان ترتبط بالاصناف والمنتجات **

### The options object

#### Public Parameters
| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in options records |
| `orderBy`           | `string`  |  using orderBy options records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy options records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  options default value true    |
| `isPublic`           | `boolean`  | The get is Public in Web records options default value true  | 
| `isDefault`           | `integer`  | The get is default records options default value false  | 

| `type`           | `string`  | get records options with type default value null.          |
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `options_values`           | `hasMny`  | The get options_values |

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/shop/options?exclude=created_at,updated_at
```

##### Response

```html
Status: 200 OK
```
```json
{
  "data": [
    {
      "id": 6,
      "name": "Drinks",
      "type": "checkbox",
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "sort_order": 6,
      "companys_id": "2",
      "departments_id": "2",
      "properties": [],
      "other_data": [],
      "config_data": [],
      "options_values": {
        "data": [
          {
            "id": 4,
            "options_id": 6,
            "value": "Coke",
            "price": 0,
            "is_public": 1,
            "is_default": 1,
            "is_active": 1,
            "sort_order": 4,
            "companys_id": "2",
            "departments_id": "2"
          },
          {
            "id": 5,
            "options_id": 6,
            "value": "Diet Coke",
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 5,
            "companys_id": "2",
            "departments_id": "2"
          }
        ]
      }
    },
    {
      "id": 5,
      "name": "التوابع",
      "type": "radio",
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "sort_order": 5,
      "companys_id": "2",
      "departments_id": "2",
      "properties": [],
      "other_data": [],
      "config_data": [],
      "options_values": {
        "data": [
          {
            "id": 1,
            "options_id": 5,
            "value": "مع التوابع",
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 1,
            "companys_id": "2",
            "departments_id": "2"
          },
          {
            "id": 2,
            "options_id": 5,
            "value": "مع التوابع",
            "price": 0,
            "is_public": 1,
            "is_default": 1,
            "is_active": 1,
            "sort_order": 2,
            "companys_id": "2",
            "departments_id": "2"
          },
          {
            "id": 3,
            "options_id": 5,
            "value": "بدون التوابع",
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 3,
            "companys_id": "2",
            "departments_id": "2"
          }
        ]
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```


### List options

Returns a list of options

```
GET /api/v1/shop/options
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |


### Example 1.1 get List Options 

GET http://localhost:8006/api/v1/shop/options

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 6,
      "name": "Drinks",
      "type": "checkbox",
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "sort_order": 6,
      "companys_id": "2",
      "departments_id": "2",
      "properties": [],
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-05 20:55:36",
      "updated_at": "2023-10-05 20:55:36",
      "options_values": {
        "data": [
          {
            "id": 4,
            "options_id": 6,
            "value": "Coke",
            "price": 0,
            "is_public": 1,
            "is_default": 1,
            "is_active": 1,
            "sort_order": 4,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-05 20:55:36",
            "updated_at": "2023-10-05 20:55:36"
          },
          {
            "id": 5,
            "options_id": 6,
            "value": "Diet Coke",
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 5,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-05 20:55:36",
            "updated_at": "2023-10-05 20:55:36"
          }
        ]
      }
    },
    {
      "id": 5,
      "name": "التوابع",
      "type": "radio",
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "sort_order": 5,
      "companys_id": "2",
      "departments_id": "2",
      "properties": [],
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-04 18:11:32",
      "updated_at": "2023-10-04 18:11:32",
      "options_values": {
        "data": [
          {
            "id": 1,
            "options_id": 5,
            "value": "مع التوابع",
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 1,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-04 18:11:32",
            "updated_at": "2023-10-04 18:11:32"
          },
          {
            "id": 2,
            "options_id": 5,
            "value": "مع التوابع",
            "price": 0,
            "is_public": 1,
            "is_default": 1,
            "is_active": 1,
            "sort_order": 2,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-04 18:24:21",
            "updated_at": "2023-10-04 18:24:21"
          },
          {
            "id": 3,
            "options_id": 5,
            "value": "بدون التوابع",
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 3,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-04 18:24:21",
            "updated_at": "2023-10-04 18:24:21"
          }
        ]
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

### Example 1.2 get List Options where type = radio,number

GET http://localhost:8006/api/v1/shop/options?type=radio,number

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 5,
      "name": "التوابع",
      "type": "radio",
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "sort_order": 5,
      "companys_id": "2",
      "departments_id": "2",
      "properties": [],
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-04 18:11:32",
      "updated_at": "2023-10-04 18:11:32",
      "options_values": {
        "data": [
          {
            "id": 1,
            "options_id": 5,
            "value": "مع التوابع",
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 1,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-04 18:11:32",
            "updated_at": "2023-10-04 18:11:32"
          },
          {
            "id": 2,
            "options_id": 5,
            "value": "مع التوابع",
            "price": 0,
            "is_public": 1,
            "is_default": 1,
            "is_active": 1,
            "sort_order": 2,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-04 18:24:21",
            "updated_at": "2023-10-04 18:24:21"
          },
          {
            "id": 3,
            "options_id": 5,
            "value": "بدون التوابع",
            "price": 0,
            "is_public": 1,
            "is_default": 0,
            "is_active": 1,
            "sort_order": 3,
            "companys_id": "2",
            "departments_id": "2",
            "created_at": "2023-10-04 18:24:21",
            "updated_at": "2023-10-04 18:24:21"
          }
        ]
      }
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

### Example 1.3 get List Options exclude = options_values and where type = radio,checkbox

GET http://localhost:8006/api/v1/shop/options?type=radio,checkbox&exclude=options_values

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 6,
      "name": "Drinks",
      "type": "checkbox",
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "sort_order": 6,
      "companys_id": "2",
      "departments_id": "2",
      "properties": [],
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-05 20:55:36",
      "updated_at": "2023-10-05 20:55:36"
    },
    {
      "id": 5,
      "name": "التوابع",
      "type": "radio",
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "sort_order": 5,
      "companys_id": "2",
      "departments_id": "2",
      "properties": [],
      "other_data": [],
      "config_data": [],
      "created_at": "2023-10-04 18:11:32",
      "updated_at": "2023-10-04 18:11:32"
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

### Show Data Record Options 

```
GET /api/v1/shop/options/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record Options 6

```
GET http://localhost:8006/api/v1/shop/options/6
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "id": 6,
  "name": "Drinks",
  "type": "checkbox",
  "is_public": 1,
  "is_default": 0,
  "is_active": 1,
  "sort_order": 6,
  "companys_id": "2",
  "departments_id": "2",
  "properties": [],
  "other_data": [],
  "config_data": [],
  "created_at": "2023-10-05 20:55:36",
  "updated_at": "2023-10-05 20:55:36",
  "options_values": {
    "data": [
      {
        "id": 4,
        "options_id": 6,
        "value": "Coke",
        "price": 0,
        "is_public": 1,
        "is_default": 1,
        "is_active": 1,
        "sort_order": 4,
        "companys_id": "2",
        "departments_id": "2",
        "created_at": "2023-10-05 20:55:36",
        "updated_at": "2023-10-05 20:55:36"
      },
      {
        "id": 5,
        "options_id": 6,
        "value": "Diet Coke",
        "price": 0,
        "is_public": 1,
        "is_default": 0,
        "is_active": 1,
        "sort_order": 5,
        "companys_id": "2",
        "departments_id": "2",
        "created_at": "2023-10-05 20:55:36",
        "updated_at": "2023-10-05 20:55:36"
      }
    ]
  }
}
```

### Check Last Update Options Data

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/shop/options/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/shop/options/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2023-10-13 17:44:28",
    "other_updated": {
      "activity_cache.option": "2023-10-13 17:44:28",
      "activity_cache.optionsvalue": "2023-10-13 17:44:29",
      "activity_cache.productsoption": "2023-10-13 17:44:29",
      "activity_cache.productsoptionsvalue": "2023-10-13 17:44:29"
    }
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2023-10-13 17:43:10",
    "last_updated": "2023-10-13 17:43:10",
    "other_updated": {
      "activity_cache.option": "2023-10-13 17:43:10",
      "activity_cache.optionsvalue": "2023-10-13 17:43:10",
      "activity_cache.productsoption": "2023-10-13 17:43:10",
      "activity_cache.productsoptionsvalue": "2023-10-13 17:43:10"
    }
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **

