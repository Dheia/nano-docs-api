## Checkout Api

This endpoint allows you to `Manage Checkout Orders`, `shippingmethods`,  `paymentmethods`, your Order .

** الجزء الخاص باستكمال الطلب وتحديد تكلفة الشحن وطريقة الدفع **


**لجلب طرق الشحن المتاحة فى الطلب الحالى نستخدم الرابط التالي **
```
POST /api/v1/shop/checkout/shippingmethods
```

**لجلب طرق الدفع المتاحة فى الطلب الحالي نستخدم الرابط التالي **
```
POST /api/v1/shop/checkout/paymentmethods
```

### Require Useing X-SHOP-ID in headr request 

** عند استخدام هذا الجزء يجب تمرير المتغير التالي فى راس الطلب جزء  header **

```html
X-SHOP-ID: 4
```

X-SHOP-ID = 4

**نقوم بتمرير رقم المتجر الحالى ضمن البرامتر السابق **

** add Parameters X-SHOP-ID in headr request **


** Require X_SHOP_ID in Header Request**

### Manage Checkout

**هناك عدة خطوات يجب ان يقوم بها المستخدم لاستكمال طلبه **


**لتنفيذ خطوات استكمال الطلب نستخدم الرابط التالي **
```
POST /api/v1/shop/checkout
```

#### Public Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `step`           | `string`  |  step name default value details |


#### Checkout Steps

**الخطوات التي يجب ان يمر بها الطلب هي كا التالي **

| Name                  | Description                                                  |
| -------------------- | ------------------------------------------------------------ |
| `details`           |  البيانات الاساسية وعنوان الطلب  |
| `shiping`           |  تحديد طريقة الشحن واحتساب رسوم الشحن  |
| `details_shiping`           |  تجمع بين الخطوتين السابقتين  |
| `coupon`           |  اضافه كوبون الخصم ان وجد والبقشيش الخاص بالموصل ان اراد الزبون  |
| `details_shiping_coupon`           |  تجمع بين الخطوات السابقه   |
| `pay`           |  تحديد طريقة الدفع والدفع  |
| `double_order`           |   لتكرار طلب معين  |


##### Checkout step = details

**الخطوه الاول تطلب العناوين الخاصه بالطلب يمكن تمرير رقم العنوان الخاص بالشحن او تمرير بيانات الحقول المطلوبه **


```
POST http://localhost:8006/api/v1/shop/checkout
```

or

```
POST http://localhost:8006/api/v1/shop/checkout?step=details
```

**فى حالة عدم تمرير بيانات سيتم ارجاع البيانات التاليه **

###### Response

```html
Status: 200 OK
```

```json```

**توضح البينات الراجعه حالة الخطوه step_status وايضا البيانات المطلوبه فى هذه الخطوه step_data**

**فى الخطوه السابقه يمكن تمرير معرف العنوان الخاص بالشحن من عناوين المستخدم وارساله ضمن البرامتر التالي shipping_address_id**

##### Checkout step = shiping

**الخطوه التاليه احتساب سعر التوصيل وتحديد طريقه الشحن  **

```
POST http://localhost:8006/api/v1/shop/checkout?step=shiping
```

###### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "step_status": true,
  "message": "طرق الشحن واحتساب سعر التوصيل ",
  "steps": {
    "previous": "coupon",
    "current": "shiping",
    "next": "pay",
    "step_status": true,
    "step_data": {
      "shipping_method_id": 1,
      "distance_unit": "km",
      "distance_unit_name": "كيلو متر",
      "shipping_price": "500.00",
      "shipping_distance": 5109.1666115797325,
      "shipping_total": 2554583,
      "shipping_method_ref_type": "DELIVERY"
    }
  },
  "input_data": {
    "step": "shiping",
  },
  "cart_data": {
    "content": [
      {
        "rowId": "de5289438c44cdd0f7b0d8f1b8eeb86e",
        "id": 2,
        "name": "الصنف الثاني",
        "units_id": "",
        "units_name": "",
        "qty": "5",
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 2",
        "subtotal": 0
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "4",
        "units_name": "نص",
        "qty": "3",
        "price": 300,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 900
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "5",
        "units_name": "ربع",
        "qty": "5",
        "price": 200,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 1000
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "1",
        "units_name": "حبه",
        "qty": "6",
        "price": 500,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 3000
      }
    ],
    "conditions": {
      "tip": {
        "name": "tip",
        "label": "nano.cart::default.text_tip",
        "priority": "100",
        "removeable": true,
        "metaData": {
          "amount": 50,
          "amountType": "amount"
        }
      }
    },
    "count": 6,
    "subtotalWithoutConditions": 4900,
    "subtotal": 4900,
    "total": 4950,
    "total_other": {
      "tip": {
        "code": "tip",
        "title": "Tip",
        "value": 50,
        "priority": "100",
        "is_summable": true
      }
    }
  },
  "cart_totals": {
    "tip": {
      "code": "tip",
      "title": "Tip",
      "value": 50,
      "priority": "100",
      "is_summable": true,
      "metaData": {
        "amount": 50,
        "amountType": "amount"
      }
    },
    "subtotal": {
      "code": "subtotal",
      "title": "Sub Total",
      "value": 4900,
      "priority": 0,
      "is_summable": false
    },
    "cart_total": {
      "code": "cart_total",
      "title": "Cart Total",
      "value": 4950,
      "priority": 999,
      "is_summable": false
    },
    "shipping_total": {
      "code": "shipping_total",
      "title": "Shipping Total",
      "value": 2554583,
      "priority": 999,
      "is_summable": false,
      "metaData": {
        "shipping_method_id": 1,
        "distance_unit": "km",
        "distance_unit_name": "كيلو متر",
        "shipping_price": "500.00",
        "shipping_distance": 5109.1666115797325
      }
    },
    "total": {
      "code": "total",
      "title": "Order Total",
      "value": 2559533,
      "priority": 999,
      "is_summable": false
    }
  }
}
```


**توضح البينات الراجعه حالة الخطوه step_status وايضا البيانات المطلوبه فى هذه الخطوه step_data**

**فى الخطوه السابقه يمكن تمرير طريقه الشحن   shipping_method_id**



**فى حالة تمرير طريقة شحن غير صحيح ستكون البيانات الراجعه كا التالي   shipping_method_id**

```
POST http://localhost:8006/api/v1/shop/checkout?step=shiping&shipping_method_id=6
```

###### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "step_status": false,
  "message": "طرق الشحن واحتساب سعر التوصيل ",
  "error": "موقع الطلب خارج نطاق خدمة التوصيل لدينا ",
  "steps": {
    "previous": "coupon",
    "current": "shiping",
    "next": "pay",
    "step_status": false,
    "step_data": {
      "shipping_method_id": "",
      "distance_unit": "",
      "distance_unit_name": "",
      "shipping_price": "",
      "shipping_distance": "",
      "shipping_total": ""
    }
  },
  "input_data": {
    "step": "shiping",
    "shipping_method_id": "6",
  },
  "cart_data": {
    "content": [
      {
        "rowId": "de5289438c44cdd0f7b0d8f1b8eeb86e",
        "id": 2,
        "name": "الصنف الثاني",
        "units_id": "",
        "units_name": "",
        "qty": "5",
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 2",
        "subtotal": 0
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "4",
        "units_name": "نص",
        "qty": "3",
        "price": 300,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 900
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "5",
        "units_name": "ربع",
        "qty": "5",
        "price": 200,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 1000
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "1",
        "units_name": "حبه",
        "qty": "6",
        "price": 500,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 3000
      }
    ],
    "conditions": {
      "tip": {
        "name": "tip",
        "label": "nano.cart::default.text_tip",
        "priority": "100",
        "removeable": true,
        "metaData": {
          "amount": 50,
          "amountType": "amount"
        }
      }
    },
    "count": 6,
    "subtotalWithoutConditions": 4900,
    "subtotal": 4900,
    "total": 4950,
    "total_other": {
      "tip": {
        "code": "tip",
        "title": "Tip",
        "value": 50,
        "priority": "100",
        "is_summable": true
      }
    }
  },
  "cart_totals": {
    "tip": {
      "code": "tip",
      "title": "Tip",
      "value": 50,
      "priority": "100",
      "is_summable": true,
      "metaData": {
        "amount": 50,
        "amountType": "amount"
      }
    },
    "subtotal": {
      "code": "subtotal",
      "title": "Sub Total",
      "value": 4900,
      "priority": 0,
      "is_summable": false
    },
    "cart_total": {
      "code": "cart_total",
      "title": "Cart Total",
      "value": 4950,
      "priority": 999,
      "is_summable": false
    },
    "shipping_total": {
      "code": "shipping_total",
      "title": "Shipping Total",
      "value": 0,
      "priority": 999,
      "is_summable": false,
      "metaData": {
        "shipping_method_id": null,
        "distance_unit": null,
        "distance_unit_name": null,
        "shipping_price": 0,
        "shipping_distance": 0
      }
    },
    "total": {
      "code": "total",
      "title": "Order Total",
      "value": 4950,
      "priority": 999,
      "is_summable": false
    }
  }
}
```

##### Checkout step = coupon

**الخطوه التاليه اضافه كود خصم ان وجد **
```
POST http://localhost:8006/api/v1/shop/checkout?step=coupon&coupon_code=22222
```

###### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "step_status": true,
  "message": "كوبون الخصم ",
  "steps": {
    "previous": "details",
    "current": "coupon",
    "next": "shiping",
    "step_status": true,
    "step_data": {
      "coupon_code": "2222",
      "tip_type": "amount",
      "tip_amount": ""
    }
  },
  "input_data": {
    "step": "coupon",
    "coupon_code": "2222"
  },
  "cart_data": {
    "content": [
      {
        "rowId": "de5289438c44cdd0f7b0d8f1b8eeb86e",
        "id": 2,
        "name": "الصنف الثاني",
        "units_id": "",
        "units_name": "",
        "qty": "5",
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 2",
        "subtotal": 0
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "4",
        "units_name": "نص",
        "qty": "3",
        "price": 300,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 900
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "5",
        "units_name": "ربع",
        "qty": "5",
        "price": 200,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 1000
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "1",
        "units_name": "حبه",
        "qty": "6",
        "price": 500,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 3000
      }
    ],
    "conditions": {
      "tip": {
        "name": "tip",
        "label": "nano.cart::default.text_tip",
        "priority": "100",
        "removeable": true,
        "metaData": {
          "amount": 50,
          "amountType": "amount"
        }
      },
      "coupon": {
        "name": "coupon",
        "label": "Coupon  [%s]",
        "priority": "200",
        "removeable": true,
        "metaData": {
          "code": "2222"
        }
      }
    },
    "count": 6,
    "subtotalWithoutConditions": 4900,
    "subtotal": 4900,
    "total": 4850,
    "total_other": {
      "tip": {
        "code": "tip",
        "title": "Tip",
        "value": 50,
        "priority": "100",
        "is_summable": true
      },
      "coupon": {
        "code": "coupon",
        "title": "Coupon  [2222]",
        "value": -100,
        "priority": "200",
        "is_summable": true
      }
    }
  },
  "cart_totals": {
    "tip": {
      "code": "tip",
      "title": "Tip",
      "value": 50,
      "priority": "100",
      "is_summable": true,
      "metaData": {
        "amount": 50,
        "amountType": "amount"
      }
    },
    "coupon": {
      "code": "coupon",
      "title": "Coupon  [2222]",
      "value": -100,
      "priority": "200",
      "is_summable": true,
      "metaData": {
        "code": "2222"
      }
    },
    "subtotal": {
      "code": "subtotal",
      "title": "Sub Total",
      "value": 4900,
      "priority": 0,
      "is_summable": false
    },
    "cart_total": {
      "code": "cart_total",
      "title": "Cart Total",
      "value": 4850,
      "priority": 999,
      "is_summable": false
    },
    "shipping_total": {
      "code": "shipping_total",
      "title": "Shipping Total",
      "value": 0,
      "priority": 999,
      "is_summable": false,
      "metaData": {
        "shipping_method_id": null,
        "distance_unit": null,
        "distance_unit_name": null,
        "shipping_price": "0.00",
        "shipping_distance": "0.000000000000"
      }
    },
    "total": {
      "code": "total",
      "title": "Order Total",
      "value": 4850,
      "priority": 999,
      "is_summable": false
    }
  }
}
```


**توضح البينات الراجعه حالة الخطوه step_status وايضا البيانات المطلوبه فى هذه الخطوه step_data**

**فى الخطوه السابقه يمكن تمرير كود الخصم ضمن المتغير  coupon_code**



**فى حالة تمرير كود خصم غير صحيح ستكون البيانات الراجعه كا التالي   coupon_code**

```
POST http://localhost:8006/api/v1/shop/checkout?step=coupon&coupon_code=22226
```

###### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "step_status": false,
  "message": "كوبون الخصم غير صحيح ",
  "error": "Please enter a valid coupon.",
  "steps": {
    "previous": "details",
    "current": "coupon",
    "next": "shiping",
    "step_status": false,
    "step_data": {
      "coupon_code": "",
      "tip_type": "amount",
      "tip_amount": ""
    }
  },
  "input_data": {
    "step": "coupon",
    "coupon_code": "22226"
  },
  "cart_data": {
    "content": [
      {
        "rowId": "de5289438c44cdd0f7b0d8f1b8eeb86e",
        "id": 2,
        "name": "الصنف الثاني",
        "units_id": "",
        "units_name": "",
        "qty": "5",
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 2",
        "subtotal": 0
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "4",
        "units_name": "نص",
        "qty": "3",
        "price": 300,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 900
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "5",
        "units_name": "ربع",
        "qty": "5",
        "price": 200,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 1000
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "1",
        "units_name": "حبه",
        "qty": "6",
        "price": 500,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 3000
      }
    ],
    "conditions": {
      "tip": {
        "name": "tip",
        "label": "nano.cart::default.text_tip",
        "priority": "100",
        "removeable": true,
        "metaData": {
          "amount": 50,
          "amountType": "amount"
        }
      }
    },
    "count": 6,
    "subtotalWithoutConditions": 4900,
    "subtotal": 4900,
    "total": 4950,
    "total_other": {
      "tip": {
        "code": "tip",
        "title": "Tip",
        "value": 50,
        "priority": "100",
        "is_summable": true
      }
    }
  },
  "cart_totals": {
    "tip": {
      "code": "tip",
      "title": "Tip",
      "value": 50,
      "priority": "100",
      "is_summable": true,
      "metaData": {
        "amount": 50,
        "amountType": "amount"
      }
    },
    "subtotal": {
      "code": "subtotal",
      "title": "Sub Total",
      "value": 4900,
      "priority": 0,
      "is_summable": false
    },
    "cart_total": {
      "code": "cart_total",
      "title": "Cart Total",
      "value": 4950,
      "priority": 999,
      "is_summable": false
    },
    "shipping_total": {
      "code": "shipping_total",
      "title": "Shipping Total",
      "value": 0,
      "priority": 999,
      "is_summable": false,
      "metaData": {
        "shipping_method_id": null,
        "distance_unit": null,
        "distance_unit_name": null,
        "shipping_price": "0.00",
        "shipping_distance": "0.000000000000"
      }
    },
    "total": {
      "code": "total",
      "title": "Order Total",
      "value": 4950,
      "priority": 999,
      "is_summable": false
    }
  }
}
```


**فى حالة عدم تمرير كوبون خصم ستكون البيانات الراجعه كالتالي**

```
POST http://localhost:8006/api/v1/shop/checkout?step=coupon
```

###### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "step_status": true,
  "message": "كوبون الخصم ",
  "steps": {
    "previous": "details",
    "current": "coupon",
    "next": "shiping",
    "step_status": true,
    "step_data": {
      "coupon_code": "",
      "tip_type": "amount",
      "tip_amount": ""
    }
  },
  "input_data": {
    "step": "coupon",
    "coupon_code2": "22226"
  },
  "cart_data": {
    "content": [
      {
        "rowId": "de5289438c44cdd0f7b0d8f1b8eeb86e",
        "id": 2,
        "name": "الصنف الثاني",
        "units_id": "",
        "units_name": "",
        "qty": "5",
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 2",
        "subtotal": 0
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "4",
        "units_name": "نص",
        "qty": "3",
        "price": 300,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 900
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "5",
        "units_name": "ربع",
        "qty": "5",
        "price": 200,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 1000
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "1",
        "units_name": "حبه",
        "qty": "6",
        "price": 500,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 3000
      }
    ],
    "conditions": {
      "tip": {
        "name": "tip",
        "label": "nano.cart::default.text_tip",
        "priority": "100",
        "removeable": true,
        "metaData": {
          "amount": 50,
          "amountType": "amount"
        }
      }
    },
    "count": 6,
    "subtotalWithoutConditions": 4900,
    "subtotal": 4900,
    "total": 4950,
    "total_other": {
      "tip": {
        "code": "tip",
        "title": "Tip",
        "value": 50,
        "priority": "100",
        "is_summable": true
      }
    }
  },
  "cart_totals": {
    "tip": {
      "code": "tip",
      "title": "Tip",
      "value": 50,
      "priority": "100",
      "is_summable": true,
      "metaData": {
        "amount": 50,
        "amountType": "amount"
      }
    },
    "subtotal": {
      "code": "subtotal",
      "title": "Sub Total",
      "value": 4900,
      "priority": 0,
      "is_summable": false
    },
    "cart_total": {
      "code": "cart_total",
      "title": "Cart Total",
      "value": 4950,
      "priority": 999,
      "is_summable": false
    },
    "shipping_total": {
      "code": "shipping_total",
      "title": "Shipping Total",
      "value": 0,
      "priority": 999,
      "is_summable": false,
      "metaData": {
        "shipping_method_id": null,
        "distance_unit": null,
        "distance_unit_name": null,
        "shipping_price": "0.00",
        "shipping_distance": "0.000000000000"
      }
    },
    "total": {
      "code": "total",
      "title": "Order Total",
      "value": 4950,
      "priority": 999,
      "is_summable": false
    }
  }
}
```

##### Checkout step = details_shiping_coupon

** بلامكان الجمع بين الخطوات السابقة بخطوه واحده مع تمرير البيانات المطلوبه  اسم الخطوه details_shiping_coupon**
```
POST http://localhost:8006/api/v1/shop/checkout
```

or

```
POST http://localhost:8006/api/v1/shop/checkout?step=details_shiping_coupon
```

###### Response

```html
Status: 200 OK
```

```json
{
  "code": 200,
  "status": true,
  "step_status": true,
  "message": "تم حفظ بيانات الاساسية للطلب بنجاح",
  "error": null,
  "errors": [],
  "input_data": {
    "departments_id": 4,
    "user_id": null,
    "email": null,
    "customer_id": null,
    "customer_notes": "مستعجل",
    "vehicle_type_id": "3",
    "vehicle_type_ref_type": "LAND_BUSES_SMALL",
    "from_address_1": "جولة المجد, طريق إب - الضالع, اب, منزل الشعبة, ذي شاط, مديرية المشنة, محافظة إب, اليمن",
    "step": "details_shiping_coupon",
    "from_country": "Ye",
    "from_state": "428",
    "from_lat": "13.9524793",
    "from_lng": "44.1842459",
    "shipping_address_1": "فندق برج النمر السياحي, شارع جبله, اب, نجد الدحثات, الدحثاث السفلى, مديرية جبلة, محافظة إب, اليمن",
    "shipping_country": "YE",
    "shipping_state": "428",
    "shipping_lat": "13.9343281",
    "shipping_lng": "44.1781313",
    "order_type": "taxi",
    "shipping_firstname": "ضياء علي محمد علي ",
    "shipping_lastname": "الشامي",
    "tip_amount": "100",
    "expected_shipping_total": 0,
    "coupon_name": "tip",
    "coupon_data": null
  },
  "process_data": {
    "departments_id": 4,
    "user_id": 3,
    "email": "test@gmail.com",
    "customer_id": 3,
    "customer_notes": "مستعجل",
    "vehicle_type_id": 3,
    "vehicle_type_ref_type": "LAND_BUSES_SMALL",
    "load_ref_type": null,
    "load_type_id": null,
    "load_notes": null,
    "is_load_liter": false,
    "is_load_storage_sensitive": 0,
    "is_load_fragile_materials": 0,
    "weight": null,
    "length": null,
    "width": null,
    "height": null,
    "load_people": 1,
    "from_country": 246,
    "from_state": "428",
    "from_address_1": "جولة المجد, طريق إب - الضالع, اب, منزل الشعبة, ذي شاط, مديرية المشنة, محافظة إب, اليمن",
    "from_lat": "13.9524793",
    "from_lng": "44.1842459",
    "shipping_firstname": "ضياء علي محمد علي ",
    "shipping_lastname": "الشامي",
    "shipping_country": 246,
    "shipping_state": "428",
    "shipping_address_1": "فندق برج النمر السياحي, شارع جبله, اب, نجد الدحثات, الدحثاث السفلى, مديرية جبلة, محافظة إب, اليمن",
    "shipping_lat": "13.9343281",
    "shipping_lng": "44.1781313",
    "shipping_phone": "770821911",
    "shipping_email": "test@gmail.com",
    "shipping_address_2": null,
    "shipping_lines": null,
    "shipping_city": "",
    "shipping_zip": "",
    "shipping_postcode": null,
    "shipping_radius": 0,
    "billing_address_id": null,
    "billing_company": null,
    "billing_firstname": "ضياء علي محمد علي ",
    "billing_lastname": "الشامي",
    "billing_email": "test@gmail.com",
    "billing_phone": "770821911",
    "billing_country": 246,
    "billing_state": "428",
    "billing_city": "",
    "billing_address_1": "فندق برج النمر السياحي, شارع جبله, اب, نجد الدحثات, الدحثاث السفلى, مديرية جبلة, محافظة إب, اليمن",
    "billing_address_2": null,
    "billing_lines": null,
    "billing_lat": "13.9343281",
    "billing_lng": "44.1781313",
    "billing_zip": "",
    "billing_postcode": null,
    "billing_differs": false,
    "shipping_method_id": 3,
    "shipping_method_ref_type": "taxi",
    "distance_unit": "km",
    "shipping_price": "500.00",
    "shipping_distance": 2.1258332819754764,
    "shipping_total": 1063,
    "expected_shipping_total": 1063,
    "coupon_name": "coupon",
    "coupon_code": null,
    "coupon_data": null,
    "metaData": {
      "amountType": "amount",
      "amount": "100"
    }
  },
  "steps": {
    "previous": "0",
    "current": "details_shiping_coupon",
    "next": "pay",
    "step_status": true,
    "step_data": {
      "departments_id": 4,
      "user_id": 3,
      "email": "test@gmail.com",
      "customer_id": 3,
      "customer_notes": "مستعجل",
      "vehicle_type_id": 3,
      "vehicle_type_ref_type": "LAND_BUSES_SMALL",
      "load_ref_type": null,
      "load_type_id": null,
      "load_notes": null,
      "is_load_liter": false,
      "is_load_storage_sensitive": 0,
      "is_load_fragile_materials": 0,
      "weight": null,
      "length": null,
      "width": null,
      "height": null,
      "load_people": 1,
      "from_country": 246,
      "from_state": "428",
      "from_address_1": "جولة المجد, طريق إب - الضالع, اب, منزل الشعبة, ذي شاط, مديرية المشنة, محافظة إب, اليمن",
      "from_lat": "13.9524793",
      "from_lng": "44.1842459",
      "shipping_firstname": "ضياء علي محمد علي ",
      "shipping_lastname": "الشامي",
      "shipping_country": 246,
      "shipping_state": "428",
      "shipping_address_1": "فندق برج النمر السياحي, شارع جبله, اب, نجد الدحثات, الدحثاث السفلى, مديرية جبلة, محافظة إب, اليمن",
      "shipping_lat": "13.9343281",
      "shipping_lng": "44.1781313",
      "shipping_phone": "770821911",
      "shipping_email": "test@gmail.com",
      "shipping_address_2": null,
      "shipping_lines": null,
      "shipping_city": "",
      "shipping_zip": "",
      "shipping_postcode": null,
      "shipping_radius": 0,
      "billing_address_id": null,
      "billing_company": null,
      "billing_firstname": "ضياء علي محمد علي ",
      "billing_lastname": "الشامي",
      "billing_email": "test@gmail.com",
      "billing_phone": "770821911",
      "billing_country": 246,
      "billing_state": "428",
      "billing_city": "",
      "billing_address_1": "فندق برج النمر السياحي, شارع جبله, اب, نجد الدحثات, الدحثاث السفلى, مديرية جبلة, محافظة إب, اليمن",
      "billing_address_2": null,
      "billing_lines": null,
      "billing_lat": "13.9343281",
      "billing_lng": "44.1781313",
      "billing_zip": "",
      "billing_postcode": null,
      "billing_differs": false,
      "shipping_method_id": 3,
      "shipping_method_ref_type": "taxi",
      "distance_unit": "km",
      "shipping_price": "500.00",
      "shipping_distance": 2.1258332819754764,
      "shipping_total": 1063,
      "expected_shipping_total": 1063,
      "coupon_name": "coupon",
      "coupon_code": null,
      "coupon_data": null,
      "metaData": {
        "amountType": "amount",
        "amount": "100"
      }
    }
  },
  "cart_data": {
    "content": [],
    "conditions": [],
    "count": 0,
    "subtotalWithoutConditions": 0,
    "subtotal": 0,
    "total": 0,
    "total_other": []
  },
  "cart_totals": {
    "subtotal": {
      "code": "subtotal",
      "title": "Sub Total",
      "value": null,
      "priority": 0,
      "is_summable": false
    },
    "cart_total": {
      "code": "cart_total",
      "title": "Cart Total",
      "value": 0,
      "priority": 999,
      "is_summable": false
    },
    "expected_cart_total": {
      "code": "expected_cart_total",
      "title": "nano.cart::default.text_expected_cart_total",
      "value": 0,
      "priority": 999,
      "is_summable": false
    },
    "shipping_total": {
      "code": "shipping_total",
      "title": "Shipping Total",
      "value": 1063,
      "priority": 999,
      "is_summable": true,
      "metaData": {
        "shipping_method_id": 3,
        "distance_unit": "km",
        "distance_unit_name": "KILOMETER",
        "shipping_price": 500,
        "shipping_distance": 2.1258332819754764
      }
    },
    "expected_shipping_total": {
      "code": "expected_shipping_total",
      "title": "nano.cart::default.text_expected_shipping_total",
      "value": 1063,
      "priority": 999,
      "is_summable": false
    },
    "total": {
      "code": "total",
      "title": "Order Total",
      "value": 1063,
      "priority": 999,
      "is_summable": false
    }
  }
}
```


##### Get list shippingmethods

**لجلب طرق الشحن المتاحة فى الطلب الحالى نستخدم الرابط التالي **
```
POST /api/v1/shop/checkout/shippingmethods
```
```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": "2-2-1",
      "name": "بالكيلو متر",
      "color": null,
      "description": "",
      "is_auto_price": 1,
      "distance_unit": "km",
      "max_distance": 5,
      "min_distance": null,
      "price": "500.00",
      "max_price": null,
      "min_price": null,
      "is_default": 0,
      "is_active": 1,
      "country_id": "249",
      "state_id": "1067",
      "directorate_id": null,
      "companys_id": "2",
      "config_data": null,
      "other_data": null,
      "flag": null,
      "ref_type": "DELIVERY",
      "ref_key_name": null,
      "ref_key_values": null,
      "sort_order": 1,
      "created_at": "2022-12-20 21:12:18",
      "updated_at": "2022-12-20 21:13:13",
      "logo": null
    }
  ]
}
```

**يتم جلب طرق الشحن بالاعتماد على عنوان الطلب فى حالة عدم وجود بياناتات العنوان الخاصه بالشحن سيتم ارجاع فراغ **

##### Checkout step = pay

**الخطوه التاليه احتساب سعر التوصيل وتحديد طريقه الشحن  **

```
POST http://localhost:8006/api/v1/shop/checkout?step=pay&payment_method_id=1
```

###### Response

```html
Status: 200 OK
```

```json
{
  "code": 200,
  "status": true,
  "step_status": true,
  "message": "تم عملية الدفع بنجاح",
  "error": null,
  "errors": [],
  "input_data": {
    "payment_method_id": null,
    "card_first_name": null,
    "card_last_name": null,
    "card_number": null,
    "card_expiry_month": null,
    "card_expiry_year": null,
    "card_cvv": null,
    "payment_trans_id": null,
    "confirm_code": null
  },
  "process_data": {
    "payment_method_id": 1,
    "process": {
      "headers": {},
      "original": null,
      "exception": null
    },
    "payment_id": null,
    "payment_state": "Nano\\MicroCart\\Classes\\PaymentState\\PendingState",
    "processed": true,
    "card_first_name": null,
    "card_last_name": null,
    "card_number": null,
    "card_expiry_month": null,
    "card_expiry_year": null,
    "card_cvv": null,
    "payment_trans_id": null
  },
  "steps": {
    "previous": "coupon",
    "current": "pay",
    "next": "finsh",
    "step_status": true,
    "step_data": {
      "payment_method_id": 1,
      "process": {
        "headers": {},
        "original": null,
        "exception": null
      },
      "payment_id": null,
      "payment_state": "Nano\\MicroCart\\Classes\\PaymentState\\PendingState",
      "processed": true,
      "card_first_name": null,
      "card_last_name": null,
      "card_number": null,
      "card_expiry_month": null,
      "card_expiry_year": null,
      "card_cvv": null,
      "payment_trans_id": null
    }
  },
  "cart_data": {
    "content": [],
    "conditions": [],
    "count": 0,
    "subtotalWithoutConditions": 0,
    "subtotal": 0,
    "total": 0,
    "total_other": []
  },
  "cart_totals": {
    "subtotal": {
      "code": "subtotal",
      "title": "Sub Total",
      "value": null,
      "priority": 0,
      "is_summable": false
    },
    "cart_total": {
      "code": "cart_total",
      "title": "Cart Total",
      "value": 0,
      "priority": 999,
      "is_summable": false
    },
    "expected_cart_total": {
      "code": "expected_cart_total",
      "title": "nano.cart::default.text_expected_cart_total",
      "value": 0,
      "priority": 999,
      "is_summable": false
    },
    "shipping_total": {
      "code": "shipping_total",
      "title": "Shipping Total",
      "value": 1063,
      "priority": 999,
      "is_summable": true,
      "metaData": {
        "shipping_method_id": 3,
        "distance_unit": "km",
        "distance_unit_name": "KILOMETER",
        "shipping_price": 500,
        "shipping_distance": 2.125833281975
      }
    },
    "expected_shipping_total": {
      "code": "expected_shipping_total",
      "title": "nano.cart::default.text_expected_shipping_total",
      "value": "1063.00",
      "priority": 999,
      "is_summable": false
    },
    "total": {
      "code": "total",
      "title": "Order Total",
      "value": 1063,
      "priority": 999,
      "is_summable": false
    }
  }
}
```


**توضح البينات الراجعه حالة الخطوه step_status وايضا البيانات المطلوبه فى هذه الخطوه step_data**




**فى حالة تمرير طريقة دفع غير صحيح ستكون البيانات الراجعه كا التالي   payment_method_id**

```
POST http://localhost:8006/api/v1/shop/checkout?step=pay&payment_method_id=3
```

###### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "step_status": false,
  "message": "طرق الدفع ",
  "error": "طريقة الدفع غير متاحة  ",
  "steps": {
    "previous": "shiping",
    "current": "pay",
    "next": "finsh",
    "step_status": false,
    "step_data": {
      "payment_method_id": 1,
      "card_first_name": "",
      "card_last_name": "",
      "card_number": "",
      "card_expiry_month": "",
      "card_expiry_year": "",
      "card_cvv": "",
      "payment_trans_id": "",
      "payment_id": 2,
      "payment_state": null,
      "processed": 0
    }
  },
  "input_data": {
    "step": "pay",
    "payment_method_id": "3"
  },
  "cart_data": {
    "content": [
      {
        "rowId": "de5289438c44cdd0f7b0d8f1b8eeb86e",
        "id": 2,
        "name": "الصنف الثاني",
        "units_id": "",
        "units_name": "",
        "qty": "5",
        "price": 0,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 2",
        "subtotal": 0
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "4",
        "units_name": "نص",
        "qty": "3",
        "price": 300,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 900
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "5",
        "units_name": "ربع",
        "qty": "5",
        "price": 200,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 1000
      },
      {
        "rowId": "d236d5552a817e0cea0dd57b3012e3b8",
        "id": 4,
        "name": "حبة دجاج برست",
        "units_id": "1",
        "units_name": "حبه",
        "qty": "6",
        "price": 500,
        "options": [],
        "conditions": [],
        "comment": "ملاحظات على الصنف 4",
        "subtotal": 3000
      }
    ],
    "conditions": {
      "tip": {
        "name": "tip",
        "label": "nano.cart::default.text_tip",
        "priority": "100",
        "removeable": true,
        "metaData": {
          "amount": 50,
          "amountType": "amount"
        }
      },
      "coupon": {
        "name": "coupon",
        "label": "Coupon  [%s]",
        "priority": "200",
        "removeable": true,
        "metaData": {
          "code": "2222"
        }
      }
    },
    "count": 6,
    "subtotalWithoutConditions": 4900,
    "subtotal": 4900,
    "total": 4850,
    "total_other": {
      "tip": {
        "code": "tip",
        "title": "Tip",
        "value": 50,
        "priority": "100",
        "is_summable": true
      },
      "coupon": {
        "code": "coupon",
        "title": "Coupon  [2222]",
        "value": -100,
        "priority": "200",
        "is_summable": true
      }
    }
  },
  "cart_totals": {
    "tip": {
      "code": "tip",
      "title": "Tip",
      "value": 50,
      "priority": "100",
      "is_summable": true,
      "metaData": {
        "amount": 50,
        "amountType": "amount"
      }
    },
    "coupon": {
      "code": "coupon",
      "title": "Coupon  [2222]",
      "value": -100,
      "priority": "200",
      "is_summable": true,
      "metaData": {
        "code": "2222"
      }
    },
    "subtotal": {
      "code": "subtotal",
      "title": "Sub Total",
      "value": 4900,
      "priority": 0,
      "is_summable": false
    },
    "cart_total": {
      "code": "cart_total",
      "title": "Cart Total",
      "value": 4850,
      "priority": 999,
      "is_summable": false
    },
    "shipping_total": {
      "code": "shipping_total",
      "title": "Shipping Total",
      "value": "2554583.00",
      "priority": 999,
      "is_summable": false,
      "metaData": {
        "shipping_method_id": 1,
        "distance_unit": "km",
        "distance_unit_name": "كيلو متر",
        "shipping_price": "500.00",
        "shipping_distance": "5109.166611579733"
      }
    },
    "total": {
      "code": "total",
      "title": "Order Total",
      "value": 2559433,
      "priority": 999,
      "is_summable": false
    }
  }
}
```


##### Get list paymentmethods

**لجلب طرق الدفع المتاحة  فى الطلب الحالى نستخدم الرابط التالي **
```
POST /api/v1/shop/checkout/paymentmethods
```
```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": "aldfaa-aand-alastlam",
      "name": "الدفع عند الاستلام",
      "description": "",
      "instructions": null,
      "payment_provider": "nano",
      "label": "",
      "price": 0,
      "percentage": "0.0000",
      "is_default": true,
      "sort_order": 1,
      "created_at": "2022-12-19 20:32:59",
      "updated_at": "2022-12-19 20:32:59",
      "logo": null
    }
  ]
}
```

##### Checkout step = double_order

**  لتكرار طلب معين نقوم بتمرير رقم الطلب واسم الخطوه step  **

```
POST http://localhost:8006/api/v1/shop/checkout?step=double_order&order_id=1
```

**تمر مرحلة تكرار الطلب بعدة خطوات اولها التحقق  من ان الاصناف متاحه ومن اسعار
الاصناف ومن صلاحية الكوبون اذا كان الطلب المراد تكراره يحتوي على كوبون خصم
والتحقق من سعر التوصيل  **


###### Response

```html
Status: 200 OK
```

```json
{
    "code": "200",
    "step_status": false,
    "message": "الطلب المراد تكرارة لاينتمي لنفس المستخدم يرجاء التاكد من الطلب ",
    "error": "الطلب المراد تكرارة لاينتمي لنفس المستخدم يرجاء التاكد من الطلب ",
    "input_data": {
        "step": "double_order",
        "order_id": "13"
    },
    "steps": {
        "previous": null,
        "current": "double_order",
        "next": null,
        "step_status": false,
        "step_data": {
            "order_id": "13",
            "confirm_name": "",
            "confirm_msg": ""
        }
    },
    "required_data": {
        "order_id": "13",
        "confirm_name": "",
        "confirm_msg": ""
    }
}
```

**فى حال تم تمرير رقم طلب غير صحيح  **

```
POST http://localhost:8006/api/v1/shop/checkout?step=double_order&order_id=133
```

###### Response

```html
Status: 200 OK
```

```json
{
    "code": "200",
    "step_status": false,
    "message": "لم يتم العثور على الطلب المراد تكراره يرجاء التاكد من الطلب",
    "error": "لم يتم العثور على الطلب المراد تكراره يرجاء التاكد من الطلب",
    "input_data": {
        "step": "double_order",
        "order_id": "133"
    },
    "steps": {
        "previous": null,
        "current": "double_order",
        "next": null,
        "step_status": false,
        "step_data": {
            "order_id": "133",
            "confirm_name": "",
            "confirm_msg": ""
        }
    },
    "required_data": {
        "order_id": "133",
        "confirm_name": "",
        "confirm_msg": ""
    }
}
```


**توضح البينات الراجعه حالة الخطوه step_status وايضا البيانات المطلوبه فى هذه الخطوه step_data**


#### Checkout Errors 
**رسائل الاخطاء التي يتم ارجاعها فى بعض الحالات **

**فى حالة الطلب خارج وقت عمل التطبيق  سيتم ارجاع الخطاء والرساله التاليه **

```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "خدمة التوصيل غير متاحة فى الوقت الحالي يرجا مراجعة اوقات العمل "
  }
}
```

**فى حالة كان المطعم او المتجر الذي طلب منه المساخدم مغلق سيتم ارجاع الرساله التاليه **


```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "المطعم مغلق فى الوقت الحالي يرجا مراجعة اوقات العمل "
  }
}
```

**فى حالة عدم وجود اصناف فى السله **


```
نص الرساله عند تفعيل اللغه الانجليزيه
```
```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "Please, add some menus before you checkout!"
  }
}
```

```
نص الرساله عند تفعيل اللغه العربيه
```

```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "يرجا اضافة الاصناف الى السلة اولا"
  }
}
```