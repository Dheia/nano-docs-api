## Type Shop 

This endpoint allows you to `list`, `show` your menu.

/shop/menus

**من خلال هذا الجزء يمكنك جلب القوائم العامه للاصناف او المنتجات مثلا قائمه الاصناف المميزه او الجديده او الاكثر مبيعاً **

** كافة القوائم  **

### The menus object

#### Public Parameters
| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in menus records |
| `orderBy`           | `string`  |  using orderBy menus records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy menus records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  menus default value true    |
| `isPublic`           | `boolean`  | The get is Public in Web records menus default value true  | 
| `isPublished`           | `integer`  | The get is Not Hidden in Web records menus default value true  | 

| `isDisplayEmpty`           | `boolean`  | get records menus not have departments default value true.          |
| `displayTo`           | `integer` | useing number have departments default value 1
| 
| `with_count`           | `boolean` | get counts departments,tags,categories default value false
| 
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `products`           | `hasMny`  | The get products |

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/shop/menus?exclude=created_at,updated_at
```

##### Response

```html
Status: 200 OK
```
```json
{
  "data": [
    {
      "id": 9,
      "code": "2-2-9",
      "name": "جديد",
      "slug": "jdyd",
      "ref_type": "new",
      "short_description": "اصناف جديدة",
      "description": "اصناف جديدة",
      "meta_title": "جديد",
      "meta_description": null,
      "keywords": null,
      "tags_type_id": "*",
      "target_type": "*",
      "target_id": "*",
      "companys_id": "2",
      "departments_id": "2",
      "is_public": null,
      "is_default": 1,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "image": null,
      "images": []
    },
    {
      "id": 10,
      "code": "2-2-10",
      "name": "Top",
      "slug": "top",
      "ref_type": "top",
      "short_description": "Top Products",
      "description": "<p>Top Products<\/p>",
      "meta_title": "Top",
      "meta_description": "",
      "keywords": "",
      "tags_type_id": "*",
      "target_type": "*",
      "target_id": "*",
      "companys_id": "2",
      "departments_id": "2",
      "is_public": null,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "image": null,
      "images": []
    },
    {
      "id": 11,
      "code": "2-2-11",
      "name": "اصناف مميزه",
      "slug": "asnaf-mmyzh",
      "ref_type": "effective",
      "short_description": "اضناف مميزه",
      "description": "<p>اضناف مميزه<\/p>",
      "meta_title": "اصناف مميزه",
      "meta_description": "",
      "keywords": "",
      "tags_type_id": "*",
      "target_type": "*",
      "target_id": "*",
      "companys_id": "2",
      "departments_id": "2",
      "is_public": null,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "image": null,
      "images": []
    },
    {
      "id": 12,
      "code": "2-2-12",
      "name": "العروض",
      "slug": "alaarod",
      "ref_type": "offer",
      "short_description": "الاصناف التى عليها عروض",
      "description": "<p>الاصناف التى عليها عروض<\/p>",
      "meta_title": "العروض",
      "meta_description": "",
      "keywords": "",
      "tags_type_id": "*",
      "target_type": "*",
      "target_id": "*",
      "companys_id": "2",
      "departments_id": "2",
      "is_public": null,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "image": null,
      "images": []
    },
    {
      "id": 13,
      "code": "2-2-13",
      "name": "أعلى تقييم",
      "slug": "aaal-tkyym",
      "ref_type": "reviews",
      "short_description": "الأعلى تقييم",
      "description": "<p>الأعلى تقييم<\/p>",
      "meta_title": "أعلى تقييم",
      "meta_description": "",
      "keywords": "",
      "tags_type_id": "*",
      "target_type": "*",
      "target_id": "*",
      "companys_id": "2",
      "departments_id": "2",
      "is_public": null,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "image": null,
      "images": []
    },
    {
      "id": 14,
      "code": "2-2-14",
      "name": "الاكثر مبيعاً",
      "slug": "alakthr-mbyaaa",
      "ref_type": "sellers",
      "short_description": "الاصناف الاكثر مبيعاً",
      "description": "<p>الاصناف الاكثر مبيعاً<\/p>",
      "meta_title": "الاكثر مبيعاً",
      "meta_description": "",
      "keywords": "",
      "tags_type_id": "*",
      "target_type": "*",
      "target_id": "*",
      "companys_id": "2",
      "departments_id": "2",
      "is_public": null,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "image": null,
      "images": []
    }
  ],
  "meta": {
    "pagination": {
      "total": 6,
      "count": 6,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```


### List menus

Returns a list of menus you’ve previously created.

```
GET /api/v1/shop/menus
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |


### Example 1 get List Menus 

GET http://localhost:8006/api/v1/shop/menus/9

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 9,
      "code": "2-2-9",
      "name": "جديد",
      "slug": "jdyd",
      "ref_type": "new",
      "short_description": "اصناف جديدة",
      "description": "اصناف جديدة",
      "meta_title": "جديد",
      "meta_description": null,
      "keywords": null,
      "tags_type_id": "*",
      "target_type": "*",
      "target_id": "*",
      "companys_id": "2",
      "departments_id": "2",
      "is_public": null,
      "is_default": 1,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "created_at": "2023-08-07 21:10:27",
      "updated_at": "2023-08-07 21:10:27",
      "image": null,
      "images": []
    },
    {
      "id": 10,
      "code": "2-2-10",
      "name": "Top",
      "slug": "top",
      "ref_type": "top",
      "short_description": "Top Products",
      "description": "<p>Top Products<\/p>",
      "meta_title": "Top",
      "meta_description": "",
      "keywords": "",
      "tags_type_id": "*",
      "target_type": "*",
      "target_id": "*",
      "companys_id": "2",
      "departments_id": "2",
      "is_public": null,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "created_at": "2023-08-07 21:10:27",
      "updated_at": "2023-08-07 22:05:47",
      "image": null,
      "images": []
    },
    {
      "id": 11,
      "code": "2-2-11",
      "name": "اصناف مميزه",
      "slug": "asnaf-mmyzh",
      "ref_type": "effective",
      "short_description": "اضناف مميزه",
      "description": "<p>اضناف مميزه<\/p>",
      "meta_title": "اصناف مميزه",
      "meta_description": "",
      "keywords": "",
      "tags_type_id": "*",
      "target_type": "*",
      "target_id": "*",
      "companys_id": "2",
      "departments_id": "2",
      "is_public": null,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "created_at": "2023-08-07 21:10:27",
      "updated_at": "2023-08-07 22:06:01",
      "image": null,
      "images": []
    },
    {
      "id": 12,
      "code": "2-2-12",
      "name": "العروض",
      "slug": "alaarod",
      "ref_type": "offer",
      "short_description": "الاصناف التى عليها عروض",
      "description": "<p>الاصناف التى عليها عروض<\/p>",
      "meta_title": "العروض",
      "meta_description": "",
      "keywords": "",
      "tags_type_id": "*",
      "target_type": "*",
      "target_id": "*",
      "companys_id": "2",
      "departments_id": "2",
      "is_public": null,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "created_at": "2023-08-07 21:10:27",
      "updated_at": "2023-08-07 22:06:15",
      "image": null,
      "images": []
    },
    {
      "id": 13,
      "code": "2-2-13",
      "name": "أعلى تقييم",
      "slug": "aaal-tkyym",
      "ref_type": "reviews",
      "short_description": "الأعلى تقييم",
      "description": "<p>الأعلى تقييم<\/p>",
      "meta_title": "أعلى تقييم",
      "meta_description": "",
      "keywords": "",
      "tags_type_id": "*",
      "target_type": "*",
      "target_id": "*",
      "companys_id": "2",
      "departments_id": "2",
      "is_public": null,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "created_at": "2023-08-07 21:10:27",
      "updated_at": "2023-08-07 22:06:27",
      "image": null,
      "images": []
    },
    {
      "id": 14,
      "code": "2-2-14",
      "name": "الاكثر مبيعاً",
      "slug": "alakthr-mbyaaa",
      "ref_type": "sellers",
      "short_description": "الاصناف الاكثر مبيعاً",
      "description": "<p>الاصناف الاكثر مبيعاً<\/p>",
      "meta_title": "الاكثر مبيعاً",
      "meta_description": "",
      "keywords": "",
      "tags_type_id": "*",
      "target_type": "*",
      "target_id": "*",
      "companys_id": "2",
      "departments_id": "2",
      "is_public": null,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "created_at": "2023-08-07 21:10:27",
      "updated_at": "2023-08-07 22:06:37",
      "image": null,
      "images": []
    }
  ],
  "meta": {
    "pagination": {
      "total": 6,
      "count": 6,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Show Data Record Menus 

```
GET /api/v1/shop/menus/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record Menus 9

```
GET http://localhost:8006/api/v1/shop/menus/9
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "id": 9,
  "code": "2-2-9",
  "name": "جديد",
  "slug": "jdyd",
  "ref_type": "new",
  "short_description": "اصناف جديدة",
  "description": "اصناف جديدة",
  "meta_title": "جديد",
  "meta_description": null,
  "keywords": null,
  "tags_type_id": "*",
  "target_type": "*",
  "target_id": "*",
  "companys_id": "2",
  "departments_id": "2",
  "is_public": null,
  "is_default": 1,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "properties": null,
  "created_at": "2023-08-07 21:10:27",
  "updated_at": "2023-08-07 21:10:27",
  "image": null,
  "images": []
}
```

#### Example 3 Show Data Record Menus 9

**لجلب القائمه او القوائم مع الاصنافه او المنتجات التابعه لها نقوم بتضمين العلاقه products**

```
GET https://localhost:8006/api/v1/shop/menus/9?include=products&isPublished=1
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "id": 9,
  "code": "2-2-9",
  "name": "جديد",
  "slug": "jdyd",
  "ref_type": "new",
  "short_description": "اصناف جديدة",
  "description": "اصناف جديدة",
  "meta_title": "جديد",
  "meta_description": null,
  "keywords": null,
  "tags_type_id": "*",
  "target_type": "*",
  "target_id": "*",
  "companys_id": "2",
  "departments_id": "2",
  "is_allow_add": 1,
  "is_public": 1,
  "is_default": 1,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "properties": null,
  "created_at": "2023-08-07 21:10:27",
  "updated_at": "2023-08-07 21:10:27",
  "image": null,
  "images": [],
  "products": {
    "data": [
      {
        "id": 1417,
        "code": "2-2-1417",
        "barcode": "0-1417",
        "name": "معصوب",
        "emblem": "",
        "short_description": "",
        "description": "",
        "users_manual": "",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "3",
        "is_offer": 0,
        "groups_products_id": "0",
        "companys_id": "2",
        "departments_id": "2",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "",
        "unpublished_at": "",
        "manage_stock": 1,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 100,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 100,
        "default_qty": 1,
        "old_price": 0,
        "price": 1500,
        "is_show_old_price": 0,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 1,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1417,
        "created_at": "2022-11-09 15:34:56",
        "updated_at": "2023-08-09 14:01:46",
        "image": {
          "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bc8\/874\/636bc8874aa80274472786.jpg",
          "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bc8\/874\/thumb_1370_160_160_0_0_crop.jpg",
          "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bc8\/874\/thumb_1370_240_240_0_0_crop.jpg",
          "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bc8\/874\/thumb_1370_800_800_0_0_crop.jpg",
          "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bc8\/874\/thumb_1370_480_480_0_0_auto.jpg"
        },
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      },
      {
        "id": 1423,
        "code": "2-2-1423",
        "barcode": "0-1423",
        "name": "فتة سادة مع قشطة مع العسل",
        "emblem": "",
        "short_description": "",
        "description": "",
        "users_manual": "",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "3",
        "is_offer": 0,
        "groups_products_id": "0",
        "companys_id": "2",
        "departments_id": "2",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "",
        "unpublished_at": "",
        "manage_stock": 1,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 100,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 100,
        "default_qty": 1,
        "old_price": 0,
        "price": 1500,
        "is_show_old_price": 0,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 1,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1423,
        "created_at": "2022-11-09 15:45:44",
        "updated_at": "2023-08-09 14:00:44",
        "image": {
          "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcb\/120\/636bcb120c691781143614.jpg",
          "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcb\/120\/thumb_1376_160_160_0_0_crop.jpg",
          "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcb\/120\/thumb_1376_240_240_0_0_crop.jpg",
          "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcb\/120\/thumb_1376_800_800_0_0_crop.jpg",
          "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcb\/120\/thumb_1376_480_480_0_0_auto.jpg"
        },
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      },
      {
        "id": 1430,
        "code": "2-2-1430",
        "barcode": "0-1430",
        "name": "شاهي",
        "emblem": "",
        "short_description": "",
        "description": "",
        "users_manual": "",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "3",
        "is_offer": 0,
        "groups_products_id": "0",
        "companys_id": "2",
        "departments_id": "2",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "",
        "unpublished_at": "",
        "manage_stock": 1,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 100,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 100,
        "default_qty": 1,
        "old_price": 0,
        "price": 50,
        "is_show_old_price": 0,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 1,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1430,
        "created_at": "2022-11-09 15:53:47",
        "updated_at": "2023-08-09 13:59:03",
        "image": {
          "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/636bccf4b203d617442273.jpg",
          "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_160_160_0_0_crop.jpg",
          "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_240_240_0_0_crop.jpg",
          "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_800_800_0_0_crop.jpg",
          "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_480_480_0_0_auto.jpg"
        },
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [
            {
              "id": 1431,
              "code": "2-2-1431",
              "barcode": "0-1431",
              "name": "شاهي احمر",
              "emblem": "شاهي",
              "short_description": "شاهي احمر",
              "description": "<p>شاهي احمر<\/p>",
              "users_manual": "دليل الاستخدام",
              "composition": "التركيبة",
              "indication": "الامور الاخري المتعلقة بالصنف",
              "meta_title": "شاهي",
              "meta_description": "وصف للبحث",
              "keywords": "كلمات مفتاحية",
              "ref_type_class": "products",
              "ref_key_values_class": "3",
              "is_offer": 0,
              "groups_products_id": "0",
              "companys_id": "2",
              "departments_id": "2",
              "is_effective": 1,
              "is_default": null,
              "is_active": 1,
              "is_published": 0,
              "published_at": "",
              "unpublished_at": "",
              "manage_stock": 1,
              "shop_stock": 1,
              "min_qty": 1,
              "max_qty": 100,
              "min_qty_in_stock": 1,
              "max_qty_in_stock": 100,
              "default_qty": 1,
              "old_price": 0,
              "price": 50,
              "is_show_old_price": 0,
              "is_parleying": 1,
              "is_sold": 1,
              "is_purchased": 1,
              "is_composite": 0,
              "is_units": 1,
              "is_downloadable": 1,
              "properties": [
                {
                  "title": "الاضافات",
                  "code": "extention",
                  "value": "10",
                  "is_default": "1",
                  "is_show": "1",
                  "sort_show": "1",
                  "_group": "properties"
                }
              ],
              "links": [
                {
                  "title": "url",
                  "url": "test.com",
                  "target": "_blank",
                  "sort_show": "1",
                  "is_download": "0",
                  "is_default": "1",
                  "is_show": "1",
                  "_group": "links"
                }
              ],
              "other_data": null,
              "config_data": null,
              "sort_order": 1431,
              "created_at": "2022-11-09 15:54:58",
              "updated_at": "2023-07-15 00:31:17",
              "image": {
                "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/636bcd2f87ee1059528054.jpg",
                "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_160_160_0_0_crop.jpg",
                "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_240_240_0_0_crop.jpg",
                "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_800_800_0_0_crop.jpg",
                "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_480_480_0_0_auto.jpg"
              },
              "images": [],
              "files": [],
              "ratings_count": 0,
              "countRating": 0,
              "sumRating": null,
              "averageRating": null,
              "user_is_rating": false,
              "user_object_rating": null,
              "favorites_count": 0,
              "user_is_favorite": false,
              "user_object_favorite": null,
              "object_type": "Nano\\Shop\\Models\\Product",
              "qty": 0,
              "children": {
                "data": [],
                "meta": {
                  "pagination": {
                    "total": 0,
                    "count": 0,
                    "per_page": 10,
                    "current_page": 1,
                    "total_pages": 1,
                    "links": []
                  }
                }
              },
              "prices_units": {
                "data": []
              }
            },
            {
              "id": 1432,
              "code": "2-2-1432",
              "barcode": "0-1432",
              "name": "شاهي حليب",
              "emblem": "",
              "short_description": "",
              "description": "",
              "users_manual": "",
              "composition": "",
              "indication": "",
              "meta_title": "",
              "meta_description": "",
              "keywords": "",
              "ref_type_class": "products",
              "ref_key_values_class": "3",
              "is_offer": 0,
              "groups_products_id": "0",
              "companys_id": "2",
              "departments_id": "2",
              "is_effective": 1,
              "is_default": null,
              "is_active": 1,
              "is_published": 0,
              "published_at": "",
              "unpublished_at": "",
              "manage_stock": 1,
              "shop_stock": 0,
              "min_qty": 1,
              "max_qty": 100,
              "min_qty_in_stock": 1,
              "max_qty_in_stock": 100,
              "default_qty": 1,
              "old_price": 0,
              "price": 100,
              "is_show_old_price": 0,
              "is_parleying": 1,
              "is_sold": 1,
              "is_purchased": 1,
              "is_composite": 0,
              "is_units": 1,
              "is_downloadable": 1,
              "properties": null,
              "links": null,
              "other_data": null,
              "config_data": null,
              "sort_order": 1432,
              "created_at": "2022-11-09 15:55:41",
              "updated_at": "2023-08-08 19:58:38",
              "image": {
                "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/6372c9c8b9cff519686397.jpg",
                "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_160_160_0_0_crop.jpg",
                "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_240_240_0_0_crop.jpg",
                "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_800_800_0_0_crop.jpg",
                "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_480_480_0_0_auto.jpg"
              },
              "images": [],
              "files": [],
              "ratings_count": 0,
              "countRating": 0,
              "sumRating": null,
              "averageRating": null,
              "user_is_rating": false,
              "user_object_rating": null,
              "favorites_count": 0,
              "user_is_favorite": false,
              "user_object_favorite": null,
              "object_type": "Nano\\Shop\\Models\\Product",
              "qty": 0,
              "children": {
                "data": [],
                "meta": {
                  "pagination": {
                    "total": 0,
                    "count": 0,
                    "per_page": 10,
                    "current_page": 1,
                    "total_pages": 1,
                    "links": []
                  }
                }
              },
              "prices_units": {
                "data": []
              }
            }
          ],
          "meta": {
            "pagination": {
              "total": 2,
              "count": 2,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      }
    ]
  }
}
```

### Check Last Update Menus Data

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/shop/menus/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/shop/menus/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2022-12-16 17:29:08",
    "other_updated": {
      "activity_cache.menu": "2022-12-16 17:29:08",
      "activity_cache.product": "2022-12-16 16:29:28",
      "activity_cache.department": "2022-12-16 16:29:28",
      "activity_cache.tag": "2022-12-16 17:27:15",
      "activity_cache.categorie": "2022-12-16 16:29:28"
    }
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2022-12-16 17:29:31",
    "last_updated": "2022-12-16 17:29:08",
    "other_updated": {
      "activity_cache.menu": "2022-12-16 17:29:08",
      "activity_cache.product": "2022-12-16 16:29:28",
      "activity_cache.department": "2022-12-16 16:29:28",
      "activity_cache.tag": "2022-12-16 17:27:15",
      "activity_cache.categorie": "2022-12-16 16:29:28"
    }
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **

