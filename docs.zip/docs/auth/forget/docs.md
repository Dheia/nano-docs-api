## auth/forget and auth/reset

Reset Password  User Accounts 

** استعاده كلمة السر الخاصه بالحساب **

**الخطوه الاولى هى ان نقوم بارسال كود استعاده كلمه المرور  عبر رسالة البريد الالكتروني او عبر رساله نصيه sms **

**الخطوة الثانيه التحقق من كود استعادة كلمة السر وتغيير كلمة المرور فى حالة كان الكود صحيح **


### Step 1 Forget User Password

**الخطوه الاولى هى ان نقوم بارسال كود استعاده كلمه المرور  عبر رسالة البريد الالكتروني او عبر رساله نصيه sms **


```
POST /auth/forgot
```
```
POST http://localhost:8006/api/v1/auth/forgot
```

#### Require Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `loginAttribute`           | `string`  |  login Attribute Name [username,email,mobile] deafult value in setting web  |
| `login`           | `string`  |  enter data login [username or email or mobile ] |
| `forgot_type`           | `string`  |  deafult value email  |

**forgot_type**
** يتم تمرير نوع ارسال كود استعاده كلمه المرور ضمن المتغير السابق علما ان القيمه الافتراضيه هي عبر الايميل **

#### Example 1 Forget User Password Send To Email 

**فى المثال التالي سنقوم بطلب كود استعاده كلمة السر عبر البريد الالكتروني بتمرير البريد الالكتروني للمستخدم **


**البراميترات الممرره فى الطلب كالتالي **

```json
{
  "loginAttribute": "email",
  "forgot_type": "email",
  "login": "kddd9033@gmail.com",
  }
```

```
 POST http://localhost:8006/api/v1/auth/forgot
```

##### Response

```html
Status: 200 OK
```

```json
{
  "code": 200,
  "http_code": 200,
  "status": true,
  "message": "We already email you password reset instructions, if you don't receive the email, try again and make sure your email address already registered.",
  "input_data": {
    "loginAttribute": "email",
    "forgot_type": "email",
    "login": "kddd9033@gmail.com"
  }
}
```

**فى حالة حدوث خطاء سيتم ارجاع البيانات التاليه **

```json
{
  "code": "WRONG_ARGS",
  "http_code": 400,
  "status": false,
  "message": "حدث خطاء اثناء عمليه ارسال كود استعادة الحساب ",
  "error": "Connection could not be established with host smtp.hostinger.ae :stream_socket_client(): php_network_getaddresses: gethostbyname failed. errno=2",
  "error_message": "Connection could not be established with host smtp.hostinger.ae :stream_socket_client(): php_network_getaddresses: gethostbyname failed. errno=2",
  "input_data": {
    "loginAttribute": "email",
    "forgot_type": "email",
    "login": "kddd9033@gmail.com"
  }
}
```
#### Example 2 Forget User Password Send  To Sms

**فى المثال التالي سنقوم بطلب كود استعاده كلمة السر عبر رسالة نصية بتمرير البريد الالكتروني للمستخدم **


**البراميترات الممرره فى الطلب كالتالي **

```json
{
  "loginAttribute": "email",
  "forgot_type": "sms",
  "login": "kddd9033@gmail.com",
  }
```

```
 POST http://localhost:8006/api/v1/auth/forgot
```

##### Response

```html
Status: 200 OK
```

```json
{
  "code": 200,
  "http_code": 200,
  "status": true,
  "message": "ستصلك رساله نصيه بكود استعاده الحساب , اذا لم تصلك الرساله اعد المحوله ",
  "input_data": {
    "loginAttribute": "email",
    "forgot_type": "sms",
    "login": "kddd9033@gmail.com"
  }
}
```

**فى حالة حدوث خطاء سيتم ارجاع البيانات التاليه**

```json
{
  "code": "WRONG_ARGS",
  "http_code": 400,
  "status": false,
  "message": "حدث خطاء اثناء عمليه ارسال كود استعادة الحساب ",
  "error": "البريد الالكتروني غير صحيح ",
  "error_message": "البريد الالكتروني غير صحيح ",
  "input_data": {
    "loginAttribute": "email",
    "forgot_type": "sms",
    "login": "kddd9033@gmail.com45"
  }
}
```
#### Example 3 Forget User Password Send  To Sms

**فى المثال التالي سنقوم بطلب كود استعاده كلمة السر عبر رسالة نصية بتمرير رقم الهاتف للمستخدم **


**البراميترات الممرره فى الطلب كالتالي **

```json
{
  "loginAttribute": "mobile",
  "forgot_type": "sms",
  "login": "+967770529482",
  }
```

```
 POST http://localhost:8006/api/v1/auth/forgot
```

##### Response

```html
Status: 200 OK
```

```json
{
  "code": 200,
  "http_code": 200,
  "status": true,
  "message": "ستصلك رساله نصيه بكود استعاده الحساب , اذا لم تصلك الرساله اعد المحوله ",
  "input_data": {
    "loginAttribute": "email",
    "forgot_type": "sms",
    "login": "+967770529482"
  }
}
```
### Step 2 Reset User Password


**الخطوة الثانيه التحقق من كود استعادة كلمة السر وتغيير كلمة المرور فى حالة كان الكود صحيح **

```
POST /auth/reset
```
```
POST http://localhost:8006/api/v1/auth/reset
```

#### Require Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `loginAttribute`           | `string`  |  login Attribute Name [username,email,mobile] deafult value in setting web  |
| `login`           | `string`  |  enter data login [username or email or mobile ] |
| `forgot_type`           | `string`  |  deafult value email  |
| `code`           | `string`  |  code  |
| `password`           | `string`  |  new password  |

**forgot_type**
** يتم تمرير نوع التحقق من  كود استعاده كلمه المرور ضمن المتغير السابق علما ان القيمه الافتراضيه هي عبر الايميل **


#### Example 4 Check code and change Password using User Email

**فى المثال التالي سنقوم بالتحقق من صحه كود استعاده الحساب ومن ثم تغيير كلمه المرور  **


**فى حالة اردنا التحقق من صحة الكود الخاص باستعاده الحساب سنقوم بتمرير البيانات التاليه **

```json
{
    "loginAttribute": "email",
    "forgot_type": "sms",
    "login": "kddd9033@gmail.com",
    "code": "EiFiX"
}
```

```
 POST http://localhost:8006/api/v1/auth/reset
```

##### Response

```html
Status: 200 OK
```

```json
{
  "code": 200,
  "http_code": 200,
  "message": "تم التحقق من الكود",
  "check_code": true,
  "change_password": false,
  "input_data": {
    "loginAttribute": "email",
    "forgot_type": "sms",
    "login": "kddd9033@gmail.com",
    "code": "EiFiX"
  }
}
```

**بعد انا تاكدنا من صحة الكود سنقوم بتغيير كلمة المرور كا التالي **

**البيانات الممررة كا التالي **

```json
{
    "loginAttribute": "email",
    "forgot_type": "sms",
    "login": "kddd9033@gmail.com",
    "code": "EiFiX",
    "password": "1234567Dd",
}
```

```
 POST http://localhost:8006/api/v1/auth/reset
```

##### Response

```html
Status: 200 OK
```

```json
{
  "code": 200,
  "http_code": 200,
  "message": "Account password has been changed successfully.",
  "check_code": true,
  "change_password": true,
  "data_token": {
    "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNzYxYWY4ZWZkOTRmZTViZDQyNjJlMjVmN2QyNzk4YjgyZWRkYzhiZmQxODE3ZTFlNGNiZmY1YWE1MGJmNWU1YTQ4NDczYmE2MTA1MTE5MTYiLCJpYXQiOjE2NzI5Mzc2OTkuNzIzMDY2MSwibmJmIjoxNjcyOTM3Njk5LjcyMzExLCJleHAiOjE3MDQ0NzM2OTkuNzAwMzk3LCJzdWIiOiI1NDMiLCJzY29wZXMiOltdfQ.ETDOL4CZUPrbkpp1uLMHQoRiEepXQmZa7SL7qGl7m-AXG8ING_-e69QGZIp9XXgM5yZ3I9z0OjUhB5ATDSKOqRRpdobX1RLnXAnERK6xe1Qi5rXdXeKGxpJ2mKJ1bKrNcRzyahW7be1UiiRl9YcoUO1boEmmOj4VwtdAF9DJ9N3f-P6VmA0q65KFV837uk4GsA7GYRrhsZ8AfTOdUGFaypzqccb454f8wr4yCnomF2f50Hbc7Pi428mZLq4X7ClX0FVTyOWoTMDQDm7_NsEnkCtTuhNZNc2hfn1elloE38uldsZuwLffuhRi-t5leGhK8BBflM8kKsfpugdqKJaKQyYsgQzIBSZh-V1uDuhjqE0yvA3fPa8Bm5CkKRX1JwSsHhWzhn3L_BGAzSoyL3aZU9d-h8DNQ-1oQszJc70l3GlJll23p8MmQZUxBgn3Wymdl_gPS2at-iN-FAOkQ5jUV9s5VS4uQW7_tTyVaZTK1o-Cfu4DaXLJiof9vOlne8UbsyvhTGcKbPef3ZXxYMKJbPEQuMxyvumrDMauQ78SJgHaUvqd5izXYzncHyAw56eubrdk_y6u8kI-D_5ANWz6LL0T-6LxJIFwvZZ1_dwl9vbcElo2GebHDUQo7vsuc31Q2ZtEnQb_6ONd0T-fnZG7MAZmQySZDgxPs1lPQr2a7UQ",
    "token_type": "Bearer",
    "expires_at": "2024-01-05T16:54:59.000000Z",
    "revoked": false,
    "user_id": 543,
    "persist_code": "$2y$10$rh5sWCwQm9CpPGwLdUZ57ONciKKarteannG67ZLRyfn7pYHvfGzc6"
  },
  "input_data": {
    "loginAttribute": "email",
    "forgot_type": "sms",
    "login": "kddd9033@gmail.com",
    "code": "EiFiX",
    "password": "1234567Dd"
  }
}
```


**من خلال المثال السابق نلاحظ ان عمليه استعاده الحساب لا تكتمل الا بعد التحقق من الكود وتغيير كلمه المرور **

#### Example 5 Check code and change Password using User Email 

**فى المثال التالي سنقوم بالتحقق من صحة كود  استعادة الحساب وتغيير كلمة المرور   **


**البراميترات الممرره فى الطلب كالتالي **

```json
{
  "loginAttribute": "email",
  "forgot_type": "email",
  "login": "kddd9033@gmail.com",
  "code": "cmWpq",
  "password": "1234567Dd"
}
```

```
 POST http://localhost:8006/api/v1/auth/reset
```

##### Response

```html
Status: 200 OK
```

```json
{
  "code": 200,
  "http_code": 200,
  "message": "Account password has been changed successfully.",
  "check_code": true,
  "change_password": true,
  "data_token": {
    "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNzYxYWY4ZWZkOTRmZTViZDQyNjJlMjVmN2QyNzk4YjgyZWRkYzhiZmQxODE3ZTFlNGNiZmY1YWE1MGJmNWU1YTQ4NDczYmE2MTA1MTE5MTYiLCJpYXQiOjE2NzI5Mzc2OTkuNzIzMDY2MSwibmJmIjoxNjcyOTM3Njk5LjcyMzExLCJleHAiOjE3MDQ0NzM2OTkuNzAwMzk3LCJzdWIiOiI1NDMiLCJzY29wZXMiOltdfQ.ETDOL4CZUPrbkpp1uLMHQoRiEepXQmZa7SL7qGl7m-AXG8ING_-e69QGZIp9XXgM5yZ3I9z0OjUhB5ATDSKOqRRpdobX1RLnXAnERK6xe1Qi5rXdXeKGxpJ2mKJ1bKrNcRzyahW7be1UiiRl9YcoUO1boEmmOj4VwtdAF9DJ9N3f-P6VmA0q65KFV837uk4GsA7GYRrhsZ8AfTOdUGFaypzqccb454f8wr4yCnomF2f50Hbc7Pi428mZLq4X7ClX0FVTyOWoTMDQDm7_NsEnkCtTuhNZNc2hfn1elloE38uldsZuwLffuhRi-t5leGhK8BBflM8kKsfpugdqKJaKQyYsgQzIBSZh-V1uDuhjqE0yvA3fPa8Bm5CkKRX1JwSsHhWzhn3L_BGAzSoyL3aZU9d-h8DNQ-1oQszJc70l3GlJll23p8MmQZUxBgn3Wymdl_gPS2at-iN-FAOkQ5jUV9s5VS4uQW7_tTyVaZTK1o-Cfu4DaXLJiof9vOlne8UbsyvhTGcKbPef3ZXxYMKJbPEQuMxyvumrDMauQ78SJgHaUvqd5izXYzncHyAw56eubrdk_y6u8kI-D_5ANWz6LL0T-6LxJIFwvZZ1_dwl9vbcElo2GebHDUQo7vsuc31Q2ZtEnQb_6ONd0T-fnZG7MAZmQySZDgxPs1lPQr2a7UQ",
    "token_type": "Bearer",
    "expires_at": "2024-01-05T16:54:59.000000Z",
    "revoked": false,
    "user_id": 543,
    "persist_code": "$2y$10$rh5sWCwQm9CpPGwLdUZ57ONciKKarteannG67ZLRyfn7pYHvfGzc6"
  },
  "input_data": {
    "loginAttribute": "email",
    "forgot_type": "sms",
    "login": "kddd9033@gmail.com",
    "code": "cmWpq",
    "password": "1234567Dd"
  }
}
```

**فى حال حدوث خطاء **

```json
{
  "code": "WRONG_ARGS",
  "http_code": 400,
  "message": "حدث حظاء اثناء عملية استعاده الحساب ",
  "check_code": false,
  "change_password": false,
  "error": "الخاصية  password حقل مطلوب",
  "error_message": "الخاصية  password حقل مطلوب"
}
```

or

```json
{
  "code": 200,
  "http_code": 200,
  "message": "الكود غير صحيح ",
  "check_code": false,
  "change_password": false,
  "input_data": {
    "loginAttribute": "email",
    "forgot_type": "email",
    "login": "kddd9033@gmail.com",
    "code": "cmWpq"
  }
}
```


