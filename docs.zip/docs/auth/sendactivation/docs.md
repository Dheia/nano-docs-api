## auth/sendactivation 

Send Code Activation  User Accounts 

** ارسال كود تنشيط الحساب   **

**الخطوه الاولى هى ان نقوم بارسال كود تنشيط الحساب  عبر رسالة البريد الالكتروني او عبر رساله نصيه sms **

**الخطوة الثانيه التحقق من كود تنشيط الحساب وتنشيط الحساب  **


### Step 1 Send Code Activation

**الخطوه الاولى هى ان نقوم بارسال كود اتنشيط الحساب عبر رسالة البريد الالكتروني او عبر رساله نصيه sms **


```
POST /auth/sendactivation
```
```
POST http://localhost:8006/api/v1/auth/sendactivation
```

#### Require Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `loginAttribute`           | `string`  |  login Attribute Name [username,email,mobile] deafult value in setting web  |
| `login`           | `string`  |  enter data login [username or email or mobile ] |
| `activate_type`           | `string`  |  deafult value email [email or sms] |

**activate_type**
** يتم تمرير نوع ارسال كود تنشيط الحساب عبر المتغير السابق علما ان القيمه الافتراضيه هي عبر الايميل **


#### Example 1 Send Code Activation To Email 

**فى المثال التالي سنقوم بطلب كود تنشيط الحساب من خلال البريد الالكتروني بتمرير البريد الالكتروني للمستخدم **


**البراميترات الممرره فى الطلب كالتالي **

```json
{
  "loginAttribute": "email",
  "activate_type": "email",
  "login": "kddd9033@gmail.com",
  }
```

```
 POST http://localhost:8006/api/v1/auth/sendactivation
```

**فى هذه الحاله سيتم ارسال كود تنشيط الحساب برساله الى البريد الالكتروني **

##### Response

```html
Status: 200 OK
```

**فى حالة كان الحساب نشط سيتم ارجاع البيانات التاليه**

```json
{
  "code": 200,
  "http_code": 200,
  "status": true,
  "message": "الحساب نشط ولايحتاج الى تنشيط",
  "input_data": {
    "loginAttribute": "email",
    "activate_type": "email",
    "login": "kddd9033@gmail.com"
  }
}
```

**فى حاله نجاح ارسال الكود عبر البريد سيتم ارجاع البيانات التاليه **

```json
{
  "code": 200,
  "http_code": 200,
  "status": true,
  "message": "سيتم ارسال كود التحقق الى البريد الالكتروني الخاص بك ",
  "input_data": {
    "loginAttribute": "email",
    "activate_type": "email",
    "login": "kddd9033@gmail.com"
  }
}
```

**فى حالة حدوث خطاء سيتم ارجاع البيانات التاليه **

```json
{
  "code": "WRONG_ARGS",
  "http_code": 400,
  "status": false,
  "message": "حدث خطاء اثناء عمليه ارسال كود تنشيط الحساب ",
  "error": "Unable to contact the mail server API",
  "error_message": "Unable to contact the mail server API",
  "input_data": {
    "loginAttribute": "email",
    "activate_type": "email",
    "login": "kddd9033@gmail.com"
  }
}
```

#### Example 2 Send Code Activation To Sms

**فى المثال التالي سنقوم بطلب  كود تنشيط الحساب عبر رساله نصية بتمرير البريد الالكتروني للمستخدم **


**البراميترات الممرره فى الطلب كالتالي **

```json
{
  "loginAttribute": "email",
  "activate_type": "sms",
  "login": "kddd9033@gmail.com",
  }
```

```
 POST http://localhost:8006/api/v1/auth/sendactivation
```

##### Response

```html
Status: 200 OK
```

**فى حالة عدم وجود رقم هاتف للمستخدم **

```json
{
  "code": 200,
  "http_code": 200,
  "status": false,
  "message": "رقم الهاتف غير موجود ",
  "input_data": {
    "loginAttribute": "email",
    "activate_type": "sms",
    "login": "kddd9033@gmail.com"
  }
}
```

**فى حالة نجاح ارسال كود التنشيط سيتم ارجاع البيانات التاليه**
```json
{
  "code": 200,
  "http_code": 200,
  "status": true,
  "message": "سيتم ارسال كود تنشيط الحساب الى رقم هاتفك ",
  "input_data": {
    "loginAttribute": "email",
    "activate_type": "sms",
    "login": "kddd9033@gmail.com"
  }
}
```

**فى حالة حدوث خطاء سيتم ارجاع البيانات التاليه**

```json
{
  "code": "WRONG_ARGS",
  "http_code": 400,
  "status": false,
  "message": "حدث خطاء اثناء عمليه ارسال كود تنشيط الحساب ",
  "error": "البريد الالكتروني غير صحيح ",
  "error_message": "البريد الالكتروني غير صحيح ",
  "input_data": {
    "loginAttribute": "email",
    "activate_type": "sms",
    "login": "kddd9033@gmail.com45"
  }
}
```

### Step 2 Activation User Accounts 


**الخطوة الثانيه التحقق من كود تنشيط الحساب وتنشيط الحساب فى حالة كان الكود صحيح **

```
POST /auth/activation/{user_id}/{activationCode}
```
```
POST http://localhost:8006/api/v1/auth/activation/{user_id}/{activationCode}
```

**
تنشيط حساب المستخدم نستخدم رابط التنشيط متبوعا برقم المستخدم وكود التنشيط 
  **

#### Example 3 User Activation

```
 POST http://localhost:8006/api/v1/auth/activation/547/PsNbT
```

**
عند نجاح الطلب يتم ارجاع بيانات الدخول الخاصه بالمستخدم كالتالي 
**

```json
{
  "data": {
    "code": "200",
    "message": "Login Success Full.",
    "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNTRmMzM1N2EyMDJiNmQ0ZDYwNTY4ZDg2NDZjNDFjMzZmNDBiN2QwNzdmYmJlMWQ0MWNlYzcyMjkyN2NjZjc2NDg0ODk4N2ViMDc5M2EwYTYiLCJpYXQiOjE2NjUzMjg0ODAuMTU3MjAxMSwibmJmIjoxNjY1MzI4NDgwLjE1NzI0MTEsImV4cCI6MTY5Njg2NDQ4MC4xMjMxMDI5LCJzdWIiOiI1NDciLCJzY29wZXMiOltdfQ.ACLlxlc2mUTDM9z_hfaN0suAZKWRa2mur-UAC7MdewPTwcY348U7FNZEZxGIOkwjiOT2Cef7x12DI8ZIRkDwxo0lA50IZRTJjsuXZOBXncJcUL8jXllld_tjnLOiGwUPfVp4e3Pull4xLW4cO9q8p1U8pLGo6DwpH6dLoW2U8a1a0bY-e71x28QRa651x87vxPvJ3nphtTiQtJfJiEIQEFK0E90j4NOU0xFOkeTbQyOu99Q506WIStMsbRDmDWYbBOddXQD--QBFhLFd2Fo-AxRl_feANcUJdm0K7kPY_Ks0g2mnbxnBcjKPQYrkEXrRgDcq6JzU-P6OZZi1PcyEjYH2pciYS7iJ5S2wFHcWSBb_RdpH1BjfvsiDU8vLfjVPuO8f-KhHNNNZ9Qj689Z7K3O0G6bUbr3hhDz2yWVVesdMvDO4UWifZSELrDvIknfxUR6k8Xqc9gbwOAo85PR9BJDU8DW6-x_v74vzQx0jkX1eLw_m2-3ahn_SIiPHYKSRdOEJdmsS5iPAvHYOsVURSBL2m6rdS_RIhLLIcu_vN00DYwmrMedtG81hGYSE57h6_iMcLI51CW2w5d_qYzpj0w_drj5CUe4w1kBohcVJ7tZDDk7S16PKozHfm1nzt_pVOKZxkmcmrKPRYtxnH1vmxEgnY6PzpO96uAeUH9JbKtQ",
    "token_type": "Bearer",
    "expires_at": "2023-10-09T15:14:40.000000Z",
    "revoked": false,
    "user_id": 547,
    "persist_code": "$2y$10$5WICP9MJNPM0yxs\/wINLEOu623OnRjcOtvZ3lRl255EvRgwIzv44m"
  }
}
```

**
وفى حال وجود خطاء مثلا كود تنشيط الحساب غير صحيح 
يتم ارجاع رساله بالخطا ورقم الخطاء
**

```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "ValidationException constructor requires instance of Validator or array"
  }
}
```
