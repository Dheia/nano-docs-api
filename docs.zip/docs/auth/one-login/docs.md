## auth/one-login

This endpoint allows you to `one-login user`.

/auth/one-login

**يختص هذا الجزء بتسجيل الدخول  او انشاء حساب عبر رقم الجوال فقط لكافة  انواع المستخدمين frontend  or backend**


### The Login object

#### Require Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `provider`           | `string`  |  provider [frontend,backend] deafult value frontend  |
| `loginAttribute`           | `string`  |  login Attribute Name [username,email,mobile] deafult value in setting web  |
| `login`           | `string`  |  enter data login  |
| `code or token`           | `string`  |  enter code or token  |
| `profile`           | `boolean`  |  get profile deafult value false   |


**provider يمثل هذا البراميتر نوع المستخدم فىنت اند او باك اند والقيمة الافتراضيه هي frontend**


**profile يستخدم هذا البراميتر فى حالة الرغبه بارجاع ملف المستخدم معا التوكن عند تسجيل الدخول **

**loginAttribute من خلال هذا المتغير يمكن تحديد طريقة تسجيل الدخول هل  عنطريق الاسم او البريد او الجوال **

**login من خلال هذا المتغير يتم ارسال بيانات الدخول الاسم او البريد او الجوال حسب طريقة التسجيل **

**code or token**
**من الضروري تمرير احد المتغيرات السابقة بقيمة رمز التحقق المرسل لرقم الشخص **

#### other  Parameters  

** يمكن استخدام هذه البراميترات عند عدم استخدام البراميتر  login **



| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `username`           | `string`  |  username |
| `email`           | `string`  |  email |
| `mobile`           | `string`  |  mobile number  |


**فى حالة ان المستخدم يسجل لاول مره يمكن تمرير بيانات تسجيل الدخول الاخري اذا اردت فى حال عدم تمريرها فان النظام سياخذ قيم افتراضيه **

### Send Code Login

**للتحقق من المستخدم  عبر جواله  نقوم بارسال كود عبر رساله نصيه sms **


```
POST /auth/otp/send
```
```
POST http://localhost:8006/api/v1/auth/otp/send
```

#### Require Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `field_name`           | `string`  | deafult value null  |
| `mobile`           | `string`  |  mobile deafult value current user mobile  |
| `provider`           | `string`  |  provider [frontend or backend user] deafult value frontend|
| `is_update_user`           | `bool`  |  option deafult value true |
| `user_id`           | `string`  |  option deafult value null |

**mobile**
** يتم تمرير رقم الهاتف المراد التحقق منه  **

**field_name**
**يجب تمرير المتغير السابق بالقيمة check_login**

#### Example 1.0 Send Code Login user To mobile 

**فى المثال التالي سنقوم بارسال كود التحقق من رقم جوال المستخدم  **


**البراميترات الممرره فى الطلب كالتالي **

```json
{
  "provider": "frontend",
  "mobile": "00967529482",
  "field_name": "check_login",
  }
```

```
 POST http://localhost:8006/api/v1/auth/otp/send
```
```
 POST http://localhost:8006/api/v1/auth/otp/send?mobile=00967770529498&provider=frontend&field_name=check_login&code=958831
```

**فى هذه الحاله سيتم ارسال كود تنشيط الحساب برساله الى  **

##### Response

```html
Status: 200 OK
```

**فى حاله نجاح ارسال الكود يتم ارجاع البيانات التاليه **

```json
{
  "code": 200,
  "status": true,
  "message": "تم ارسال كود التحقق بنجاح",
  "error": null,
  "errors": null,
  "input_data": [],
  "process_data": []
}
```

**فى حالة حدوث خطاء سيتم ارجاع البيانات التاليه **

```json
{
  "code": 0,
  "status": false,
  "message": "فشلة العملية",
  "error": "لايمكن ارسال الكود انتظر انقضاء المهله",
  "errors": null,
  "input_data": [],
  "process_data": [],
  "debug": {
    "line": 427,
    "file": "\/storage\/emulated\/0\/htdocs\/october_demo\/plugins\/nano2\/verifycode\/classes\/Manager.php",
    "class": "October\\Rain\\Exception\\ApplicationException"
  }
}
```


```json
{
  "code": "WRONG_ARGS",
  "http_code": 400,
  "status": false,
  "message": "حدث خطاء اثناء عمليه ارسال كود تنشيط الحساب ",
  "error": "Unable to contact the mail server API",
  "error_message": "Unable to contact the mail server API",
  "input_data": {
    "loginAttribute": "email",
    "activate_type": "email",
    "login": "kddd9033@gmail.com"
  }
}
```

### Example 1.1 login frontend user

```
POST /api/v1/auth/one-login
```

تسجيل الدخول عن طريق رقم الهاتف 
```
http://localhost:8006/api/v1/auth/one-login?loginAttribute=mobile&mobile=00967770529444&field_name=check_login&token=456765
```

**البراميترات الممرره **

```json
{
  "provider": "frontend",
  "loginAttribute": "mobile",
  "mobile": "00967770529444",
  "field_name": "check_login",
  "token": 456765,
  }
```

**نلاحظ انه عند عدم تحديد نوع المستخدم  فان النظام سيتعامل مع البيانات على انها المستخدمم frontend**

#### Response

```html
Status: 200  
```

```json
{
  "code": 200,
  "status": true,
  "message": "تمت العملية بنجاح ",
  "error": null,
  "errors": null,
  "is_login": true,
  "is_register": false,
  "is_access_token": true,
  "is_profile": false,
  "id": 23,
  "name": "mobile",
  "token": "23|1ufjGoIcCKnbDd8ncf3HyrfZxsA6mZJVyZaTC1fVPWerAyB6MXmpkWUSkbcgHo2F8v3h9jRnw3DmrhSH",
  "token_type": "Bearer",
  "abilities": [
    "*"
  ],
  "created_at": "2023-12-25 17:44:20",
  "last_used_at": "2023-12-25 17:44:20",
  "expires_at": "2024-06-22 17:44:20",
  "is_expires": false,
  "expires_in": 260639,
  "user_id": 569,
  "user_type": "RainLab\\User\\Models\\User",
  "persist_code": "$2y$10$3HG8H5BQFEX6Di.0o8181OVSYgBj9ZkL4qwUkEmWJcaR.yWFZ4Xnq"
}
```

**فى حالة ان المستخدم لم يكن مسجل من قبل سيتم ارجاع البيانات التاليه **

**من خلال البيانات فى الاسفل نلاحظ ان المتغير is_register يحمل القيمة true للدلاله على ان المستخدم تم تسجيله الان **

```json
{
  "code": 200,
  "status": true,
  "message": "تمت العملية بنجاح ",
  "error": null,
  "errors": null,
  "is_login": true,
  "is_register": true,
  "is_access_token": true,
  "is_profile": false,
  "id": 24,
  "name": "mobile",
  "token": "24|F89zSqAhpHxDDwKPGDq4oS3zsFuBfa5df3j3jkr7oGebxiSG02lBoIuty664h9LSr6Wgz91P6tzjKF2r",
  "token_type": "Bearer",
  "abilities": [
      "*"
  ],
  "created_at": "2023-12-25 17:47:17",
  "last_used_at": "2023-12-25 17:47:17",
  "expires_at": "2024-06-22 17:47:17",
  "is_expires": false,
  "expires_in": 260639,
  "user_id": 570,
  "user_type": "RainLab\\User\\Models\\User",
  "persist_code": "$2y$10$0nLNtB8ShbRUF\/iT3hIiyeAfauyKjjMij1gQHk1Dllxase9q6eNCe"
}
```


### Example 1.2 login frontend user and return profile

**لارجاع ملف المستخدم مع  البيانات سنقوم بتمرير المتغير profile كالتالي **


```
POST http://localhost:8006/api/v1/auth/one-login?mobile=00967770529443&provider=frontend&field_name=check_login&code=324090&loginAttribute=mobile&profile=1
```

**البراميترات الممرره **

```json
{
  "provider": "frontend",
  "loginAttribute": "mobile",
  "mobile": "00967770529443",
  "field_name": "check_login",
  "code": 324090,
  "profile": 1,
  }
```

#### Response

```html
Status: 200  
```

```json
{
  "code": 200,
  "status": true,
  "message": "تمت العملية بنجاح ",
  "error": null,
  "errors": null,
  "is_login": true,
  "is_register": false,
  "is_access_token": true,
  "is_profile": true,
  "id": 26,
  "name": "mobile",
  "token": "26|Nh1uxIZZF95Xy3oNL4EsXzVmAVfWerW5yBcKVEdW4oilf1qbolOj1jQnwdh3SCD6udjW3s9DHcMFUNbt",
  "token_type": "Bearer",
  "abilities": [
    "*"
  ],
  "created_at": "2023-12-25 17:55:34",
  "last_used_at": "2023-12-25 17:55:34",
  "expires_at": "2024-06-22 17:55:34",
  "is_expires": false,
  "expires_in": 260639,
  "user_id": 570,
  "user_type": "RainLab\\User\\Models\\User",
  "persist_code": "$2y$10$0nLNtB8ShbRUF\/iT3hIiyeAfauyKjjMij1gQHk1Dllxase9q6eNCe",
  "profile": {
    "id": 570,
    "name": "00967770529443@gmail.com",
    "surname": "",
    "username": "00967770529443@gmail.com",
    "email": "00967770529443@gmail.com",
    "mobile": "00967770529443",
    "gender": "",
    "date_of_birth": "",
    "address_1": "",
    "address_2": "",
    "street_name": "",
    "street_number": "",
    "latitude": 0,
    "longitude": 0,
    "geo_components": [],
    "city": "",
    "zip": "",
    "postcode": "",
    "country_long": "",
    "country_id": "",
    "state_id": "",
    "directorate_id": "",
    "formataddress": "",
    "vicinity": "",
    "avatar": null,
    "companys_id": "2",
    "departments_id": "4",
    "employees_id": "",
    "ref_type": "user",
    "ref_id": "",
    "permissions": [],
    "is_guest": 0,
    "is_superuser": 0,
    "is_activated": 1,
    "activated_at": "2023-12-25 17:47:17",
    "last_login": "2023-12-25 17:55:34",
    "created_at": "2023-12-25 17:47:16",
    "updated_at": "2023-12-25 17:55:34",
    "deleted_at": "",
    "created_ip_address": "127.0.0.1",
    "last_ip_address": "127.0.0.1",
    "is_delivery": 0,
    "provider": "frontend",
    "orders_user_count": 0,
    "orders_user_complete_count": 0,
    "orders_user_cancelled_count": 0,
    "orders_user_delivery_count": 0,
    "orders_user_new_count": 0,
    "orders_delivery_count": 0,
    "orders_delivery_complete_count": 0,
    "orders_delivery_cancelled_count": 0,
    "orders_delivery_delivery_count": 0,
    "orders_delivery_new_count": 0,
    "ratings_count": 0,
    "countRating": 0,
    "sumRating": 0,
    "averageRating": 0,
    "user_is_rating": 0,
    "user_object_rating": null,
    "favorites_count": 0,
    "user_is_favorite": 0,
    "likes_count": 0,
    "bookmarks_count": 0,
    "reactions_count": 0,
    "object_type": "RainLab\\User\\Models\\User"
  }
}
```


## Useing token in login 

add Parameters Authorization in headr request 

Authorization = [token_type token]

** Require Authorization in Header Request**

```html
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiOTJiYjhkNWJjZjE4MWYxMjcyMjhlZjc5ODFmYzE5ZWFmOGY1ZjVjMWUxZjg5ZWEzMDVhMDNiMzMxZjM2OWUxYjMzZDA3NWFkM2FlMGE3YTMiLCJpYXQiOjE2NjU4NTUyODcuOTM4NDI1MSwibmJmIjoxNjY1ODU1Mjg3LjkzODQ3NDksImV4cCI6MTY5NzM5MTI4Ny45MDM3Mzk5LCJzdWIiOiI1NDkiLCJzY29wZXMiOltdfQ.uKRNZo1MNtDmdjR3pk00JjPoyE6IcJMvqdqMEOhR7syyw_a584gH4rMW9Jp4Rqq7Rc6ttM9UvKoDUk6Y38oA6elU96PcSk8nRsWZ_grSR7EwSX4DgW8qhEfVGUUm8GRceen12OBYnB3-sHOluVGWotFJdYYjWtWc9pw9otX3a8ZcC1kM3FZDqusYkPRuQiG4PiCsaRL1dRiMyp5cEc1JPma0aZL9iOBqwwB9sJYd9_wYz8S-ZEWBAGXwqbOkhZ9_GYwnfckQlgKiO1pDuX_Au_F138E659BFKNXibvU8rUTi9q15smFJ8icUBHrUhzIcQFjfdgqPQfGXkanJr5BcpByZbQMEqPhe18IBGduNaE53wClR4UL3ighFSmZWUa1ebdq6oKama5-DWDUVF18pi_owiTlkfHyXF-2aEvT-myxC7_9jvfbC3KVrOGCRuHiwWBALcdYP45ogSo7-RVCAupQi9TGrkzU85tEKCuo-JYQ3ATHjCmuW0bHsazM9je2vIe6j_-56v7YBaMR7vxoJ1kk-1rLoiEOg_IbRJ9XuQDCMk7gCOZLS9TmYvLm2oBe4VjTw7GVB8GxwB3mC8OwrcVyubTvNHTgvZH8BOrJDF349uQea4PGvXgySNktMo490zUQqn56uCCcBry3glHpdw-MYbBD5mGt5ma3AP4riLXE
```

#### Response Error Type 

** في حالة الفشل سيتم ارجاع رقم الخطاء ورساله الخطاء كا التالي **


```
POST http://localhost:8006/api/v1/auth/one-login?login=dheiaAli6&loginAttribute=mobile
```

```html
Status: 400 error 
```

```json
{
  "code": 0,
  "status": false,
  "message": "فشل تسجيل الدخول",
  "error": "رمز التحقق غير موجود يرجا ادخال رمز تحقق صحيح ",
  "errors": null,
  "is_login": false,
  "is_register": false,
  "is_access_token": false,
  "is_profile": false,
  "input_data": {
    "mobile": "00967770529444",
    "provider": "frontend",
    "field_name": "check_login",
    "code": "493470",
    "loginAttribute": "mobile"
  },
  "process_data": {
    "mobile": "00967770529444",
    "provider": "frontend",
    "field_name": "check_login",
    "code": "493470",
    "loginAttribute": "mobile"
  },
  "debug": {
    "line": 581,
    "file": "\/storage\/emulated\/0\/htdocs\/october_demo\/plugins\/nano\/authapi\/controllers\/Auth.php",
    "class": "Exception"
  }
}
```

**خطاء فى حال كان تسجيل حسابات جديده موقف **

```json
{
  "code": 0,
  "status": false,
  "message": "فشل تسجيل الدخول",
  "error": "التسجيل معطل حاليا.",
  "errors": null,
  "is_login": false,
  "is_register": false,
  "is_access_token": false,
  "is_profile": false,
  "input_data": {
    "mobile": "00967770529445",
    "provider": "backend",
    "field_name": "check_login",
    "code": "927361",
    "loginAttribute": "mobile",
    "profile": "1"
  },
  "process_data": {
    "mobile": "00967770529445",
    "provider": "backend",
    "field_name": "check_login",
    "code": "927361",
    "loginAttribute": "mobile",
    "profile": "1"
  },
  "debug": {
    "line": 105,
    "file": "\/storage\/emulated\/0\/htdocs\/october_demo\/plugins\/nano\/authapi\/classes\/AuthHelpers.php",
    "class": "October\\Rain\\Exception\\ApplicationException"
  }
}
```

**خطاء فى حال لم يتم ارسال كود التحقق من قبل بنجاح **

```json
{
  "code": 0,
  "status": false,
  "message": "فشل تسجيل الدخول",
  "error": "يرجا اعادة المحاولة لايوجد بيانات متطابقة تاكد من ارسال رمز التحقق   ",
  "errors": null,
  "is_login": false,
  "is_register": false,
  "is_access_token": false,
  "is_profile": false,
  "input_data": {
    "mobile": "00967770529443",
    "provider": "backend",
    "field_name": "check_login",
    "code": "927361",
    "loginAttribute": "mobile",
    "profile": "1"
  },
  "process_data": {
    "mobile": "00967770529443",
    "provider": "backend",
    "field_name": "check_login",
    "code": "927361",
    "loginAttribute": "mobile",
    "profile": "1"
  },
  "debug": {
    "line": 121,
    "file": "\/storage\/emulated\/0\/htdocs\/october_demo\/plugins\/nano2\/verifycode\/classes\/Manager.php",
    "class": "October\\Rain\\Exception\\ApplicationException"
  }
}
```

**حطاء فى حال كان هناك حقول الزاميه من قبل الادارة يجب ادخالها عند التسجيل **

```json
{
  "code": 0,
  "status": false,
  "message": "فشل تسجيل الدخول",
  "error": "الخاصية  الاسم الكامل حقل مطلوب",
  "errors": {
    "name": [
      "الخاصية  الاسم الكامل حقل مطلوب"
    ]
  },
  "is_login": false,
  "is_register": false,
  "is_access_token": false,
  "is_profile": false,
  "input_data": {
    "mobile": "00967770529444",
    "provider": "frontend",
    "field_name": "check_login",
    "code": "455937",
    "loginAttribute": "mobile"
  },
  "process_data": {
    "mobile": "00967770529444",
    "provider": "frontend",
    "field_name": "check_login",
    "code": "455937",
    "loginAttribute": "mobile"
  },
  "debug": {
    "line": 582,
    "file": "\/storage\/emulated\/0\/htdocs\/october_demo\/plugins\/nano\/authapi\/classes\/AuthHelpers.php",
    "class": "October\\Rain\\Exception\\ValidationException"
  }
}
```
```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "رقم الهاتف غير صحيح "
  }
}
```

```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "تنسيق الخاصية  رقم الهاتف غير صالح"
  }
}
```
```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "تنسيق الخاصية  البريد الالكتروني غير صالح"
  }
}
```

**فى البداية يجب علين ارسال كود التحقق لرقم الشخص كما فى الفقرة التالية **

