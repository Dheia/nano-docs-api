## auth/login-validator

This endpoint allows you to `login validator user`.

/auth/login-validator
**يختص هذا الجزء بالتحقق من وجود حساب مستخدم  لكافة انواع المستخدمين frontend  or backend**


### The Login validator object

#### Require Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `provider`           | `string`  |  provider [frontend,backend] deafult value frontend  |
| `loginAttribute`           | `string`  |  login Attribute Name [username,email,mobile] deafult value in setting web  |
| `login`           | `string`  |  enter data login  |


**provider يمثل هذا البراميتر نوع المستخدم فىنت اند او باك اند والقيمة الافتراضيه هي frontend**


**loginAttribute من خلال هذا المتغير يمكن تحديد طريقة تسجيل الدخول هل  عنطريق الاسم او البريد او الجوال **

**login من خلال هذا المتغير يتم ارسال بيانات الدخول الاسم او البريد او الجوال حسب طريقة التسجيل **

#### other  Parameters  

** يمكن استخدام هذه البراميترات عند عدم استخدام البراميتر  login **



| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `username`           | `string`  |  username |
| `email`           | `string`  |  email |
| `mobile`           | `string`  |  mobile number  |


#### Response Type 

** في حالة الفشل سيتم ارجاع رقم الخطاء ورساله الخطاء كا التالي **


```
POST http://localhost:8006/api/v1/auth/login-validator?login=dheiaAli6&loginAttribute=mobile
```

```html
Status: 400 error 
```

```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "رقم الهاتف غير صحيح "
  }
}
```

```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "تنسيق الخاصية  رقم الهاتف غير صالح"
  }
}
```
```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "تنسيق الخاصية  البريد الالكتروني غير صالح"
  }
}
```
### Example 1.1 login frontend user

**التحقق من وجود مستخدم فرنت اند**
```
POST /api/v1/auth/login-validator
```

** عن طريق الايميل **
```
http://localhost:8006/api/v1/auth/login-validator?provider=frontend&login=kddd90@gmail.com&loginAttribute=email
```

**البراميترات الممرره **

```json
{
  "provider": "frontend",
  "loginAttribute": "email",
  "login": "kddd90@gmail.com",
  }
```

 
 **عن طريق الجوال**
```
http://localhost:8006/api/v1/auth/login-validator?login=7705294826&loginAttribute=mobile
```

**البراميترات الممرره **

```json
{
  "provider": "frontend",
  "loginAttribute": "mobile",
  "login": "7705294826",
  }
```

#### Response

```html
Status: 200  
```

```json
{
  "code": 200,
  "status": true,
  "message": "المستخدم موجود ",
  "error": null,
  "errors": null
}
```


### Example 1.2 login backend user

**فى المثال التالي سنقوم بالتحقق من وجود مستخدم باك اند **

```
POST /api/v1/auth/login-validator
```

```
POST http://localhost:8006/api/v1/auth/login-validator?provider=backend&login=admin2&loginAttribute=username
```
**البراميترات الممرره **

```json
{
  "provider": "backend",
  "loginAttribute": "username",
  "login": "admin2",
  }
```

#### Response

```html
Status: 200  
```

```json
{
  "code": 200,
  "status": true,
  "message": "المستخدم موجود ",
  "error": null,
  "errors": null
}
```


