## auth/otp 

Send Code Activation  User Accounts 
**التحقق من صحة ،قم الهاتف**

** ارسال كود تنشيط الحساب   **

**الخطوه الاولى هى ان نقوم بارسال كود تنشيط الحساب   عبر رساله نصيه sms **

**الخطوة الثانيه التحقق من كود تنشيط الحساب وتنشيط الحساب  **


### Step 1 Send Code Activation

**الخطوه الاولى هى ان نقوم بارسال كود اتنشيط الحساب   عبر رساله نصيه sms **


```
POST /auth/otp/send
```
```
POST http://localhost:8006/api/v1/auth/otp/send
```

#### Require Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `mobile`           | `string`  |  mobile deafult value current user mobile  |
| `provider`           | `string`  |  provider [frontend or backend user] deafult value frontend|
| `is_update_user`           | `bool`  |  option deafult value true |
| `user_id`           | `string`  |  option deafult value null |

**mobile**
** يتم تمرير رقم الهاتف المراد التحقق منه  **

**يمكن التحقق من صحة رقم الهاتف قبل تسجيل المستخدم او بعد تسجيلة**

#### Example 1 Send Code Activation To mobile 

**فى المثال التالي سنقوم بارسال كود التحقق من رقم جوال المستخدم  **


**البراميترات الممرره فى الطلب كالتالي **

```json
{
  "provider": "frontend",
  "mobile": "00967529482",
  }
```

```
 POST http://localhost:8006/api/v1/auth/otp/send
```

**فى هذه الحاله سيتم ارسال كود تنشيط الحساب برساله الى  **

##### Response

```html
Status: 200 OK
```

**فى حالة كان الحساب نشط سيتم ارجاع البيانات التاليه**

```json
{
  "code": 200,
  "http_code": 200,
  "status": true,
  "message": "الحساب نشط ولايحتاج الى تنشيط",
  "input_data": {
    "loginAttribute": "email",
    "activate_type": "email",
    "login": "kddd9033@gmail.com"
  }
}
```

**فى حاله نجاح ارسال الكود عبر البريد سيتم ارجاع البيانات التاليه **

```json
{
  "code": 200,
  "http_code": 200,
  "status": true,
  "message": "سيتم ارسال كود التحقق الى  الخاص بك ",
  "input_data": {
    "loginAttribute": "email",
    "activate_type": "email",
    "login": "kddd9033@gmail.com"
  }
}
```

**فى حالة حدوث خطاء سيتم ارجاع البيانات التاليه **

```json
{
  "code": "WRONG_ARGS",
  "http_code": 400,
  "status": false,
  "message": "حدث خطاء اثناء عمليه ارسال كود تنشيط الحساب ",
  "error": "Unable to contact the mail server API",
  "error_message": "Unable to contact the mail server API",
  "input_data": {
    "loginAttribute": "email",
    "activate_type": "email",
    "login": "kddd9033@gmail.com"
  }
}
```


### Step 2 Activation mobile User


**الخطوة الثانيه التحقق من كود تنشيط الحساب وتنشيط الحساب فى حالة كان الكود صحيح **

```
POST /auth/otp/validate
```
```
POST http://localhost:8006/api/v1/auth/otp/validate
```

#### Example 3 User Activation

```
 POST http://localhost:8006/api/v1/auth/otp/validate
```


**البراميترات الممرره فى الطلب كالتالي **

```json
{
  "provider": "frontend",
  "mobile": "00967529482",
  "token": "529482",
  }
```


### Send Code Login

**للتحقق من المستخدم  عبر جواله  نقوم بارسال كود اتنشيط الحساب   عبر رساله نصيه sms **


```
POST /auth/otp/send
```
```
POST http://localhost:8006/api/v1/auth/otp/send
```

#### Require Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `field_name`           | `string`  | deafult value null  |
| `mobile`           | `string`  |  mobile deafult value current user mobile  |
| `provider`           | `string`  |  provider [frontend or backend user] deafult value frontend|
| `is_update_user`           | `bool`  |  option deafult value true |
| `user_id`           | `string`  |  option deafult value null |

**mobile**
** يتم تمرير رقم الهاتف المراد التحقق منه  **

**field_name**
**يجب تمرير المتغير السابق بالقيمة check_login**

#### Example 3 Send Code Login user To mobile 

**فى المثال التالي سنقوم بارسال كود التحقق من رقم جوال المستخدم  **


**البراميترات الممرره فى الطلب كالتالي **

```json
{
  "provider": "frontend",
  "mobile": "00967529482",
  "field_name": "check_login",
  }
```

```
 POST http://localhost:8006/api/v1/auth/otp/send
```
```
 POST http://localhost:8006/api/v1/auth/otp/send?mobile=00967770529498&provider=frontend&field_name=check_login&code=958831
```

**فى هذه الحاله سيتم ارسال كود تنشيط الحساب برساله الى  **

##### Response

```html
Status: 200 OK
```

**فى حاله نجاح ارسال الكود يتم ارجاع البيانات التاليه **

```json
{
  "code": 200,
  "status": true,
  "message": "تم ارسال كود التحقق بنجاح",
  "error": null,
  "errors": null,
  "input_data": [],
  "process_data": []
}
```

**فى حالة حدوث خطاء سيتم ارجاع البيانات التاليه **

```json
{
  "code": 0,
  "status": false,
  "message": "فشلة العملية",
  "error": "لايمكن ارسال الكود انتظر انقضاء المهله",
  "errors": null,
  "input_data": [],
  "process_data": [],
  "debug": {
    "line": 427,
    "file": "\/storage\/emulated\/0\/htdocs\/october_demo\/plugins\/nano2\/verifycode\/classes\/Manager.php",
    "class": "October\\Rain\\Exception\\ApplicationException"
  }
}
```


```json
{
  "code": "WRONG_ARGS",
  "http_code": 400,
  "status": false,
  "message": "حدث خطاء اثناء عمليه ارسال كود تنشيط الحساب ",
  "error": "Unable to contact the mail server API",
  "error_message": "Unable to contact the mail server API",
  "input_data": {
    "loginAttribute": "email",
    "activate_type": "email",
    "login": "kddd9033@gmail.com"
  }
}
```


### Validate Code Login

**للتحقق من الكود المرسل للمستخدم عبر جواله نستخدم الرابط التالي **


```
POST /auth/otp/send
```
```
POST http://localhost:8006/api/v1/auth/otp/send
```

#### Require Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `field_name`           | `string`  | deafult value null  |
| `mobile`           | `string`  |  mobile deafult value current user mobile  |
| `code`           | `string`  |  code or token  |
| `provider`           | `string`  |  provider [frontend or backend user] deafult value frontend|
| `is_update_user`           | `bool`  |  option deafult value true |
| `user_id`           | `string`  |  option deafult value null |

**mobile**
** يتم تمرير رقم الهاتف المراد التحقق منه  **

**field_name**
**يجب تمرير المتغير السابق بالقيمة check_login**

**token**
**فى حقل الكود او التكن نقوم بتمرير الرمز للتحقق منه **

#### Example 4 Validate Code Login user To mobile 

**فى المثال التالي سنقوم بالتحقق من الكود المرسل الى جوال المستخدم  **


**البراميترات الممرره فى الطلب كالتالي **

```json
{
  "provider": "frontend",
  "mobile": "00967529482",
  "field_name": "check_login",
  "code": "720487",
  }
```

```
 POST http://localhost:8006/api/v1/auth/otp/send
```
```
 POST http://localhost:8006/api/v1/auth/otp/validate?mobile=00967770529498&provider=frontend&field_name=check_login&code=720487
```

**فى هذه الحاله سيتم ارسال كود تنشيط الحساب برساله الى  **

##### Response

```html
Status: 200 OK
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم التحقق بنجاح",
  "error": null,
  "errors": null,
  "input_data": [],
  "process_data": {
    "model_id": 6
  }
}
```

**فى حالة حدوث خطاء سيتم ارجاع البيانات التاليه **

```json
{
  "code": 0,
  "status": false,
  "message": "فشلة العملية",
  "error": "الكود غير صحيح",
  "errors": null,
  "input_data": [],
  "process_data": {
    "model_id": 6
  },
  "debug": {
    "line": 150,
    "file": "\/storage\/emulated\/0\/htdocs\/october_demo\/plugins\/nano2\/verifycode\/classes\/Manager.php",
    "class": "October\\Rain\\Exception\\ApplicationException"
  }
}
```


```json
{
  "code": 0,
  "status": false,
  "message": "فشلة العملية",
  "error": "انتهة صلاحية الكود",
  "errors": null,
  "input_data": [],
  "process_data": {
    "model_id": 6
  },
  "debug": {
    "line": 135,
    "file": "\/storage\/emulated\/0\/htdocs\/october_demo\/plugins\/nano2\/verifycode\/classes\/Manager.php",
    "class": "October\\Rain\\Exception\\ApplicationException"
  }
}
```

```json
{
  "code": 0,
  "status": false,
  "message": "فشلة العملية",
  "error": "[HTTP 400] Unable to create record: Invalid parameter `To`: 00967770529498",
  "errors": null,
  "input_data": [],
  "process_data": {
    "model_id": 6
  },
  "debug": {
    "line": 146,
    "file": "\/storage\/emulated\/0\/htdocs\/october_demo\/plugins\/nano2\/verifycode\/classes\/Manager.php",
    "class": "October\\Rain\\Exception\\ApplicationException"
  }
}
```