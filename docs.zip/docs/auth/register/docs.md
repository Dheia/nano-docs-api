## auth/register

This endpoint allows you to `register user`.

/auth/register
### The departments object

#### Require Parameters
| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `username`           | `string`  |  username |
| `email`           | `string`  |  email |
| `mobile`           | `string`  |  mobile number  |
| `password`           | `string`  |  password  |
| `password_confirmation`           | `string`  |  password_confirmation  |
| `country_id`           | `integer`  |  country_id |
| `state_id`           | `integer`  |  state_id |
| `latitude`           | `float`  |  latitude |
| `longitude`           | `float`  |  latitude |


#### Attributes

```json
{
  "id": 543,
  "name": "dheiaAli1",
  "username": "kddd9033@gmail.com",
  "email": "kddd9033@gmail.com",
  "mobile": null,
  "gender": null,
  "address_1": null,
  "address_2": null,
  "street_name": null,
  "street_number": null,
  "latitude": null,
  "longitude": null,
  "geo_components": null,
  "city": null,
  "zip": null,
  "postcode": null,
  "country_long": null,
  "country_id": null,
  "state_id": null,
  "directorate_id": null,
  "formataddress": null,
  "vicinity": null,
  "avatar": null,
  "companys_id": "2",
  "departments_id": "2",
  "employees_id": null,
  "ref_type": "user",
  "ref_id": null,
  "permissions": null,
  "is_guest": false,
  "is_superuser": false,
  "is_activated": true,
  "activated_at": "2022-08-31 20:23:58",
  "last_login": "2022-10-15 20:14:35",
  "created_at": "2022-08-31 20:23:58",
  "updated_at": "2022-10-15 20:14:35",
  "deleted_at": "",
  "created_ip_address": "127.0.0.1",
  "last_ip_address": "127.0.0.1"
}
```


#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `department`           | `belongsTo`  | The department | 
| `groups`           | `belongsTo`  | The get groups    | 
| `notifications`           | `hasMany`  | The get notifications user   | 
| `address`           | `hasMany`  | The get address user   | 
| `country`           | `belongsTo`  | The get country data   | 
| `state`           | `belongsTo`  | The get state data   | 
| `directorate`           | `belongsTo`  | The get directorate data   | 


### Example 1 Register user

```
POST /api/v1/auth/register
```
```
POST http://localhost:8006/api/v1/auth/register?password=123456Dd&username=kddd90335@gmail.com&login2=dheiaAli5&email=kddd90335@gmail.com&mobile=7705294825
```

#### Response

```html
Status: 400 error 
```

```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "الخاصية  البريد الالكتروني  تم أخذه مسبقاً"
  }
}
```

### Example 2 Register user

```
POST /api/v1/auth/register
```
```
http://localhost:8006/api/v1/auth/register?password=123456Dd&username=kddd90336@gmail.com&login2=dheiaAli6&email=kddd90336@gmail.com&mobile=7705294826
```

#### Response

```html
Status: 200 Ok 
```

```json
{
  "code": "200",
  "message": "Login Success Full.",
  "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiOTJiYjhkNWJjZjE4MWYxMjcyMjhlZjc5ODFmYzE5ZWFmOGY1ZjVjMWUxZjg5ZWEzMDVhMDNiMzMxZjM2OWUxYjMzZDA3NWFkM2FlMGE3YTMiLCJpYXQiOjE2NjU4NTUyODcuOTM4NDI1MSwibmJmIjoxNjY1ODU1Mjg3LjkzODQ3NDksImV4cCI6MTY5NzM5MTI4Ny45MDM3Mzk5LCJzdWIiOiI1NDkiLCJzY29wZXMiOltdfQ.uKRNZo1MNtDmdjR3pk00JjPoyE6IcJMvqdqMEOhR7syyw_a584gH4rMW9Jp4Rqq7Rc6ttM9UvKoDUk6Y38oA6elU96PcSk8nRsWZ_grSR7EwSX4DgW8qhEfVGUUm8GRceen12OBYnB3-sHOluVGWotFJdYYjWtWc9pw9otX3a8ZcC1kM3FZDqusYkPRuQiG4PiCsaRL1dRiMyp5cEc1JPma0aZL9iOBqwwB9sJYd9_wYz8S-ZEWBAGXwqbOkhZ9_GYwnfckQlgKiO1pDuX_Au_F138E659BFKNXibvU8rUTi9q15smFJ8icUBHrUhzIcQFjfdgqPQfGXkanJr5BcpByZbQMEqPhe18IBGduNaE53wClR4UL3ighFSmZWUa1ebdq6oKama5-DWDUVF18pi_owiTlkfHyXF-2aEvT-myxC7_9jvfbC3KVrOGCRuHiwWBALcdYP45ogSo7-RVCAupQi9TGrkzU85tEKCuo-JYQ3ATHjCmuW0bHsazM9je2vIe6j_-56v7YBaMR7vxoJ1kk-1rLoiEOg_IbRJ9XuQDCMk7gCOZLS9TmYvLm2oBe4VjTw7GVB8GxwB3mC8OwrcVyubTvNHTgvZH8BOrJDF349uQea4PGvXgySNktMo490zUQqn56uCCcBry3glHpdw-MYbBD5mGt5ma3AP4riLXE",
  "token_type": "Bearer",
  "expires_at": "2023-10-15T17:34:47.000000Z",
  "revoked": false,
  "user_id": 549,
  "persist_code": "$2y$10$S0oMYQMudrFzvVC0D9iXH.jjG9S3P6i99s7yY7UGbB94VfLbZO63m"
}
```

## Useing token in login 

add Parameters Authorization in headr request 

Authorization = [token_type token]

** Require Authorization in Header Request**

```html
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiOTJiYjhkNWJjZjE4MWYxMjcyMjhlZjc5ODFmYzE5ZWFmOGY1ZjVjMWUxZjg5ZWEzMDVhMDNiMzMxZjM2OWUxYjMzZDA3NWFkM2FlMGE3YTMiLCJpYXQiOjE2NjU4NTUyODcuOTM4NDI1MSwibmJmIjoxNjY1ODU1Mjg3LjkzODQ3NDksImV4cCI6MTY5NzM5MTI4Ny45MDM3Mzk5LCJzdWIiOiI1NDkiLCJzY29wZXMiOltdfQ.uKRNZo1MNtDmdjR3pk00JjPoyE6IcJMvqdqMEOhR7syyw_a584gH4rMW9Jp4Rqq7Rc6ttM9UvKoDUk6Y38oA6elU96PcSk8nRsWZ_grSR7EwSX4DgW8qhEfVGUUm8GRceen12OBYnB3-sHOluVGWotFJdYYjWtWc9pw9otX3a8ZcC1kM3FZDqusYkPRuQiG4PiCsaRL1dRiMyp5cEc1JPma0aZL9iOBqwwB9sJYd9_wYz8S-ZEWBAGXwqbOkhZ9_GYwnfckQlgKiO1pDuX_Au_F138E659BFKNXibvU8rUTi9q15smFJ8icUBHrUhzIcQFjfdgqPQfGXkanJr5BcpByZbQMEqPhe18IBGduNaE53wClR4UL3ighFSmZWUa1ebdq6oKama5-DWDUVF18pi_owiTlkfHyXF-2aEvT-myxC7_9jvfbC3KVrOGCRuHiwWBALcdYP45ogSo7-RVCAupQi9TGrkzU85tEKCuo-JYQ3ATHjCmuW0bHsazM9je2vIe6j_-56v7YBaMR7vxoJ1kk-1rLoiEOg_IbRJ9XuQDCMk7gCOZLS9TmYvLm2oBe4VjTw7GVB8GxwB3mC8OwrcVyubTvNHTgvZH8BOrJDF349uQea4PGvXgySNktMo490zUQqn56uCCcBry3glHpdw-MYbBD5mGt5ma3AP4riLXE
```


