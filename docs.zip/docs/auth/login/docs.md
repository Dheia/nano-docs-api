## auth/login

This endpoint allows you to `login user`.

/auth/login
**يختص هذا الجزء بتسجيل الدخول لكافة انواع المستخدمين frontend  or backend**
### The Login object

#### Require Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `provider`           | `string`  |  provider [frontend,backend] deafult value frontend  |
| `loginAttribute`           | `string`  |  login Attribute Name [username,email,mobile] deafult value in setting web  |
| `login`           | `string`  |  enter data login  |
| `password`           | `string`  |  password  |
| `profile`           | `boolean`  |  get profile deafult value false   |


**provider يمثل هذا البراميتر نوع المستخدم فىنت اند او باك اند والقيمة الافتراضيه هي frontend**


**profile يستخدم هذا البراميتر فى حالة الرغبه بارجاع ملف المستخدم معا التوكن عند تسجيل الدخول **

**loginAttribute من خلال هذا المتغير يمكن تحديد طريقة تسجيل الدخول هل  عنطريق الاسم او البريد او الجوال **

**login من خلال هذا المتغير يتم ارسال بيانات الدخول الاسم او البريد او الجوال حسب طريقة التسجيل **

#### other  Parameters  

** يمكن استخدام هذه البراميترات عند عدم استخدام البراميتر  login **



| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `username`           | `string`  |  username |
| `email`           | `string`  |  email |
| `mobile`           | `string`  |  mobile number  |


#### Response Type 

** في حالة الفشل سيتم ارجاع رقم الخطاء ورساله الخطاء كا التالي **


```
POST http://localhost:8006/api/v1/auth/login?login=dheiaAli6&loginAttribute=mobile
```

```html
Status: 400 error 
```

```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "رقم الهاتف غير صحيح "
  }
}
```

```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "تنسيق الخاصية  رقم الهاتف غير صالح"
  }
}
```
```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "تنسيق الخاصية  البريد الالكتروني غير صالح"
  }
}
```
### Example 1.1 login frontend user

```
POST /api/v1/auth/login
```

```
http://localhost:8006/api/v1/auth/login?password=123456Dd&username=kddd90335@gmail.com&login2=dheiaAli5&email=kddd90335@gmail.com&mobile=7705294825
```

تسجيل الدخول عن طريق رقم الهاتف 
```
http://localhost:8006/api/v1/auth/login?password=123456Dd&login=7705294826&loginAttribute=mobile
```
**نلاحظ انه عند عدم تحديد نوع المستخدم profile فان النظام سيتعامل مع البيانات على انها المستخدمم frontend**

#### Response

```html
Status: 200  
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم تسجيل الدخول بنجاح ",
  "error": null,
  "errors": null,
  "id": 1,
  "name": "mobile",
  "token": "1|A7om8jqvmBnexVfRPpgv5tYVfP1CKKHcWCZG94mMBdV7turhxDWItSWodFfEd5IU8RXxw1NmAB8vVNTF",
  "token_type": "Bearer",
  "abilities": [
    "*"
  ],
  "created_at": "2023-08-21 13:28:06",
  "last_used_at": "2023-09-05 21:02:19",
  "expires_at": "2024-03-03 21:02:19",
  "is_expires": false,
  "expires_in": 260639,
  "user_id": 3,
  "user_type": "RainLab\\User\\Models\\User",
  "persist_code": "$2y$10$Oks.0eL.HoMrMb29VqLJMOjljgOL7QQ79Bfqwm4kzGanjpyEJnlRq"
}
```

**لارجاع ملف المستخدم مع  البيانات سنقوم بتمرير المتغير profile كالتالي **


```
POST https://alnaeem.nano2soft.com/api/v1/auth/login?locale=ar&loginAttribute=email&login=test@gmail.com&password=12345678&profile=1
```

**البراميترات الممرره **

```json
{
  "provider": "frontend",
  "loginAttribute": "email",
  "login": "test@gmail.com",
  "password": "12345678",
  "profile": 1,
  }
```

#### Response

```html
Status: 200  
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم تسجيل الدخول بنجاح ",
  "error": null,
  "errors": null,
  "id": 1,
  "name": "mobile",
  "token": "1|A7om8jqvmBnexVfRPpgv5tYVfP1CKKHcWCZG94mMBdV7turhxDWItSWodFfEd5IU8RXxw1NmAB8vVNTF",
  "token_type": "Bearer",
  "abilities": [
    "*"
  ],
  "created_at": "2023-08-21 13:28:06",
  "last_used_at": "2023-09-05 21:08:22",
  "expires_at": "2024-03-03 21:08:22",
  "is_expires": false,
  "expires_in": 260639,
  "user_id": 3,
  "user_type": "RainLab\\User\\Models\\User",
  "persist_code": "$2y$10$Oks.0eL.HoMrMb29VqLJMOjljgOL7QQ79Bfqwm4kzGanjpyEJnlRq",
  "profile": {
    "id": 3,
    "name": "",
    "surname": null,
    "username": "test_user",
    "email": "test@gmail.com",
    "mobile": "770821911",
    "gender": null,
    "date_of_birth": null,
    "address_1": null,
    "address_2": null,
    "street_name": null,
    "street_number": null,
    "latitude": null,
    "longitude": null,
    "geo_components": null,
    "city": "",
    "zip": "",
    "postcode": null,
    "country_long": null,
    "country_id": null,
    "state_id": null,
    "directorate_id": null,
    "formataddress": null,
    "vicinity": null,
    "avatar": null,
    "companys_id": "2",
    "departments_id": "2",
    "employees_id": null,
    "ref_type": "delivery",
    "ref_id": "14",
    "permissions": null,
    "is_guest": false,
    "is_superuser": false,
    "is_activated": true,
    "activated_at": "2023-07-08 18:42:28",
    "last_login": "2023-09-05 21:08:22",
    "created_at": "2023-07-08 18:42:28",
    "updated_at": "2023-09-05 21:08:22",
    "deleted_at": "",
    "created_ip_address": "185.71.133.156",
    "last_ip_address": "176.123.19.45",
    "is_delivery": true,
    "provider": "frontend",
    "orders_user_count": 35,
    "orders_user_complete_count": 1,
    "orders_user_cancelled_count": 1,
    "orders_user_delivery_count": 13,
    "orders_user_new_count": 3,
    "orders_delivery_count": 12,
    "orders_delivery_complete_count": 0,
    "orders_delivery_cancelled_count": 0,
    "orders_delivery_delivery_count": 12,
    "orders_delivery_new_count": 0,
    "ratings_count": 0,
    "countRating": 0,
    "sumRating": null,
    "averageRating": null,
    "user_is_rating": false,
    "user_object_rating": null,
    "object_type": "RainLab\\User\\Models\\User"
  }
}
```
### Example 1.2 login backend user

```
POST /api/v1/auth/login
```
**فى هذا المثال قمنا بتسجيل الدخول الى جزء الباك اند وارجاع ملف المستخدم profile مع ال token **
```
POST https://alnaeem.nano2soft.com/api/v1/auth/login?provider=backend&name=dheia%20ali&mobile=770529489&password=****&loginAttribute=username&login=system&profile=1
```
**البراميترات الممرره **
```json
{
  "provider": "backend",
  "loginAttribute": "username",
  "login": "system",
  "password": "******",
  "profile": 1,
  }
```

#### Response

```html
Status: 200  
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم تسجيل الدخول بنجاح ",
  "error": null,
  "errors": null,
  "id": 20,
  "name": "mobile",
  "token": "20|8iQdDS4wEX5nl1PTHPBC5oCBoQGwJIJgFfXMTvjB7ZuI9lRpgl0JCKrnRnY3InpyMkni2soITrvGyE0Q",
  "token_type": "Bearer",
  "abilities": [
    "*"
  ],
  "created_at": "2023-09-05 20:47:20",
  "last_used_at": "2023-09-05 20:47:20",
  "expires_at": "2024-03-03 20:47:20",
  "is_expires": false,
  "expires_in": 260639,
  "user_id": 24,
  "user_type": "Backend\\Models\\User",
  "persist_code": "$2y$10$0on2SbPa6hRfcoppMI6BnOAbThfY7JLvWBhOwrWfrF9Ac5\/dPGC4u",
  "profile": {
    "id": 24,
    "name": "system",
    "surname": "system",
    "username": "system",
    "email": "info@nano2soft.com",
    "mobile": "",
    "gender": null,
    "date_of_birth": null,
    "address_1": null,
    "address_2": null,
    "street_name": null,
    "street_number": null,
    "latitude": null,
    "longitude": null,
    "geo_components": null,
    "city": null,
    "zip": null,
    "postcode": null,
    "country_long": null,
    "country_id": "246",
    "state_id": "636",
    "directorate_id": null,
    "formataddress": null,
    "vicinity": null,
    "avatar": null,
    "companys_id": "2",
    "departments_id": "2",
    "employees_id": "",
    "ref_type": null,
    "ref_id": null,
    "permissions": "",
    "is_guest": false,
    "is_superuser": true,
    "is_activated": true,
    "activated_at": "",
    "last_login": "2023-09-05 20:47:20",
    "created_at": "2023-05-02 17:13:55",
    "updated_at": "2023-09-05 20:47:20",
    "deleted_at": "",
    "created_ip_address": null,
    "last_ip_address": null,
    "is_delivery": false,
    "provider": "backend",
    "ratings_count": 0,
    "countRating": 0,
    "sumRating": null,
    "averageRating": null,
    "user_is_rating": false,
    "user_object_rating": null,
    "object_type": "Backend\\Models\\User"
  }
}
```

## Useing token in login 

add Parameters Authorization in headr request 

Authorization = [token_type token]

** Require Authorization in Header Request**

```html
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiOTJiYjhkNWJjZjE4MWYxMjcyMjhlZjc5ODFmYzE5ZWFmOGY1ZjVjMWUxZjg5ZWEzMDVhMDNiMzMxZjM2OWUxYjMzZDA3NWFkM2FlMGE3YTMiLCJpYXQiOjE2NjU4NTUyODcuOTM4NDI1MSwibmJmIjoxNjY1ODU1Mjg3LjkzODQ3NDksImV4cCI6MTY5NzM5MTI4Ny45MDM3Mzk5LCJzdWIiOiI1NDkiLCJzY29wZXMiOltdfQ.uKRNZo1MNtDmdjR3pk00JjPoyE6IcJMvqdqMEOhR7syyw_a584gH4rMW9Jp4Rqq7Rc6ttM9UvKoDUk6Y38oA6elU96PcSk8nRsWZ_grSR7EwSX4DgW8qhEfVGUUm8GRceen12OBYnB3-sHOluVGWotFJdYYjWtWc9pw9otX3a8ZcC1kM3FZDqusYkPRuQiG4PiCsaRL1dRiMyp5cEc1JPma0aZL9iOBqwwB9sJYd9_wYz8S-ZEWBAGXwqbOkhZ9_GYwnfckQlgKiO1pDuX_Au_F138E659BFKNXibvU8rUTi9q15smFJ8icUBHrUhzIcQFjfdgqPQfGXkanJr5BcpByZbQMEqPhe18IBGduNaE53wClR4UL3ighFSmZWUa1ebdq6oKama5-DWDUVF18pi_owiTlkfHyXF-2aEvT-myxC7_9jvfbC3KVrOGCRuHiwWBALcdYP45ogSo7-RVCAupQi9TGrkzU85tEKCuo-JYQ3ATHjCmuW0bHsazM9je2vIe6j_-56v7YBaMR7vxoJ1kk-1rLoiEOg_IbRJ9XuQDCMk7gCOZLS9TmYvLm2oBe4VjTw7GVB8GxwB3mC8OwrcVyubTvNHTgvZH8BOrJDF349uQea4PGvXgySNktMo490zUQqn56uCCcBry3glHpdw-MYbBD5mGt5ma3AP4riLXE
```

