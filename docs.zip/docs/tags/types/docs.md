## Type Shop 

This endpoint allows you to `list`, `show` your type.

/tags/types

**من خلال هذا الجزء يمكنك جلب انواع المحلات او فئات المحلات **

**كافة الفئات او الانواع  **

### The types object

#### Public Parameters
| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in types records |
| `orderBy`           | `string`  |  using orderBy types records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy types records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  types default value true    |
| `isPublic`           | `boolean`  | The get is Public in Web records types default value true  | 
| `isPublished`           | `integer`  | The get is Not Hidden in Web records types default value true  | 
| `isDepartments`           | `boolean`  |  get records types departments default value true.         |
| `isDisplayEmpty`           | `boolean`  | get records types not have departments default value true.          |
| `displayTo`           | `integer` | useing number have departments default value 1
| 
| `with_count`           | `boolean` | get counts departments,tags,categories default value false
| 
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/tags/types?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |



### List types

Returns a list of types you’ve previously created.

```
GET /api/v1/tags/types
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 2,
      "code": "2-2-2",
      "name": "مطاعم",
      "slug": "mtaaam",
      "ref_type": "mtaaam",
      "short_description": "",
      "description": "<p>مطاعم<\/p>",
      "meta_title": "مطاعم",
      "meta_description": "",
      "keywords": "",
      "user_id": null,
      "user_type": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_departments": 1,
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "created_at": "2022-10-25 22:43:08",
      "updated_at": "2022-10-25 22:43:08",
      "image": null,
      "images": [],
      "object_type": "Nano\\Tags\\Models\\Type"
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Example 1 get List Types 

GET http://localhost:8006/api/v1/tags/types

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 3,
      "code": "2-2-3",
      "name": "اسواق تجاريه",
      "slug": "asoak-tgaryh",
      "ref_type": "asoak-tgaryh",
      "short_description": "",
      "description": "<p>اسواق تجاريه<\/p>",
      "meta_title": "اسواق تجاريه",
      "meta_description": "اسواق تجاريه",
      "keywords": "اسواق تجاريه",
      "user_id": null,
      "user_type": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_departments": 1,
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "created_at": "2022-10-26 21:24:40",
      "updated_at": "2022-10-26 21:24:40",
      "image": null,
      "images": [],
      "object_type": "Nano\\Tags\\Models\\Type"
    },
    {
      "id": 2,
      "code": "2-2-2",
      "name": "مطاعم",
      "slug": "mtaaam",
      "ref_type": "mtaaam",
      "short_description": "",
      "description": "<p>مطاعم<\/p>",
      "meta_title": "مطاعم",
      "meta_description": "",
      "keywords": "",
      "user_id": null,
      "user_type": null,
      "companys_id": "2",
      "departments_id": "2",
      "is_departments": 1,
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "created_at": "2022-10-25 22:43:08",
      "updated_at": "2022-10-25 22:43:08",
      "image": null,
      "images": [],
      "object_type": "Nano\\Tags\\Models\\Type"
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Show Data Record Types 

```
GET /api/v1/tags/types/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record Types 3

```
GET http://localhost:8006/api/v1/tags/types/3
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "id": 3,
  "code": "2-2-3",
  "name": "اسواق تجاريه",
  "slug": "asoak-tgaryh",
  "ref_type": "asoak-tgaryh",
  "short_description": "",
  "description": "<p>اسواق تجاريه<\/p>",
  "meta_title": "اسواق تجاريه",
  "meta_description": "اسواق تجاريه",
  "keywords": "اسواق تجاريه",
  "user_id": null,
  "user_type": null,
  "companys_id": "2",
  "departments_id": "2",
  "is_departments": 1,
  "is_public": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "properties": null,
  "created_at": "2022-10-26 21:24:40",
  "updated_at": "2022-10-26 21:24:40",
  "image": null,
  "images": [],
  "object_type": "Nano\\Tags\\Models\\Type"
}
```

### Check Last Update Categorie Daa 

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/tags/types/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/tags/types/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2022-12-16 17:29:08",
    "other_updated": {
      "activity_cache.type": "2022-12-16 17:29:08",
      "activity_cache.product": "2022-12-16 16:29:28",
      "activity_cache.department": "2022-12-16 16:29:28",
      "activity_cache.tag": "2022-12-16 17:27:15",
      "activity_cache.categorie": "2022-12-16 16:29:28"
    }
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2022-12-16 17:29:31",
    "last_updated": "2022-12-16 17:29:08",
    "other_updated": {
      "activity_cache.type": "2022-12-16 17:29:08",
      "activity_cache.product": "2022-12-16 16:29:28",
      "activity_cache.department": "2022-12-16 16:29:28",
      "activity_cache.tag": "2022-12-16 17:27:15",
      "activity_cache.categorie": "2022-12-16 16:29:28"
    }
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **

