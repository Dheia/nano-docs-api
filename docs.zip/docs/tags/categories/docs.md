## Categories Shop 

This endpoint allows you to `list`, `show` your type.

/tags/categories

**من خلال هذا الجزء يمكنك جلب التصنيفات  **

### The Categories object

#### Public Parameters
| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in categories records |
| `orderBy`           | `string`  |  using orderBy categories records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy categories records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  categories default value true    |
| `isPublic`           | `boolean`  | The get is Public in Web records categories default value true  | 
| `isPublished`           | `integer`  | The get is Not Hidden in Web records categories default value true  | 
| `tags_type_id`           | `integer` | useing select type departments default value false
| 
| `isDisplayEmpty`           | `boolean`  | get records categories not have departments default value true.          |
| `displayTo`           | `integer` | useing number have departments default value 1
| 
| `with_count`           | `boolean` | get counts useing categories default value false
| 
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/tags/categories?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `products`           | `belongsTo`  | The get products |



### List categories

Returns a list of categories you’ve previously created.

```
GET /api/v1/tags/categories
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": "2-4-1",
      "name": "عامه",
      "slug": "aaamh",
      "type": "1",
      "user_id": null,
      "user_type": null,
      "companys_id": "2",
      "departments_id": "4",
      "country_id": null,
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "main_sub": "main",
      "parent_id": null,
      "level": "1",
      "properties": null,
      "created_at": "2022-09-26 19:55:19",
      "updated_at": "2022-10-03 20:13:13",
      "object_type": "Nano\\Tags\\Models\\Categorie"
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Example 1 get List Categories 

GET http://localhost:8006/api/v1/tags/categories

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 1,
      "code": "2-4-1",
      "name": "عامه",
      "slug": "aaamh",
      "type": "1",
      "user_id": null,
      "user_type": null,
      "companys_id": "2",
      "departments_id": "4",
      "country_id": null,
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "main_sub": "main",
      "parent_id": null,
      "level": "1",
      "properties": null,
      "created_at": "2022-09-26 19:55:19",
      "updated_at": "2022-10-03 20:13:13",
      "object_type": "Nano\\Tags\\Models\\Categorie"
    }
  ],
  "meta": {
    "pagination": {
      "total": 1,
      "count": 1,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Show Data Record Types 

```
GET /api/v1/tags/categories/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record Types 1

```
GET http://localhost:8006/api/v1/tags/categories/3
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "id": 1,
  "code": "2-4-1",
  "name": "عامه",
  "slug": "aaamh",
  "type": "1",
  "user_id": null,
  "user_type": null,
  "companys_id": "2",
  "departments_id": "4",
  "country_id": null,
  "is_public": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "main_sub": "main",
  "parent_id": null,
  "level": "1",
  "properties": null,
  "created_at": "2022-09-26 19:55:19",
  "updated_at": "2022-10-03 20:13:13",
  "object_type": "Nano\\Tags\\Models\\Categorie"
}
```

### Example 2 get List Categories With products not isOffer

```
GET http://localhost:8006/api/v1/tags/categories/47?include=products
```

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "include": products,
}
```
#### Response

**نلاحظ انه تم جلب الاصناف التابعه للتصنيف الممرار بدون جلب العروض **

```html
Status: 200 OK
```

```json
{
  "id": 47,
  "code": "2-4-47",
  "name": "الرز",
  "slug": "alrz",
  "type": null,
  "user_id": null,
  "user_type": null,
  "companys_id": "2",
  "departments_id": "4",
  "country_id": null,
  "is_public": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "main_sub": null,
  "parent_id": "0",
  "level": "1",
  "properties": null,
  "created_at": "2023-08-08 20:03:28",
  "updated_at": "2023-08-08 20:03:28",
  "image": null,
  "images": [],
  "object_type": "Nano\\Tags\\Models\\Categorie",
  "products": {
    "data": [
      {
        "id": 1580,
        "code": "24-47-1580",
        "barcode": "0-1580",
        "name": "رز مزه",
        "emblem": "",
        "short_description": "",
        "description": "",
        "users_manual": "",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "49",
        "is_offer": 0,
        "groups_products_id": "0",
        "companys_id": "24",
        "departments_id": "47",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "",
        "unpublished_at": "",
        "manage_stock": 0,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 1,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 1,
        "default_qty": 1,
        "old_price": 100,
        "price": 800,
        "is_show_old_price": 1,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 0,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1580,
        "created_at": "2023-08-13 18:29:37",
        "updated_at": "2023-08-13 18:29:37",
        "image": null,
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      }
    ]
  }
}
```

### Example 3 get List Categories With products isOffer 

**فى المثال التالي سنقوم بجلب العروض فقط التي تنتمي للتصنيف الممرار **
```
GET http://localhost:8006/api/v1/tags/categories/47?include=products&isOffer=true
```

**لجلب العروض التابعه للتصنيف الممر نقوم بتمرير المتغير isOffer**

```json
{
  "isOffer": true,
}
```
#### Response

** فى المثال التالي تم جلب العروض التابعه للتصنيف الممرار **

```html
Status: 200 OK
```

```json
{
  "id": 47,
  "code": "2-4-47",
  "name": "الرز",
  "slug": "alrz",
  "type": null,
  "user_id": null,
  "user_type": null,
  "companys_id": "2",
  "departments_id": "4",
  "country_id": null,
  "is_public": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "main_sub": null,
  "parent_id": "0",
  "level": "1",
  "properties": null,
  "created_at": "2023-08-08 20:03:28",
  "updated_at": "2023-08-08 20:03:28",
  "image": null,
  "images": [],
  "object_type": "Nano\\Tags\\Models\\Categorie",
  "products": {
    "data": [
      {
        "id": 1576,
        "code": "2-2-1576",
        "barcode": "0-1576",
        "name": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "emblem": "",
        "short_description": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "description": "<p>عرض جديد حبه دجاج + نفر رز + سلطه<\/p>",
        "users_manual": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "3",
        "is_offer": 1,
        "groups_products_id": "0",
        "companys_id": "2",
        "departments_id": "2",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "2023-08-01 20:00:57",
        "unpublished_at": "2024-08-01 20:01:04",
        "manage_stock": 0,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 1,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 1,
        "default_qty": 1,
        "old_price": 3000,
        "price": 2500,
        "is_show_old_price": 1,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 0,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1576,
        "created_at": "2023-08-08 20:03:28",
        "updated_at": "2023-08-08 20:29:39",
        "image": null,
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      }
    ]
  }
}
```

### Example 4 get List Categories With products and isOffer (all)

**فى المثال التالي سنقوم بجلب  الاصناف والعروض التي تنتمي للتصنيف الممرار **

```
GET http://localhost:8006/api/v1/tags/categories/47?include=products&isOffer=all
```

**لجلب العروض التابعه للتصنيف الممر نقوم بتمرير المتغير isOffer**

```json
{
  "include": products,
  "isOffer": all,
}
```
#### Response

** فى المثال التالي تم جلب العروض التابعه للتصنيف الممرار **

```html
Status: 200 OK
```

```json
{
  "id": 47,
  "code": "2-4-47",
  "name": "الرز",
  "slug": "alrz",
  "type": null,
  "user_id": null,
  "user_type": null,
  "companys_id": "2",
  "departments_id": "4",
  "country_id": null,
  "is_public": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "main_sub": null,
  "parent_id": "0",
  "level": "1",
  "properties": null,
  "created_at": "2023-08-08 20:03:28",
  "updated_at": "2023-08-08 20:03:28",
  "image": null,
  "images": [],
  "object_type": "Nano\\Tags\\Models\\Categorie",
  "products": {
    "data": [
      {
        "id": 1576,
        "code": "2-2-1576",
        "barcode": "0-1576",
        "name": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "emblem": "",
        "short_description": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "description": "<p>عرض جديد حبه دجاج + نفر رز + سلطه<\/p>",
        "users_manual": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "3",
        "is_offer": 1,
        "groups_products_id": "0",
        "companys_id": "2",
        "departments_id": "2",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "2023-08-01 20:00:57",
        "unpublished_at": "2024-08-01 20:01:04",
        "manage_stock": 0,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 1,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 1,
        "default_qty": 1,
        "old_price": 3000,
        "price": 2500,
        "is_show_old_price": 1,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 0,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1576,
        "created_at": "2023-08-08 20:03:28",
        "updated_at": "2023-08-08 20:29:39",
        "image": null,
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      },
      {
        "id": 1580,
        "code": "24-47-1580",
        "barcode": "0-1580",
        "name": "رز مزه",
        "emblem": "",
        "short_description": "",
        "description": "",
        "users_manual": "",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "49",
        "is_offer": 0,
        "groups_products_id": "0",
        "companys_id": "24",
        "departments_id": "47",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "",
        "unpublished_at": "",
        "manage_stock": 0,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 1,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 1,
        "default_qty": 1,
        "old_price": 100,
        "price": 800,
        "is_show_old_price": 1,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 0,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1580,
        "created_at": "2023-08-13 18:29:37",
        "updated_at": "2023-08-13 18:29:37",
        "image": null,
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      }
    ]
  }
}
```

### Note
**يجب ملاحظه انه عند تضمين العلاقه التابعه للاصناف products انه يتم ارجاع الاصناف من كافه الفروع او المحلات ولتحديد محل معين يجب تمرير رقم المحل او الفرع ضمن الطلب كالتالي **

```
GET http://localhost:8006/api/v1/tags/categories/47?include=products&isOffer=all&departments_id=4
```

```json
{
  "include": products,
  "isOffer": all,
  "departments_id": 4,
}
```

#### Response

**النتيجه فى حالة تمرير رقم المتجر او الفرع **

```
GET http://localhost:8006/api/v1/tags/categories/47?include=products&isOffer=all&departments_id=4
```

```html
Status: 200 OK
```

```json
{
  "id": 47,
  "code": "2-4-47",
  "name": "الرز",
  "slug": "alrz",
  "type": null,
  "user_id": null,
  "user_type": null,
  "companys_id": "2",
  "departments_id": "4",
  "country_id": null,
  "is_public": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "main_sub": null,
  "parent_id": "0",
  "level": "1",
  "properties": null,
  "created_at": "2023-08-08 20:03:28",
  "updated_at": "2023-08-08 20:03:28",
  "image": null,
  "images": [],
  "object_type": "Nano\\Tags\\Models\\Categorie",
  "products": {
    "data": [
      {
        "id": 1576,
        "code": "2-2-1576",
        "barcode": "0-1576",
        "name": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "emblem": "",
        "short_description": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "description": "<p>عرض جديد حبه دجاج + نفر رز + سلطه<\/p>",
        "users_manual": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "3",
        "is_offer": 1,
        "groups_products_id": "0",
        "companys_id": "2",
        "departments_id": "2",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "2023-08-01 20:00:57",
        "unpublished_at": "2024-08-01 20:01:04",
        "manage_stock": 0,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 1,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 1,
        "default_qty": 1,
        "old_price": 3000,
        "price": 2500,
        "is_show_old_price": 1,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 0,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1576,
        "created_at": "2023-08-08 20:03:28",
        "updated_at": "2023-08-08 20:29:39",
        "image": null,
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      }
    ]
  }
}
```

**النتيجه فى حالة عدم تمرير رقم المتجر او الفرع **

```
GET http://localhost:8006/api/v1/tags/categories/47?include=products&isOffer=all
```

```html
Status: 200 OK
```

```json
{
  "id": 47,
  "code": "2-4-47",
  "name": "الرز",
  "slug": "alrz",
  "type": null,
  "user_id": null,
  "user_type": null,
  "companys_id": "2",
  "departments_id": "4",
  "country_id": null,
  "is_public": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "main_sub": null,
  "parent_id": "0",
  "level": "1",
  "properties": null,
  "created_at": "2023-08-08 20:03:28",
  "updated_at": "2023-08-08 20:03:28",
  "image": null,
  "images": [],
  "object_type": "Nano\\Tags\\Models\\Categorie",
  "products": {
    "data": [
      {
        "id": 1576,
        "code": "2-2-1576",
        "barcode": "0-1576",
        "name": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "emblem": "",
        "short_description": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "description": "<p>عرض جديد حبه دجاج + نفر رز + سلطه<\/p>",
        "users_manual": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "3",
        "is_offer": 1,
        "groups_products_id": "0",
        "companys_id": "2",
        "departments_id": "2",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "2023-08-01 20:00:57",
        "unpublished_at": "2024-08-01 20:01:04",
        "manage_stock": 0,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 1,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 1,
        "default_qty": 1,
        "old_price": 3000,
        "price": 2500,
        "is_show_old_price": 1,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 0,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1576,
        "created_at": "2023-08-08 20:03:28",
        "updated_at": "2023-08-08 20:29:39",
        "image": null,
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      },
      {
        "id": 1580,
        "code": "24-47-1580",
        "barcode": "0-1580",
        "name": "رز مزه",
        "emblem": "",
        "short_description": "",
        "description": "",
        "users_manual": "",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "49",
        "is_offer": 0,
        "groups_products_id": "0",
        "companys_id": "24",
        "departments_id": "47",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "",
        "unpublished_at": "",
        "manage_stock": 0,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 1,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 1,
        "default_qty": 1,
        "old_price": 100,
        "price": 800,
        "is_show_old_price": 1,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 0,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1580,
        "created_at": "2023-08-13 18:29:37",
        "updated_at": "2023-08-13 18:29:37",
        "image": null,
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      }
    ]
  }
}
```

### Check Last Update Categorie Daa 

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/tags/categories/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/tags/categories/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2022-12-16 16:29:28",
    "other_updated": {
      "activity_cache.categorie": "2022-12-16 16:29:28",
      "activity_cache.department": "2022-12-16 16:29:28",
      "activity_cache.product": "2022-12-16 16:29:28",
      "activity_cache.cateable": "2022-12-16 16:29:28"
    }
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2022-12-16 17:24:50",
    "last_updated": "2022-12-16 16:29:28",
    "other_updated": {
      "activity_cache.categorie": "2022-12-16 16:29:28",
      "activity_cache.department": "2022-12-16 16:29:28",
      "activity_cache.product": "2022-12-16 16:29:28",
      "activity_cache.cateable": "2022-12-16 16:29:28"
    }
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **
