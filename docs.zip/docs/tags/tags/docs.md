## Tags Shop 

This endpoint allows you to `list`, `show` your type.

/tags/tags

**من خلال هذا الجزء يمكنك جلب الهاشتجات التي تستخدم للربط بين محتويات التطبيق كالاصناف والاخبار والمحلات  **

### The Tags object

#### Public Parameters
| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in tags records |
| `orderBy`           | `string`  |  using orderBy tags records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy tags records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  tags default value true    |
| `isPublic`           | `boolean`  | The get is Public in Web records tags default value true  | 
| `isPublished`           | `integer`  | The get is Not Hidden in Web records tags default value true  | 
| `tags_type_id`           | `integer` | useing select type departments default value false
| 
| `isDisplayEmpty`           | `boolean`  | get records tags not have departments default value true.          |
| `displayTo`           | `integer` | useing number have departments default value 1
| 
| `with_count`           | `boolean` | get counts useing tags default value false
| 
| `include`           | `string` | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/tags/tags?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `products`           | `belongsTo`  | The get products |


### List tags

Returns a list of tags you’ve previously created.

```
GET /api/v1/tags/tags
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 2,
      "code": "2-4-2",
      "name": "مشروبات",
      "slug": "mshrobat",
      "type": null,
      "user_id": null,
      "user_type": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "created_at": "2022-09-11 13:52:27",
      "updated_at": "2022-09-11 13:52:27",
      "object_type": "Nano\\Tags\\Models\\Tag"
    },
    {
      "id": 3,
      "code": "2-4-3",
      "name": "عصائر",
      "slug": "aasaer",
      "type": null,
      "user_id": null,
      "user_type": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "created_at": "2022-09-11 13:52:27",
      "updated_at": "2022-09-11 13:52:27",
      "object_type": "Nano\\Tags\\Models\\Tag"
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Example 1 get List Tags 

GET http://localhost:8006/api/v1/tags/tags

#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 2,
      "code": "2-4-2",
      "name": "مشروبات",
      "slug": "mshrobat",
      "type": null,
      "user_id": null,
      "user_type": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "created_at": "2022-09-11 13:52:27",
      "updated_at": "2022-09-11 13:52:27",
      "object_type": "Nano\\Tags\\Models\\Tag"
    },
    {
      "id": 3,
      "code": "2-4-3",
      "name": "عصائر",
      "slug": "aasaer",
      "type": null,
      "user_id": null,
      "user_type": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_public": 1,
      "is_default": 0,
      "is_active": 1,
      "is_published": 1,
      "published_at": "",
      "unpublished_at": "",
      "properties": null,
      "created_at": "2022-09-11 13:52:27",
      "updated_at": "2022-09-11 13:52:27",
      "object_type": "Nano\\Tags\\Models\\Tag"
    }
  ],
  "meta": {
    "pagination": {
      "total": 2,
      "count": 2,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": []
    }
  }
}
```

### Show Data Record Tags 

```
GET /api/v1/tags/tags/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record Tags 3

```
GET http://localhost:8006/api/v1/tags/tags/3
```

#### Response

```html
Status: 200 Ok
```

```json
{
  "id": 3,
  "code": "2-4-3",
  "name": "عصائر",
  "slug": "aasaer",
  "type": null,
  "user_id": null,
  "user_type": null,
  "companys_id": "2",
  "departments_id": "4",
  "is_public": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "properties": null,
  "created_at": "2022-09-11 13:52:27",
  "updated_at": "2022-09-11 13:52:27",
  "object_type": "Nano\\Tags\\Models\\Tag"
}
```

### Example 2 get List Tags With products not isOffer

```
GET http://localhost:8006/api/v1/tags/tags/47?include=products
```

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "include": products,
}
```
#### Response

**نلاحظ انه تم جلب الاصناف التابعه للهاشتاج الممرار بدون جلب العروض **

```html
Status: 200 OK
```

```json
{
  "id": 47,
  "code": "2-4-47",
  "name": "المشروبات الساخنة",
  "slug": "almshrobat-alsakhn",
  "type": null,
  "user_id": null,
  "user_type": null,
  "companys_id": "2",
  "departments_id": "4",
  "is_public": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "properties": null,
  "created_at": "2022-11-09 15:48:18",
  "updated_at": "2022-11-09 15:48:18",
  "image": null,
  "images": [],
  "object_type": "Nano\\Tags\\Models\\Tag",
  "products": {
    "data": [
      {
        "id": 1430,
        "code": "2-2-1430",
        "barcode": "0-1430",
        "name": "شاهي",
        "emblem": "",
        "short_description": "",
        "description": "",
        "users_manual": "",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "3",
        "is_offer": 0,
        "groups_products_id": "0",
        "companys_id": "2",
        "departments_id": "2",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "",
        "unpublished_at": "",
        "manage_stock": 1,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 100,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 100,
        "default_qty": 1,
        "old_price": 0,
        "price": 50,
        "is_show_old_price": 0,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 1,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1430,
        "created_at": "2022-11-09 15:53:47",
        "updated_at": "2023-08-09 13:59:03",
        "image": {
          "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/636bccf4b203d617442273.jpg",
          "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_160_160_0_0_crop.jpg",
          "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_240_240_0_0_crop.jpg",
          "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_800_800_0_0_crop.jpg",
          "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_480_480_0_0_auto.jpg"
        },
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [
            {
              "id": 1431,
              "code": "2-2-1431",
              "barcode": "0-1431",
              "name": "شاهي احمر",
              "emblem": "شاهي",
              "short_description": "شاهي احمر",
              "description": "<p>شاهي احمر<\/p>",
              "users_manual": "دليل الاستخدام",
              "composition": "التركيبة",
              "indication": "الامور الاخري المتعلقة بالصنف",
              "meta_title": "شاهي",
              "meta_description": "وصف للبحث",
              "keywords": "كلمات مفتاحية",
              "ref_type_class": "products",
              "ref_key_values_class": "3",
              "is_offer": 0,
              "groups_products_id": "0",
              "companys_id": "2",
              "departments_id": "2",
              "is_effective": 1,
              "is_default": null,
              "is_active": 1,
              "is_published": 0,
              "published_at": "",
              "unpublished_at": "",
              "manage_stock": 1,
              "shop_stock": 1,
              "min_qty": 1,
              "max_qty": 100,
              "min_qty_in_stock": 1,
              "max_qty_in_stock": 100,
              "default_qty": 1,
              "old_price": 0,
              "price": 50,
              "is_show_old_price": 0,
              "is_parleying": 1,
              "is_sold": 1,
              "is_purchased": 1,
              "is_composite": 0,
              "is_units": 1,
              "is_downloadable": 1,
              "properties": [
                {
                  "title": "الاضافات",
                  "code": "extention",
                  "value": "10",
                  "is_default": "1",
                  "is_show": "1",
                  "sort_show": "1",
                  "_group": "properties"
                }
              ],
              "links": [
                {
                  "title": "url",
                  "url": "test.com",
                  "target": "_blank",
                  "sort_show": "1",
                  "is_download": "0",
                  "is_default": "1",
                  "is_show": "1",
                  "_group": "links"
                }
              ],
              "other_data": null,
              "config_data": null,
              "sort_order": 1431,
              "created_at": "2022-11-09 15:54:58",
              "updated_at": "2023-07-15 00:31:17",
              "image": {
                "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/636bcd2f87ee1059528054.jpg",
                "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_160_160_0_0_crop.jpg",
                "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_240_240_0_0_crop.jpg",
                "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_800_800_0_0_crop.jpg",
                "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_480_480_0_0_auto.jpg"
              },
              "images": [],
              "files": [],
              "ratings_count": 0,
              "countRating": 0,
              "sumRating": null,
              "averageRating": null,
              "user_is_rating": false,
              "user_object_rating": null,
              "favorites_count": 0,
              "user_is_favorite": false,
              "user_object_favorite": null,
              "object_type": "Nano\\Shop\\Models\\Product",
              "qty": 0,
              "children": {
                "data": [],
                "meta": {
                  "pagination": {
                    "total": 0,
                    "count": 0,
                    "per_page": 10,
                    "current_page": 1,
                    "total_pages": 1,
                    "links": []
                  }
                }
              },
              "prices_units": {
                "data": []
              }
            },
            {
              "id": 1432,
              "code": "2-2-1432",
              "barcode": "0-1432",
              "name": "شاهي حليب",
              "emblem": "",
              "short_description": "",
              "description": "",
              "users_manual": "",
              "composition": "",
              "indication": "",
              "meta_title": "",
              "meta_description": "",
              "keywords": "",
              "ref_type_class": "products",
              "ref_key_values_class": "3",
              "is_offer": 0,
              "groups_products_id": "0",
              "companys_id": "2",
              "departments_id": "2",
              "is_effective": 1,
              "is_default": null,
              "is_active": 1,
              "is_published": 0,
              "published_at": "",
              "unpublished_at": "",
              "manage_stock": 1,
              "shop_stock": 0,
              "min_qty": 1,
              "max_qty": 100,
              "min_qty_in_stock": 1,
              "max_qty_in_stock": 100,
              "default_qty": 1,
              "old_price": 0,
              "price": 100,
              "is_show_old_price": 0,
              "is_parleying": 1,
              "is_sold": 1,
              "is_purchased": 1,
              "is_composite": 0,
              "is_units": 1,
              "is_downloadable": 1,
              "properties": null,
              "links": null,
              "other_data": null,
              "config_data": null,
              "sort_order": 1432,
              "created_at": "2022-11-09 15:55:41",
              "updated_at": "2023-08-08 19:58:38",
              "image": {
                "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/6372c9c8b9cff519686397.jpg",
                "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_160_160_0_0_crop.jpg",
                "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_240_240_0_0_crop.jpg",
                "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_800_800_0_0_crop.jpg",
                "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_480_480_0_0_auto.jpg"
              },
              "images": [],
              "files": [],
              "ratings_count": 0,
              "countRating": 0,
              "sumRating": null,
              "averageRating": null,
              "user_is_rating": false,
              "user_object_rating": null,
              "favorites_count": 0,
              "user_is_favorite": false,
              "user_object_favorite": null,
              "object_type": "Nano\\Shop\\Models\\Product",
              "qty": 0,
              "children": {
                "data": [],
                "meta": {
                  "pagination": {
                    "total": 0,
                    "count": 0,
                    "per_page": 10,
                    "current_page": 1,
                    "total_pages": 1,
                    "links": []
                  }
                }
              },
              "prices_units": {
                "data": []
              }
            }
          ],
          "meta": {
            "pagination": {
              "total": 2,
              "count": 2,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      },
      {
        "id": 1580,
        "code": "24-47-1580",
        "barcode": "0-1580",
        "name": "رز مزه",
        "emblem": "",
        "short_description": "",
        "description": "",
        "users_manual": "",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "49",
        "is_offer": 0,
        "groups_products_id": "0",
        "companys_id": "24",
        "departments_id": "47",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "",
        "unpublished_at": "",
        "manage_stock": 0,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 1,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 1,
        "default_qty": 1,
        "old_price": 100,
        "price": 800,
        "is_show_old_price": 1,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 0,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1580,
        "created_at": "2023-08-13 18:29:37",
        "updated_at": "2023-08-13 19:11:19",
        "image": null,
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      }
    ]
  }
}
```

### Example 3 get List Tags With products isOffer 

**فى المثال التالي سنقوم بجلب العروض فقط التي تنتمي للهاشتاج الممرار **
```
GET http://localhost:8006/api/v1/tags/tags/47?include=products&isOffer=true
```

**لجلب العروض التابعه للهاشتاج الممر نقوم بتمرير المتغير isOffer**

```json
{
  "isOffer": true,
}
```
#### Response

** فى المثال التالي تم جلب العروض التابعه للهاشتاج الممرار **

```html
Status: 200 OK
```

```json
{
  "id": 47,
  "code": "2-4-47",
  "name": "المشروبات الساخنة",
  "slug": "almshrobat-alsakhn",
  "type": null,
  "user_id": null,
  "user_type": null,
  "companys_id": "2",
  "departments_id": "4",
  "is_public": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "properties": null,
  "created_at": "2022-11-09 15:48:18",
  "updated_at": "2022-11-09 15:48:18",
  "image": null,
  "images": [],
  "object_type": "Nano\\Tags\\Models\\Tag",
  "products": {
    "data": [
      {
        "id": 1576,
        "code": "2-2-1576",
        "barcode": "0-1576",
        "name": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "emblem": "",
        "short_description": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "description": "<p>عرض جديد حبه دجاج + نفر رز + سلطه<\/p>",
        "users_manual": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "3",
        "is_offer": 1,
        "groups_products_id": "0",
        "companys_id": "2",
        "departments_id": "2",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "2023-08-01 20:00:57",
        "unpublished_at": "2024-08-01 20:01:04",
        "manage_stock": 0,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 1,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 1,
        "default_qty": 1,
        "old_price": 3000,
        "price": 2500,
        "is_show_old_price": 1,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 0,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1576,
        "created_at": "2023-08-08 20:03:28",
        "updated_at": "2023-08-08 20:29:39",
        "image": null,
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      }
    ]
  }
}
```

### Example 4 get List Tags With products and isOffer (all)

**فى المثال التالي سنقوم بجلب  الاصناف والعروض التي تنتمي للهاشتاج الممرار **

```
GET http://localhost:8006/api/v1/tags/tags/47?include=products&isOffer=all
```

**لجلب العروض التابعه للهاشتاج الممر نقوم بتمرير المتغير isOffer**

```json
{
  "include": products,
  "isOffer": all,
}
```
#### Response

** فى المثال التالي تم جلب العروض والاصناف التابعه للهاشتاج الممرار **

```html
Status: 200 OK
```

```json
{
  "id": 47,
  "code": "2-4-47",
  "name": "المشروبات الساخنة",
  "slug": "almshrobat-alsakhn",
  "type": null,
  "user_id": null,
  "user_type": null,
  "companys_id": "2",
  "departments_id": "4",
  "is_public": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "properties": null,
  "created_at": "2022-11-09 15:48:18",
  "updated_at": "2022-11-09 15:48:18",
  "image": null,
  "images": [],
  "object_type": "Nano\\Tags\\Models\\Tag",
  "products": {
    "data": [
      {
        "id": 1430,
        "code": "2-2-1430",
        "barcode": "0-1430",
        "name": "شاهي",
        "emblem": "",
        "short_description": "",
        "description": "",
        "users_manual": "",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "3",
        "is_offer": 0,
        "groups_products_id": "0",
        "companys_id": "2",
        "departments_id": "2",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "",
        "unpublished_at": "",
        "manage_stock": 1,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 100,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 100,
        "default_qty": 1,
        "old_price": 0,
        "price": 50,
        "is_show_old_price": 0,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 1,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1430,
        "created_at": "2022-11-09 15:53:47",
        "updated_at": "2023-08-09 13:59:03",
        "image": {
          "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/636bccf4b203d617442273.jpg",
          "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_160_160_0_0_crop.jpg",
          "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_240_240_0_0_crop.jpg",
          "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_800_800_0_0_crop.jpg",
          "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_480_480_0_0_auto.jpg"
        },
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [
            {
              "id": 1431,
              "code": "2-2-1431",
              "barcode": "0-1431",
              "name": "شاهي احمر",
              "emblem": "شاهي",
              "short_description": "شاهي احمر",
              "description": "<p>شاهي احمر<\/p>",
              "users_manual": "دليل الاستخدام",
              "composition": "التركيبة",
              "indication": "الامور الاخري المتعلقة بالصنف",
              "meta_title": "شاهي",
              "meta_description": "وصف للبحث",
              "keywords": "كلمات مفتاحية",
              "ref_type_class": "products",
              "ref_key_values_class": "3",
              "is_offer": 0,
              "groups_products_id": "0",
              "companys_id": "2",
              "departments_id": "2",
              "is_effective": 1,
              "is_default": null,
              "is_active": 1,
              "is_published": 0,
              "published_at": "",
              "unpublished_at": "",
              "manage_stock": 1,
              "shop_stock": 1,
              "min_qty": 1,
              "max_qty": 100,
              "min_qty_in_stock": 1,
              "max_qty_in_stock": 100,
              "default_qty": 1,
              "old_price": 0,
              "price": 50,
              "is_show_old_price": 0,
              "is_parleying": 1,
              "is_sold": 1,
              "is_purchased": 1,
              "is_composite": 0,
              "is_units": 1,
              "is_downloadable": 1,
              "properties": [
                {
                  "title": "الاضافات",
                  "code": "extention",
                  "value": "10",
                  "is_default": "1",
                  "is_show": "1",
                  "sort_show": "1",
                  "_group": "properties"
                }
              ],
              "links": [
                {
                  "title": "url",
                  "url": "test.com",
                  "target": "_blank",
                  "sort_show": "1",
                  "is_download": "0",
                  "is_default": "1",
                  "is_show": "1",
                  "_group": "links"
                }
              ],
              "other_data": null,
              "config_data": null,
              "sort_order": 1431,
              "created_at": "2022-11-09 15:54:58",
              "updated_at": "2023-07-15 00:31:17",
              "image": {
                "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/636bcd2f87ee1059528054.jpg",
                "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_160_160_0_0_crop.jpg",
                "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_240_240_0_0_crop.jpg",
                "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_800_800_0_0_crop.jpg",
                "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_480_480_0_0_auto.jpg"
              },
              "images": [],
              "files": [],
              "ratings_count": 0,
              "countRating": 0,
              "sumRating": null,
              "averageRating": null,
              "user_is_rating": false,
              "user_object_rating": null,
              "favorites_count": 0,
              "user_is_favorite": false,
              "user_object_favorite": null,
              "object_type": "Nano\\Shop\\Models\\Product",
              "qty": 0,
              "children": {
                "data": [],
                "meta": {
                  "pagination": {
                    "total": 0,
                    "count": 0,
                    "per_page": 10,
                    "current_page": 1,
                    "total_pages": 1,
                    "links": []
                  }
                }
              },
              "prices_units": {
                "data": []
              }
            },
            {
              "id": 1432,
              "code": "2-2-1432",
              "barcode": "0-1432",
              "name": "شاهي حليب",
              "emblem": "",
              "short_description": "",
              "description": "",
              "users_manual": "",
              "composition": "",
              "indication": "",
              "meta_title": "",
              "meta_description": "",
              "keywords": "",
              "ref_type_class": "products",
              "ref_key_values_class": "3",
              "is_offer": 0,
              "groups_products_id": "0",
              "companys_id": "2",
              "departments_id": "2",
              "is_effective": 1,
              "is_default": null,
              "is_active": 1,
              "is_published": 0,
              "published_at": "",
              "unpublished_at": "",
              "manage_stock": 1,
              "shop_stock": 0,
              "min_qty": 1,
              "max_qty": 100,
              "min_qty_in_stock": 1,
              "max_qty_in_stock": 100,
              "default_qty": 1,
              "old_price": 0,
              "price": 100,
              "is_show_old_price": 0,
              "is_parleying": 1,
              "is_sold": 1,
              "is_purchased": 1,
              "is_composite": 0,
              "is_units": 1,
              "is_downloadable": 1,
              "properties": null,
              "links": null,
              "other_data": null,
              "config_data": null,
              "sort_order": 1432,
              "created_at": "2022-11-09 15:55:41",
              "updated_at": "2023-08-08 19:58:38",
              "image": {
                "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/6372c9c8b9cff519686397.jpg",
                "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_160_160_0_0_crop.jpg",
                "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_240_240_0_0_crop.jpg",
                "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_800_800_0_0_crop.jpg",
                "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_480_480_0_0_auto.jpg"
              },
              "images": [],
              "files": [],
              "ratings_count": 0,
              "countRating": 0,
              "sumRating": null,
              "averageRating": null,
              "user_is_rating": false,
              "user_object_rating": null,
              "favorites_count": 0,
              "user_is_favorite": false,
              "user_object_favorite": null,
              "object_type": "Nano\\Shop\\Models\\Product",
              "qty": 0,
              "children": {
                "data": [],
                "meta": {
                  "pagination": {
                    "total": 0,
                    "count": 0,
                    "per_page": 10,
                    "current_page": 1,
                    "total_pages": 1,
                    "links": []
                  }
                }
              },
              "prices_units": {
                "data": []
              }
            }
          ],
          "meta": {
            "pagination": {
              "total": 2,
              "count": 2,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      },
      {
        "id": 1576,
        "code": "2-2-1576",
        "barcode": "0-1576",
        "name": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "emblem": "",
        "short_description": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "description": "<p>عرض جديد حبه دجاج + نفر رز + سلطه<\/p>",
        "users_manual": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "3",
        "is_offer": 1,
        "groups_products_id": "0",
        "companys_id": "2",
        "departments_id": "2",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "2023-08-01 20:00:57",
        "unpublished_at": "2024-08-01 20:01:04",
        "manage_stock": 0,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 1,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 1,
        "default_qty": 1,
        "old_price": 3000,
        "price": 2500,
        "is_show_old_price": 1,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 0,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1576,
        "created_at": "2023-08-08 20:03:28",
        "updated_at": "2023-08-08 20:29:39",
        "image": null,
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      },
      {
        "id": 1580,
        "code": "24-47-1580",
        "barcode": "0-1580",
        "name": "رز مزه",
        "emblem": "",
        "short_description": "",
        "description": "",
        "users_manual": "",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "49",
        "is_offer": 0,
        "groups_products_id": "0",
        "companys_id": "24",
        "departments_id": "47",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "",
        "unpublished_at": "",
        "manage_stock": 0,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 1,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 1,
        "default_qty": 1,
        "old_price": 100,
        "price": 800,
        "is_show_old_price": 1,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 0,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1580,
        "created_at": "2023-08-13 18:29:37",
        "updated_at": "2023-08-13 19:11:19",
        "image": null,
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      }
    ]
  }
}
```

### Note
**يجب ملاحظه انه عند تضمين العلاقه التابعه للاصناف products انه يتم ارجاع الاصناف من كافه الفروع او المحلات ولتحديد محل معين يجب تمرير رقم المحل او الفرع ضمن الطلب كالتالي **

```
GET http://localhost:8006/api/v1/tags/tags/47?include=products&isOffer=all&departments_id=4
```

```json
{
  "include": products,
  "isOffer": all,
  "departments_id": 4,
}
```

#### Response

**النتيجه فى حالة تمرير رقم المتجر او الفرع **

```
GET http://localhost:8006/api/v1/tags/tags/47?include=products&isOffer=all&departments_id=4
```

```html
Status: 200 OK
```

```json
{
  "id": 47,
  "code": "2-4-47",
  "name": "المشروبات الساخنة",
  "slug": "almshrobat-alsakhn",
  "type": null,
  "user_id": null,
  "user_type": null,
  "companys_id": "2",
  "departments_id": "4",
  "is_public": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "properties": null,
  "created_at": "2022-11-09 15:48:18",
  "updated_at": "2022-11-09 15:48:18",
  "image": null,
  "images": [],
  "object_type": "Nano\\Tags\\Models\\Tag",
  "products": {
    "data": [
      {
        "id": 1430,
        "code": "2-2-1430",
        "barcode": "0-1430",
        "name": "شاهي",
        "emblem": "",
        "short_description": "",
        "description": "",
        "users_manual": "",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "3",
        "is_offer": 0,
        "groups_products_id": "0",
        "companys_id": "2",
        "departments_id": "2",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "",
        "unpublished_at": "",
        "manage_stock": 1,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 100,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 100,
        "default_qty": 1,
        "old_price": 0,
        "price": 50,
        "is_show_old_price": 0,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 1,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1430,
        "created_at": "2022-11-09 15:53:47",
        "updated_at": "2023-08-09 13:59:03",
        "image": {
          "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/636bccf4b203d617442273.jpg",
          "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_160_160_0_0_crop.jpg",
          "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_240_240_0_0_crop.jpg",
          "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_800_800_0_0_crop.jpg",
          "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_480_480_0_0_auto.jpg"
        },
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [
            {
              "id": 1431,
              "code": "2-2-1431",
              "barcode": "0-1431",
              "name": "شاهي احمر",
              "emblem": "شاهي",
              "short_description": "شاهي احمر",
              "description": "<p>شاهي احمر<\/p>",
              "users_manual": "دليل الاستخدام",
              "composition": "التركيبة",
              "indication": "الامور الاخري المتعلقة بالصنف",
              "meta_title": "شاهي",
              "meta_description": "وصف للبحث",
              "keywords": "كلمات مفتاحية",
              "ref_type_class": "products",
              "ref_key_values_class": "3",
              "is_offer": 0,
              "groups_products_id": "0",
              "companys_id": "2",
              "departments_id": "2",
              "is_effective": 1,
              "is_default": null,
              "is_active": 1,
              "is_published": 0,
              "published_at": "",
              "unpublished_at": "",
              "manage_stock": 1,
              "shop_stock": 1,
              "min_qty": 1,
              "max_qty": 100,
              "min_qty_in_stock": 1,
              "max_qty_in_stock": 100,
              "default_qty": 1,
              "old_price": 0,
              "price": 50,
              "is_show_old_price": 0,
              "is_parleying": 1,
              "is_sold": 1,
              "is_purchased": 1,
              "is_composite": 0,
              "is_units": 1,
              "is_downloadable": 1,
              "properties": [
                {
                  "title": "الاضافات",
                  "code": "extention",
                  "value": "10",
                  "is_default": "1",
                  "is_show": "1",
                  "sort_show": "1",
                  "_group": "properties"
                }
              ],
              "links": [
                {
                  "title": "url",
                  "url": "test.com",
                  "target": "_blank",
                  "sort_show": "1",
                  "is_download": "0",
                  "is_default": "1",
                  "is_show": "1",
                  "_group": "links"
                }
              ],
              "other_data": null,
              "config_data": null,
              "sort_order": 1431,
              "created_at": "2022-11-09 15:54:58",
              "updated_at": "2023-07-15 00:31:17",
              "image": {
                "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/636bcd2f87ee1059528054.jpg",
                "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_160_160_0_0_crop.jpg",
                "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_240_240_0_0_crop.jpg",
                "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_800_800_0_0_crop.jpg",
                "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_480_480_0_0_auto.jpg"
              },
              "images": [],
              "files": [],
              "ratings_count": 0,
              "countRating": 0,
              "sumRating": null,
              "averageRating": null,
              "user_is_rating": false,
              "user_object_rating": null,
              "favorites_count": 0,
              "user_is_favorite": false,
              "user_object_favorite": null,
              "object_type": "Nano\\Shop\\Models\\Product",
              "qty": 0,
              "children": {
                "data": [],
                "meta": {
                  "pagination": {
                    "total": 0,
                    "count": 0,
                    "per_page": 10,
                    "current_page": 1,
                    "total_pages": 1,
                    "links": []
                  }
                }
              },
              "prices_units": {
                "data": []
              }
            },
            {
              "id": 1432,
              "code": "2-2-1432",
              "barcode": "0-1432",
              "name": "شاهي حليب",
              "emblem": "",
              "short_description": "",
              "description": "",
              "users_manual": "",
              "composition": "",
              "indication": "",
              "meta_title": "",
              "meta_description": "",
              "keywords": "",
              "ref_type_class": "products",
              "ref_key_values_class": "3",
              "is_offer": 0,
              "groups_products_id": "0",
              "companys_id": "2",
              "departments_id": "2",
              "is_effective": 1,
              "is_default": null,
              "is_active": 1,
              "is_published": 0,
              "published_at": "",
              "unpublished_at": "",
              "manage_stock": 1,
              "shop_stock": 0,
              "min_qty": 1,
              "max_qty": 100,
              "min_qty_in_stock": 1,
              "max_qty_in_stock": 100,
              "default_qty": 1,
              "old_price": 0,
              "price": 100,
              "is_show_old_price": 0,
              "is_parleying": 1,
              "is_sold": 1,
              "is_purchased": 1,
              "is_composite": 0,
              "is_units": 1,
              "is_downloadable": 1,
              "properties": null,
              "links": null,
              "other_data": null,
              "config_data": null,
              "sort_order": 1432,
              "created_at": "2022-11-09 15:55:41",
              "updated_at": "2023-08-08 19:58:38",
              "image": {
                "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/6372c9c8b9cff519686397.jpg",
                "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_160_160_0_0_crop.jpg",
                "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_240_240_0_0_crop.jpg",
                "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_800_800_0_0_crop.jpg",
                "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_480_480_0_0_auto.jpg"
              },
              "images": [],
              "files": [],
              "ratings_count": 0,
              "countRating": 0,
              "sumRating": null,
              "averageRating": null,
              "user_is_rating": false,
              "user_object_rating": null,
              "favorites_count": 0,
              "user_is_favorite": false,
              "user_object_favorite": null,
              "object_type": "Nano\\Shop\\Models\\Product",
              "qty": 0,
              "children": {
                "data": [],
                "meta": {
                  "pagination": {
                    "total": 0,
                    "count": 0,
                    "per_page": 10,
                    "current_page": 1,
                    "total_pages": 1,
                    "links": []
                  }
                }
              },
              "prices_units": {
                "data": []
              }
            }
          ],
          "meta": {
            "pagination": {
              "total": 2,
              "count": 2,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      },
      {
        "id": 1576,
        "code": "2-2-1576",
        "barcode": "0-1576",
        "name": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "emblem": "",
        "short_description": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "description": "<p>عرض جديد حبه دجاج + نفر رز + سلطه<\/p>",
        "users_manual": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "3",
        "is_offer": 1,
        "groups_products_id": "0",
        "companys_id": "2",
        "departments_id": "2",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "2023-08-01 20:00:57",
        "unpublished_at": "2024-08-01 20:01:04",
        "manage_stock": 0,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 1,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 1,
        "default_qty": 1,
        "old_price": 3000,
        "price": 2500,
        "is_show_old_price": 1,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 0,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1576,
        "created_at": "2023-08-08 20:03:28",
        "updated_at": "2023-08-08 20:29:39",
        "image": null,
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      }
    ]
  }
}
```

**النتيجه فى حالة عدم تمرير رقم المتجر او الفرع **

```
GET http://localhost:8006/api/v1/tags/tags/47?include=products&isOffer=all
```

```html
Status: 200 OK
```

```json
{
  "id": 47,
  "code": "2-4-47",
  "name": "المشروبات الساخنة",
  "slug": "almshrobat-alsakhn",
  "type": null,
  "user_id": null,
  "user_type": null,
  "companys_id": "2",
  "departments_id": "4",
  "is_public": 1,
  "is_default": 0,
  "is_active": 1,
  "is_published": 1,
  "published_at": "",
  "unpublished_at": "",
  "properties": null,
  "created_at": "2022-11-09 15:48:18",
  "updated_at": "2022-11-09 15:48:18",
  "image": null,
  "images": [],
  "object_type": "Nano\\Tags\\Models\\Tag",
  "products": {
    "data": [
      {
        "id": 1430,
        "code": "2-2-1430",
        "barcode": "0-1430",
        "name": "شاهي",
        "emblem": "",
        "short_description": "",
        "description": "",
        "users_manual": "",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "3",
        "is_offer": 0,
        "groups_products_id": "0",
        "companys_id": "2",
        "departments_id": "2",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "",
        "unpublished_at": "",
        "manage_stock": 1,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 100,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 100,
        "default_qty": 1,
        "old_price": 0,
        "price": 50,
        "is_show_old_price": 0,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 1,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1430,
        "created_at": "2022-11-09 15:53:47",
        "updated_at": "2023-08-09 13:59:03",
        "image": {
          "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/636bccf4b203d617442273.jpg",
          "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_160_160_0_0_crop.jpg",
          "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_240_240_0_0_crop.jpg",
          "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_800_800_0_0_crop.jpg",
          "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcc\/f4b\/thumb_1383_480_480_0_0_auto.jpg"
        },
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [
            {
              "id": 1431,
              "code": "2-2-1431",
              "barcode": "0-1431",
              "name": "شاهي احمر",
              "emblem": "شاهي",
              "short_description": "شاهي احمر",
              "description": "<p>شاهي احمر<\/p>",
              "users_manual": "دليل الاستخدام",
              "composition": "التركيبة",
              "indication": "الامور الاخري المتعلقة بالصنف",
              "meta_title": "شاهي",
              "meta_description": "وصف للبحث",
              "keywords": "كلمات مفتاحية",
              "ref_type_class": "products",
              "ref_key_values_class": "3",
              "is_offer": 0,
              "groups_products_id": "0",
              "companys_id": "2",
              "departments_id": "2",
              "is_effective": 1,
              "is_default": null,
              "is_active": 1,
              "is_published": 0,
              "published_at": "",
              "unpublished_at": "",
              "manage_stock": 1,
              "shop_stock": 1,
              "min_qty": 1,
              "max_qty": 100,
              "min_qty_in_stock": 1,
              "max_qty_in_stock": 100,
              "default_qty": 1,
              "old_price": 0,
              "price": 50,
              "is_show_old_price": 0,
              "is_parleying": 1,
              "is_sold": 1,
              "is_purchased": 1,
              "is_composite": 0,
              "is_units": 1,
              "is_downloadable": 1,
              "properties": [
                {
                  "title": "الاضافات",
                  "code": "extention",
                  "value": "10",
                  "is_default": "1",
                  "is_show": "1",
                  "sort_show": "1",
                  "_group": "properties"
                }
              ],
              "links": [
                {
                  "title": "url",
                  "url": "test.com",
                  "target": "_blank",
                  "sort_show": "1",
                  "is_download": "0",
                  "is_default": "1",
                  "is_show": "1",
                  "_group": "links"
                }
              ],
              "other_data": null,
              "config_data": null,
              "sort_order": 1431,
              "created_at": "2022-11-09 15:54:58",
              "updated_at": "2023-07-15 00:31:17",
              "image": {
                "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/636bcd2f87ee1059528054.jpg",
                "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_160_160_0_0_crop.jpg",
                "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_240_240_0_0_crop.jpg",
                "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_800_800_0_0_crop.jpg",
                "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/636\/bcd\/2f8\/thumb_1384_480_480_0_0_auto.jpg"
              },
              "images": [],
              "files": [],
              "ratings_count": 0,
              "countRating": 0,
              "sumRating": null,
              "averageRating": null,
              "user_is_rating": false,
              "user_object_rating": null,
              "favorites_count": 0,
              "user_is_favorite": false,
              "user_object_favorite": null,
              "object_type": "Nano\\Shop\\Models\\Product",
              "qty": 0,
              "children": {
                "data": [],
                "meta": {
                  "pagination": {
                    "total": 0,
                    "count": 0,
                    "per_page": 10,
                    "current_page": 1,
                    "total_pages": 1,
                    "links": []
                  }
                }
              },
              "prices_units": {
                "data": []
              }
            },
            {
              "id": 1432,
              "code": "2-2-1432",
              "barcode": "0-1432",
              "name": "شاهي حليب",
              "emblem": "",
              "short_description": "",
              "description": "",
              "users_manual": "",
              "composition": "",
              "indication": "",
              "meta_title": "",
              "meta_description": "",
              "keywords": "",
              "ref_type_class": "products",
              "ref_key_values_class": "3",
              "is_offer": 0,
              "groups_products_id": "0",
              "companys_id": "2",
              "departments_id": "2",
              "is_effective": 1,
              "is_default": null,
              "is_active": 1,
              "is_published": 0,
              "published_at": "",
              "unpublished_at": "",
              "manage_stock": 1,
              "shop_stock": 0,
              "min_qty": 1,
              "max_qty": 100,
              "min_qty_in_stock": 1,
              "max_qty_in_stock": 100,
              "default_qty": 1,
              "old_price": 0,
              "price": 100,
              "is_show_old_price": 0,
              "is_parleying": 1,
              "is_sold": 1,
              "is_purchased": 1,
              "is_composite": 0,
              "is_units": 1,
              "is_downloadable": 1,
              "properties": null,
              "links": null,
              "other_data": null,
              "config_data": null,
              "sort_order": 1432,
              "created_at": "2022-11-09 15:55:41",
              "updated_at": "2023-08-08 19:58:38",
              "image": {
                "original": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/6372c9c8b9cff519686397.jpg",
                "small": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_160_160_0_0_crop.jpg",
                "medium": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_240_240_0_0_crop.jpg",
                "large": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_800_800_0_0_crop.jpg",
                "thumb": "https:\/\/alnaeem.nano2soft.com\/storage\/app\/uploads\/public\/637\/2c9\/c8b\/thumb_1473_480_480_0_0_auto.jpg"
              },
              "images": [],
              "files": [],
              "ratings_count": 0,
              "countRating": 0,
              "sumRating": null,
              "averageRating": null,
              "user_is_rating": false,
              "user_object_rating": null,
              "favorites_count": 0,
              "user_is_favorite": false,
              "user_object_favorite": null,
              "object_type": "Nano\\Shop\\Models\\Product",
              "qty": 0,
              "children": {
                "data": [],
                "meta": {
                  "pagination": {
                    "total": 0,
                    "count": 0,
                    "per_page": 10,
                    "current_page": 1,
                    "total_pages": 1,
                    "links": []
                  }
                }
              },
              "prices_units": {
                "data": []
              }
            }
          ],
          "meta": {
            "pagination": {
              "total": 2,
              "count": 2,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      },
      {
        "id": 1576,
        "code": "2-2-1576",
        "barcode": "0-1576",
        "name": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "emblem": "",
        "short_description": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "description": "<p>عرض جديد حبه دجاج + نفر رز + سلطه<\/p>",
        "users_manual": "عرض جديد حبه دجاج + نفر رز + سلطه",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "3",
        "is_offer": 1,
        "groups_products_id": "0",
        "companys_id": "2",
        "departments_id": "2",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "2023-08-01 20:00:57",
        "unpublished_at": "2024-08-01 20:01:04",
        "manage_stock": 0,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 1,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 1,
        "default_qty": 1,
        "old_price": 3000,
        "price": 2500,
        "is_show_old_price": 1,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 0,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1576,
        "created_at": "2023-08-08 20:03:28",
        "updated_at": "2023-08-08 20:29:39",
        "image": null,
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      },
      {
        "id": 1580,
        "code": "24-47-1580",
        "barcode": "0-1580",
        "name": "رز مزه",
        "emblem": "",
        "short_description": "",
        "description": "",
        "users_manual": "",
        "composition": "",
        "indication": "",
        "meta_title": "",
        "meta_description": "",
        "keywords": "",
        "ref_type_class": "products",
        "ref_key_values_class": "49",
        "is_offer": 0,
        "groups_products_id": "0",
        "companys_id": "24",
        "departments_id": "47",
        "is_effective": 1,
        "is_default": null,
        "is_active": 1,
        "is_published": 1,
        "published_at": "",
        "unpublished_at": "",
        "manage_stock": 0,
        "shop_stock": 0,
        "min_qty": 1,
        "max_qty": 1,
        "min_qty_in_stock": 1,
        "max_qty_in_stock": 1,
        "default_qty": 1,
        "old_price": 100,
        "price": 800,
        "is_show_old_price": 1,
        "is_parleying": 1,
        "is_sold": 1,
        "is_purchased": 1,
        "is_composite": 0,
        "is_units": 0,
        "is_downloadable": 1,
        "properties": null,
        "links": null,
        "other_data": null,
        "config_data": null,
        "sort_order": 1580,
        "created_at": "2023-08-13 18:29:37",
        "updated_at": "2023-08-13 19:11:19",
        "image": null,
        "images": [],
        "files": [],
        "ratings_count": 0,
        "countRating": 0,
        "sumRating": null,
        "averageRating": null,
        "user_is_rating": false,
        "user_object_rating": null,
        "favorites_count": 0,
        "user_is_favorite": false,
        "user_object_favorite": null,
        "object_type": "Nano\\Shop\\Models\\Product",
        "qty": 0,
        "children": {
          "data": [],
          "meta": {
            "pagination": {
              "total": 0,
              "count": 0,
              "per_page": 10,
              "current_page": 1,
              "total_pages": 1,
              "links": []
            }
          }
        },
        "prices_units": {
          "data": []
        }
      }
    ]
  }
}
```

### Check Last Update Tags Daa 

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/tags/tags/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/tags/tags/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2022-12-16 17:27:15",
    "other_updated": {
      "activity_cache.tag": "2022-12-16 17:27:15",
      "activity_cache.department": "2022-12-16 16:29:28",
      "activity_cache.product": "2022-12-16 16:29:28",
      "activity_cache.taggable": "2022-12-16 17:27:15"
    }
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2022-12-16 17:27:15",
    "last_updated": "2022-12-16 17:27:15",
    "other_updated": {
      "activity_cache.tag": "2022-12-16 17:27:15",
      "activity_cache.department": "2022-12-16 16:29:28",
      "activity_cache.product": "2022-12-16 16:29:28",
      "activity_cache.taggable": "2022-12-16 17:27:15"
    }
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **

