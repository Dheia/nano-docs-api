http://localhost:8006/api/v1/me?include=all_preferences

{
  "id": 4,
  "name": "admin2",
  "surname": "admin2",
  "username": "admin2",
  "email": "admin2@admin.com",
  "mobile": "",
  "gender": "",
  "date_of_birth": "",
  "address_1": "",
  "address_2": "",
  "street_name": "",
  "street_number": "",
  "latitude": 0,
  "longitude": 0,
  "geo_components": [],
  "city": "",
  "zip": "",
  "postcode": "",
  "country_long": "",
  "country_id": "",
  "state_id": "",
  "directorate_id": "",
  "formataddress": "",
  "vicinity": "",
  "avatar": {
    "original": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/630\/66e\/2e5\/63066e2e570fb857228283.png",
    "small": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/630\/66e\/2e5\/thumb_561_160_160_0_0_crop.png",
    "medium": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/630\/66e\/2e5\/thumb_561_240_240_0_0_crop.png",
    "large": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/630\/66e\/2e5\/thumb_561_800_800_0_0_crop.png",
    "thumb": "http:\/\/localhost:8006\/storage\/app\/uploads\/public\/630\/66e\/2e5\/thumb_561_480_480_0_0_auto.png"
  },
  "companys_id": "2",
  "departments_id": "2",
  "employees_id": "1",
  "ref_type": "",
  "ref_id": "",
  "permissions": [
    ""
  ],
  "is_guest": 0,
  "is_superuser": 1,
  "is_activated": 1,
  "activated_at": "",
  "last_login": "2023-11-02 17:32:00",
  "created_at": "2019-09-25 15:07:24",
  "updated_at": "2023-11-02 17:32:00",
  "deleted_at": "",
  "created_ip_address": "",
  "last_ip_address": "",
  "is_delivery": 0,
  "provider": "backend",
  "ratings_count": 0,
  "countRating": 0,
  "sumRating": 0,
  "averageRating": 0,
  "user_is_rating": 0,
  "user_object_rating": null,
  "favorites_count": 0,
  "user_is_favorite": 0,
  "likes_count": 0,
  "bookmarks_count": 0,
  "reactions_count": 0,
  "object_type": "Backend\\Models\\User",
  "all_preferences": {
    "backend_reportwidgets_Pepoles": {
      "welcome": {
        "class": "Tss\\Basic\\ReportWidgets\\WelcomePepoles",
        "sortOrder": 50,
        "configuration": {
          "title": "مرحبا بكم في ادارة الأشخاص",
          "ocWidgetWidth": 10,
          "ocWidgetNewRow": null
        }
      }
    },
    "backend_reportwidgets_dashboard": {
      "report_container_dashboard_10": {
        "class": "FszTeam\\MPosts\\ReportWidgets\\Posts",
        "configuration": {
          "title": "MPosts - Posts",
          "total": 0,
          "active": 0,
          "inactive": true,
          "draft": true,
          "category": true,
          "ocWidgetWidth": "12",
          "ocWidgetNewRow": null
        },
        "sortOrder": 77
      },
      "report_container_dashboard_11": {
        "class": "FszTeam\\MPosts\\ReportWidgets\\NewPosts",
        "configuration": {
          "title": "fszteam.mposts::lang.widget.newposts",
          "piece": 5,
          "date": true,
          "rank": false,
          "ocWidgetWidth": "12"
        },
        "sortOrder": 78
      },
      "report_container_dashboard_12": {
        "class": "Tss\\Absence\\ReportWidgets\\Logs",
        "configuration": {
          "title": "tss.absence::lang.widgets.logs.label",
          "access": true,
          "event": true,
          "request": true,
          "total": true,
          "ocWidgetWidth": "12"
        },
        "sortOrder": 79
      },
      "report_container_dashboard_13": {
        "class": "Tss\\Absence\\ReportWidgets\\Cache",
        "configuration": {
          "title": "tss.absence::lang.widgets.cache.label",
          "ocWidgetWidth": "12"
        },
        "sortOrder": 80
      },
      "report_container_dashboard_8": {
        "class": "Tss\\school\\ReportWidgets\\WelcomeSchoolReport",
        "configuration": {
          "title": "tss.school::lang.ReportWidget.welcome_report.widget_title_default",
          "ocWidgetWidth": "12"
        },
        "sortOrder": 81
      },
      "report_container_dashboard_15": {
        "class": "Romanov\\ClearCacheWidget\\ReportWidgets\\ClearCache",
        "configuration": {
          "title": "romanov.clearcachewidget::lang.plugin.label",
          "radius": "200",
          "delthumbs": false,
          "ocWidgetWidth": "12"
        },
        "sortOrder": 83
      },
      "report_container_dashboard_21": {
        "class": "Jacob\\Logbook\\ReportWidgets\\LogBookModelChanges",
        "configuration": {
          "limitPerPage": 20,
          "ocWidgetWidth": "12",
          "ocWidgetNewRow": null
        },
        "sortOrder": 89
      },
      "report_container_dashboard_16": {
        "class": "Nano\\ActivityLog\\ReportWidgets\\Onboarding",
        "configuration": {
          "title": "التحقق من كافه الخطوات الاساسيه فى النظام ",
          "ocWidgetWidth": "5",
          "ocWidgetNewRow": null
        },
        "sortOrder": 92
      },
      "report_container_dashboard_14": {
        "class": "Nano\\ClearCacheWidget\\ReportWidgets\\ClearCache",
        "configuration": {
          "title": "File cache",
          "radius": "200",
          "delthumbs": 0,
          "ocWidgetWidth": "7",
          "ocWidgetNewRow": null,
          "nochart": null,
          "thumbspath": null,
          "thumb_regex": null
        },
        "sortOrder": 94
      },
      "report_container_dashboard_22": {
        "class": "Tss\\SmallContactForm\\ReportWidgets\\Messages",
        "configuration": {
          "ocWidgetWidth": "2",
          "ocWidgetNewRow": null
        },
        "sortOrder": 98
      },
      "report_container_dashboard_20": {
        "class": "Tss\\SmallContactForm\\ReportWidgets\\NewMessage",
        "configuration": {
          "ocWidgetWidth": "2",
          "ocWidgetNewRow": null
        },
        "sortOrder": 99
      },
      "report_container_dashboard_17": {
        "class": "Tss\\Reportcharts\\ReportWidgets\\Charts",
        "configuration": {
          "title": "tss.reportcharts::lang.report_widgets.charts.title",
          "rangeFormat": "MMMM D, YYYY",
          "ocWidgetWidth": "12"
        },
        "sortOrder": 106
      },
      "report_container_dashboard_23": {
        "class": "Tss\\Reportcharts\\ReportWidgets\\StatisticsPlus",
        "configuration": {
          "title": " تقارير  احصائيه متقدمة ",
          "context": "nano.orders::ordes_cancel",
          "range": "year",
          "ocWidgetWidth": "2",
          "ocWidgetNewRow": 0
        },
        "sortOrder": 108
      },
      "report_container_dashboard_18": {
        "class": "Tss\\Reportcharts\\ReportWidgets\\StatisticsPlus",
        "configuration": {
          "title": " تقارير  احصائيه متقدمة ",
          "context": "nano.orders::ordes_complete",
          "range": "last_month",
          "ocWidgetWidth": "2",
          "ocWidgetNewRow": null
        },
        "sortOrder": 109
      },
      "report_container_dashboard_25": {
        "class": "Tss\\Reportcharts\\ReportWidgets\\StatisticsPlus",
        "configuration": {
          "title": " تقارير  احصائيه متقدمة ",
          "context": "nano.orders::ordes_new",
          "range": "day",
          "ocWidgetWidth": "2",
          "ocWidgetNewRow": null
        },
        "sortOrder": 110
      },
      "report_container_dashboard_26": {
        "class": "Tss\\Reportcharts\\ReportWidgets\\StatisticsPlus",
        "configuration": {
          "title": " تقارير  احصائيه متقدمة ",
          "context": "nano.orders::ordes_delivery",
          "range": "day",
          "ocWidgetWidth": "2",
          "ocWidgetNewRow": null
        },
        "sortOrder": 111
      },
      "report_container_dashboard_19": {
        "class": "Tss\\Reportcharts\\ReportWidgets\\Charts",
        "configuration": {
          "title": "تقارير مخططات احصائيه ",
          "ocWidgetWidth": "12",
          "ocWidgetNewRow": null
        },
        "sortOrder": 112
      },
      "report_container_dashboard_27": {
        "class": "Nano\\ActivityLog\\ReportWidgets\\RWActivities",
        "configuration": {
          "title": "الإشعارات",
          "count": 15,
          "ocWidgetWidth": "12",
          "ocWidgetNewRow": null
        },
        "sortOrder": 114
      },
      "report_container_dashboard_24": {
        "class": "Tss\\Accounts\\ReportWidgets\\WelcomeAccounts",
        "configuration": {
          "title": "مرحبا في جزء الحسابات",
          "ocWidgetWidth": "6",
          "ocWidgetNewRow": null
        },
        "sortOrder": 115
      },
      "report_container_dashboard_28": {
        "class": "System\\ReportWidgets\\Status",
        "configuration": {
          "title": "حالة النظام",
          "ocWidgetWidth": "6",
          "ocWidgetNewRow": null
        },
        "sortOrder": 116
      },
      "report_container_dashboard_29": {
        "class": "Indikator\\News\\ReportWidgets\\Posts",
        "configuration": {
          "title": "News - Posts",
          "total": true,
          "active": true,
          "inactive": true,
          "draft": true,
          "category": true,
          "ocWidgetWidth": "6",
          "ocWidgetNewRow": null
        },
        "sortOrder": 117
      },
      "report_container_dashboard_30": {
        "class": "Nano\\SecurityHeaders\\ReportWidgets\\CSPReports",
        "configuration": {
          "title": "CSP Violation Reports",
          "days": "30",
          "ocWidgetWidth": "12"
        },
        "sortOrder": 118
      }
    },
    "backend_reportwidgets_Config_accounts": {
      "welcome": {
        "class": "Tss\\Accounts\\ReportWidgets\\WelcomeConfigAccounts",
        "sortOrder": 50,
        "configuration": {
          "title": "مرحبا في جزء اعدادات الحسابات",
          "ocWidgetWidth": 10,
          "ocWidgetNewRow": null
        }
      }
    },
    "backend_reportwidgets_Accounts": {
      "report_container_Accounts_2": {
        "class": "Tss\\Student\\ReportWidgets\\WelcomeStudent",
        "configuration": {
          "title": "tss.student::lang.ReportWidget.welcome_student.widget_title_default",
          "ocWidgetWidth": "12"
        },
        "sortOrder": 51
      }
    },
    "backend_reportwidgets_absence": {
      "locale": "en",
      "fallback_locale": "en",
      "timezone": "UTC",
      "editor_font_size": "12",
      "editor_word_wrap": "fluid",
      "editor_code_folding": "manual",
      "editor_tab_size": "4",
      "editor_theme": "twilight",
      "editor_show_invisibles": "0",
      "editor_highlight_active_line": "1",
      "editor_use_hard_tabs": "0",
      "editor_show_gutter": "1",
      "editor_auto_closing": "0",
      "editor_autocompletion": "manual",
      "editor_enable_snippets": "0",
      "editor_display_indent_guides": "0",
      "editor_show_print_margin": "0",
      "rounded_avatar": "0",
      "topmenu_label": "0",
      "sidebar_description": "0",
      "sidebar_search": "0",
      "focus_searchfield": "0",
      "context_menu": "0",
      "virtual_keyboard": "0",
      "user_id": 4
    },
    "backend_reportwidgets_SchoolControl": {
      "welcome": {
        "class": "Tss\\SchoolControl\\ReportWidgets\\WelcomeSchoolControl",
        "sortOrder": "50",
        "configuration": {
          "title": "مرحبا في جزء كنتروال المدرسه",
          "ocWidgetWidth": "12",
          "ocWidgetNewRow": null
        }
      }
    },
    "backend_hints_hidden": {
      "system_eventlogs_hint": 1,
      "hint_manage_location": 1,
      "hint_manage_order": 1
    },
    "backend_backend_preferences": {
      "locale": "ar",
      "fallback_locale": "ar",
      "timezone": "Asia\/Aden",
      "editor_font_size": "12",
      "editor_word_wrap": "fluid",
      "editor_code_folding": "manual",
      "editor_tab_size": "4",
      "editor_theme": "twilight",
      "editor_show_invisibles": "0",
      "editor_highlight_active_line": "1",
      "editor_use_hard_tabs": "0",
      "editor_show_gutter": "1",
      "editor_auto_closing": "0",
      "editor_autocompletion": "manual",
      "editor_enable_snippets": "0",
      "editor_display_indent_guides": "0",
      "editor_show_print_margin": "0",
      "rounded_avatar": "1",
      "topmenu_label": "0",
      "sidebar_description": "0",
      "sidebar_search": "0",
      "focus_searchfield": "0",
      "context_menu": "0",
      "virtual_keyboard": "0",
      "user_id": 4
    },
    "backend_userroles_lists": {
      "visible": [
        "name",
        "description",
        "users_count"
      ],
      "order": [
        "name",
        "code",
        "description",
        "users_count"
      ],
      "per_page": "25"
    },
    "backend_users_lists": {
      "visible": [
        "login",
        "email",
        "groups",
        "role",
        "last_login",
        "is_activated",
        "inetis_is_banned",
        "companys_id",
        "departments_id",
        "employees_id",
        "mobile",
        "country_id",
        "state_id",
        "directorate_id"
      ],
      "order": [
        "first_name",
        "last_name",
        "full_name",
        "login",
        "email",
        "groups",
        "role",
        "last_login",
        "created_at",
        "updated_at",
        "deleted_at",
        "is_activated",
        "is_superuser",
        "inetis_is_banned",
        "companys_id",
        "departments_id",
        "employees_id",
        "mobile",
        "country_id",
        "state_id",
        "directorate_id"
      ],
      "per_page": "20"
    },
    "tss_absence_absences_lists": {
      "visible": [
        "student_id",
        "student_name",
        "class_id",
        "group_id",
        "year_id",
        "semster",
        "ref_type_class",
        "files_id",
        "month_num",
        "date_at",
        "absences_status",
        "absences_bacuse",
        "notes"
      ],
      "per_page": "20",
      "order": [
        "id",
        "student_id",
        "record_id",
        "student_name",
        "stages_id",
        "class_id",
        "group_id",
        "year_id",
        "semster",
        "ref_type_class",
        "files_id",
        "month_num",
        "month_number",
        "teacher_id",
        "date_at",
        "absences_status",
        "absences_bacuse",
        "is_published",
        "is_finality",
        "is_active",
        "notes",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ]
    },
    "tss_absence_absences_liststructure": {
      "visible": [
        "id",
        "student_id",
        "record_id",
        "student_name",
        "stages_id",
        "class_id",
        "group_id",
        "files_id",
        "date_at",
        "absences_status",
        "absences_bacuse"
      ],
      "order": [
        "id",
        "student_id",
        "record_id",
        "student_name",
        "stages_id",
        "class_id",
        "group_id",
        "year_id",
        "semster",
        "ref_type_class",
        "files_id",
        "month_num",
        "month_number",
        "teacher_id",
        "date_at",
        "absences_status",
        "absences_bacuse",
        "is_published",
        "is_finality",
        "is_active",
        "notes",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "per_page": 20
    },
    "tss_basic_tsstemplates_lists": {
      "visible": [
        "id",
        "name",
        "code",
        "type",
        "ref_type",
        "tsslayouts_id",
        "is_active",
        "is_default"
      ],
      "per_page": null
    },
    "tss_basic_employees_lists": {
      "visible": [
        "full_name",
        "employee_image",
        "gender",
        "address",
        "groups_class_id",
        "date_of_birth",
        "accounts_id",
        "passport_type",
        "passport_number",
        "specialties_id",
        "last_qualification",
        "degree"
      ],
      "per_page": "20",
      "order": [
        "id",
        "code",
        "full_name",
        "first_name",
        "last_name",
        "employee_image",
        "short_description",
        "description",
        "gender",
        "country_of_birth",
        "city_of_birth",
        "language",
        "nationality",
        "address",
        "country_id",
        "state_id",
        "admin_id",
        "groups_class_id",
        "departments_id",
        "date_of_birth",
        "accounts_id",
        "bank_acc_id",
        "currencys_id",
        "is_active",
        "status",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at",
        "passport_type",
        "passport_number",
        "specialties_id",
        "last_qualification",
        "degree"
      ]
    },
    "tss_basic_tsslayouts_lists": {
      "visible": [
        "name",
        "code",
        "type",
        "is_active",
        "is_default"
      ],
      "order": [
        "id",
        "name",
        "code",
        "companys_id",
        "departments_id",
        "type",
        "is_active",
        "is_default",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "per_page": null
    },
    "tss_basic_departments_liststructure": {
      "visible": [
        "id",
        "code",
        "name",
        "main_sub",
        "parent",
        "companys_id",
        "level",
        "short_description",
        "mobile",
        "address",
        "is_active",
        "tags_type_id"
      ],
      "order": [
        "id",
        "code",
        "name",
        "main_sub",
        "parent_id",
        "parent",
        "companys_id",
        "level",
        "short_description",
        "description",
        "mobile",
        "address",
        "country_id",
        "state_id",
        "meta_title",
        "meta_description",
        "keywords",
        "is_active",
        "status",
        "is_hidden",
        "is_default",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at",
        "tags_type_id",
        "address_1",
        "address_2",
        "street_name",
        "street_number",
        "latitude",
        "longitude",
        "city",
        "zip",
        "postcode"
      ],
      "per_page": 20
    },
    "tss_student_students_lists": {
      "visible": [
        "id",
        "full_name",
        "student_image",
        "gender",
        "address",
        "phone[0]['phone_number']",
        "accounts_id",
        "parent_id",
        "year_id",
        "is_active",
        "student_status",
        "state_id"
      ],
      "per_page": "20"
    },
    "tss_student_students_lists-records": {
      "visible": [
        "id",
        "student_id",
        "student_name",
        "class_id",
        "group_id",
        "year_id",
        "status_class",
        "status_mony",
        "status_books",
        "is_bus",
        "is_active"
      ],
      "order": [
        "id",
        "student_id",
        "student_name",
        "class_id",
        "group_id",
        "year_id",
        "status_class",
        "status_mony",
        "status_books",
        "is_bus",
        "is_active",
        "code",
        "status",
        "created_at",
        "updated_at",
        "deleted_at",
        "created_by"
      ],
      "per_page": "20"
    },
    "tss_schoolcontrol_examperiods_lists": {
      "visible": [
        "name",
        "year_id",
        "semster",
        "month_num",
        "short_description",
        "is_active"
      ],
      "per_page": "20"
    },
    "tss_schoolcontrol_committees_lists": {
      "visible": [
        "id",
        "name",
        "year_id",
        "semster",
        "month_num",
        "short_description",
        "is_active"
      ],
      "per_page": "20"
    },
    "tss_schoolcontrol_seatings_lists": {
      "visible": [
        "student_id",
        "student_name",
        "sitting_number",
        "class_id",
        "group_id",
        "year_id",
        "semster",
        "month_num",
        "exam_periods_id",
        "committees_id"
      ],
      "per_page": "20",
      "order": [
        "id",
        "code",
        "student_id",
        "record_id",
        "student_name",
        "sitting_number",
        "pin_number",
        "class_id",
        "group_id",
        "departments_id",
        "year_id",
        "semster",
        "month_num",
        "exam_periods_id",
        "committees_id",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ]
    },
    "tss_schoolcontrol_resultalls_lists": {
      "visible": [
        "student_id",
        "student_name",
        "class_id",
        "result",
        "sort"
      ],
      "per_page": "120"
    },
    "tss_schoolcontrol_studentmonthlyworkkashfs_lists": {
      "visible": [
        "id",
        "student_id",
        "class_id",
        "group_id",
        "subject_id",
        "year_id",
        "semster",
        "month_number",
        "exam_mark",
        "homework_mark",
        "attendance_mark",
        "oral_mark",
        "total",
        "total_avarg",
        "notes",
        "is_active",
        "month_num",
        "is_transfer"
      ],
      "per_page": "20"
    },
    "tss_studyyear_periods_lists": {
      "visible": [
        "name",
        "companys_id",
        "departments_id",
        "calendar_type",
        "from_date",
        "to_date",
        "short_description",
        "is_default",
        "is_active"
      ],
      "per_page": "20"
    },
    "tss_studyyear_months_lists": {
      "visible": [
        "name",
        "study_year_id",
        "semsters_id",
        "calendar_type",
        "from_date",
        "to_date",
        "short_description",
        "is_default",
        "is_active",
        "created_at"
      ],
      "order": [
        "id",
        "code",
        "name",
        "companys_id",
        "departments_id",
        "study_year_id",
        "semsters_id",
        "calendar_type",
        "from_date",
        "to_date",
        "short_description",
        "description",
        "is_default",
        "is_active",
        "status",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "per_page": "20"
    },
    "tss_studyyear_semsters_lists": {
      "visible": [
        "id",
        "name",
        "study_year_id",
        "is_default",
        "is_active"
      ],
      "order": [
        "id",
        "code",
        "name",
        "companys_id",
        "departments_id",
        "study_year_id",
        "calendar_type",
        "from_date",
        "to_date",
        "short_description",
        "description",
        "is_default",
        "is_active",
        "status",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "per_page": "20"
    },
    "tss_accounts_relays_lists": {
      "visible": [
        "button",
        "id",
        "transactions_type",
        "date_at",
        "TransactionDetail",
        "notes",
        "is_relay"
      ],
      "per_page": "5",
      "order": [
        "button",
        "id",
        "code",
        "companys_id",
        "periods_id",
        "departments_id",
        "cost_centers_id",
        "transactions_type",
        "paper_id",
        "date_at",
        "TransactionDetail",
        "notes",
        "cheque_number",
        "cheque_date_at",
        "cheque_date_worth",
        "cheque_date_end",
        "is_relay",
        "user_relay_id",
        "relay_date_at",
        "employees_id",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ]
    },
    "tss_accounts_payreceipts_lists": {
      "visible": [
        "button",
        "periods_id",
        "cost_centers_id",
        "transactions_type",
        "date_at",
        "TransactionDetail",
        "notes"
      ],
      "per_page": "25"
    },
    "tss_accounts_catchreceipts_lists": {
      "visible": [
        "button",
        "id",
        "code",
        "companys_id",
        "periods_id",
        "departments_id",
        "cost_centers_id",
        "transactions_type",
        "paper_id",
        "date_at",
        "TransactionDetail",
        "notes",
        "employees_id",
        "created_by",
        "created_at"
      ],
      "per_page": "25"
    },
    "tss_accounts_boxes_lists": {
      "visible": [
        "id",
        "code",
        "name",
        "companys_id",
        "departments_id",
        "accounts_id",
        "is_one_currency",
        "currencys_id",
        "short_description",
        "description",
        "is_hidden",
        "is_effective",
        "is_default",
        "is_active",
        "status",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "per_page": "20"
    },
    "tss_accounts_bondsdays_lists": {
      "visible": [
        "button",
        "id",
        "created_at",
        "cost_centers_id",
        "transactions_type",
        "notes",
        "date_at",
        "TransactionDetail",
        "is_relay2"
      ],
      "order": [
        "button",
        "id",
        "created_at",
        "code",
        "companys_id",
        "periods_id",
        "departments_id",
        "cost_centers_id",
        "transactions_type",
        "notes",
        "date_at",
        "TransactionDetail",
        "paper_id",
        "is_relay",
        "user_relay_id",
        "relay_date_at",
        "employees_id",
        "created_by",
        "updated_by",
        "updated_at",
        "is_relay2"
      ],
      "per_page": "5"
    },
    "tss_accounts_accounts_liststructure": {
      "visible": [
        "code",
        "account_number",
        "name",
        "description",
        "companys_id",
        "departments_id",
        "main_sub",
        "parent_id",
        "parent",
        "currencys_id",
        "level",
        "account_normal",
        "reports",
        "is_active",
        "status",
        "ref_type",
        "ref_key_name",
        "ref_key_values",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "order": [
        "id",
        "code",
        "account_number",
        "name",
        "description",
        "companys_id",
        "departments_id",
        "main_sub",
        "parent_id",
        "parent",
        "currencys_id",
        "level",
        "account_normal",
        "reports",
        "is_active",
        "status",
        "ref_type",
        "ref_key_name",
        "ref_key_values",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "per_page": 20
    },
    "tss_accounts_partners_lists": {
      "visible": [
        "full_name",
        "short_description",
        "gender",
        "country_of_birth",
        "city_of_birth",
        "date_of_birth",
        "language",
        "nationality",
        "address",
        "country_id",
        "state_id",
        "groups_class_id",
        "departments_id",
        "accounts_id",
        "bank_acc_id",
        "is_active"
      ],
      "order": [
        "id",
        "code",
        "full_name",
        "first_name",
        "last_name",
        "short_description",
        "description",
        "gender",
        "country_of_birth",
        "city_of_birth",
        "date_of_birth",
        "language",
        "nationality",
        "address",
        "country_id",
        "state_id",
        "groups_class_id",
        "departments_id",
        "accounts_id",
        "bank_acc_id",
        "currencys_id",
        "is_active",
        "status",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "per_page": "20"
    },
    "tss_accounts_banks_lists": {
      "visible": [
        "name",
        "companys_id",
        "departments_id",
        "accounts_id",
        "bank_accounts",
        "is_one_currency",
        "currencys_id",
        "short_description",
        "description",
        "address",
        "country_id",
        "state_id",
        "location",
        "is_hidden",
        "is_effective",
        "is_active"
      ],
      "order": [
        "id",
        "code",
        "name",
        "companys_id",
        "departments_id",
        "accounts_id",
        "bank_accounts",
        "is_one_currency",
        "currencys_id",
        "short_description",
        "description",
        "address",
        "country_id",
        "state_id",
        "location",
        "is_hidden",
        "is_effective",
        "is_default",
        "is_active",
        "status",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "per_page": "20"
    },
    "tss_accounts_debitnotes_lists": {
      "visible": [
        "button",
        "cost_centers_id",
        "transactions_type",
        "date_at",
        "TransactionDetail",
        "notes"
      ],
      "order": [
        "button",
        "id",
        "code",
        "companys_id",
        "periods_id",
        "departments_id",
        "cost_centers_id",
        "transactions_type",
        "process_type",
        "paper_id",
        "date_at",
        "TransactionDetail",
        "notes",
        "cheque_number",
        "cheque_date_at",
        "cheque_date_worth",
        "cheque_date_end",
        "is_relay",
        "user_relay_id",
        "relay_date_at",
        "employees_id",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "per_page": "25"
    },
    "nano_location_directorates_lists": {
      "visible": [
        "id",
        "name",
        "code",
        "is_enabled",
        "country_id",
        "country_name",
        "state_id",
        "state_name"
      ],
      "order": [
        "id",
        "name",
        "code",
        "is_enabled",
        "country_id",
        "country_name",
        "state_id",
        "state_name"
      ],
      "per_page": "20"
    },
    "nano_location_geolocation_location": {
      "latitude": "37.75100",
      "longitude": "-97.82200"
    },
    "fszteam_mposts_posts_lists": {
      "visible": [
        "title",
        "tags",
        "statistics",
        "length",
        "last_send_at",
        "stat",
        "status",
        "published_at"
      ],
      "order": [
        "id",
        "image",
        "title",
        "slug",
        "category",
        "tags",
        "author",
        "statistics",
        "length",
        "featured",
        "last_send_at",
        "stat",
        "status",
        "published_at",
        "created_at",
        "updated_at"
      ],
      "per_page": "15"
    },
    "indikator_news_categories_lists": {
      "visible": [
        "id",
        "image",
        "name",
        "slug",
        "sort_order",
        "posts",
        "subscribers",
        "hidden",
        "status",
        "created_at",
        "updated_at"
      ],
      "order": [
        "id",
        "image",
        "name",
        "slug",
        "sort_order",
        "posts",
        "subscribers",
        "hidden",
        "status",
        "created_at",
        "updated_at"
      ],
      "per_page": "15"
    },
    "nitm_api_history_lists": {
      "visible": [
        "created_at",
        "status_code",
        "request_method",
        "ip",
        "timepassed",
        "used_key",
        "api_status",
        "fullurl",
        "browser",
        "referer"
      ],
      "order": [
        "created_at",
        "status_code",
        "request_method",
        "ip",
        "timepassed",
        "used_key",
        "api_status",
        "fullurl",
        "browser",
        "referer"
      ],
      "per_page": "30"
    },
    "nano_campaign_subscribers_lists": {
      "visible": [
        "email",
        "first_name",
        "last_name",
        "subscriber_lists",
        "confirmed_at",
        "created_at",
        "unsubscribed_at"
      ],
      "order": [
        "email",
        "first_name",
        "last_name",
        "subscriber_lists",
        "confirmed_at",
        "created_at",
        "unsubscribed_at"
      ],
      "per_page": "20"
    },
    "nano_campaign_messages_lists": {
      "visible": [
        "status",
        "name",
        "subject",
        "launch_at",
        "created_at",
        "updated_at",
        "count_repeat"
      ],
      "order": [
        "status",
        "name",
        "subject",
        "launch_at",
        "created_at",
        "updated_at",
        "count_repeat"
      ],
      "per_page": "20"
    },
    "cms_theme_edit": "nano-themes",
    "tss_accountslooks_bondstrashs_lists": {
      "visible": [
        "button",
        "transactions_type",
        "trashs_notes",
        "trashs_at",
        "trashs_by",
        "notes",
        "date_at",
        "TransactionDetail"
      ],
      "order": [
        "button",
        "id",
        "code",
        "companys_id",
        "periods_id",
        "departments_id",
        "cost_centers_id",
        "transactions_type",
        "trashs_notes",
        "trashs_at",
        "trashs_by",
        "notes",
        "date_at",
        "TransactionDetail",
        "paper_id",
        "is_relay",
        "user_relay_id",
        "relay_date_at",
        "employees_id",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "per_page": "5"
    },
    "system_eventlogs_lists": {
      "visible": [
        "id",
        "created_at",
        "message"
      ],
      "order": [
        "id",
        "created_at",
        "message"
      ],
      "per_page": "30"
    },
    "rainlab_user_users_lists": {
      "visible": [
        "id",
        "name",
        "surname",
        "email",
        "created_at",
        "last_seen",
        "created_ip_address",
        "last_ip_address"
      ],
      "order": [
        "id",
        "username",
        "name",
        "surname",
        "email",
        "created_at",
        "last_seen",
        "is_guest",
        "created_ip_address",
        "last_ip_address"
      ],
      "per_page": "20"
    },
    "nano_microcart_carts_lists": {
      "visible": [
        "email",
        "payment_state",
        "created_at"
      ],
      "order": [
        "session_id",
        "email",
        "shipping_company",
        "shipping_firstname",
        "shipping_lastname",
        "shipping_lines",
        "shipping_zip",
        "shipping_city",
        "shipping_country",
        "billing_differs",
        "billing_company",
        "billing_firstname",
        "billing_lastname",
        "billing_lines",
        "billing_zip",
        "billing_city",
        "billing_country",
        "payment_id",
        "payment_method_id",
        "payment_state",
        "currency",
        "created_at",
        "updated_at"
      ],
      "per_page": "20"
    },
    "nano_smsnotify_templates_lists": {
      "visible": [
        "id",
        "code",
        "name",
        "companys_id",
        "departments_id",
        "is_custom",
        "is_default",
        "is_active"
      ],
      "order": [
        "id",
        "code",
        "name",
        "companys_id",
        "departments_id",
        "is_custom",
        "is_default",
        "is_active",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "per_page": "20"
    },
    "nano_shop_products_lists": {
      "visible": [
        "id",
        "name",
        "short_description",
        "price",
        "old_price",
        "shop_stock",
        "is_published",
        "min_qty",
        "max_qty",
        "default_qty",
        "is_effective",
        "is_active",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at",
        "main_sub",
        "parent_id",
        "parent"
      ],
      "order": [
        "id",
        "code",
        "barcode",
        "name",
        "type_p_s",
        "companys_id",
        "departments_id",
        "groups_products_id",
        "short_description",
        "description",
        "meta_title",
        "meta_description",
        "price",
        "old_price",
        "is_show_old_price",
        "is_parleying",
        "manage_stock",
        "shop_stock",
        "is_published",
        "published_at",
        "unpublished_at",
        "min_qty",
        "max_qty",
        "default_qty",
        "is_effective",
        "is_active",
        "status",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at",
        "main_sub",
        "parent_id",
        "parent"
      ],
      "per_page": "20"
    },
    "nano_coupons_coupons_liststructure": {
      "visible": [
        "code",
        "name",
        "formatted_discount"
      ],
      "order": [
        "id",
        "code",
        "name",
        "companys_id",
        "departments_id",
        "formatted_discount",
        "validity",
        "status"
      ],
      "per_page": 20
    },
    "nano_tags_tags_liststructure": {
      "visible": [
        "id",
        "name",
        "is_default",
        "is_public",
        "is_active"
      ],
      "order": [
        "id",
        "code",
        "name",
        "companys_id",
        "departments_id",
        "is_default",
        "is_public",
        "is_active",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "per_page": 20
    },
    "nano_tags_categories_liststructure": {
      "visible": [
        "name",
        "companys_id",
        "departments_id",
        "main_sub",
        "parent",
        "short_description",
        "is_active"
      ],
      "order": [
        "id",
        "code",
        "name",
        "companys_id",
        "departments_id",
        "main_sub",
        "parent_id",
        "parent",
        "level",
        "short_description",
        "description",
        "is_default",
        "is_public",
        "is_active",
        "is_published",
        "published_at",
        "unpublished_at",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "per_page": 20
    },
    "nano_comments_comments_liststructure": {
      "visible": [
        "content",
        "is_approved",
        "is_active",
        "commentable_id"
      ],
      "order": [
        "id",
        "code",
        "content",
        "companys_id",
        "departments_id",
        "is_approved",
        "is_active",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at",
        "commentable_id"
      ],
      "per_page": 20
    },
    "nano_orders_ordersstates_lists": {
      "visible": [
        "name",
        "color",
        "ref_type",
        "companys_id",
        "description",
        "is_cancel",
        "is_completed",
        "is_default",
        "is_active"
      ],
      "order": [
        "id",
        "code",
        "name",
        "color",
        "ref_type",
        "companys_id",
        "description",
        "is_cancel",
        "is_completed",
        "is_default",
        "is_hidden",
        "is_active",
        "status",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "per_page": "20"
    },
    "nano_orders_orders_lists": {
      "visible": [
        "button",
        "id",
        "paper_id",
        "order_type",
        "companys_id_name",
        "departments_id_name",
        "email",
        "user_id",
        "customer_id",
        "delivery_id",
        "shipping_phone",
        "shipping_address_1",
        "billing_phone",
        "billing_address_1",
        "order_states_ref_type",
        "payment_method_id",
        "payment_state",
        "currencys_id",
        "shipping_method_ref_type",
        "distance_unit",
        "shipping_distance",
        "shipping_price",
        "shipping_total",
        "subtotal",
        "order_total",
        "total_payment_post_taxes",
        "order_date",
        "order_time",
        "delivery_at",
        "shipped_at",
        "end_date",
        "customer_notes",
        "admin_notes",
        "sort_order",
        "created_by_name",
        "created_at",
        "updated_at",
        "shipping_address",
        "billing_country_name",
        "shipping_country_name",
        "shipping_state_name",
        "billing_address",
        "billing_state_name"
      ],
      "order": [
        "button",
        "id",
        "paper_id",
        "order_type",
        "companys_id_name",
        "departments_id_name",
        "email",
        "user_id",
        "customer_id",
        "delivery_id",
        "shipping_phone",
        "shipping_address_1",
        "billing_phone",
        "billing_address_1",
        "order_states_ref_type",
        "payment_method_id",
        "payment_state",
        "currencys_id",
        "shipping_method_ref_type",
        "distance_unit",
        "shipping_distance",
        "shipping_price",
        "shipping_total",
        "subtotal",
        "order_total",
        "total_payment_post_taxes",
        "order_date",
        "order_time",
        "delivery_at",
        "shipped_at",
        "end_date",
        "customer_notes",
        "admin_notes",
        "sort_order",
        "created_by_name",
        "created_at",
        "updated_at",
        "shipping_address",
        "billing_country_name",
        "shipping_country_name",
        "shipping_state_name",
        "billing_address",
        "billing_state_name"
      ],
      "per_page": "20"
    },
    "nano_orders_shippingmethods_lists": {
      "visible": [
        "name",
        "color",
        "ref_type",
        "country",
        "distance_unit",
        "price",
        "is_auto_price",
        "is_active",
        "state"
      ],
      "order": [
        "id",
        "code",
        "name",
        "color",
        "ref_type",
        "companys_id",
        "description",
        "country",
        "distance_unit",
        "max_distance",
        "min_distance",
        "price",
        "max_price",
        "min_price",
        "is_auto_price",
        "is_active",
        "status",
        "is_hidden",
        "is_default",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at",
        "state"
      ],
      "per_page": "20"
    },
    "nano_orders_loadtypes_liststructure": {
      "visible": [
        "name",
        "color",
        "ref_type",
        "is_active",
        "sort_order"
      ],
      "order": [
        "id",
        "code",
        "name",
        "color",
        "ref_type",
        "description",
        "is_allow_load_people",
        "is_required_load_people",
        "default_load_people",
        "min_load_people",
        "max_load_people",
        "is_allow_load_notes",
        "is_required_load_notes",
        "default_load_notes",
        "is_load_liter",
        "is_allow_weight",
        "is_required_weight",
        "min_weight",
        "max_weight",
        "is_allow_length",
        "is_required_length",
        "min_length",
        "max_length",
        "is_allow_width",
        "is_required_width",
        "min_width",
        "max_width",
        "is_allow_height",
        "is_required_height",
        "min_height",
        "max_height",
        "is_allow_load_storage_sensitive",
        "is_required_load_storage_sensitive",
        "default_load_storage_sensitive",
        "is_allow_load_fragile_materials",
        "is_required_load_fragile_materials",
        "default_load_fragile_materials",
        "is_default",
        "is_hidden",
        "is_active",
        "status",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at"
      ],
      "per_page": 20
    },
    "nano_reviews_reviews_liststructure": {
      "visible": [
        "reviewrateable_type",
        "reviewrateable_id",
        "reviewrateable_name",
        "rating",
        "title",
        "content",
        "user_name",
        "is_recommended",
        "approved",
        "is_active",
        "inform"
      ],
      "order": [
        "id",
        "code",
        "reviewrateable_type",
        "reviewrateable_id",
        "reviewrateable_name",
        "rating",
        "title",
        "content",
        "user_name",
        "companys_id",
        "departments_id",
        "is_recommended",
        "approved",
        "is_active",
        "sort_order",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at",
        "inform"
      ],
      "per_page": 20
    },
    "nano.backendnotifications_notifications_preferences": {
      "enable_notifications": "1",
      "show_count": "1",
      "enable_browser_push_notifications": "1",
      "user_id": 4
    },
    "nano_devices_devices_lists": {
      "visible": [
        "id",
        "user",
        "name",
        "platform",
        "platform_version",
        "version",
        "latitude",
        "longitude",
        "last_seen",
        "push_token",
        "created_at",
        "updated_at"
      ],
      "order": [
        "id",
        "user",
        "name",
        "platform",
        "platform_version",
        "version",
        "latitude",
        "longitude",
        "last_seen",
        "push_token",
        "created_at",
        "updated_at"
      ],
      "per_page": "20"
    },
    "vdlp_redirect_redirects_lists": {
      "visible": [
        "from_url",
        "target_type",
        "status_code",
        "match_type",
        "category",
        "hits",
        "last_used_at",
        "sparkline",
        "sort_order",
        "is_enabled",
        "system"
      ],
      "order": [
        "from_url",
        "target_type",
        "status_code",
        "match_type",
        "category",
        "description",
        "hits",
        "last_used_at",
        "sparkline",
        "sort_order",
        "is_enabled",
        "system",
        "updated_at",
        "created_at"
      ],
      "per_page": "20"
    },
    "nano.sitemanager_location_editLocation_id": 4,
    "nano.sitemanager_location_editLocation_id.backend_4": 4,
    "tss.basic_license_check_license.backend_4": "2023-06-13",
    "nano_menu_menus_liststructure": {
      "visible": [
        "label",
        "button",
        "is_active",
        "sort_order"
      ],
      "order": [
        "id",
        "code",
        "owner",
        "label",
        "button",
        "menu_code",
        "side_menu_code",
        "is_default",
        "is_active",
        "sort_order"
      ],
      "per_page": 20
    }
  }
}