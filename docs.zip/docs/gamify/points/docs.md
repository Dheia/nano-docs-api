## Points  Api

This endpoint allows you to `list`, `show` your points.

/gamify/points

**الجزء الخاص بالنقاط يمكنك من جلب النقاط التي حصل عليها المستخدم**


### The points object

#### Public Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `q`           | `string`  |  using search in points  records |
| `orderBy`           | `string`  |  using orderBy departments records - Name column default value created_at |
| `orderDirection`           | `string`  |  using orderBy departments records [asc,desc] - Name column default value desc |
| `per_page`           | `integer`  |  Number Records in Page default value 15 |
| `page`           | `integer`  |  Number  Page default value 1 |


#### Attributes

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `isActive`           | `boolean`  | **Required**. The get is Active  points default value true    |
| `companys_id`           | `integer`  |  get records points to companys_id default value false.         |
| `departments_id`           | `integer`  | get records points to departments_id default value true.          |
| `process_type`           | `string`  | get records points to process_type [in,out] default value *.          |
| `type`           | `string`  | get records points to type [add,remove,out] default value *.          |
| `level_id`           | `integer`  | get records points to level_id default value *.          |
| `event_type`           | `string`  | get records points to event_type default value *.          |
| `subject_id`           | `string`  | get records points to subject_id default value *.          |
| `subject_type`           | `string`  | get records points to subject_type default value *.          |
| `subject_id`           | `string`  | get records points to subject_id default value *.          |
| `points`           | `integer`  | get records points to points default value *.          |
| `total`           | `integer`  | get records points to total default value *.          |
| `include`           | `string `  | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/gamify/points?exclude=created_at,updated_at
```

#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `companys`           | `belongsTo`  | The get companys |
| `department`           | `belongsTo`  | The get department | 
| `user`           | `belongsTo`  | The get user   | 


### List points

Returns a list of Points’

```
GET /api/v1/gamify/points
```

#### Parameters

| Key                 | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `page`           | `integer`  | The page number.         |
| `per_page`           | `integer`  | The number of items per page.         |

#### Example 1.1 get List Points  

**فى المثال التالي سيتم جلب سجلات نقاط المستخدم الحالي **
```
GET http://localhost:8006/api/v1/gamify/points
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 24,
      "name": "مبروك لقد حصلت على  4 نقطة يمكنك استخدمها فى وقت لاحق",
      "description": "مبروك لقد حصلت على  4 نقطة يمكنك استخدمها فى وقت لاحق",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 0,
      "points": 4,
      "total": 400,
      "total_alien": 400,
      "type": "add",
      "process_type": "in",
      "date_at": "2023-11-27 15:50:09",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": "4",
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 24,
      "created_at": "2023-11-27 15:50:09",
      "updated_at": "2023-11-27 15:50:09",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 21,
      "name": "شراء من رصيد نقاطك",
      "description": "تم خصم عدد نقاط 50 بقيمة 500 مقابل عملية شراء",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 10,
      "price_alien": 0,
      "points": 50,
      "total": 500,
      "total_alien": 500,
      "type": "out",
      "process_type": "out",
      "date_at": "2023-11-27 15:03:58",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 21,
      "created_at": "2023-11-27 15:03:58",
      "updated_at": "2023-11-27 15:03:58",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 18,
      "name": "شراء من رصيد نقاطك",
      "description": "تم خصم عدد نقاط 31 بقيمة 3070 مقابل عملية شراء",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": 41,
      "subject_type": "orders",
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 99.0323,
      "price_alien": 0,
      "points": 31,
      "total": 3070,
      "total_alien": 3070,
      "type": "out",
      "process_type": "out",
      "date_at": "2023-11-26 18:15:07",
      "read_at": null,
      "url": "\/api\/v1\/shop\/checkout2",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": "41",
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 18,
      "created_at": "2023-11-26 18:15:07",
      "updated_at": "2023-11-26 18:15:07",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 14,
      "name": "شراء من رصيد نقاطك",
      "description": "تم خصم عدد نقاط 33 بقيمة 3300 مقابل عملية شراء",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": 40,
      "subject_type": "orders",
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 0,
      "points": 33,
      "total": 3300,
      "total_alien": 3300,
      "type": "out",
      "process_type": "out",
      "date_at": "2023-11-26 18:01:22",
      "read_at": null,
      "url": "\/api\/v1\/shop\/checkout2",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": "40",
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 14,
      "created_at": "2023-11-26 18:01:22",
      "updated_at": "2023-11-26 18:01:22",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 13,
      "name": "مبروك لقد حصلت على  40 نقطة يمكنك استخدمها فى وقت لاحق",
      "description": "مبروك لقد حصلت على  40 نقطة يمكنك استخدمها فى وقت لاحق",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 0,
      "points": 40,
      "total": 4000,
      "total_alien": 4000,
      "type": "add",
      "process_type": "in",
      "date_at": "2023-11-26 18:00:27",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 13,
      "created_at": "2023-11-26 18:00:27",
      "updated_at": "2023-11-26 18:00:27",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 3,
      "name": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_name",
      "description": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_description",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 0,
      "points": 2,
      "total": 200,
      "total_alien": 200,
      "type": "remove",
      "process_type": "out",
      "date_at": "2023-11-23 17:16:15",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 3,
      "created_at": "2023-11-23 17:16:15",
      "updated_at": "2023-11-23 17:16:15",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 2,
      "name": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_name",
      "description": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_description",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 0,
      "points": 5,
      "total": 500,
      "total_alien": 500,
      "type": "out",
      "process_type": "out",
      "date_at": "2023-11-23 17:16:15",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 2,
      "created_at": "2023-11-23 17:16:15",
      "updated_at": "2023-11-23 17:16:15",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 1,
      "name": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_name",
      "description": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_description",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 0,
      "points": 10,
      "total": 1000,
      "total_alien": 1000,
      "type": "add",
      "process_type": "in",
      "date_at": "2023-11-23 17:16:15",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 1,
      "created_at": "2023-11-23 17:16:15",
      "updated_at": "2023-11-23 17:16:15",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    }
  ],
  "meta": {
    "pagination": {
      "total": 8,
      "count": 8,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

#### Example 1.2 get List Points where process_type=in 

**فى المثال التالي سيتم جلب سجلات نقاط المستخدم الحالي والتي من النوع in اي المضافة للمستخدم  **
```
GET http://localhost:8006/api/v1/gamify/points?process_type=in
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 24,
      "name": "مبروك لقد حصلت على  4 نقطة يمكنك استخدمها فى وقت لاحق",
      "description": "مبروك لقد حصلت على  4 نقطة يمكنك استخدمها فى وقت لاحق",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 0,
      "points": 4,
      "total": 400,
      "total_alien": 400,
      "type": "add",
      "process_type": "in",
      "date_at": "2023-11-27 15:50:09",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": "4",
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 24,
      "created_at": "2023-11-27 15:50:09",
      "updated_at": "2023-11-27 15:50:09",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 13,
      "name": "مبروك لقد حصلت على  40 نقطة يمكنك استخدمها فى وقت لاحق",
      "description": "مبروك لقد حصلت على  40 نقطة يمكنك استخدمها فى وقت لاحق",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 0,
      "points": 40,
      "total": 4000,
      "total_alien": 4000,
      "type": "add",
      "process_type": "in",
      "date_at": "2023-11-26 18:00:27",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 13,
      "created_at": "2023-11-26 18:00:27",
      "updated_at": "2023-11-26 18:00:27",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 1,
      "name": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_name",
      "description": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_description",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 0,
      "points": 10,
      "total": 1000,
      "total_alien": 1000,
      "type": "add",
      "process_type": "in",
      "date_at": "2023-11-23 17:16:15",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 1,
      "created_at": "2023-11-23 17:16:15",
      "updated_at": "2023-11-23 17:16:15",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    }
  ],
  "meta": {
    "pagination": {
      "total": 3,
      "count": 3,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

#### Example 1.3 get List Points where process_type=out 

**فى المثال التالي سيتم جلب سجلات نقاط للمستخدم الحالي   **

** التي تم سحبها او حذفها  **

```
GET http://localhost:8006/api/v1/gamify/points?process_type=out
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 21,
      "name": "شراء من رصيد نقاطك",
      "description": "تم خصم عدد نقاط 50 بقيمة 500 مقابل عملية شراء",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 10,
      "price_alien": 0,
      "points": 50,
      "total": 500,
      "total_alien": 500,
      "type": "out",
      "process_type": "out",
      "date_at": "2023-11-27 15:03:58",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 21,
      "created_at": "2023-11-27 15:03:58",
      "updated_at": "2023-11-27 15:03:58",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 18,
      "name": "شراء من رصيد نقاطك",
      "description": "تم خصم عدد نقاط 31 بقيمة 3070 مقابل عملية شراء",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": 41,
      "subject_type": "orders",
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 99.0323,
      "price_alien": 0,
      "points": 31,
      "total": 3070,
      "total_alien": 3070,
      "type": "out",
      "process_type": "out",
      "date_at": "2023-11-26 18:15:07",
      "read_at": null,
      "url": "\/api\/v1\/shop\/checkout2",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": "41",
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 18,
      "created_at": "2023-11-26 18:15:07",
      "updated_at": "2023-11-26 18:15:07",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 14,
      "name": "شراء من رصيد نقاطك",
      "description": "تم خصم عدد نقاط 33 بقيمة 3300 مقابل عملية شراء",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": 40,
      "subject_type": "orders",
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 0,
      "points": 33,
      "total": 3300,
      "total_alien": 3300,
      "type": "out",
      "process_type": "out",
      "date_at": "2023-11-26 18:01:22",
      "read_at": null,
      "url": "\/api\/v1\/shop\/checkout2",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": "40",
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 14,
      "created_at": "2023-11-26 18:01:22",
      "updated_at": "2023-11-26 18:01:22",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 3,
      "name": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_name",
      "description": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_description",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 0,
      "points": 2,
      "total": 200,
      "total_alien": 200,
      "type": "remove",
      "process_type": "out",
      "date_at": "2023-11-23 17:16:15",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 3,
      "created_at": "2023-11-23 17:16:15",
      "updated_at": "2023-11-23 17:16:15",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 2,
      "name": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_name",
      "description": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_description",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 0,
      "points": 5,
      "total": 500,
      "total_alien": 500,
      "type": "out",
      "process_type": "out",
      "date_at": "2023-11-23 17:16:15",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 2,
      "created_at": "2023-11-23 17:16:15",
      "updated_at": "2023-11-23 17:16:15",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    }
  ],
  "meta": {
    "pagination": {
      "total": 5,
      "count": 5,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

#### Example 1.4 get List Points where process_type=out and type=out

**فى المثال التالي سيتم جلب سجلات نقاط للمستخدم الحالي   **

** التي تم سحبها والاستفادة منها  **

```
GET http://localhost:8006/api/v1/gamify/points?process_type=out&type=out
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 21,
      "name": "شراء من رصيد نقاطك",
      "description": "تم خصم عدد نقاط 50 بقيمة 500 مقابل عملية شراء",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 10,
      "price_alien": 0,
      "points": 50,
      "total": 500,
      "total_alien": 500,
      "type": "out",
      "process_type": "out",
      "date_at": "2023-11-27 15:03:58",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 21,
      "created_at": "2023-11-27 15:03:58",
      "updated_at": "2023-11-27 15:03:58",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 18,
      "name": "شراء من رصيد نقاطك",
      "description": "تم خصم عدد نقاط 31 بقيمة 3070 مقابل عملية شراء",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": 41,
      "subject_type": "orders",
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 99.0323,
      "price_alien": 0,
      "points": 31,
      "total": 3070,
      "total_alien": 3070,
      "type": "out",
      "process_type": "out",
      "date_at": "2023-11-26 18:15:07",
      "read_at": null,
      "url": "\/api\/v1\/shop\/checkout2",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": "41",
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 18,
      "created_at": "2023-11-26 18:15:07",
      "updated_at": "2023-11-26 18:15:07",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 14,
      "name": "شراء من رصيد نقاطك",
      "description": "تم خصم عدد نقاط 33 بقيمة 3300 مقابل عملية شراء",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": 40,
      "subject_type": "orders",
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 0,
      "points": 33,
      "total": 3300,
      "total_alien": 3300,
      "type": "out",
      "process_type": "out",
      "date_at": "2023-11-26 18:01:22",
      "read_at": null,
      "url": "\/api\/v1\/shop\/checkout2",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": "40",
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 14,
      "created_at": "2023-11-26 18:01:22",
      "updated_at": "2023-11-26 18:01:22",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 2,
      "name": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_name",
      "description": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_description",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 0,
      "points": 5,
      "total": 500,
      "total_alien": 500,
      "type": "out",
      "process_type": "out",
      "date_at": "2023-11-23 17:16:15",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 2,
      "created_at": "2023-11-23 17:16:15",
      "updated_at": "2023-11-23 17:16:15",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    }
  ],
  "meta": {
    "pagination": {
      "total": 4,
      "count": 4,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```

#### Example 1.4 get List Points where process_type=out and type=remove

**فى المثال التالي سيتم جلب سجلات نقاط للمستخدم الحالي   **

** التي تم حذفها على المستخدم   **

```
GET http://localhost:8006/api/v1/gamify/points?process_type=out&type=remove
```

##### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "id": 12,
      "name": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_name",
      "description": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_description",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 100,
      "points": 2,
      "total": 200,
      "total_alien": 200,
      "type": "remove",
      "process_type": "out",
      "date_at": "2023-11-23 17:21:01",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 12,
      "created_at": "2023-11-23 17:21:01",
      "updated_at": "2023-11-23 17:21:01",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 9,
      "name": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_name",
      "description": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_description",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 100,
      "points": 2,
      "total": 200,
      "total_alien": 200,
      "type": "remove",
      "process_type": "out",
      "date_at": "2023-11-23 17:19:41",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 9,
      "created_at": "2023-11-23 17:19:41",
      "updated_at": "2023-11-23 17:19:41",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 6,
      "name": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_name",
      "description": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_description",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 100,
      "points": 2,
      "total": 200,
      "total_alien": 200,
      "type": "remove",
      "process_type": "out",
      "date_at": "2023-11-23 17:18:37",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 6,
      "created_at": "2023-11-23 17:18:37",
      "updated_at": "2023-11-23 17:18:37",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    },
    {
      "id": 3,
      "name": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_name",
      "description": "nano2.gamify::lang.public.helpers.create_points.msg_default_points_description",
      "icon": null,
      "level_id": 1,
      "user_id": 549,
      "user_type": "RainLab\\User\\Models\\User",
      "event_type": null,
      "subject_id": null,
      "subject_type": null,
      "currencys_id": "1",
      "main_currencys_id": "1",
      "currency_conversions_id": null,
      "currency_conversions_data": null,
      "rate": "1.000000000000",
      "price": 100,
      "price_alien": 100,
      "points": 2,
      "total": 200,
      "total_alien": 200,
      "type": "remove",
      "process_type": "out",
      "date_at": "2023-11-23 17:16:15",
      "read_at": null,
      "url": "\/api\/v1\/me",
      "ip_address": "127.0.0.1",
      "ip_forwarded": null,
      "user_agent": "okhttp\/3.8.1",
      "extend_id": null,
      "companys_id": "2",
      "departments_id": "4",
      "is_relay": 0,
      "user_relay_id": null,
      "relay_date_at": null,
      "is_active": true,
      "status": "active",
      "other_data": null,
      "config_data": null,
      "sort_order": 3,
      "created_at": "2023-11-23 17:16:15",
      "updated_at": "2023-11-23 17:16:15",
      "object_type": "Nano2\\Gamify\\Models\\Point"
    }
  ],
  "meta": {
    "pagination": {
      "total": 4,
      "count": 4,
      "per_page": 15,
      "current_page": 1,
      "total_pages": 1,
      "links": {}
    }
  }
}
```


### Show Data Record Point 

```
GET /api/v1/gamify/points/{id}
```

Required Parameters: `id`

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `id`           | `integer`  | **Required**. The id          |


#### Example 2 Show Data Record Point 18

```
GET http://localhost:8006/api/v1/gamify/points/18
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "id": 18,
  "name": "شراء من رصيد نقاطك",
  "description": "تم خصم عدد نقاط 31 بقيمة 3070 مقابل عملية شراء",
  "icon": null,
  "level_id": 1,
  "user_id": 549,
  "user_type": "RainLab\\User\\Models\\User",
  "event_type": null,
  "subject_id": 41,
  "subject_type": "orders",
  "currencys_id": "1",
  "main_currencys_id": "1",
  "currency_conversions_id": null,
  "currency_conversions_data": null,
  "rate": "1.000000000000",
  "price": 99.0323,
  "price_alien": 0,
  "points": 31,
  "total": 3070,
  "total_alien": 3070,
  "type": "out",
  "process_type": "out",
  "date_at": "2023-11-26 18:15:07",
  "read_at": null,
  "url": "\/api\/v1\/shop\/checkout2",
  "ip_address": "127.0.0.1",
  "ip_forwarded": null,
  "user_agent": "okhttp\/3.8.1",
  "extend_id": "41",
  "companys_id": "2",
  "departments_id": "4",
  "is_relay": 0,
  "user_relay_id": null,
  "relay_date_at": null,
  "is_active": true,
  "status": "active",
  "other_data": null,
  "config_data": null,
  "sort_order": 18,
  "created_at": "2023-11-26 18:15:07",
  "updated_at": "2023-11-26 18:15:07",
  "object_type": "Nano2\\Gamify\\Models\\Point"
}
```

### Get User Statistical Point 

** جلب احصائيات النقاط  للمستخدم الحالي **

```
GET /api/v1/gamify/points/statistical
```

#### Example 5 Get User Statistical Points

```
GET http://localhost:8006/api/v1/gamify/points/statistical
```


##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب الإحصائية بنجاح ",
  "error": "",
  "data": {
    "sum_points": 32,
    "sum_points_add": 40,
    "sum_points_remove": 8,
    "sum_points_out": 20,
    "sum_points_available": 12,
    "sum_total": 3200,
    "point_price": 100,
    "sum_total_add": 4000,
    "sum_total_remove": 800,
    "sum_total_out": 2000,
    "sum_total_available": 1200
  }
}
```

**شرح القيم الراجعة **

```json
{
    "sum_points": "عدد النقاط التي حصل عليه المستخدم بعد خصم النقاط المحذوفة",
    "sum_points_add": "كافة النقاط مع النقاط المحذوفه ",
    "sum_points_remove": "النقاط المحذوفة للمستخدم ",
    "sum_points_out": "النقاط المسحوبة او التي تم الاستفادة منها ",
    "sum_points_available": "عدد النقاط المتاحة للمستخدم بعد حذف النقاط المسحوبة والمحذوفة ",
    
    "point_price": "متوسط سعر النقطة",
    
    "sum_total": "اجمالي قيمة النقاط التي حصل عليها المستخدم بعد خصم النقاط المحذوفة",
    "sum_total_add": "اجمالي قيمة كافة النقاط مع النقاط المحذوفة والمسحوبه ",
    "sum_total_remove": "اجمالي قيمة النقاط المحذوفة",
    "sum_total_out": "اجمالي قيمة النقاط المسحوبة او المستخدمة ",
    "sum_total_available": "اجمالي قيمة النقاط المتاحة للمستخدم بعد حذف النقاط المسحوبة والمحذوفة "
  }
```

### Get Options Point 

** جلب خيارات الحقول  اثناء انشاء حساب  موصل للمستخدم الحالي **

```
GET /api/v1/gamify/points/options
```

#### Example 6 Get Options Fields Point 

```
GET http://localhost:8006/api/v1/gamify/points/options
```


##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب الخيارات بنجاح ",
  "error": "",
  "data": {
    "process_type": [
      {
        "id": "in",
        "name": "in"
      },
      {
        "id": "out",
        "name": "out"
      }
    ],
    "type": [
      {
        "id": "add",
        "name": "add"
      },
      {
        "id": "out",
        "name": "out"
      },
      {
        "id": "remove",
        "name": "remove"
      },
      {
        "id": "reset",
        "name": "reset"
      },
      {
        "id": "level_up",
        "name": "level_up"
      }
    ]
  }
}
```

**لجلب خيارات حقل معين نقوم بتمري، اسم الحقل ضمن متغير fields **

```
GET http://localhost:8006/api/v1/gamify/points/options?fields=process_type
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب الخيارات بنجاح ",
  "error": "",
  "data": {
    "process_type": [
      {
        "id": "in",
        "name": "in"
      },
      {
        "id": "out",
        "name": "out"
      }
    ]
  }
}
```

#### جلب الخيارات على شكل مصفوفه

** نقوم بتمرير المتغير is_collection بالقيمه 0 ضمن الطلب كالتالي **

```
GET http://localhost:8006/api/v1/gamify/points/options?is_collection=0
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب الخيارات بنجاح ",
  "error": "",
  "data": {
    "process_type": {
      "in": "in",
      "out": "out"
    },
    "type": {
      "add": "add",
      "out": "out",
      "remove": "remove",
      "reset": "reset",
      "level_up": "level_up"
    }
  }
}
```

** لجلب خيارات حقل معين نقوم بتمرير اسم الحقل كالتالي **
```
GET http://localhost:8006/api/v1/gamify/points/options?is_collection=0&fields=type
```

##### Response

```html
Status: 200 Ok
```

```json
{
  "code": 200,
  "status": true,
  "message": "تم جلب الخيارات بنجاح ",
  "error": "",
  "data": {
    "type": {
      "add": "add",
      "out": "out",
      "remove": "remove",
      "reset": "reset",
      "level_up": "level_up"
    }
  }
}
```

### Check Last Update Point Data 

** لفحص اخر عملية تحديث للبيانات نستخدم الرابط التالي مع تمرير التاريخ المراد فحصه  **

```
GET /api/v1/gamify/points/activelystats
```

Required Parameters: `date = 2022-12-15 17:10:00`

**البراميترات التي يتم تمريرها هى كا التالى **

```json
{
  "date": '2022-12-15 17:10:00',
}
```
** ملاحظه يجب ان تكون صيغه التاريخ الممر كما هو موضح فى القيمة السابقة وفى حالة تمرير التاريخ بصيغه مختلفه لن يتم الفحص بشكل صحيح **

**فى حالة عدم تمرير متغير التاريخ date سيتم اعتماد التاريخ الحالي **

```
GET http://localhost:8006/api/v1/gamify/points/activelystats?date=2022-12-15%2017:10:00
```
**فى المثال التالى سنقوم بتمرير تاريخ معين لمعرفه هل تم التعديل على البيانات بعد هذه التاريخ  **

#### Response

```html
Status: 200 Ok
```

```json
{
  "code": "200",
  "data": {
    "activity_stats": true,
    "check_date": "2022-12-15 17:10:00",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": null
  }
}
```

**فى حالة عدم تمرير متغير التاريخ ستكون النتيجه كا التالي **

```json
{
  "code": "200",
  "data": {
    "activity_stats": false,
    "check_date": "2022-12-20 18:17:04",
    "last_updated": "2022-12-20 18:15:32",
    "other_updated": null
  }
}
```

**فى البيانات الراجعه قيمة المتغير last_updated تمثل تاريخ اخر تحديث للبيانات فى السيرفر **

**بينما يمثل المتغير activity_stats حالة الفحص بالاعتماد على التاريخ الممرر او التاريخ الحالي فى حاة عدم تمرير تاريخ **

