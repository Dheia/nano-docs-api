##get Current User Devices Data 

This endpoint allows show user Devices data . 

 GET /devices/
### The User Device object

#### Parameters

| Key                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `include`           | `string `  | get relation using [relation1,relation2,relation3]
| 
| `exclude`           | `string` | exclude fields  using [field_name1,field_name1,field_name1]
| 

#### Exclude Fields 

**لاستثناء حقول معينه من البيانات الراجعه نستخدم البراميتر exclude وتمرير الحقول المراد عدم عرضها **

##### Example Exclude Fields 

**فى المثال التالي سنقوم باستثناء عرض حقل تاريخ الاضافه وتاريخ التعديل **


```
GET http://localhost:8006/api/v1/devices?exclude=created_at,updated_at
```


#### Device Attributes

```json
{
      "uuid": "2iygffhgcg",
      "push_token": "c4WQzukwStO9o-f2kLZACc:APA91bEEiCJhUDaFXLr4-1tXV_3qn1CffK8ijv7jo3aMK3GKvBnhpjiitXvsfzr8CqzVd270RIiKkf8MvGUMMc4YGomjb1WTTH0Vw4odNuzDJ7JNpQA3sL90eeIG1zG94HR31MKyf7Si",
      "name": "iphone 6",
      "platform": "iphone",
      "platform_version": "6.0",
      "version": "6",
      "latitude": "14",
      "longitude": "13"
}
```


#### Include Relation 

| Relation Name                  | Type      | Description                                                  |
| -------------------- | --------- | ------------------------------------------------------------ |
| `user`           | `belongsTo`  | The get user |



### Require Useing token to show User Data

** add Parameters Authorization in headr request **

Authorization = [token_type token]

** Require Authorization in Header Request**

```html
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiOTJiYjhkNWJjZjE4MWYxMjcyMjhlZjc5ODFmYzE5ZWFmOGY1ZjVjMWUxZjg5ZWEzMDVhMDNiMzMxZjM2OWUxYjMzZDA3NWFkM2FlMGE3YTMiLCJpYXQiOjE2NjU4NTUyODcuOTM4NDI1MSwibmJmIjoxNjY1ODU1Mjg3LjkzODQ3NDksImV4cCI6MTY5NzM5MTI4Ny45MDM3Mzk5LCJzdWIiOiI1NDkiLCJzY29wZXMiOltdfQ.uKRNZo1MNtDmdjR3pk00JjPoyE6IcJMvqdqMEOhR7syyw_a584gH4rMW9Jp4Rqq7Rc6ttM9UvKoDUk6Y38oA6elU96PcSk8nRsWZ_grSR7EwSX4DgW8qhEfVGUUm8GRceen12OBYnB3-sHOluVGWotFJdYYjWtWc9pw9otX3a8ZcC1kM3FZDqusYkPRuQiG4PiCsaRL1dRiMyp5cEc1JPma0aZL9iOBqwwB9sJYd9_wYz8S-ZEWBAGXwqbOkhZ9_GYwnfckQlgKiO1pDuX_Au_F138E659BFKNXibvU8rUTi9q15smFJ8icUBHrUhzIcQFjfdgqPQfGXkanJr5BcpByZbQMEqPhe18IBGduNaE53wClR4UL3ighFSmZWUa1ebdq6oKama5-DWDUVF18pi_owiTlkfHyXF-2aEvT-myxC7_9jvfbC3KVrOGCRuHiwWBALcdYP45ogSo7-RVCAupQi9TGrkzU85tEKCuo-JYQ3ATHjCmuW0bHsazM9je2vIe6j_-56v7YBaMR7vxoJ1kk-1rLoiEOg_IbRJ9XuQDCMk7gCOZLS9TmYvLm2oBe4VjTw7GVB8GxwB3mC8OwrcVyubTvNHTgvZH8BOrJDF349uQea4PGvXgySNktMo490zUQqn56uCCcBry3glHpdw-MYbBD5mGt5ma3AP4riLXE
```


#### Response Error 
** يتم ارجاع خطاء فى حاله عدم وجود مستخدم مسجل كا التالي  **

```html
Status: 401 Error UNAUTHORIZED
```

```json
{
  "error": {
    "code": "UNAUTHORIZED",
    "http_code": 401,
    "message": "Invalid user credential."
  }
}
```

### Show Data Current User Device

Returns a Data Devices 

```
GET /api/v1/devices
```
**لجب الاجهزة التى  قام المستخدم بالتسجيل عليها نستخدم الرابط التالي **
```
GET http://localhost:8006/api/v1/devices
```


#### Response

```html
Status: 200 OK
```

```json
{
  "data": [
    {
      "name": "iphone 6",
      "uuid": "2iygffhgcg",
      "push_token": "c4WQzukwStO9o-f2kLZACc:APA91bEEiCJhUDaFXLr4-1tXV_3qn1CffK8ijv7jo3aMK3GKvBnhpjiitXvsfzr8CqzVd270RIiKkf8MvGUMMc4YGomjb1WTTH0Vw4odNuzDJ7JNpQA3sL90eeIG1zG94HR31MKyf7Si",
      "platform": "iphone",
      "platform_version": "6.0",
      "version": "6",
      "last_seen": "2022-12-15 21:20:01",
      "latitude": "14",
      "longitude": "13"
    }
  ]
}
```

**فى حال كان المستخدم مسجل على اكثر من جهاز جوال ستكون البيانات الراجعه كالتالى**
```json
{
  "data": [
    {
      "name": "iphone 6",
      "uuid": "2iygffhgcg",
      "push_token": "c4WQzukwStO9o-f2kLZACc:APA91bEEiCJhUDaFXLr4-1tXV_3qn1CffK8ijv7jo3aMK3GKvBnhpjiitXvsfzr8CqzVd270RIiKkf8MvGUMMc4YGomjb1WTTH0Vw4odNuzDJ7JNpQA3sL90eeIG1zG94HR31MKyf7Si",
      "platform": "iphone",
      "platform_version": "6.0",
      "version": "6",
      "last_seen": "2022-12-15 21:20:01",
      "latitude": "14",
      "longitude": "13"
    },
    {
      "name": "Glcassy 7",
      "uuid": "aa3456876",
      "push_token": "c4WQzukwStO9o-f2kLZACc:APA91bEEiCJhUDaFXLr4-1tXV_3qn1CffK8ijv7jo3aMK3GKvBnhpjiitXvsfzr8CqzVd270RIiKkf8MvGUMMc4YGomjb1WTTH0Vw4odNuzDJ7JNpQA3sL90eeIG1zG94HR31MKyf7Sa",
      "platform": "android",
      "platform_version": "7.0",
      "version": "7",
      "last_seen": "2022-12-15 21:22:36",
      "latitude": "12",
      "longitude": "11"
    }
  ]
}
```

#### Add Or Update Current User Device Data
** يتم استخدام الرابط التالى لتعديل بيانات الاجهزه الخاصه بالمستخدم الحالي معا تمرير الحقول المطلوبه   **
```
POST /api/v1/devices
```

```
POST http://localhost:8006/api/v1/devices
```

### Example add Data Device 

** ف ى المثال التالى سنقوم باضافه الجهاز المسجل عليه المستخدم الحالي   **

**البيانات المطلوب تمريرها كا التالي **
```json
{
    "uuid": "gyyg768876yhh77",
    "platform": "android",
    "push_token": "c4WQzukwStO9o-f2kLZACc:APA91bEEiCJhUDaFXLr4-1tXV_3qn1CffK8ijv7jo3aMK3GKvBnhpjiitXvsfzr8CqzVd270RIiKkf8MvGUMMc4YGomjb1WTTH0Vw4odNuzDJ7JNpQA3sL90eeIG1zG94HR31MKyf7Si",
    "version": "6",
    "name": "glcassy",
    "platform_version": "glcassy",
    "latitude": "7656766",
    "longitude": "5777877",
}
```

```
POST http://localhost:8006/api/v1/devices?uuid=2iygffhgcg&platform=iphone&push_token=c4WQzukwStO9o-f2kLZACc:APA91bEEiCJhUDaFXLr4-1tXV_3qn1CffK8ijv7jo3aMK3GKvBnhpjiitXvsfzr8CqzVd270RIiKkf8MvGUMMc4YGomjb1WTTH0Vw4odNuzDJ7JNpQA3sL90eeIG1zG94HR31MKyf7Si&version=6&name=iphone%206&platform_version=6.0&latitude=14&longitude=13
```
#### Response

**فى حالة حدوث خطاء سيتم ارجاع الخطاء كالتالى **


```json
{
  "error": {
    "code": "WRONG_ARGS",
    "http_code": 400,
    "message": "الخاصية  uuid حقل مطلوب"
  }
}
```

**فى حال نجحة العمليه سيتم ارجاع البيانات التاليه  :- **

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "status": true,
  "message": "Device Successfully Saved"
}
```

### Delete Device User 

**لحذف بيانات جهاز لمستخدم معين نستخدم  الرابط التالى **

```
DELETE /api/v1/devices/{uuid}
```

**فى المثال التالي سنقوم بتمرير uuidالمستخدم فى المثال السابق لحذفه من قائمة اجهزة المستخدم الحالي **
```
DELETE http://localhost:8006/api/v1/devices/2iygffhgcg
```
#### Response

```html
Status: 200 OK
```

```json
{
  "code": "200",
  "status": true,
  "message": "Device Successfully Delete"
}
```
